//
//  ChatViewController.h
//  simpleChat
//
//  Created by I-VERVE7 on 26/02/13.
//  Copyright (c) 2013 I-VERVE7. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

static CGFloat padding = 20.0;

@interface ChatViewController : UIViewController <UITableViewDataSource, UITableViewDelegate, chatDelegate, UITextFieldDelegate>
{
    IBOutlet UITableView *tblView;
    IBOutlet UITextField *tfMsg;
    IBOutlet UIView *viewContainer;
}

- (AppDelegate *)appDelegate;
-(IBAction)sendMsg:(id)sender;

@end
