//
//  ChatViewController.m
//  simpleChat
//
//  Created by I-VERVE7 on 26/02/13.
//  Copyright (c) 2013 I-VERVE7. All rights reserved.
//

#import "ChatViewController.h"
#import "MessageViewTableCell.h"

@interface ChatViewController ()

@end

@implementation ChatViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [self setTitle:ShareObj.toUserJid];
    AppDelegate *appDel = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [appDel setChatDelegate:self];
    
    [tblView setBackgroundColor:[UIColor clearColor]];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWasShown:)
                                                 name:UIKeyboardDidShowNotification
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillHide:)
                                                 name:UIKeyboardWillHideNotification
                                               object:nil];
    
    // Create plist if doesn't exist else load it.
    
}

-(void)viewWillAppear:(BOOL)animated
{
    NSString *filePath = [NSString stringWithFormat:@"%@/%@.plist", [SharedManager docDirPath],ShareObj.toUserJid];
    if([[NSFileManager defaultManager] fileExistsAtPath:filePath])
    {
        NSDictionary *dict = [NSDictionary dictionaryWithContentsOfFile:filePath];
        ShareObj.arrChat = [dict objectForKey:ShareObj.toUserJid];
        [tblView reloadData];
        NSIndexPath *topIndexPath = [NSIndexPath indexPathForRow:ShareObj.arrChat.count-1
                                                       inSection:0];
        
        [tblView scrollToRowAtIndexPath:topIndexPath
                       atScrollPosition:UITableViewScrollPositionMiddle
                               animated:YES];        
    }
}

-(void)viewDidDisappear:(BOOL)animated
{
    @try {
        [self writeToPlist];
        [[NSNotificationCenter defaultCenter] removeObserver:self];
    }
    @catch (NSException *exception) {
        NSLog(@"%@",[exception debugDescription]);
    }
    @finally {
    }
}

-(void)viewDidAppear:(BOOL)animated
{
    [viewContainer setFrame:CGRectMake(viewContainer.frame.origin.x, self.view.frame.size.height - viewContainer.frame.size.height, viewContainer.frame.size.width, viewContainer.frame.size.height)];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (AppDelegate *)appDelegate
{
	return (AppDelegate *)[[UIApplication sharedApplication] delegate];
}

#pragma mark - Send/Receive Msg
-(IBAction)sendMsg:(id)sender
{
    NSString *messageStr = tfMsg.text;
	
    if([messageStr length] > 0) {
		
        NSXMLElement *body = [NSXMLElement elementWithName:@"body"];
        [body setStringValue:messageStr];
		
        NSXMLElement *message = [NSXMLElement elementWithName:@"message"];
        [message addAttributeWithName:@"type" stringValue:@"chat"];
        [message addAttributeWithName:@"to" stringValue:ShareObj.toUserJid];
        [message addChild:body];
		
        [[self appDelegate].xmppStream sendElement:message];
		
		tfMsg.text = @"";
		[tfMsg resignFirstResponder];
        
        NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
        [dateFormat setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        
        NSString *currentTime = [dateFormat stringFromDate:[NSDate date]];
        
		NSMutableDictionary *m = [[NSMutableDictionary alloc] init];
		[m setObject:messageStr forKey:@"msg"];
		[m setObject:@"you" forKey:@"sender"];
		[m setObject:currentTime forKey:@"time"];
		
		[ShareObj.arrChat addObject:m];
		[tblView reloadData];

        NSIndexPath *topIndexPath = [NSIndexPath indexPathForRow:ShareObj.arrChat.count-1
                                                       inSection:0];
        
        [tblView scrollToRowAtIndexPath:topIndexPath
                       atScrollPosition:UITableViewScrollPositionMiddle
                               animated:YES];            
    }

}

-(void)receivedMessageWithStream:(XMPPStream *)sender andMessage:(XMPPMessage *)message
{
    XMPPUserCoreDataStorageObject *user = [[self appDelegate].xmppRosterStorage userForJID:[message from]
                                                             xmppStream:[self appDelegate].xmppStream
                                                   managedObjectContext:[[self appDelegate] managedObjectContext_roster]];
    
    NSString *body = [[message elementForName:@"body"] stringValue];
    NSString *displayName = [user displayName];
    
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    
    NSString *currentTime = [dateFormat stringFromDate:[NSDate date]];
    
    NSMutableDictionary *m = [[NSMutableDictionary alloc] init];
    [m setObject:body forKey:@"msg"];
    [m setObject:displayName forKey:@"sender"];
    [m setObject:currentTime forKey:@"time"];
    
    [ShareObj.arrChat addObject:m];
    [tblView reloadData];
   
	NSIndexPath *topIndexPath = [NSIndexPath indexPathForRow:ShareObj.arrChat.count-1
												   inSection:0];
    
	[tblView scrollToRowAtIndexPath:topIndexPath
					  atScrollPosition:UITableViewScrollPositionMiddle
							  animated:YES];    
}

#pragma mark - Tableview Datasource method
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[SharedManager sharedInstance].arrChat count];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary *dict = (NSDictionary *)[ShareObj.arrChat objectAtIndex:indexPath.row];
	NSString *msg = [dict objectForKey:@"msg"];
	
	CGSize  textSize = { 260.0, 10000.0 };
	CGSize size = [msg sizeWithFont:[UIFont boldSystemFontOfSize:13]
				  constrainedToSize:textSize
					  lineBreakMode:UILineBreakModeWordWrap];
	
	size.height += padding*2;
	
	CGFloat height = size.height < 65 ? 65 : size.height;
	return height;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
	
	MessageViewTableCell *cell = (MessageViewTableCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	   
	if (cell == nil) {
        cell = [[MessageViewTableCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
	}
    
//        [cell.textLabel setLineBreakMode:UILineBreakModeWordWrap];
//        [cell.textLabel setNumberOfLines:0];
//        [cell.textLabel sizeToFit];
	@try {
        NSDictionary *dict = [ShareObj.arrChat objectAtIndex:indexPath.row];
        
//        cell.textLabel.text = [dict valueForKey:@"msg"];
//        cell.detailTextLabel.text = [NSString stringWithFormat:@"[%@] %@ says",[dict valueForKey:@"time"],[dict valueForKey:@"sender"]];
        
        NSString *sender = [dict objectForKey:@"sender"];
        NSString *message = [dict objectForKey:@"msg"];
        NSString *time = [dict objectForKey:@"time"];
        
        CGSize  textSize = { 260.0, 10000.0 };
        CGSize size = [message sizeWithFont:[UIFont boldSystemFontOfSize:13]
                          constrainedToSize:textSize
                              lineBreakMode:UILineBreakModeWordWrap];
        
        
        size.width += (padding/2);
        
//        NSLog(@"%@",NSStringFromCGSize(size));
        if(size.width < 30)
            size.width = 30;
        cell.messageContentView.text = message;
        cell.accessoryType = UITableViewCellAccessoryNone;
        cell.userInteractionEnabled = NO;
        
        
        UIImage *bgImage = nil;
        
		
        if ([sender isEqualToString:@"you"]) { // left aligned
            
            bgImage = [[UIImage imageNamed:@"orange.png"] stretchableImageWithLeftCapWidth:24  topCapHeight:15];
            
            [cell.messageContentView setFrame:CGRectMake(padding, padding*2, size.width, size.height)];
            
            [cell.bgImageView setFrame:CGRectMake( cell.messageContentView.frame.origin.x - padding/2,
                                                  cell.messageContentView.frame.origin.y - padding/2,
                                                  size.width+padding,
                                                  size.height+padding)];
            
        } else {
            
            bgImage = [[UIImage imageNamed:@"aqua.png"] stretchableImageWithLeftCapWidth:24  topCapHeight:15];
            
            [cell.messageContentView setFrame:CGRectMake(320 - size.width - padding,
                                                         padding*2,
                                                         size.width, 
                                                         size.height)];
            
            [cell.bgImageView setFrame:CGRectMake(cell.messageContentView.frame.origin.x - padding/2, 
                                                  cell.messageContentView.frame.origin.y - padding/2, 
                                                  size.width+padding, 
                                                  size.height+padding)];
            
        }
        
        cell.bgImageView.image = bgImage;
        cell.senderAndTimeLabel.text = [NSString stringWithFormat:@"%@ %@", sender, time];
        
    }
    @catch (NSException *exception) {
        NSLog(@"%@",[exception debugDescription]);
    }
    @finally {
    }
	
	return cell;
}

- (void)keyboardWasShown:(NSNotification *)notification
{
    // Step 1: Get the size of the keyboard.
    CGSize keyboardSize = [[[notification userInfo] objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    viewContainer.frame = CGRectMake(viewContainer.frame.origin.x, self.view.frame.size.height - (keyboardSize.height +30),
                                     viewContainer.frame.size.width, viewContainer.frame.size.height);
}

- (void) keyboardWillHide:(NSNotification *)notification {
    viewContainer.frame = CGRectMake(viewContainer.frame.origin.x, self.view.frame.size.height - 30,
                                     viewContainer.frame.size.width, viewContainer.frame.size.height);
}

#pragma mark - Write to Plist
- (void)writeToPlist{
    NSString *filePath = [NSString stringWithFormat:@"%@/%@.plist", [SharedManager docDirPath],ShareObj.toUserJid];
    NSDictionary *dict = [NSDictionary dictionaryWithObject:ShareObj.arrChat forKey:ShareObj.toUserJid];
    [dict writeToFile:filePath atomically: YES];
}

@end
