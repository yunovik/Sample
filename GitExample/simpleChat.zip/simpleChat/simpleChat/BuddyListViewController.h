//
//  BuddyListViewController.h
//  simpleChat
//
//  Created by I-VERVE7 on 26/02/13.
//  Copyright (c) 2013 I-VERVE7. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import <CoreData/CoreData.h>
#import "SVProgressHUD.h"

@interface BuddyListViewController : UITableViewController <NSFetchedResultsControllerDelegate, buddyStatusDelegate, chatDelegate>
{
	NSFetchedResultsController *fetchedResultsController;
}

- (AppDelegate *)appDelegate;
#pragma mark - signout
-(void)signout;
-(void)newMessage:(NSNotification *)notification;

@end
