//
//  MessageViewTableCell.h
//  simpleChat
//
//  Created by cesarerocchi on 9/8/11.
//  Copyright 2011 studiomagnolia.com. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface MessageViewTableCell : UITableViewCell {

	UILabel	*senderAndTimeLabel;
	UITextView *messageContentView;
	UIImageView *bgImageView;
	
}

@property (nonatomic, retain) UILabel *senderAndTimeLabel;
@property (nonatomic, retain) UITextView *messageContentView;
@property (nonatomic, retain) UIImageView *bgImageView;

@end
