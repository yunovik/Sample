//
//  BuddyListViewController.m
//  simpleChat
//
//  Created by I-VERVE7 on 26/02/13.
//  Copyright (c) 2013 I-VERVE7. All rights reserved.
//

#import "BuddyListViewController.h"
#import "LoginViewController.h"
#import "ChatViewController.h"

@interface BuddyListViewController ()

@end

@implementation BuddyListViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
 
    AppDelegate *appDel = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [appDel setBuddyStatusDelegate:self];
    [appDel setChatDelegate:self];
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    UIBarButtonItem *itemLogout = [[UIBarButtonItem alloc]initWithTitle:@"SignOut" style:UIBarStyleBlack target:self action:@selector(signout)];
    [self.navigationItem setLeftBarButtonItem:itemLogout];
    [self setTitle:@"Buddies"];
    [self.navigationController.navigationBar setBarStyle:UIBarStyleBlack];
    
//    [[self tableView] setRowHeight:60.0f];
    
    if(![[[self appDelegate] xmppStream] isConnected])
    {
        LoginViewController *objLVC = [[LoginViewController alloc] initWithNibName:@"LoginViewController" bundle:nil];
        if([self respondsToSelector:@selector(presentViewController:animated:completion:)])
            [self presentViewController:objLVC animated:YES completion:^{}];
        else
            [self presentModalViewController:objLVC animated:YES];
    }
}
-(void)viewDidAppear:(BOOL)animated
{
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(newMessage:)
                                                 name:NotifName
                                               object:nil];
    
    [[self tableView] reloadData];
}

-(void)viewDidDisappear:(BOOL)animated
{
    @try {
        [[NSNotificationCenter defaultCenter] removeObserver:self];
    }
    @catch (NSException *exception) {
        NSLog(@"%@",[exception debugDescription]);
    }
    @finally {
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (AppDelegate *)appDelegate
{
	return (AppDelegate *)[[UIApplication sharedApplication] delegate];
}

#pragma mark - NSFetchedResultsController
- (NSFetchedResultsController *)fetchedResultsController
{
	if (fetchedResultsController == nil)
	{
		NSManagedObjectContext *moc = [[self appDelegate] managedObjectContext_roster];
        
		NSEntityDescription *entity = [NSEntityDescription entityForName:@"XMPPUserCoreDataStorageObject"
		                                          inManagedObjectContext:moc];
//        for(NSAttributeDescription *attr in [entity attributesByName])
//            NSLog(@"%@",attr);
    
		NSSortDescriptor *sd1 = [[NSSortDescriptor alloc] initWithKey:@"sectionNum" ascending:YES];
		NSSortDescriptor *sd2 = [[NSSortDescriptor alloc] initWithKey:@"displayName" ascending:YES];
		
		NSArray *sortDescriptors = [NSArray arrayWithObjects:sd1, sd2, nil];
		
		NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
		[fetchRequest setEntity:entity];
		[fetchRequest setSortDescriptors:sortDescriptors];
		[fetchRequest setFetchBatchSize:10];
		
		fetchedResultsController = [[NSFetchedResultsController alloc] initWithFetchRequest:fetchRequest
		                                                               managedObjectContext:moc
		                                                                 sectionNameKeyPath:@"sectionNum"
		                                                                          cacheName:nil];
		[fetchedResultsController setDelegate:self];
		
		
		NSError *error = nil;
		if (![fetchedResultsController performFetch:&error])
		{
//			DDLogError(@"Error performing fetch: %@", error);
		}
        
	}
	
	return fetchedResultsController;
}

- (void)controllerDidChangeContent:(NSFetchedResultsController *)controller
{
	[[self tableView] reloadData];
}

#pragma mark - UITableViewCell helper
- (void)configurePhotoForCell:(UITableViewCell *)cell user:(XMPPUserCoreDataStorageObject *)user
{
	// Our xmppRosterStorage will cache photos as they arrive from the xmppvCardAvatarModule.
	// We only need to ask the avatar module for a photo, if the roster doesn't have it.
	@try{
        if (user.photo != nil)
        {
            cell.imageView.image = user.photo;
        }
        else
        {
            NSData *photoData = [[[self appDelegate] xmppvCardAvatarModule] photoDataForJID:user.jid];
            
            if (photoData != nil)
                cell.imageView.image = [UIImage imageWithData:photoData];
            else
                cell.imageView.image = [UIImage imageNamed:@"placeholder"];
        }
    }@catch (NSException *exception) {
        NSLog(@"%@",[exception debugDescription]);
    }
    @finally {
    }
}

#pragma mark -  UITableView datasource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return [[[self fetchedResultsController] sections] count];
}

- (NSString *)tableView:(UITableView *)sender titleForHeaderInSection:(NSInteger)sectionIndex
{
	NSArray *sections = [[self fetchedResultsController] sections];
	
	if (sectionIndex < [sections count])
	{
		id <NSFetchedResultsSectionInfo> sectionInfo = [sections objectAtIndex:sectionIndex];
		int section = [sectionInfo.name intValue];
		switch (section)
		{
			case 0  : return @"Available";
			case 1  : return @"Away";
			default : return @"Offline";
		}
	}
	
	return @"";
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)sectionIndex
{
	NSArray *sections = [[self fetchedResultsController] sections];
	if([sections count]>0)
    {
        if (sectionIndex < [sections count])
        {
            id <NSFetchedResultsSectionInfo> sectionInfo = [sections objectAtIndex:sectionIndex];
            return sectionInfo.numberOfObjects;
        }
    }
	return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	static NSString *CellIdentifier = @"Cell";
	
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	if (cell == nil)
	{
		cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                      reuseIdentifier:CellIdentifier];
	}
    
	XMPPUserCoreDataStorageObject *user = [[self fetchedResultsController] objectAtIndexPath:indexPath];

	[cell setBackgroundColor:[UIColor purpleColor]];
    
    [cell.textLabel setFont:[UIFont fontWithName:@"Arial" size:14.0f]];
    @try {
        [cell.textLabel setText:user.displayName];
        [cell.detailTextLabel setText:user.nickname];
    }
    @catch (NSException *exception) {
        NSLog(@"%@",[exception debugDescription]);
    }
    @finally {        
    }
	[self configurePhotoForCell:cell user:user];
	
	return cell;
}

#pragma mark - TableView Delegate
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    XMPPUserCoreDataStorageObject *user = [[self fetchedResultsController] objectAtIndexPath:indexPath];
    [ShareObj.arrChat removeAllObjects];
//    NSLog(@"%@",[user jidStr]);
//    NSLog(@"me [%@]",ShareObj.fromUserJid);
    ShareObj.toUserJid = [user jidStr];
    NSLog(@"%@",ShareObj.toUserJid);
    ChatViewController *objCVC = [[ChatViewController alloc] initWithNibName:@"ChatViewController" bundle:nil];
    [self.navigationController pushViewController:objCVC animated:YES];        
}


#pragma mark - signout
-(void)signout
{
    [[self appDelegate] disconnect];

    LoginViewController *objLVC = [[LoginViewController alloc] initWithNibName:@"LoginViewController" bundle:nil];
    if([self respondsToSelector:@selector(presentViewController:animated:completion:)])
        [self presentViewController:objLVC animated:YES completion:^{}];
    else
        [self presentModalViewController:objLVC animated:YES];

}

#pragma mark - BuddyDelegate
-(void)userAuthenticated
{
    FUNCTION_NAME;
    [SVProgressHUD showSuccessWithStatus:@"User Authenticated Succeesfully!"];
    [[self tableView] reloadData];
}
-(void)startAuthentication
{
    FUNCTION_NAME;
    [SVProgressHUD showWithStatus:@"Authenticating..." maskType:SVProgressHUDMaskTypeBlack];
}

-(void)authenticationFailed
{
    FUNCTION_NAME;
    [SVProgressHUD showErrorWithStatus:@"Authentication Failed"];
    
    LoginViewController *objLVC = [[LoginViewController alloc] initWithNibName:@"LoginViewController" bundle:nil];

    if([self respondsToSelector:@selector(presentViewController:animated:completion:)])
        [self presentViewController:objLVC animated:YES completion:^{}];
    else
        [self presentModalViewController:objLVC animated:YES];
}

#pragma mark - chat Delegate
-(void)receivedMessageWithStream:(XMPPStream *)sender andMessage:(XMPPMessage *)message
{
    FUNCTION_NAME;
    XMPPUserCoreDataStorageObject *user = [[self appDelegate].xmppRosterStorage userForJID:[message from]
                                                                                xmppStream:[self appDelegate].xmppStream
                                                                      managedObjectContext:[[self appDelegate] managedObjectContext_roster]];
    
    NSString *body = [[message elementForName:@"body"] stringValue];
    NSString *displayName = [user displayName];
    
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    
    NSString *currentTime = [dateFormat stringFromDate:[NSDate date]];
    
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
    [dict setObject:body forKey:@"msg"];
    [dict setObject:displayName forKey:@"sender"];
    [dict setObject:currentTime forKey:@"time"];

    [[iToast makeText:NSLocalizedString([dict valueForKey:@"msg"], @"")] show];
}

-(void)newMessage:(NSNotification *)notification
{
    NSDictionary *dict = [notification userInfo];
    NSString *str = [NSString stringWithFormat:@"%@ %@",[dict valueForKey:@"sender"],[dict valueForKey:@"msg"]];
    NSLog(@"%@",str);
//    [[[iToast makeText:NSLocalizedString(str, @"")]
//      setGravity:iToastGravityBottom] show];
}

@end
