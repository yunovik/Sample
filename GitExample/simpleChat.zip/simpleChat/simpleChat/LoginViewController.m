//
//  LoginViewController.m
//  simpleChat
//
//  Created by I-VERVE7 on 26/02/13.
//  Copyright (c) 2013 I-VERVE7. All rights reserved.
//

#import "LoginViewController.h"

@interface LoginViewController ()

@end

@implementation LoginViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

-(void)viewDidAppear:(BOOL)animated
{
    [SharedManager sharedInstance].uname = @"";
    [SharedManager sharedInstance].password = @"";    
}

-(void)viewDidDisappear:(BOOL)animated
{
    [tfUsername setText:@""];
    [tfPassword setText:@""];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (AppDelegate *)appDelegate
{
	return (AppDelegate *)[[UIApplication sharedApplication] delegate];
}

-(IBAction)login:(id)sender
{
    if([tfUsername.text length] > 0 && [tfPassword.text length] > 0)
    {
        [SharedManager sharedInstance].uname = tfUsername.text;
        [SharedManager sharedInstance].password = tfPassword.text;
        
        [[self appDelegate] connect];
                
        if([self respondsToSelector:@selector(dismissViewControllerAnimated:completion:)])
            [self dismissViewControllerAnimated:YES completion:^{}];
        else
            [self dismissModalViewControllerAnimated:YES];
    }
}

@end
