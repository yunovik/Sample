//
//  ViewController.h
//  simpleChat
//
//  Created by I-VERVE7 on 26/02/13.
//  Copyright (c) 2013 I-VERVE7. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "LoginViewController.h"

@interface ViewController : UIViewController <buddyStatusDelegate, UITableViewDataSource, UITableViewDelegate>
{
    IBOutlet UITableView *tblView;
}

- (AppDelegate *)appDelegate;

@end
