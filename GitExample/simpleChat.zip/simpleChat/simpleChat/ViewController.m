//
//  ViewController.m
//  simpleChat
//
//  Created by I-VERVE7 on 26/02/13.
//  Copyright (c) 2013 I-VERVE7. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    AppDelegate *appDel = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [appDel setBuddyStatusDelegate:self];
    
    if(![[[self appDelegate] xmppStream] isConnected])
    {        
        LoginViewController *objLVC = [[LoginViewController alloc] initWithNibName:@"LoginViewController" bundle:nil];
        if([self respondsToSelector:@selector(presentViewController:animated:completion:)])
            [self presentViewController:objLVC animated:YES completion:^{}];
        else
            [self presentModalViewController:objLVC animated:YES];
    }
}

-(void)viewDidAppear:(BOOL)animated
{
    FUNCTION_NAME;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (AppDelegate *)appDelegate
{
	return (AppDelegate *)[[UIApplication sharedApplication] delegate];
}

#pragma mark - Buddy List Update Delegate
-(void)buddyStatus
{
//    FUNCTION_NAME;
    [tblView reloadData];
}

#pragma mark - Tableview Datasource method
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[SharedManager sharedInstance].buddyList count];
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return @"Available";
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
	
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	if (cell == nil)
	{
		cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                      reuseIdentifier:CellIdentifier];
	}
	@try {
        NSArray *temp = [[SharedManager sharedInstance].buddyList allObjects];
        NSLog(@"%@",temp);
        NSDictionary *dict = [temp objectAtIndex:indexPath.row];
        cell.textLabel.text = [dict valueForKey:username];
        cell.detailTextLabel.text = [dict valueForKey:userId];
    }
    @catch (NSException *exception) {
        NSLog(@"%@",[exception debugDescription]);
    }
    @finally {
    }

	
	return cell;
}

@end
