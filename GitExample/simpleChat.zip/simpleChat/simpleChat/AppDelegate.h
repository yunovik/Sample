//
//  AppDelegate.h
//  simpleChat
//
//  Created by I-VERVE7 on 26/02/13.
//  Copyright (c) 2013 I-VERVE7. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import "XMPPFramework.h"
#import "SharedManager.h"
#import "iToast.h"

#define FUNCTION_NAME   NSLog(@"%s",__FUNCTION__)

#define username        @"username"
#define userId          @"user_id"

#define kXMPPmyJID      @"kXMPPmyJID"
#define kXMPPmyPassword @"kXMPPmyPassword"

#define NotifName       @"NewReceivedMessage"

#define ShareObj        [SharedManager sharedInstance]

@protocol buddyStatusDelegate <NSObject>

@optional
-(void)buddyStatus;
-(void)userAuthenticated;
-(void)authenticationFailed;
-(void)startAuthentication;

@end

@protocol chatDelegate <NSObject>

-(void)receivedMessageWithStream:(XMPPStream *)sender andMessage:(XMPPMessage *)message;

@end

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate, XMPPRosterDelegate>
{
    UINavigationController *navController;
    UIWindow *window;
    
    XMPPStream *xmppStream;
	XMPPReconnect *xmppReconnect;
    XMPPRoster *xmppRoster;
	XMPPRosterCoreDataStorage *xmppRosterStorage;
    XMPPvCardCoreDataStorage *xmppvCardStorage;
	XMPPvCardTempModule *xmppvCardTempModule;
	XMPPvCardAvatarModule *xmppvCardAvatarModule;
	XMPPCapabilities *xmppCapabilities;
	XMPPCapabilitiesCoreDataStorage *xmppCapabilitiesStorage;
	
	NSString *password;
	
	BOOL allowSelfSignedCertificates;
	BOOL allowSSLHostNameMismatch;
	
	BOOL isXmppConnected;

    UIBarButtonItem *loginButton;
    
    id<buddyStatusDelegate> buddyStatusDelegate;
    id<chatDelegate> chatDelegate;

}

@property (nonatomic, strong) UINavigationController *navController;

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@property (nonatomic, strong, readonly) XMPPStream *xmppStream;
@property (nonatomic, strong, readonly) XMPPReconnect *xmppReconnect;
@property (nonatomic, strong, readonly) XMPPRoster *xmppRoster;
@property (nonatomic, strong, readonly) XMPPRosterCoreDataStorage *xmppRosterStorage;
@property (nonatomic, strong, readonly) XMPPvCardTempModule *xmppvCardTempModule;
@property (nonatomic, strong, readonly) XMPPvCardAvatarModule *xmppvCardAvatarModule;
@property (nonatomic, strong, readonly) XMPPCapabilities *xmppCapabilities;
@property (nonatomic, strong, readonly) XMPPCapabilitiesCoreDataStorage *xmppCapabilitiesStorage;

@property (nonatomic, strong) UIBarButtonItem *loginButton;

@property (nonatomic, retain) id<buddyStatusDelegate> buddyStatusDelegate;
@property (nonatomic, retain) id<chatDelegate> chatDelegate;

- (NSManagedObjectContext *)managedObjectContext_roster;
- (NSManagedObjectContext *)managedObjectContext_capabilities;

- (BOOL)connect;
- (void)disconnect;

+ (NSData *)base64DataFromString: (NSString *)string;

@end
