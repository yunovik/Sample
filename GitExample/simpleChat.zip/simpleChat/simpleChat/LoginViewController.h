//
//  LoginViewController.h
//  simpleChat
//
//  Created by I-VERVE7 on 26/02/13.
//  Copyright (c) 2013 I-VERVE7. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface LoginViewController : UIViewController
{
    IBOutlet UITextField *tfUsername, *tfPassword;
}

- (AppDelegate *)appDelegate;
-(IBAction)login:(id)sender;

@end
