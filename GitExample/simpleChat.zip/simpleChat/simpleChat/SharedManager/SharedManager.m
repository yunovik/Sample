//
//  SharedManager.m
//  colorPicker
//
//  Created by I-VERVE7 on 23/02/13.
//  Copyright (c) 2013 I-VERVE7. All rights reserved.
//


#import "SharedManager.h"
static SharedManager *sm;

@implementation SharedManager

@synthesize myAppName, buddyList, list;
@synthesize uname, password;
@synthesize fromUserJid, toUserJid;

@synthesize arrChat;

+ (SharedManager *)sharedInstance
{
    if(sm == nil)
    {
        sm = [[SharedManager alloc] init];
        sm.myAppName = @"This is SharedManager";
        sm.buddyList = [[NSMutableSet alloc] initWithCapacity:0];
        sm.list = [[NSMutableArray alloc] initWithCapacity:0];
        
        sm.uname = @"";
        sm.password = @"";
        sm.fromUserJid = sm.toUserJid = @"";
        
        sm.arrChat = [NSMutableArray arrayWithCapacity:0];
    }
    
    return sm;
}

+ (NSString *)docDirPath
{
    NSArray *sysPaths = NSSearchPathForDirectoriesInDomains( NSDocumentDirectory, NSUserDomainMask, YES );
    return [sysPaths objectAtIndex:0];
}

@end
