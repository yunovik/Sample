//
//  SharedManager.h
//  colorPicker
//
//  Created by I-VERVE7 on 23/02/13.
//  Copyright (c) 2013 I-VERVE7. All rights reserved.
//


/*
 * Required Frameworks
 =====================
 #import <Foundation/Foundation.h>
 
 * Usage
 =====================
 SharedManager *sm = [SharedManager sharedInstance];
 NSLog(@"%@",sm.myAppName);
 
 */


#import <Foundation/Foundation.h>

@interface SharedManager : NSObject
{
    NSString *myAppName;
    NSMutableSet *buddyList;
    NSMutableArray *list;
    
    NSString *uname, *password;
    
    NSString *fromUserJid, *toUserJid;
    
    NSMutableArray *arrChat;
}

@property (nonatomic, retain) NSString *myAppName;
@property (nonatomic, retain) NSMutableSet *buddyList;
@property (nonatomic, retain) NSString *uname, *password;
@property (nonatomic, retain) NSString *fromUserJid, *toUserJid;
@property (nonatomic, retain) NSMutableArray *list;

@property (nonatomic, retain) NSMutableArray *arrChat;

+ (SharedManager *)sharedInstance;
+ (NSString *)docDirPath;

@end
