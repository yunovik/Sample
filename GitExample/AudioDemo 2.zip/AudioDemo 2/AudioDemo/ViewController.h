//
//  ViewController.h
//  AudioDemo
//
//  Created by Simon on 24/2/13.
//  Copyright (c) 2013 Appcoda. All rights reserved.
//

//#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import <AudioToolbox/AudioServices.h>

#import <CoreAudio/CoreAudioTypes.h>

#import "EAFRead.h"
#import "EAFWrite.h"

#include "Dirac.h"
#include <stdio.h>
#include <sys/time.h>
#import <AVFoundation/AVAudioPlayer.h>



@interface ViewController : UIViewController <AVAudioRecorderDelegate, AVAudioPlayerDelegate>
{
    EAFRead *reader;
	EAFWrite *writer;
	NSURL *outUrl;
        float time;
    float pitch;
	float formant;
    float percent;
    NSError *error;
}
@property (assign, nonatomic) IBOutlet UISwitch *processSwitch;
@property (assign, nonatomic) IBOutlet UIButton *recordPauseButton;
@property (assign, nonatomic) IBOutlet UIButton *stopButton;
@property (assign, nonatomic) IBOutlet UIButton *playButton;

- (IBAction)recordPauseTapped:(id)sender;
- (IBAction)stopTapped:(id)sender;
- (IBAction)playTapped:(id)sender;

@end
