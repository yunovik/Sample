//
//  SplashScreenViewController.h
//  ELogBooks
//
//  Created by nayan mistry on 04/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UploadFile.h"

@interface SplashScreenViewController : UIViewController
{
    IBOutlet UIActivityIndicatorView *activityIndicator;
}
@end
