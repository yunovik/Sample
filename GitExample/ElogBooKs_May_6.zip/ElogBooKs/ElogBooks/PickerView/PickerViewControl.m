//
//  PickerViewControl.m
//  ElogBooks
//
//  Created by i-Verve on 11/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import "PickerViewControl.h"

#define PICKER_CONTROL_TAG 123

@implementation PickerViewControl

@synthesize _delegate,arrPickerData;

@synthesize strSelectKey;
@synthesize selectedIndex;


- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    
    Length = frame.size.height;
    
    if (self) 
    {
        NSLog(@"@Picker Clicked");
        
        
    }
    return self;
}

-(void)setPicker
{
    
    BOOL isDic;
    
    arrPickerData = [[NSMutableArray alloc] initWithArray:arrPickerData];
    
    if([[arrPickerData objectAtIndex:0] isKindOfClass:[NSMutableDictionary class]])
    {
        isDic=YES;
    }else {
        isDic=NO;
    }
    
    
    if([strSelectKey length] <= 0) strSelectKey = @"SelectedKey";

    if(!isDic)
    {
        
        NSMutableArray *arrTemp = [[NSMutableArray alloc] initWithArray:arrPickerData];
        [arrPickerData removeAllObjects];
        
        for (int i=0;i<[arrTemp count]; i++) {
            
            NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
            [dic setObject:[arrTemp objectAtIndex:i] forKey:strSelectKey];
            [arrPickerData addObject:dic];
            [dic release];
            
        }
    }
    
    NSLog(@"%@",[arrPickerData description]);
    
    CGRect pickerFrame = CGRectMake(0, self.frame.size.height, self.frame.size.width, 200);
    
    UIPickerView *pkrView = [[UIPickerView alloc]initWithFrame:pickerFrame];
    [pkrView setDataSource:self];
    [pkrView setDelegate:self];
    [pkrView setTag:PICKER_CONTROL_TAG];
    
    [pkrView selectRow:selectedIndex inComponent:0 animated:YES];
    
    pkrView.showsSelectionIndicator = YES;    
    [self addSubview:pkrView];
    
    //BackGround Touch Event
    UIButton *btnClosePicker = [[UIButton alloc] initWithFrame:[self frame]];
    [btnClosePicker setBackgroundColor:[UIColor clearColor]];
    [btnClosePicker setAlpha:0.0];
    [btnClosePicker setBackgroundColor:[UIColor blackColor]];    
    [btnClosePicker setOpaque:YES];
    [btnClosePicker addTarget:self action:@selector(btnClosePicker_Tapped:) forControlEvents:UIControlEventTouchUpInside];
    
    [self addSubview:btnClosePicker];
    [self addSubview:pkrView];
    
    [UIView animateWithDuration:0.5  animations:^
     {
         [btnClosePicker setAlpha:0.3];
         [pkrView setFrame:CGRectMake(0, self.frame.size.height-180, 320, 180)];
         
     } completion:^(BOOL finished){
         
         //[pkrView release];
     }];
}

#pragma mark -
#pragma mark BackGround Touch Event

-(IBAction)btnClosePicker_Tapped:(id)Sender
{
    
    UIPickerView *pkrView = (UIPickerView *)[self viewWithTag:PICKER_CONTROL_TAG];
    
    [UIView animateWithDuration:0.5  animations:^{
        [pkrView setFrame:CGRectMake(0, Length, 320, 0)];	
        [Sender setAlpha:0.0];
    }
                     completion:^(BOOL finished)
     {      
         [Sender	removeFromSuperview];
         [pkrView removeFromSuperview];
         [self removeFromSuperview];
         
         [_delegate pickerCloseWithTag:self.tag];

     }];

}

#pragma mark -
#pragma mark pickerView delegate
-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
	return 1;
}

-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
	
    return  [arrPickerData count];
}
-(NSString *) pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    
    return  [[arrPickerData objectAtIndex:row] objectForKey:strSelectKey];
    
}
-(void) pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    NSString *strTitle = [[arrPickerData objectAtIndex:row] objectForKey:strSelectKey];
    
    [_delegate selectedRow:row andValue:strTitle andTag:self.tag selectedRow:row];
    
    
}


/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect
 {
 // Drawing code
 }
 */

@end
