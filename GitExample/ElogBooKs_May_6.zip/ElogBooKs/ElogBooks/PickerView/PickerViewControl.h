//
//  PickerViewControl.h
//  ElogBooks
//
//  Created by i-Verve on 11/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol PickerViewControlDelegate

-(void)selectedRow:(int)row andValue:(NSString *)strVal andTag:(int)tag selectedRow:(int)selRow;
-(void)pickerCloseWithTag:(int)tag;

@optional
-(void)pickerControllerClosed:(UIView *)pkrView;

-(NSInteger)numberOfComponentsInPickerViewControl:(UIPickerView *)pickerView;
-(NSInteger)pickerViewControl:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component;
-(NSString *) pickerViewControl:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component;
-(void) pickerViewControl:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component;

@end

@interface PickerViewControl : UIView<UIPickerViewDelegate,UIPickerViewDataSource>
{
    int Length;
    id<PickerViewControlDelegate> _delegate;
    NSMutableArray *arrPickerData;
}

-(void)setPicker;

@property (nonatomic, assign) id<PickerViewControlDelegate> _delegate;
@property (nonatomic, assign) NSMutableArray *arrPickerData;

@property (nonatomic, assign) NSString *strSelectKey;
@property (nonatomic, assign) int selectedIndex;

@end
