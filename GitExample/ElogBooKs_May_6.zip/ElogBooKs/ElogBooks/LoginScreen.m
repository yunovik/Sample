//
//  LoginScreen.m
//  ELogBooks
//
//  Created by nayan mistry on 04/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import "LoginScreen.h"
#import "HomeScreen.h"
#import "AddMaterials.h"
#import "SyncViewController.h"
#import "UploadDatabase.h"
#import "SyncInBackGround.h"
@interface LoginScreen ()

@end

@implementation LoginScreen

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
#pragma mark DidLoad

-(void)viewWillAppear:(BOOL)animated
{
    //Hide navigation
    [self.navigationController.navigationBar setHidden:YES]; 
    [progressBar setProgress:0.0];
    txtAccount.text = @"";
    txtDomain.text = @"elogbooks.net";

    txtUserName.text = @"";
    txtPwd.text = @"";

    [progressBar setHidden:YES];

    [super viewWillAppear:animated];
}
-(void)viewDidAppear:(BOOL)animated
{
    
    NSMutableArray *arr =[DataSource getRecordsFromQuery:[NSString stringWithFormat:@"SELECT * FROM EnteredUserData"]];
    //    NSString *strUserName = [DataSource getStringFromQuery:[NSString stringWithFormat:@"SELECT Username FROM EnteredUserData"]];
    NSLog(@"%@",arr);
    
    if (![[[arr objectAtIndex:0] objectForKey:@"Username"] isEqualToString:@"NODATA"]) {
        HomeScreen  *objNav = [[[HomeScreen alloc] initWithNibName:@"HomeScreen" bundle:nil]autorelease];
        //set global values again from the table
        //Set Global Url
        NSString *strBaseUrl = [CommonFunctions getBaseUrl];
        [ElogBooksAppDelegate SetGlobalObject:strBaseUrl :BASE_URL];
        //Set Global User_Id and user_name
        NSMutableArray *arrUserInfo = [DataSource getRecordsFromQuery:[NSString stringWithFormat:@"select uid,name from UserTable"]];
        if ([arrUserInfo count]>0)
        {
            //set background timer duration
            SyncInBackGround *objSync = (SyncInBackGround *)[ElogBooksAppDelegate getSyncInBackGroundObj];
            [objSync setTimerDuration];
            
            [ElogBooksAppDelegate SetGlobalObject:[[arrUserInfo objectAtIndex:0]valueForKey:USER_ID] :USER_ID];
            [ElogBooksAppDelegate SetGlobalObject:[[arrUserInfo objectAtIndex:0]valueForKey:USER_NAME] :USER_NAME];
            

//            if ([CommonFunctions isNetAvailable])
//            {
//                //perform uploading or downloading here 
//                [self Start_Update];
//                //   [self.navigationController pushViewController:objNav animated:YES];   
//                
//            }
//            else 
            {
                NSLog(@"no net available");
                [self.navigationController pushViewController:objNav animated:YES];
            }
        }
    }
    
}

- (void)viewDidLoad
{
    
    
    [super viewDidLoad];
    
    
    //Allocate Co-ordinates
   [CommonFunctions performSelectorOnMainThread:@selector(AllocCooridnates) withObject:nil waitUntilDone:NO];
    
    //Domain Array
    arrDomains = [[NSMutableArray alloc]initWithObjects:@"elogbooks.net",@"elogbooks.co.uk/users/jack/WOM",@"elogbooks.co.uk",nil];
    
//    //set Default
//    txtDomain.text = @"elogbooks.net";
    
    //Temporary View for 
    UIView *navView = [[[UIView alloc]initWithFrame:CGRectMake(0, 0, 320, 44)]autorelease];
    UIImageView *backImgView = [[[UIImageView alloc]initWithFrame:CGRectMake(-5, 0, 320, 44)]autorelease];
    [backImgView setImage:[UIImage imageNamed:@"btn_darkgreen.png"]];
    [navView addSubview:backImgView]; 
    
    UIImageView *backImgView2 = [[[UIImageView alloc]initWithFrame:CGRectMake(15, 0, 44, 44)]autorelease];
    [backImgView2 setImage:[UIImage imageNamed:@"e_Log.png"]];
    [navView addSubview:backImgView2]; 
    
    UILabel *lbltext = [[[UILabel alloc]initWithFrame:CGRectMake(70, 5, 280, 34)]autorelease];
	lbltext.backgroundColor = [UIColor clearColor];

    lbltext.text = @"Login";
	lbltext.font = [UIFont fontWithName:@"Arial Rounded MT Bold" size:(19.0)];
//        [lbltext setTextColor:DEFAULT_FONT_COLOR];
    lbltext.textColor = [UIColor colorWithRed:0.0f green:0.0f blue:255.0/255.0f alpha:0.5];
	[navView addSubview:lbltext];
    [self.view addSubview:navView];
    
    
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    
    UIImageView *imgBack = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, screenBounds.size.width, screenBounds.size.height)];
//    [imgBack setImage:[UIImage imageNamed:@"Default-568h@2x.png"]];
    [self.view addSubview:imgBack];
    [self.view sendSubviewToBack:imgBack];

    
    //Set Left Margin
    [CommonFunctions SetLeftViewMode:txtAccount :10.0f];
    [CommonFunctions SetLeftViewMode:txtPwd :10.0f];
    [CommonFunctions SetLeftViewMode:txtDomain :10.0f];
    [CommonFunctions SetLeftViewMode:txtUserName :10.0f];
    
    //Lock Scrolling Temporarily 
    [scrView setContentSize:CGSizeMake(320, 580)];
    
//    [self.view setBackgroundColor:getImageColor(@"Default.png")];
    [self.view setBackgroundColor:[UIColor whiteColor]];

}


-(NSString *)validate
{

    NSString *strMsg = @"Ok";
    
    if([CommonFunctions checkTextField:txtAccount])
    {
        strMsg = @"Please Enter Account.";
    }
    else if([CommonFunctions checkTextField:txtDomain])
    {
        strMsg = @"Please select domain.";
    }
    else if([CommonFunctions checkTextField:txtUserName])
    {
        strMsg = @"Please Enter User name.";
    }
    else if([CommonFunctions checkTextField:txtPwd])
    {
        strMsg = @"Please Enter Password.";
    }
    
    return strMsg;
}


#pragma mark btnLogin Tapped
-(IBAction)btnLoginTapped: (id)sender
{
//static
    
//    txtAccount.text = @"code";
//    txtDomain.text = @"elogbooks.co.uk/users/jack/WOM";
//    txtUserName.text = @"816";
//    txtPwd.text = @"aron";
    
//    txtAccount.text = @"prupim";
//    txtDomain.text = @"elogbooks.net";
//    txtUserName.text = @"16";
//    txtPwd.text = @"john";
    
    if (tmpTextField !=nil)
    [tmpTextField resignFirstResponder];
    [scrView setScrollEnabled:NO];
    [scrView setContentOffset:CGPointMake(0, 0) animated:YES];      
    
    NSString *strMsg = [self validate];
    
    if([strMsg isEqualToString:@"Ok"])
    {
    
        [progressBar setHidden:NO];
        
        //disable view
        [self.view setUserInteractionEnabled:NO];
        
        objService=[[getWebService alloc] init];
        objService._delegate=self;
        
        NSMutableDictionary *dicc=[[[NSMutableDictionary alloc] init]autorelease];
        [dicc setObject:@"Login" forKey:@"01:qd"];
        [dicc setObject:txtUserName.text forKey:@"02:username"];
        [dicc setObject:txtPwd.text forKey:@"03:password"];
        objService.argsDic=dicc;
        
        objService.strWebService=@"UserTable";
        objService.strUrl= [NSString stringWithFormat:@"http://%@.%@/%@",txtAccount.text,txtDomain.text,LOGIN_URL];
        objService.strParent=LOGIN_PARENT_NODE;
        objService.strSubParent=LOGIN_CHILD_NODE;
        
        [objService performSelector:@selector(setArray) withObject:nil afterDelay:0.1];
        
        //Push
        //    AddMaterials  *objNav = [[[AddMaterials alloc] initWithNibName:@"AddMaterials" bundle:nil]autorelease];
        //    [self.navigationController pushViewController:objNav animated:YES];

    }
    else {

        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:APP_TITLE message:strMsg delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        [alertView show];
        [alertView release];
    }
    
}


#pragma mark -  My WebService Delegate ....

-(void)filedWithError:(NSString *)strMsg forFlage:(NSString *)flage
{

    //Enable view
    [self.view setUserInteractionEnabled:YES];
    UIAlertView *alert=[[[UIAlertView alloc] initWithTitle:APP_TITLE message:strMsg delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil]autorelease];
    
    [alert show];
    
	[objService release];
}

-(void)EndParsing:(NSMutableArray *)arrData forFlage:(NSString *)flage
{
    //Static values elogbooks.net
//    txtAccount.text = @"code";
//    txtDomain.text = @"elogbooks.co.uk/users/jack/WOM";
//    txtUserName.text = @"38";
//    txtPwd.text = @"android";
    
    //static
//     [arrData removeAllObjects];
//     NSMutableDictionary *tempDic = [[NSMutableDictionary alloc]init];
//    [tempDic setObject:@"1" forKey:@"login"];
//    [tempDic setObject:@"816" forKey:@"uid"];
//    [tempDic setObject:@"816" forKey:@"name"];
//    [tempDic setObject:@"ab@android-app-developer.co.uk" forKey:@"email"];
//    [arrData addObject:tempDic];
    
    NSLog(@"\n \n %@ : %@",flage,arrData);
    if ([arrData count]>0)
    {
        
        
//        NSMutableDictionary *d = [[NSMutableDictionary alloc] init];
//        [d setObject:@"16" forKey:USER_ID];
//        [d setObject:@"16" forKey:USER_NAME];
//        [d setObject:@"1" forKey:@"login"];
//        arrData = [[NSMutableArray alloc] initWithObjects:d, nil];

        if ([flage isEqualToString:@"UserTable"])
        {
            if (!([[[arrData objectAtIndex:0]valueForKey:@"login"]rangeOfString:@"1"].location==NSNotFound))
            {
                //set Progress
               // [self SetprogressValue:0.2];
                
                //Login Success
                NSLog(@"Login Success");
                
                
                //Populate Users Table
                NSMutableArray *arrToInsert = [[NSMutableArray alloc]initWithArray:arrData];
                DataSource *dataObj = [[[DataSource alloc]init]autorelease];
                [dataObj insertArray:arrToInsert toTable:TBL_USERS :SYNCED_DATA];
                
                NSLog(@"login details inserted in UserTable table");
                
                //Populate entered values for auto-Login in the EnteredUserData table
                [DataSource executeQuery:[NSString stringWithFormat:@"UPDATE EnteredUserData SET Account='%@', Domain='%@',Username='%@',Password='%@' WHERE rowid=1",txtAccount.text,txtDomain.text,txtUserName.text,txtPwd.text]];
                
                //Set Global User_Id
                [ElogBooksAppDelegate SetGlobalObject:[[arrData objectAtIndex:0]valueForKey:USER_ID] :USER_ID];
                [ElogBooksAppDelegate SetGlobalObject:[[arrData objectAtIndex:0]valueForKey:USER_NAME] :USER_NAME];
                
                //Set Global Url
                NSString *strBaseUrl = [CommonFunctions getBaseUrl];
                [ElogBooksAppDelegate SetGlobalObject:strBaseUrl :BASE_URL];

                [self Start_Update];
                
            }
            else 
            {
                //Login Failed
                NSLog(@"Login Failed");
                
                UIAlertView *alert=[[[UIAlertView alloc] initWithTitle:APP_TITLE message:@"Incorrect Login Data!" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil]autorelease];
                
                [alert show];
                [self.view setUserInteractionEnabled:YES];
            }
        }
    }

    [objService release];
}

#pragma mark Upload Start
-(void)Start_Update
{
    if([CommonFunctions isNetAvailable])
    {
        //Allocate Co-ordinates
       [CommonFunctions performSelectorOnMainThread:@selector(AllocCooridnates) withObject:nil waitUntilDone:NO];
        
        SyncViewController *objNav = [[[SyncViewController alloc] initWithNibName:@"SyncViewController" bundle:nil]autorelease];
        objNav.navigationItem.hidesBackButton = YES;
        [self.navigationController pushViewController:objNav animated:YES];
    }
    else
    {
        HomeScreen  *objNav = [[[HomeScreen alloc] initWithNibName:@"HomeScreen" bundle:nil]autorelease];
        [self.navigationController pushViewController:objNav animated:YES];
    }
     [self.view setUserInteractionEnabled:YES];
}


-(IBAction)OpenPicker:(id)sender
{
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    screenBounds.size.height=screenBounds.size.height-20;
    
    [tmpTextField resignFirstResponder];
    txtDomain.text = [arrDomains objectAtIndex:lastSelected];
    
    PickerViewControl *objPicker = [[PickerViewControl alloc] initWithFrame:screenBounds];
    objPicker.arrPickerData = arrDomains;
    objPicker._delegate=self;
    objPicker.selectedIndex=lastSelected;
    [objPicker setPicker];
    [self.view addSubview:objPicker];
}

-(void)pickerCloseWithTag:(int)tag 
{
    NSLog(@"PickerClosed:");
    [scrView setScrollEnabled:NO];
    [scrView setContentOffset:CGPointMake(0, 0) animated:YES];  

}


-(void)selectedRow:(int)row andValue:(NSString *)strVal andTag:(int)tag selectedRow:(int)selRow
{
    lastSelected=selRow;
    NSLog(@"%@",strVal);
    txtDomain.text = strVal;
    [scrView setContentOffset:CGPointMake(0, 0) animated:YES];  
    
}

#pragma mark UITextField Delegate
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{  
    
    NSLog(@"value: %d",(([textField tag]-TAG_TEXTFIELD)*50));
    [scrView setContentOffset:CGPointMake(0, (([textField tag]-TAG_TEXTFIELD)*50)) animated:YES];  
    tmpTextField = textField;
    return  YES;
}


-(BOOL)textFieldShouldReturn:(UITextField *)textField
{ 
    //    UIResponder *nextResponder = [textField.superview viewWithTag:(textField == txtAccount)?([textField tag]+2):([textField tag]+1)];
    //    if (nextResponder)
    //        [nextResponder becomeFirstResponder];
    //    else 
    //    {
    
    [scrView setScrollEnabled:NO];
    [scrView setContentOffset:CGPointMake(0, 0) animated:YES];  
    [textField resignFirstResponder];
    //    }
    return YES;
}


- (void)viewDidUnload
{
    tmpTextField = nil;
    scrView = nil;
    txtAccount =nil;
    txtDomain = nil;
    txtUserName = nil;
    txtPwd = nil;
    btnLogin = nil;
    sheet = nil;
    PickerDomain = nil;
    
    //Release Array
    [arrDomains release];
    arrDomains = nil;
    [super viewDidUnload];
    
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

#pragma Dismiss keyboard on touch


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
