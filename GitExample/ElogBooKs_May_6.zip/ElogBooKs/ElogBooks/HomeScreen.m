//
//  HomeScreen.m
//  ELogBooks
//
//  Created by iphone on 05/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import "HomeScreen.h"
#import "JobListScreen.h"
#import "AssetsListScreen.h"
#import "PatrolsScreen.h"
#import "SearchingScreen.h"
#import "SettingScreen.h"
#import "SyncInBackGround.h"
#import "LogNewJobViewController.h"
#define SYNC_ALERT 777
@interface HomeScreen ()
@end

@implementation HomeScreen

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}

-(void)viewWillAppear:(BOOL)animated
{
    //Allocate Co-ordinates
    [CommonFunctions performSelectorOnMainThread:@selector(AllocCooridnates) withObject:nil waitUntilDone:NO];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
    [self.navigationController.navigationBar setHidden:NO];    
    
    //self.navigationController.navigationItem.leftBarButtonItem=NO;
    
    self.navigationItem.hidesBackButton= YES;
    
    [self setTitle:@""];
    [CommonFunctions setTitleView:self amdtitle:@"Home"];
    
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    [tblView setFrame:screenBounds];
    
//    [self.view setBackgroundColor:getImageColor(@"Default.png")];
    [self.view setBackgroundColor:[UIColor whiteColor]];

    [tblView setBackgroundColor:[UIColor clearColor]];
    
    tblView.delegate = self;
    tblView.dataSource = self;
    
    [tblView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
     arrGrid = [[NSMutableArray alloc]initWithObjects:@"All Jobs",@"Patrols",@"Planned Jobs",@"Reactive Jobs",@"Search",@"Assets",@"Settings",@"Log a Job",@"Log Out", nil];

}

-(void)btnMenuTapped:(id)Sender
{
    NSLog(@"%d Tapped...",[Sender tag]);
}


#pragma mark -
#pragma mark Table view methods

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrGrid.count;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 43;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *CellIdentifier = [NSString stringWithFormat:@"Cel_%d",indexPath.row];
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil) 
    {
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] ;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        [cell.contentView setBackgroundColor:getImageColor(@"Home_Cell.png")];
        
        UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(40, 0, 150, 43)];
        label.backgroundColor = [UIColor clearColor];
        label.text = [arrGrid objectAtIndex:indexPath.row];
        [label setFont:FONT_NEUE_SIZE(14)];
        [label setTextColor:DEFAULT_FONT_COLOR];
        [cell.contentView addSubview:label];
        
        
        UIView *selectedView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 61)];
        [selectedView setBackgroundColor:getImageColor(@"Home_Cell_Sel")];
        //[selectedView setBackgroundColor:[UIColor greenColor]];
        [cell setSelectedBackgroundView:selectedView];
        
    }
    
    [cell setSelectionStyle:UITableViewCellSelectionStyleBlue];
    
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{

    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (indexPath.row == 0) {
        
        JobListScreen* objNav=[[JobListScreen alloc] initWithNibName:@"JobListScreen" bundle:nil];
        [self.navigationController pushViewController:objNav animated:YES];
        [objNav release];
        
    }
    else if (indexPath.row == 1) {
        PatrolsScreen* objNav=[[PatrolsScreen alloc] initWithNibName:@"PatrolsScreen" bundle:nil];
        [self.navigationController pushViewController:objNav animated:YES];
        [objNav release];

    }
    else if (indexPath.row == 2) {
        
        JobListScreen* objNav=[[JobListScreen alloc] initWithNibName:@"JobListScreen" bundle:nil];
        objNav.selJobType=@"Planned Jobs";
        [self.navigationController pushViewController:objNav animated:YES];
        [objNav release];
        
    }else if (indexPath.row == 3) {
        
        JobListScreen* objNav=[[JobListScreen alloc] initWithNibName:@"JobListScreen" bundle:nil];
        objNav.selJobType=@"Reactive Jobs";
        [self.navigationController pushViewController:objNav animated:YES];
        [objNav release];
        
    }
    else if (indexPath.row == 4)
    {
        SearchingScreen* objNav=[[SearchingScreen alloc] initWithNibName:@"SearchingScreen" bundle:nil];
        [self.navigationController pushViewController:objNav animated:YES];
        [objNav release];

    }
    else if (indexPath.row == 5)
    {
        AssetsListScreen* objNav=[[AssetsListScreen alloc] initWithNibName:@"AssetsListScreen" bundle:nil];
        [self.navigationController pushViewController:objNav animated:YES];
        [objNav release];
    }
    else if (indexPath.row == 6) {

        SettingScreen* objNav=[[SettingScreen alloc] initWithNibName:@"SettingScreen" bundle:nil];
        [self.navigationController pushViewController:objNav animated:YES];
        [objNav release];

    }
    else if (indexPath.row == 7) 
    {
        LogNewJobViewController* objNav=[[LogNewJobViewController alloc] initWithNibName:@"LogNewJobViewController" bundle:nil];
        [self.navigationController pushViewController:objNav animated:YES];
        [objNav release];
    }
    else if (indexPath.row == 8) 
    {
            if ( [self CheckIsAnyUnSyncedData] >0) 
            {
                UIAlertView *alert;
                if ([CommonFunctions isNetAvailable])
                {
                alert = [[UIAlertView alloc] initWithTitle:APP_TITLE
                                                                message:@"Updates remaining Unsynced?"
                                                               delegate:self    
                                                      cancelButtonTitle:@"Sync Now"
                                     otherButtonTitles:@"LogOut", nil];
                    alert.tag = SYNC_ALERT;
                  

                }
                else 
                {   
                    alert = [[UIAlertView alloc] initWithTitle:APP_TITLE message:@"No Internet Connection Available!" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                    
                }
                [alert show];
                [alert release];
            }
            else 
            {
                //No Unsynced Data available 
                //logout
                [self CallLogout];
            }
    }
    
}

#pragma Logout 
-(void)CallLogout
{
    [DataSource executeQuery:[NSString stringWithFormat:@"UPDATE EnteredUserData SET Account='NODATA', Domain='NODATA',Username='NODATA',Password='NODATA' WHERE rowid=1"]];
    [DataSource executeQuery:[NSString stringWithFormat:@"DELETE FROM UserTable WHERE uid = %@",[ElogBooksAppDelegate getValueForKey:USER_ID]]];
    [DataSource executeQuery: @"DELETE FROM Asset_notes"];
    [DataSource executeQuery: @"DELETE FROM Assets"];
    [DataSource executeQuery: @"DELETE FROM Assets_sub"];
    [DataSource executeQuery: @"DELETE FROM Customers"];
    [DataSource executeQuery: @"DELETE FROM  Job_lines"];
    [DataSource executeQuery: @"DELETE FROM Job_materials"];
    [DataSource executeQuery: @"DELETE FROM Job_patrol_schedule_points"];
    [DataSource executeQuery: @"DELETE FROM Job_patrol_schedules"];
    [DataSource executeQuery:@"DELETE FROM Jobs"];
    [DataSource executeQuery:@"DELETE FROM Legcomp_types"];
    [DataSource executeQuery:@"DELETE FROM Priorities"];
    [DataSource executeQuery:@"DELETE FROM Suppliers"];
    [DataSource executeQuery:@"DELETE FROM Uploaded_files"];
     [DataSource executeQuery:@"DELETE FROM NewJobs"];
     [DataSource executeQuery:@"DELETE FROM Service"];
    [DataSource executeQuery:@"DELETE FROM Users"];
    
    [DataSource executeQuery:@"DELETE FROM service_routine_lines"];
    [DataSource executeQuery:@"DELETE FROM service_routines"];
    SyncInBackGround *objSync = (SyncInBackGround *)[ElogBooksAppDelegate getSyncInBackGroundObj];
    [objSync InValidate];  
    
    //set NO_DATA for timestamp
    [DataSource executeQuery:[NSString stringWithFormat:@"Update Upload_Info set Previous_TimeStamp ='NO_DATA',settings_TimeStamp ='NO_DATA'  where rowid = 1"]];
    
    [self.navigationController
     popToViewController:[[self.navigationController viewControllers] objectAtIndex:1]
     animated:YES];
}

#pragma Mark AlertView Delegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == SYNC_ALERT)
    {
        if (buttonIndex == 0)
        {
            //Sync Now 

             alert_View1 = [CommonFunctions AlertWithMessage:@"Please wait...."];
            [self.view addSubview:alert_View1];
            NSString *strNewJobsCount = nil;
            strNewJobsCount = [DataSource getStringFromQuery:@"select COUNT(*) from NewJobs"];
            if ([strNewJobsCount intValue]>0)
            {
                [self UpdateNewJobs];
            }
            else 
            {
                [self Start_Update];
            }

            
        }
        else 
       if (buttonIndex ==1)
       {
           //logout 
           [self performSelector:@selector(CallLogout) withObject:nil afterDelay:0.5];
       }
        
    }

}


#pragma -
#pragma -UploadDataBaseDelegate

-(void)UploadComplete:(NSMutableDictionary *)_responceDic
{
    
    if ([_responceDic objectForKey:CREATE_JOB]!=nil) //is uploaded job creation status
    {
        [self Start_Update];
    }
    else  //normal uploading return
    {
    NSLog(@"Upload Response \n %@",[_responceDic description]);
    //Upload completed now
    [alert_View1 removeFromSuperview];
    [self CallLogout];
    }
    
}

-(void)setProgress:(float)val forFlag:(NSString *)strFlag
{
    NSLog(@" \n Current Progress: %f",val);
}

-(void)UpdateNewJobs
{
    //set isSync_ON key ON
    [ElogBooksAppDelegate SetGlobalObject:@"YES" :IsSync_ON];
    
    NSMutableArray *arrPutInfo = [CommonFunctions getArraynewReactiveJobs];
    UploadDatabase *objPutInfo = [[UploadDatabase alloc] init];
    objPutInfo.arrWebServiceObjects = arrPutInfo;
    objPutInfo._delegate=self;
    [objPutInfo Uploading:@"START"];
}

-(void)Start_Update
{
    //set isSync_ON key ON
    [ElogBooksAppDelegate SetGlobalObject:@"YES" :IsSync_ON];
    
    NSMutableArray *arrPutInfo = [CommonFunctions getArrayForPutInfo];
    UploadDatabase *objPutInfo = [[UploadDatabase alloc] init];
    objPutInfo.arrWebServiceObjects = arrPutInfo;
    objPutInfo._delegate=self;
    [objPutInfo Uploading:@"START"];
}


-(NSInteger)CheckIsAnyUnSyncedData
{
    NSInteger rowCount = 0;
    
    NSArray *arrTableNames = [NSArray arrayWithArray:[DataSource getRecordsFromQuery:@"SELECT name  FROM sqlite_master WHERE sql LIKE '%IsSynced%'"]];
    
    for (int i =0;i<[arrTableNames count];i++)
    {
    NSMutableArray *arrUnsyncedRows =  [DataSource getRecordsFromQuery: [NSString stringWithFormat:@"select IsSynced from %@ where IsSynced LIKE '%0%'",[[arrTableNames objectAtIndex:i]valueForKey:@"name"]]];
        if ([arrUnsyncedRows count]>0)
        {
            rowCount = 1;
            break;
        }
    }
    //static
    //rowCount = 1;
    return rowCount;
}

- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}


- (void)viewDidUnload
{
    [super viewDidUnload];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
