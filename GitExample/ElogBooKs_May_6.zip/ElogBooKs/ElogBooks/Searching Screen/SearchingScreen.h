//
//  SearchingScreen.h
//  ElogBooks
//
//  Created by I-VERVE5 on 12/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchingScreen : UIViewController<UITableViewDataSource,
UITableViewDelegate,
PickerViewControlDelegate,
UITextFieldDelegate,
MyTableViewDelegate,MYXMLParserDelegate>
{
    UIButton *btnFind,*btnCustomer,*btnPicker;
    
    UITableView *tblAssets,*tblJobs,*tblSearch;
    
    int lastSelectedFind,lastSelectedCust;
    
    NSMutableArray *arrPickerData;
    
    NSMutableArray *arrTableData;
    
    NSMutableArray *arr_Find,*arr_Cus;
    
    SearchType currentSearch;
    
    getWebService *objWebService;
    UITextField *txtNumber,*txtDesc;
    
    NSString *strCId;
}

-(UITableViewCell *)getCellForAssets:(UITableViewCell *)cell at:(NSIndexPath *)indexPath andRec:(NSMutableDictionary *)redDic;
-(UITableViewCell *)getCellForJob:(UITableViewCell *)cell at:(NSIndexPath *)indexPath andRec:(NSMutableDictionary *)redDic;
-(void)btnInfoTapped:(id)sender;
@end
