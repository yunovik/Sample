//
//  SearchingScreen.m
//  ElogBooks
//
//  Created by I-VERVE5 on 12/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import "SearchingScreen.h"
#define BTNFIND_TAG 100
#define BTNCUSTOMER_TAG 101
#define FINDPICKER_TAG 1000
#define CUSTOMERPICKER_TAG 1001
#define BTNSEARCH_TAG 10000
#define TAG_ASSETS_INFO 15000
#define TAG_JOB_INFO 75000
#import "JobInfoScreen.h"
#import "AssetsInfoScreen.h"



@interface SearchingScreen ()

@end

@implementation SearchingScreen

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.title = @"Search";
    [CommonFunctions setTitleView:self amdtitle:@"Search"];
    lastSelectedFind =1;
    
    
    //UIview
    UIView *backView = [[[UIView alloc] init] autorelease];
    backView.frame = CGRectMake(0, 0, 320, 150);
    backView.backgroundColor = getImageColor(@"seacrhView.png");
    //    [backView setBackgroundColor:[UIColor brownColor]];
    //[View release];
    
    
    //NSMutableArraies
    
    arr_Find = [[NSMutableArray alloc]initWithObjects:@"Jobs ",@"Assets ", nil];
    
    UILabel *lblFind = [[UILabel alloc]initWithFrame:CGRectMake(15, 20, 40, 15)];
    lblFind.backgroundColor = [UIColor clearColor];
    [lblFind setFont:FONT_NEUE_SIZE(13)];
    [lblFind setTextColor:DEFAULT_FONT_COLOR];
    [lblFind setText:@"Find:"];
    [backView addSubview:lblFind];
    [lblFind release];
    
    //UIButton  btnFind
    btnFind = [UIButton buttonWithType:UIButtonTypeCustom];
    [btnFind addTarget:self action:@selector(OpenPicker:)forControlEvents:UIControlEventTouchUpInside];
    [btnFind setTag:BTNFIND_TAG];
    [btnFind setTitleColor:[UIColor blackColor] forState:UIControlStateNormal ];
    btnFind.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
    [btnFind setTitle:@"Assets    " forState:UIControlStateNormal];
    [btnFind.titleLabel setFont:FONT_NEUE_SIZE(14) ];
    [btnFind setTitleColor:DEFAULT_FONT_COLOR forState:UIControlStateNormal ];
    [btnFind setBackgroundImage:[UIImage imageNamed:@"Btn_JobInfo.png"] forState:UIControlStateNormal];
    btnFind.frame = CGRectMake(110.0, 6.0, 200.0, 29);
    //    btnFind.tag = btnFind_TAG;
    btnFind.backgroundColor = [UIColor clearColor];
    [backView addSubview:btnFind];
    
    
    arr_Cus = [DataSource getRecordsFromQuery:
               [NSString stringWithFormat:
                @"Select * from Customers"]];
    
    //UIButton  btnCustomer
    btnCustomer = [UIButton buttonWithType:UIButtonTypeCustom];
    [btnCustomer addTarget:self action:@selector(OpenPicker:)forControlEvents:UIControlEventTouchUpInside];
    [btnCustomer setTitleColor:[UIColor blackColor] forState:UIControlStateNormal ];
    [btnCustomer setTag:BTNCUSTOMER_TAG];
    btnCustomer.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
    
    if([arr_Cus count]>0)
    {
        [btnCustomer setTitle:
         [NSString stringWithFormat:@"%@    ",[[arr_Cus objectAtIndex:0] objectForKey:CUSTOMERS_CUSTOMER]]
                     forState:UIControlStateNormal];
    }
    else
    {
        [btnCustomer setTitle:@"--"
                     forState:UIControlStateNormal];
        
        [btnCustomer setEnabled:NO];
        
    }
    [btnCustomer.titleLabel setFont:FONT_NEUE_SIZE(14) ];
    [btnCustomer setTitleColor:DEFAULT_FONT_COLOR forState:UIControlStateNormal ];
    [btnCustomer setBackgroundImage:[UIImage imageNamed:@"Btn_JobInfo.png"] forState:UIControlStateNormal];
    btnCustomer.frame = CGRectMake(110.0, 40.0, 200.0, 29);
    //    btnCustomer.tag = btnCustomer_TAG;
    btnCustomer.backgroundColor = [UIColor clearColor];
    [backView addSubview:btnCustomer];
    
    
    UILabel *lblCus = [[UILabel alloc]initWithFrame:CGRectMake(15, 50, 80, 15)];
    lblCus.backgroundColor = [UIColor clearColor];
    [lblCus setFont:FONT_NEUE_SIZE(13)];
    [lblCus setTextColor:DEFAULT_FONT_COLOR];
    [lblCus setText:@"Customer:"];
    [backView addSubview:lblCus];
    [lblCus release];
    
    
    UILabel *lblNum = [[UILabel alloc]initWithFrame:CGRectMake(15, 80, 80, 15)];
    lblNum.backgroundColor = [UIColor clearColor];
    [lblNum setFont:FONT_NEUE_SIZE(13)];
    [lblNum setTextColor:DEFAULT_FONT_COLOR];
    [lblNum setText:@"Number:"];
    [backView addSubview:lblNum];
    [lblNum release];
    
    txtNumber = [[UITextField alloc] initWithFrame:CGRectMake(110.0, 72.0, 200.0, 27)];
    txtNumber.borderStyle = UITextBorderStyleNone;
    txtNumber.placeholder = @"Click to begin typing";
//    txtNumber.background = [UIImage imageNamed:@"txtBig.png"];
    txtNumber.backgroundColor = [UIColor whiteColor];
    [txtNumber.layer setBorderWidth:1.0];
    [txtNumber.layer setBorderColor:[[UIColor colorWithRed:193.0/255.0f green:193.0/255.0f blue:193.0/255.0f alpha:1] CGColor]];
    [txtNumber setTextAlignment:UITextAlignmentLeft];
    txtNumber.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    txtNumber.font = [UIFont systemFontOfSize:10];
    
    [txtNumber setDelegate:self];
    [txtNumber setReturnKeyType:UIReturnKeySearch];
    
    txtNumber.text=@"";
    [CommonFunctions SetLeftViewMode:txtNumber :10.0f];
    txtNumber.delegate = self;
    [backView addSubview:txtNumber];
    
    UILabel *lblDes = [[UILabel alloc]initWithFrame:CGRectMake(15, 110, 80, 15)];
    lblDes.backgroundColor = [UIColor clearColor];
    [lblDes setFont:FONT_NEUE_SIZE(13)];
    [lblDes setTextColor:DEFAULT_FONT_COLOR];
    [lblDes setText:@"Description:"];
    [backView addSubview:lblDes];
    [lblDes release];
    
    txtDesc = [[UITextField alloc] initWithFrame:CGRectMake(110.0, 102.0, 200.0, 27)];
    txtDesc.borderStyle = UITextBorderStyleNone;
//    txtDesc.background = [UIImage imageNamed:@"txtBig.png"];
    txtDesc.placeholder = @"Click to begin typing";
    txtDesc.backgroundColor = [UIColor whiteColor];
    [txtDesc.layer setBorderWidth:1.0];
    [txtDesc.layer setBorderColor:[[UIColor colorWithRed:193.0/255.0f green:193.0/255.0f blue:193.0/255.0f alpha:1] CGColor]];
    [txtDesc setTextAlignment:UITextAlignmentLeft];
    
    txtDesc.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    txtDesc.font = [UIFont systemFontOfSize:10];
    
    [txtDesc setDelegate:self];
    [txtDesc setReturnKeyType:UIReturnKeySearch];
    
    txtDesc.text=@"";
    [CommonFunctions SetLeftViewMode:txtDesc :10.0f];
    txtDesc.delegate = self;
    [backView addSubview:txtDesc];
    
    //Back Button On Navigation
    [CommonFunctions setBack:self target:@selector(btnBackTapped:)];
    
    [self.view addSubview:backView];
    
    arrTableData = [[NSMutableArray alloc] init];
    
    strCId = [[arr_Cus objectAtIndex:0] objectForKey:CUSTOMERS_ID];
    
    //    tblAssets = [[UITableView alloc] initWithFrame:CGRectMake(00, 150, 320, 270) style:UITableViewStylePlain];
    //    [tblAssets setShowsVerticalScrollIndicator:NO];
    //    [tblAssets setDataSource:self];
    //    [tblAssets setDelegate:self];
    //    [tblAssets setBackgroundColor:[UIColor clearColor]];
    //    [tblAssets setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    //
    //    [self.view addSubview:tblAssets];
    //
    //    tblJobs = [[UITableView alloc] initWithFrame:CGRectMake(00, 150, 320, 270) style:UITableViewStylePlain];
    //    [tblJobs setShowsVerticalScrollIndicator:NO];
    //    [tblJobs setDataSource:self];
    //    [tblJobs setDelegate:self];
    //    [tblJobs setBackgroundColor:[UIColor clearColor]];
    //    [tblJobs setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    //
    //    [self.view addSubview:tblJobs];
    
//    tblSearch = [[UITableView alloc] initWithFrame:CGRectMake(00, 150, 320, 270) style:UITableViewStylePlain];
//    tblSearch = [[UITableView alloc] initWithFrame:CGRectMake(00, 150, 320, [[UIScreen mainScreen] bounds].size.height-213) style:UITableViewStylePlain];
        tblSearch = [[UITableView alloc] initWithFrame:CGRectMake(00, 150, 320, [[UIScreen mainScreen] bounds].size.height-150) style:UITableViewStylePlain];
//    [tblSearch setShowsVerticalScrollIndicator:NO];
    [tblSearch setDataSource:self];
    [tblSearch setDelegate:self];
    [tblSearch setBackgroundColor:[UIColor clearColor]];
//    [tblSearch setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    
    [self.view addSubview:tblSearch];
    
    
    
    [self search:AssetsSearch Cursomer:strCId Number:txtNumber.text Description:txtDesc.text];
    
    
}

#pragma -
#pragma -- Search Delegate...

-(void)search:(SearchType )SearchFor Cursomer:(NSString *)strCustId Number:(NSString *)strNum Description:(NSString *)strDesc
{
    
    NSString *strQuery;
    
    currentSearch = SearchFor;
    
    NSLog(@"%d",currentSearch);
    
    
    if(SearchFor == JobSearch)
    {
        strQuery = [NSString stringWithFormat:
                    @"Select * from Jobs Where Jobs.cid = %@ AND (Jobs.jid LIKE '%%%@%%' AND jobs.description LIKE '%%%@%%')",strCustId,strNum,strDesc];
        NSLog(@"%@",strQuery);
        
        arrTableData = [DataSource getRecordsFromQuery:strQuery];
    }
    else if(SearchFor == AssetsSearch)
    {
        strQuery = [NSString stringWithFormat:
                    @"Select * from Assets Where Assets.cid = %@ AND ( Assets.aid LIKE '%%%@%%' AND Assets.descr LIKE '%%%@%%')",strCustId,strNum,strDesc];
        NSLog(@"%@",strQuery);
        arrTableData = [DataSource getRecordsFromQuery:strQuery];
        
    }
    
    
    [tblSearch reloadData];
    
    NSLog(@"%d:%@",[arrTableData count],[arrTableData description]);
    
    
}
#pragma mark -
#pragma mark - OpenPicker Method

-(IBAction)OpenPicker:(id)sender{
    
    [txtNumber resignFirstResponder];
    [txtDesc resignFirstResponder];
    
    PickerViewControl *objPicker = [[PickerViewControl alloc] initWithFrame:[self.view frame]];
    
    if ([sender tag] == BTNFIND_TAG)
    {
        objPicker.arrPickerData = arr_Find;
        objPicker.tag = FINDPICKER_TAG;
        objPicker.selectedIndex=lastSelectedFind;
    }
    else
    {
        objPicker.arrPickerData = arr_Cus;
        objPicker.tag = CUSTOMERPICKER_TAG;
        objPicker.strSelectKey = CUSTOMERS_CUSTOMER;
        objPicker.selectedIndex=lastSelectedCust;
        
    }
    
    objPicker._delegate=self;
    [objPicker setPicker];
    
    [self.view addSubview:objPicker];
    txtNumber.text = @"";
    txtDesc.text = @"";
}

-(void)pickerCloseWithTag:(int)tag
{
    NSLog(@"PickerClosed:");
}

-(void)selectedRow:(int)row andValue:(NSString *)strVal andTag:(int)tag selectedRow:(int)selRow
{
    
    if (tag==FINDPICKER_TAG)
    {
        [btnFind setTitle:strVal forState:UIControlStateNormal];
        
        if (selRow == 0) {
            currentSearch = JobSearch;
        }else if (selRow == 1) {
            currentSearch = AssetsSearch;
        }
        
        lastSelectedFind=selRow;
    }
    else
    {
        [btnCustomer setTitle:strVal forState:UIControlStateNormal];
        
        strCId = [[arr_Cus objectAtIndex:selRow] objectForKey:CUSTOMERS_ID];
        
        lastSelectedCust=selRow;
        
    }
    
    [self search:currentSearch Cursomer:strCId Number:txtNumber.text Description:txtDesc.text];
    
    
    // NSLog(@"%@",strVal);
    
}

#pragma mark -
#pragma mark Table view methods

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrTableData count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 61;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *CellIdentifier;
    
    if(currentSearch == AssetsSearch)
    {
        CellIdentifier = [NSString stringWithFormat:@"Cel_%d_%d_%d",currentSearch,indexPath.row,[[[arrTableData objectAtIndex:indexPath.row] objectForKey:ASSETS_ID]intValue]];
    }
    else if(currentSearch == JobSearch)
    {
        CellIdentifier = [NSString stringWithFormat:@"Cel_%d_%d_%d",currentSearch,indexPath.row,[[[arrTableData objectAtIndex:indexPath.row] objectForKey:@"jid"]intValue]];
    }
    
    NSMutableDictionary *redDic = [arrTableData objectAtIndex:indexPath.row];
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    //    cell = nil;
    
    if (cell == nil)
    {
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] ;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;

//        [cell.contentView setBackgroundColor:getImageColor(@"Cell_Stripe.png")];
        
        if(currentSearch == AssetsSearch)
        {
            cell = [self getCellForAssets:cell at:indexPath andRec:redDic];
        }
        else if(currentSearch == JobSearch)
        {
            cell = [self getCellForJob:cell at:indexPath andRec:redDic];
        }
        
//        UIView *selectedView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 61)];
//        [selectedView setBackgroundColor:getImageColor(@"Cell_Stripe_Sel.png")];
//        [cell setSelectedBackgroundView:selectedView];
    }
    else
    {
        
        
    }
    
   
    
    return cell;
}

-(UITableViewCell *)getCellForAssets:(UITableViewCell *)cell at:(NSIndexPath *)indexPath andRec:(NSMutableDictionary *)redDic
{
    
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(10, 15, 40, 15)];
    label.backgroundColor = [UIColor clearColor];
    [label setFont:FONT_NEUE_BOLD_SIZE(14)];
    [label setTextColor:DEFAULT_FONT_COLOR];
    label.text = [redDic objectForKey:ASSETS_ID];
    [cell.contentView addSubview:label];
    [label release];
    
    
    UILabel *label_ = [[UILabel alloc]initWithFrame:CGRectMake(35, 15, 10, 15)];
    label_.backgroundColor = [UIColor clearColor];
    [label_ setFont:FONT_NEUE_BOLD_SIZE(12)];
    [label_ setTextColor:DEFAULT_FONT_COLOR];
    label_.text = @"-";
    [cell.contentView addSubview:label_];
    [label_ release];
    
    
    UILabel *lblFloor = [[UILabel alloc] initWithFrame:CGRectMake(10, 33, 130, 15)];
    lblFloor.backgroundColor = [UIColor clearColor];
    lblFloor.numberOfLines = 0;
    [lblFloor setFont:FONT_NEUE_SIZE(12)];
    [lblFloor setTextColor:DEFAULT_FONT_COLOR];
    lblFloor.text = [redDic objectForKey:ASSETS_LOCATION];
    [cell.contentView addSubview:lblFloor];
    [lblFloor release];
    //
    UILabel *lblAssetsDesc = [[UILabel alloc] initWithFrame:CGRectMake(45, 15, 250, 15)];
    lblAssetsDesc.backgroundColor = [UIColor clearColor];
    lblAssetsDesc.numberOfLines = 0;
    [lblAssetsDesc setFont:FONT_NEUE_BOLD_SIZE(14) ];
    [lblAssetsDesc setTextColor:DEFAULT_FONT_COLOR];
    lblAssetsDesc.text = [redDic objectForKey:ASSETS_DESC];
    
    
   
    UIButton * btnInfo=[UIButton buttonWithType:UIButtonTypeCustom];
    [btnInfo setFrame:CGRectMake(260,5,50,50)];
    UIImage *newButtonImage = [UIImage imageNamed:@"Info.png"];        
    [btnInfo setImage:newButtonImage forState:UIControlStateNormal];
        [ btnInfo setTag:TAG_ASSETS_INFO+indexPath.row];
    [btnInfo addTarget:self action:@selector(btnInfoTapped:) forControlEvents:UIControlEventTouchUpInside];
    [cell.contentView addSubview:btnInfo];
    [btnInfo release];
    
    [cell.contentView addSubview:lblAssetsDesc];
    [lblAssetsDesc release];
    //
    
    
    return cell;
}

-(UITableViewCell *)getCellForJob:(UITableViewCell *)cell at:(NSIndexPath *)indexPath andRec:(NSMutableDictionary *)redDic
{
    
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(10, 15, 80, 15)];
    label.backgroundColor = [UIColor clearColor];
    [label setFont:FONT_NEUE_BOLD_SIZE(14)];
    [label setTextColor:DEFAULT_FONT_COLOR];
    label.text = [redDic objectForKey:@"jid"];
    [cell.contentView addSubview:label];
    [label release];
    
    
    UILabel *label_ = [[UILabel alloc]initWithFrame:CGRectMake(85, 15, 10, 15)];
    label_.backgroundColor = [UIColor clearColor];
    [label_ setFont:FONT_NEUE_BOLD_SIZE(12)];
    [label_ setTextColor:DEFAULT_FONT_COLOR];
    label_.text = @"-";
    [cell.contentView addSubview:label_];
    [label_ release];
    
    
    UILabel *lblFloor = [[UILabel alloc] initWithFrame:CGRectMake(10, 33, 130, 15)];
    lblFloor.backgroundColor = [UIColor clearColor];
    lblFloor.numberOfLines = 0;
    [lblFloor setFont:FONT_NEUE_SIZE(12)];
    [lblFloor setTextColor:DEFAULT_FONT_COLOR];
    lblFloor.text = [redDic objectForKey:@"location"];
    [cell.contentView addSubview:lblFloor];
    [lblFloor release];
    //
    UILabel *lblAssetsDesc = [[UILabel alloc] initWithFrame:CGRectMake(95, 5, 170, 40)];
    lblAssetsDesc.backgroundColor = [UIColor clearColor];
    lblAssetsDesc.numberOfLines = 0;
    [lblAssetsDesc  setLineBreakMode:UILineBreakModeWordWrap];
    [lblAssetsDesc setFont:FONT_NEUE_BOLD_SIZE(12)];
    [lblAssetsDesc setTextColor:DEFAULT_FONT_COLOR];
    lblAssetsDesc.text = [redDic objectForKey:@"description"];
    
    

     UIButton * btnInfo=[UIButton buttonWithType:UIButtonTypeCustom];
    [btnInfo setFrame:CGRectMake(260,5,50,50)];
    UIImage *newButtonImage = [UIImage imageNamed:@"Info.png"];        
    [btnInfo setImage:newButtonImage forState:UIControlStateNormal];
            [ btnInfo setTag:TAG_JOB_INFO+indexPath.row];
    [btnInfo addTarget:self action:@selector(btnInfoTapped:) forControlEvents:UIControlEventTouchUpInside];
    [cell.contentView addSubview:btnInfo];
    [btnInfo release];
    
    
    
    [cell.contentView addSubview:lblAssetsDesc];
    [lblAssetsDesc release];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}


#pragma mark btnInfoTapped
-(void)btnInfoTapped:(id)sender
{
    
// TAG_ASSETS_INFO 15000
// TAG_JOB_INFO 75000

    NSLog(@"%d",[sender tag]);
    if ([sender tag]>=TAG_JOB_INFO)
    {
        int CurrentRow = [sender tag]-TAG_JOB_INFO;
    NSString *strJid = [[arrTableData objectAtIndex:CurrentRow] objectForKey:JOBS_ID];
    JobInfoScreen * objJobInfo=[[JobInfoScreen alloc] initWithNibName:@"JobInfoScreen" bundle:nil];
    objJobInfo.strJid = strJid;
    [self.navigationController pushViewController:objJobInfo animated:YES];
    [objJobInfo release];   
    }
    else if ([sender tag]>=TAG_ASSETS_INFO)
    {
        int CurrentRow = [sender tag]-TAG_ASSETS_INFO;
    NSString *strAId = [[arrTableData objectAtIndex:CurrentRow] objectForKey:ASSETS_ID];
    AssetsInfoScreen *objNav = [[AssetsInfoScreen alloc] initWithNibName:@"AssetsInfoScreen" bundle:nil];
    objNav.strAId=strAId;
    [self.navigationController pushViewController:objNav animated:YES];
    [objNav release];
    }
        
    
//    NSString *strAId = [[arrAssets objectAtIndex:[sender tag]] objectForKey:ASSETS_ID];
//    
//    AssetsInfoScreen *objNav = [[AssetsInfoScreen alloc] initWithNibName:@"AssetsInfoScreen" bundle:nil];
//    objNav.strAId=strAId;
//    [self.navigationController pushViewController:objNav animated:YES];
//    [objNav release];

    
    
    
//    NSString *strJid = [[arr_JobList objectAtIndex:indexPath.row] objectForKey:JOBS_ID];
//    //NSString *strSelJobType = [[arr_JobList objectAtIndex:indexPath.row] objectForKey:JOBS_TYPE];
//    
//    JobInfoScreen* objJobInfo=[[JobInfoScreen alloc] initWithNibName:@"JobInfoScreen" bundle:nil];
//    objJobInfo.strJid = strJid;
//    //objJobInfo.jobType = strSelJobType;
//    //objJobInfo.s
//    
//    [self.navigationController pushViewController:objJobInfo animated:YES];
//    [objJobInfo release];
//    
//    [tblJobList deselectRowAtIndexPath:indexPath animated:YES];
    
    
}
 
 

- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //[[tableView cellForRowAtIndexPath:indexPath] setBackgroundView:[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"cellUnselected"]]];
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 61;
}

//-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
//    
//    UIView *FooterView =[[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 125)];
//    FooterView.backgroundColor = getImageColor(@"Cell_Stripe.png");
//    
//    UILabel *lblSerchServer = [[UILabel alloc] initWithFrame:CGRectMake(60 , 7, 200, 40)];
//    lblSerchServer.backgroundColor = [UIColor clearColor];
//    [lblSerchServer setText:@"Continue Searching on server"];
//    [lblSerchServer setFont:FONT_NEUE_BOLD_SIZE(14) ];
//    [lblSerchServer setTextColor:DEFAULT_FONT_COLOR];
//    [FooterView addSubview:lblSerchServer];
//    
//    
//    
//    
//    UIButton  *btnSearch = [UIButton buttonWithType:UIButtonTypeCustom];
//    [btnSearch addTarget:self action:@selector(btnSearchTapped:)forControlEvents:UIControlEventTouchUpInside];
//    [btnSearch setTag:BTNSEARCH_TAG];
//    btnSearch.frame = CGRectMake(0, 0, 320, 125);
//    //    btnFind.tag = btnFind_TAG;
//    btnSearch.backgroundColor = [UIColor clearColor];
//    [FooterView addSubview:btnSearch];
//    
//    
//    return FooterView;
//}

//-(IBAction)btnSearchTapped:(id)sender
//{
//    objWebService=[[getWebService alloc] init];
//    objWebService._delegate=self;
//    NSMutableDictionary *dicc=[[[NSMutableDictionary alloc] init]autorelease];
//    [dicc setObject:[ElogBooksAppDelegate getValueForKey:USER_ID] forKey:@"01:uid"];
//    [dicc setObject:strCId forKey:@"03:cid"];
//    
//    NSString *strSearchFor;
//    if(currentSearch == AssetsSearch)
//    {
//        strSearchFor = @"Assets";
//        [dicc setObject:strSearchFor forKey:@"02:DataTable"];
//        if (txtNumber.text.length != 0) {
//            [dicc setObject:txtNumber.text forKey:@"04:aid"];
//        }
//        if (txtDesc.text.length != 0) {
//            [dicc setObject:txtDesc.text forKey:@"05:descr"];
//        }
//        objWebService.strWebService=@"searchForAssets";
//        objWebService.strParent=SEARCH_PARENT_NODE_ASSETS;
//        objWebService.strSubParent=SEARCH_CHILD_NODE_ASSETS;
//        
//    }
//    else if(currentSearch == JobSearch)
//    {
//        strSearchFor = @"Jobs";
//        [dicc setObject:strSearchFor forKey:@"02:DataTable"];
//        
//        if (txtNumber.text.length != 0) {
//            [dicc setObject:txtNumber.text forKey:@"04:jid"];
//        }
//        if (txtDesc.text.length != 0) {
//            [dicc setObject:txtDesc.text forKey:@"05:description"];
//        }
//        objWebService.strWebService=@"searchForJobs";
//        objWebService.strParent=SEARCH_PARENT_NODE_JOBS;
//        objWebService.strSubParent=SEARCH_CHILD_NODE_JOBS;
//    }
//    
//    objWebService.argsDic=dicc;
////    objWebService.strUrl= [NSString stringWithFormat:@"http://code.elogbooks.co.uk/users/jack/WOM/%@",SEARCH_URL];
//    objWebService.strUrl = [NSString stringWithFormat:@"%@%@",[ElogBooksAppDelegate getValueForKey:BASE_URL],SEARCH_URL];
//    [objWebService performSelector:@selector(setArray) withObject:nil afterDelay:0.1];
//}



-(void)EndParsing:(NSMutableArray *)arrData forFlage:(NSString *)flage
{
    if ([flage isEqualToString:@"searchForAssets"] || [flage isEqualToString:@"searchForJobs"]) //latlon parsing result
    {
        [arrTableData removeAllObjects];
        arrTableData = arrData;
        [tblSearch reloadData];
    }
}
#pragma mark -
#pragma mark - backTapped Method

-(IBAction)btnBackTapped:(id)sender
{
    
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark -
#pragma mark UITextField Methods

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    
    
    [self search:currentSearch Cursomer:strCId Number:txtNumber.text Description:txtDesc.text];
    
    [textField resignFirstResponder];
    return YES;
}
- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
