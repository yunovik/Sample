//
//  LogNewJobViewController.m
//  ElogBooks
//
//  Created by i-verve10 on 26/02/13.
//  Copyright (c) 2013 nayanmist@gmail.com. All rights reserved.
//

#import "LogNewJobViewController.h"
#import "UpdatePointScreen.h"
#import "UploadImageScreen.h"
#import "JobInfoScreen.h"
#define CUSTOMER_TAG 33
#define GROUP_TAG  44
#define PRIORITY_TAG  55
#define SERVICE_TAG 66
#define CANCEL_ALERT 786



@interface LogNewJobViewController ()

@end

@implementation LogNewJobViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)viewWillAppear:(BOOL)animated
{
    NSString *strBarCode = [ElogBooksAppDelegate getValueForKey:BARCODE_FOR_NEW_JOB];
    if (strBarCode!=nil)
    {
        [ElogBooksAppDelegate SetGlobalObject:nil :BARCODE_FOR_NEW_JOB];
        txtLocationBarcode.text = strBarCode;
    }
    NSMutableArray *arrAttachments = (NSMutableArray *) [ElogBooksAppDelegate getValueForKey:NEW_JOB_ATTACHMENTS];
    
    if (arrAttachments!=nil)
    {
        NSDate *today = [NSDate date];
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"dd/MM/YYYY"];
        NSString *currentDate = [dateFormatter stringFromDate:today];
        [dateFormatter release]; 
        arrAttachmentsList = [[NSMutableArray alloc]init];
        for (int i =0 ;i<[arrAttachments count];i++)
        {
            NSMutableDictionary *dicAttachRecord = [[[NSMutableDictionary alloc]init]autorelease];
            [dicAttachRecord setObject:[arrAttachments objectAtIndex:i] forKey:@"Attachments"];
            [dicAttachRecord setObject:currentDate forKey:@"Date"];  
            [arrAttachmentsList addObject:dicAttachRecord];
        }
        
        if ([arrAttachmentsList count]>0)
        {   
            UIView *titleView = [[UIView alloc]initWithFrame:CGRectMake(0, 410, 320,25)];
            titleView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"jobInfo_Row_Stripe.png"]];
            [scrView addSubview:titleView];
            
            UILabel *lblDate = [[UILabel alloc]initWithFrame:CGRectMake(5, 0, 75, 25)];
            lblDate.text = @"Date";
            lblDate.textColor = DEFAULT_FONT_COLOR;
            lblDate.backgroundColor = [UIColor clearColor];
            [titleView addSubview:lblDate];
            
            UILabel *lblFileName = [[UILabel alloc]initWithFrame:CGRectMake(93, 2, 200, 25)];
            lblFileName.text = @"File Name";
            lblFileName.textColor = DEFAULT_FONT_COLOR;
            lblFileName.backgroundColor = [UIColor clearColor];
            [titleView addSubview:lblFileName];
            
            UIView *AttachView = [[[UIView alloc]initWithFrame:CGRectMake(0, 435, 320, 25*[arrAttachmentsList count])]autorelease];
            [AttachView setTag:77];
            [[scrView viewWithTag:77]removeFromSuperview];
            [scrView addSubview:AttachView];
            for (int i =0;i< [arrAttachmentsList count];i++)
            {
                UILabel *lblDate = [[UILabel alloc]initWithFrame:CGRectMake(3, i*25, 75, 25)];
                [lblDate setText: [[arrAttachmentsList objectAtIndex:i]valueForKey:@"Date"]]  ;
                lblDate.textColor = DEFAULT_FONT_COLOR;
                lblDate.font=FONT_NEUE_SIZE(14);
                lblDate.backgroundColor = [UIColor clearColor];
                [AttachView addSubview:lblDate];
                
                UILabel *lblFileName = [[UILabel alloc]initWithFrame:CGRectMake(93, i*25, 200, 25)];
                [lblFileName setText:[[arrAttachmentsList objectAtIndex:i]valueForKey:@"Attachments"]];
                lblFileName.textColor = DEFAULT_FONT_COLOR;
                lblFileName.font=FONT_NEUE_SIZE(14);
                lblFileName.backgroundColor = [UIColor clearColor];
                [AttachView addSubview:lblFileName];
            }
        [scrView setContentSize:CGSizeMake(320, 430+AttachView.frame.size.height+15)];
            
            CGPoint bottomOffset = CGPointMake(0, scrView.contentSize.height - scrView.bounds.size.height);
            [scrView setContentOffset:bottomOffset animated:YES];
        }
        
    }
}


- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    //and move back         
    [self.navigationController  performSelector:@selector(popViewControllerAnimated:) withObject: [NSNumber numberWithBool:YES] afterDelay:0.1];
    
//    if (alertView.tag = CANCEL_ALERT)
//    {
//        if (buttonIndex == 0)
//        { 
//
//
//            
//        }
//    }
}

- (void)viewWillDisappear:(BOOL)animated {
    NSArray *viewControllers = self.navigationController.viewControllers;
    if (viewControllers.count > 1 && [viewControllers objectAtIndex:viewControllers.count-2] == self) {
        // View is disappearing because a new view controller was pushed onto the stack
        NSLog(@"New view controller was pushed");
    } else if ([viewControllers indexOfObject:self] == NSNotFound) {
        // View is disappearing because it was popped from the stack
        NSLog(@"View controller was popped");
        if ([arrAttachmentsList count]>0)
        {
            
            
//            UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:APP_TITLE message:[NSString stringWithFormat:@""] delegate:nil cancelButtonTitle:@"Continue" otherButtonTitles:@"Cancel", nil]autorelease];
//            alert.delegate = self;
//            alert.tag = CANCEL_ALERT;
//            [alert show];
//            [alert release];
//            
            
            NSString *LibrayDirectory = [NSHomeDirectory() stringByAppendingPathComponent:@"Library"];
            NSString *DestinationFolder =[LibrayDirectory stringByAppendingPathComponent:NEW_JOBS_IMAGES_FOLDER];
            
            if ([[NSFileManager defaultManager]removeItemAtPath:DestinationFolder error:nil])
                NSLog(@"new images folder deleted");
            else 
                NSLog(@"failed to deleted athe new images folder in viewwill disappear");
            [ElogBooksAppDelegate SetGlobalObject:nil :NEW_JOB_ATTACHMENTS];
            
        }
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    [CommonFunctions setTitleView:self amdtitle:@"Log a Job"];

    //Allocate Attachments Array in Global Dictionary
    NSMutableArray *arrAttachments = [[NSMutableArray alloc]init];
    [ElogBooksAppDelegate SetGlobalObject:arrAttachments :NEW_JOB_ATTACHMENTS];
    
    
    //Back Button On Navigation
    [CommonFunctions setBack:self target:@selector(btnBackTapped:)];
    //set scrollview content Size 
    [scrView setContentSize:CGSizeMake(320, 430)];
    
    //set EdgeInset for TextFields
    [CommonFunctions SetLeftViewMode:txt_Customer :5.0f];
    [CommonFunctions SetLeftViewMode:txtJobGroup :5.0f];
    [CommonFunctions SetLeftViewMode:txtPriority :5.0f];
    [CommonFunctions SetLeftViewMode:txtLocation :5.0f];
    [CommonFunctions SetLeftViewMode:txtLocationBarcode :5.0f];
    [CommonFunctions SetLeftViewMode:txtService :5.0f];
    
    

  
    //Load Arrays
    arrCustomers = [DataSource getRecordsFromQuery:@"SELECT cid,customer  FROM Customers"];   
    arrJobGroup = [DataSource getRecordsFromQuery:@"select iid,jgpid,descr from job_groups order by descr"];
    
    //Load Initial Values
    if ([arrCustomers count]>0)
    {
        strCid = [[arrCustomers objectAtIndex:0]valueForKey:CUSTOMERS_ID];
        txt_Customer.text = [[arrCustomers objectAtIndex:0]valueForKey:CUSTOMERS_CUSTOMER];
    }
    else 
    {
        strCid = @"0";
        txt_Customer.text = @"No Customer Available";
    }
    
    if ([arrJobGroup count]>0)
    {
//        JOB_GROUPS_ID
                strJob_groupsId = [[arrJobGroup objectAtIndex:0]valueForKey:JOB_GROUPS_ID];
//        strJob_groupsId = [[arrJobGroup objectAtIndex:0]valueForKey:JOB_GROUPS_JGPID];
        txtJobGroup.text = [[arrJobGroup objectAtIndex:0]valueForKey:JOB_GROUPS_DESCR];   
    }
    else 
    {
        strJob_groupsId = @"0";
        txtJobGroup.text = @"No Job_Group Available";
    }
    
    
       [self LoadPriorityArray];
    
        if ([arrPriority count]>0)
        {
            strPriorityId = [[arrPriority objectAtIndex:0]valueForKey:PRIORITIES_ID];
            txtPriority.text = [[arrPriority objectAtIndex:0]valueForKey:CUST_PRIORITIES_PRIORITY];
        }
        else 
        {
            strPriorityId = @"0";
            txtPriority.text = @"No Priority Available";
        }
        
    
    [self LoadServicesArray];
     
    
    //save isjobapproval status
    strIsCustomerRequireApproval = [DataSource getStringFromQuery: [NSString stringWithFormat:@"select apprjid_reqd from Customers where cid=%@",strCid]];
    [strIsCustomerRequireApproval retain];
    
    self.view.backgroundColor = [UIColor whiteColor];
    


    // Do any additional setup after loading the view from its nib.
}

-(void)LoadServicesArray
{
    arrServices = [DataSource getRecordsFromQuery:
                   [NSString stringWithFormat:@"Select sid,name from Service Where sid in (Select sid from cust_services where cid = %@)",strCid]];
    
    if ([arrServices count]>0)
    {
        strServiceId = [[arrServices objectAtIndex:0]valueForKey:SERVICE_ID];
        txtService.text = [[arrServices objectAtIndex:0]valueForKey:SERVICE_NAME];
        NSMutableDictionary *dicLastRecord = [[NSMutableDictionary alloc]init];
        [dicLastRecord setObject:@"This job is for myself" forKey:@"name"];
        [dicLastRecord setObject:@"0" forKey:@"sid"];
        [arrServices insertObject:dicLastRecord atIndex:0];
    }
    else
    {
        strServiceId = @"0";
        txtService.text = @"This job is for myself";
    }

    strServiceId = @"0";
    txtService.text = @"This job is for myself";

}

-(void)LoadPriorityArray
{


    
    if (strCid != nil)
    {
        arrPriority = [DataSource getRecordsFromQuery: [NSString stringWithFormat:@"select priority as priid,priority from cust_priorities where cid = %@",strCid]];
    }
    else  if ((!([strJob_groupsId isEqualToString:@"0"])) && (!([arrPriority count]>0)))
    {
        
        NSString *StrJgpid = [DataSource getStringFromQuery:[NSString stringWithFormat:@"select jgpid from Job_groups where iid = %@",strJob_groupsId]] ;
        
        if (!([strJob_groupsId isEqualToString:@"0"]))
arrPriority =  [DataSource getRecordsFromQuery: [NSString stringWithFormat:@"select priorities.priid,priorities.priority from priorities where priid in (select priid from job_group_priorities where jgid in ( select iid from Job_groups where jgpid = %@))",StrJgpid]];
        
        
//        arrPriority = [DataSource getRecordsFromQuery:@"select priid,priority from Priorities join Job_groups on Job_groups.iid = Priorities.priid"];   
    }
    
   if (!([arrPriority count]>0))
    {
        arrPriority = [DataSource getRecordsFromQuery:@"select priid,priority from Priorities"];   
    }
    
   if (!([arrPriority count]>0)) 
       {
           strPriorityId = @"0";
           txtPriority.text = @"No Priority Available";
       }
    
 
}

-(IBAction)btnBackTapped:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
-(BOOL)IsTextFieldEmpty:(NSString *)strText
{
        if ([[strText stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0)
            return NO;
    else 
            return YES;
}


#pragma mark Validation
-(NSString *)ValidateAll 
{
    NSString *result = @"OK";
    if ([self IsTextFieldEmpty:txtView_Description.text])
        return  result = @"Description";
    else  if ([self IsTextFieldEmpty:txtLocationBarcode.text] && [self IsTextFieldEmpty:txtLocation.text])
    {
         return result = @"Location";
    }
    
    return result;
}  

#pragma mark Create Job Tapped
-(IBAction)btnCreateJobTapped:(id)Sender 
{
    NSString *StrResult = [self ValidateAll];
    if ([StrResult isEqualToString:@"OK"])
    {
        
        if ([txtService.text isEqualToString:@"This job is for myself"])
          strServiceId = @"0";  
        
        NSString *strQuery = @"";
        NSString *strAttachments = @" ";
        NSString *strCurrentTimeStamp = [CommonFunctions getCurrentTimeStampForDatabaseInsertion];
        if ([arrAttachmentsList count]>0)
            strAttachments = [[arrAttachmentsList valueForKey:@"Attachments"]componentsJoinedByString:@":"];
        if (![self IsTextFieldEmpty:txtLocation.text])
            strQuery = [NSString stringWithFormat: @"insert into NewJobs (uid,cid,description,jgid,sid,priority,location,Attachments,tstamp,IsSynced)values(%@,%@,'%@','%@','%@','%@','%@','%@','%@',%@)",[ElogBooksAppDelegate getValueForKey:USER_ID],strCid,txtView_Description.text,strJob_groupsId,strServiceId,strPriorityId,txtLocation.text,strAttachments,strCurrentTimeStamp,UN_SYNCED_DATA];
        else if (![self IsTextFieldEmpty:txtLocationBarcode.text])
            strQuery = [NSString stringWithFormat: @"insert into NewJobs (uid,cid,description,jgid,sid,priority,barcode,Attachments,tstamp,IsSynced)values(%@,%@,'%@','%@','%@','%@','%@','%@','%@',%@)",[ElogBooksAppDelegate getValueForKey:USER_ID],strCid,txtView_Description.text,strJob_groupsId,strServiceId,strPriorityId,txtLocationBarcode.text,strAttachments,strCurrentTimeStamp,UN_SYNCED_DATA];
        else if ((![self IsTextFieldEmpty:txtLocation.text]) && (![self IsTextFieldEmpty:txtLocationBarcode.text]))
            strQuery = [NSString stringWithFormat: @"insert into NewJobs (uid,cid,description,jgid,sid,priority,location,barcode,Attachments,tstamp,IsSynced)values(%@,%@,'%@','%@','%@','%@','%@','%@','%@',%@)",[ElogBooksAppDelegate getValueForKey:USER_ID],strCid,txtView_Description.text,strJob_groupsId,strServiceId,strPriorityId,txtLocation.text,txtLocationBarcode.text,strAttachments,strCurrentTimeStamp,UN_SYNCED_DATA];
        else 
            strQuery = [NSString stringWithFormat: @"insert into NewJobs (uid,cid,description,jgid,sid,priority,Attachments,tstamp,IsSynced)values(%@,%@,'%@','%@','%@','%@','%@','%@',%@)",[ElogBooksAppDelegate getValueForKey:USER_ID],strCid,txtView_Description.text,strJob_groupsId,strServiceId,strPriorityId,strAttachments,strCurrentTimeStamp,UN_SYNCED_DATA];
        
      if ([CommonFunctions isNetAvailable])
      {

          NSInteger currJobID = [DataSource executeInsertQuery:strQuery :YES];
          if (currJobID >0)
          { 
              
              objService=[[PutInfoClass alloc] init];
              objService._delegate=self;
              
              NSMutableDictionary *diccRecordToUpload  =[[[NSMutableDictionary alloc] init]autorelease];
              [diccRecordToUpload setObject:[ElogBooksAppDelegate getValueForKey:USER_ID] forKey:USER_ID];
              [diccRecordToUpload setObject:@"reactive" forKey:@"UpdateType"];
              [diccRecordToUpload setObject:@"Create" forKey:@"qd"];
              
              [diccRecordToUpload setObject:strCid forKey:@"cid"]; //quantity-->Job_materials.rate
              [diccRecordToUpload setObject:txtView_Description.text forKey:@"description"]; //Price -->job_materials.charge
              
              [diccRecordToUpload setObject:strJob_groupsId forKey:@"jgid"];
              [diccRecordToUpload setObject:strServiceId forKey:@"sid"];
              [diccRecordToUpload setObject:strPriorityId forKey:@"priority"];
 
              if (![self IsTextFieldEmpty:txtLocation.text])
              [diccRecordToUpload setObject:txtLocation.text forKey:@"location"];   
              if (![self IsTextFieldEmpty:txtLocationBarcode.text])
                  [diccRecordToUpload setObject:txtLocationBarcode.text forKey:@"barcode"]; 
          strTimeStampToUpload = [CommonFunctions getCurrentTimeStamp:strCurrentTimeStamp];
              [strTimeStampToUpload retain];
              [diccRecordToUpload setObject:strTimeStampToUpload forKey:@"tstamp"];
              
              objService.argsDic=[CommonFunctions getDicAsParameter:diccRecordToUpload] ;
              //special Array: Create Job : currentJobId
              objService.strWebService=[NSString stringWithFormat:@"CreateJob:%d",currJobID];
              objService.strUrl= [NSString stringWithFormat:@"%@%@",[ElogBooksAppDelegate getValueForKey:BASE_URL],PUT_INFO_API];
              objService.ParentNode=@"Responses";
              objService.ChildNode=@"Response";
              objService.retType=isArray;
              [objService performSelector:@selector(setArray) withObject:nil afterDelay:0.1];
          }
          else 
          {
              NSLog(@"Unable to get current jobid ");
              UIAlertView *alert = [[UIAlertView alloc] initWithTitle:APP_TITLE message:[NSString stringWithFormat:@"Please Try Again!"] delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
              [alert show];
              [alert release];
          }
      }
        else 
        {
            //No Internet connection
            //static 
//            strIsCustomerRequireApproval = @"N";
//            strServiceId = @"0";
//            txtService.text = @"This job is for myself";
            
            
            NSInteger currJobID = [DataSource executeInsertQuery:strQuery :YES];
            
            //save the attachments if available
            if ([arrAttachmentsList count]>0)
            {
                //copy the attachments
                for (int i =0;i<[arrAttachmentsList count];i++)
                {
                    [self copyIteminLocal: [[arrAttachmentsList objectAtIndex:i]valueForKey:@"Attachments"]];
                    
                }           
                //Delete unwanted session Attachments
                NSString *LibrayDirectory = [NSHomeDirectory() stringByAppendingPathComponent:@"Library"];
                NSString *DestinationFolder =[LibrayDirectory stringByAppendingPathComponent:NEW_JOBS_IMAGES_FOLDER];
                if ([[NSFileManager defaultManager]removeItemAtPath:DestinationFolder error:nil])
                    NSLog(@"new images folder deleted");   
            }
            
            if ((!([strIsCustomerRequireApproval rangeOfString:@"N"].location == NSNotFound)) &&  ([[txtService text]isEqualToString:@"This job is for myself"]))
            {
                    if (currJobID>0)
                    {
                        //jid from NewJobs Table
                        NSString *strJid =[NSString stringWithFormat:@"%@%d",NEW_JOB,currJobID];
                        if ( [DataSource executeQuery: [NSString stringWithFormat:@"insert into jobs (jid,eid,cid,sid,description,location,job_type,priority,stt,created,IsSynced,eng_complete) values      ('%@',%@,%@,%@,'%@','%@','Non-PM','%@','Assigned','%@',%@,'')",strJid,[ElogBooksAppDelegate getValueForKey:USER_ID],strCid,strServiceId,txtView_Description.text,txtLocation.text,strPriorityId,strCurrentTimeStamp,UN_SYNCED_DATA]])
                        {
                            JobInfoScreen* objJobInfo=[[JobInfoScreen alloc] initWithNibName:@"JobInfoScreen" bundle:nil];
                        objJobInfo.strJid = strJid;
                            [self.navigationController pushViewController:objJobInfo animated:YES];
                            [objJobInfo release];
                            
                        }
                    }
                    else 
                    {              
                        NSLog(@"Unable to get current jobid ");
                        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:APP_TITLE message:[NSString stringWithFormat:@"Please Try Again!"] delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                        [alert show];
                        [alert release];
                        
                    }
            }
            else  if ((!([strIsCustomerRequireApproval rangeOfString:@"N"].location == NSNotFound)) &&  (!([[txtService text]isEqualToString:@"This job is for myself"])))
            {
                //move back
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:APP_TITLE message:@"No Internet Connection Available! \n This job will be sent on next Sync" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                alert.delegate = self;
                [alert show];
                [alert release];
            }
            else  //if (!([strIsCustomerRequireApproval rangeOfString:@"Y"].location == NSNotFound))
            {
                //move back
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:APP_TITLE message:@"No Internet Connection Available! This job will be sent for approval on next Sync" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                alert.delegate = self;
                [alert show];
                [alert release];
            }
        
        }
    }
    else
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:APP_TITLE message:[NSString stringWithFormat:@"Please Enter %@!",StrResult] delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        [alert show];
        [alert release];
    }
}

#pragma mark Parsing delegates
-(void)filedWithError:(NSString *)strMsg forFlage:(NSString *)flage
{
if (!([flage rangeOfString:@"CreateJob"].location==NSNotFound))
{
    //No Internet connection
    //get recently updating curr jobs id
    NSInteger currJobID = [[[flage componentsSeparatedByString:@":"]objectAtIndex:1]intValue];
    
    //save the attachments if available
    if ([arrAttachmentsList count]>0)
    {
        //copy the attachments
        for (int i =0;i<[arrAttachmentsList count];i++)
        {
            [self copyIteminLocal: [[arrAttachmentsList objectAtIndex:i]valueForKey:@"Attachments"]];
            
        }           
        //Delete unwanted session Attachments
        NSString *LibrayDirectory = [NSHomeDirectory() stringByAppendingPathComponent:@"Library"];
        NSString *DestinationFolder =[LibrayDirectory stringByAppendingPathComponent:NEW_JOBS_IMAGES_FOLDER];
        if ([[NSFileManager defaultManager]removeItemAtPath:DestinationFolder error:nil])
            NSLog(@"new images folder deleted");   
    }
    
    if ((!([strIsCustomerRequireApproval rangeOfString:@"N"].location == NSNotFound)) &&  ([[txtService text]isEqualToString:@"This job is for myself"]))
    {
        if (currJobID>0)
        {
            //jid from NewJobs Table
            NSString *strJid =[NSString stringWithFormat:@"%@%d",NEW_JOB,currJobID];
            NSString *strCurrentTimeStamp = [CommonFunctions getCurrentTimeStampForDatabaseInsertion:strTimeStampToUpload];
            if ( [DataSource executeQuery: [NSString stringWithFormat:@"insert into jobs (jid,eid,cid,sid,description,location,job_type,priority,stt,created,IsSynced,eng_complete) values      (%@,%@,%@,%@,'%@','%@','Non-PM','%@','Assigned','%@',%@,'')",strJid,[ElogBooksAppDelegate getValueForKey:USER_ID],strCid,strServiceId,txtView_Description.text,txtLocation.text,strPriorityId,strCurrentTimeStamp,UN_SYNCED_DATA]])
            {
                JobInfoScreen* objJobInfo=[[JobInfoScreen alloc] initWithNibName:@"JobInfoScreen" bundle:nil];
                objJobInfo.strJid = strJid;
                [self.navigationController pushViewController:objJobInfo animated:YES];
                [objJobInfo release];
                
            }
        }
        else 
        {              
            NSLog(@"Unable to get current jobid ");
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:APP_TITLE message:[NSString stringWithFormat:@"Please Try Again!"] delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
            [alert show];
            [alert release];
            
        }
    }
    else  if ((!([strIsCustomerRequireApproval rangeOfString:@"N"].location == NSNotFound)) &&  (!([[txtService text]isEqualToString:@"This job is for myself"])))
    {
        //move back
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:APP_TITLE message:@"No Internet Connection Available! \n This job will be sent on next Sync" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        alert.delegate = self;
        [alert show];
        [alert release];
    }
    else // if (!([strIsCustomerRequireApproval rangeOfString:@"Y"].location == NSNotFound))
    {
        //move back
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:APP_TITLE message:@"No Internet Connection Available! This job will be sent for approval on next Sync" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        alert.delegate = self;
        [alert show];
        [alert release];
    }

}

}
-(void)EndParsingArray:(NSMutableArray *)arrData forFlage:(NSString *)flage
{

    
    
    
if (!([flage rangeOfString:@"CreateJob"].location==NSNotFound))
{
if ([arrData count]>1) // job for approval
{
     if (!([[arrData objectAtIndex:0]rangeOfString:@"Error"].location==NSNotFound))
     {
         //remove the file record from New Jobs table 
         [DataSource executeQuery:[NSString stringWithFormat:@"Delete from NewJobs where jid = %@",[[flage componentsSeparatedByString:@":"]objectAtIndex:1]]];         
         
         
         //Delete unwanted session Attachments
         NSString *LibrayDirectory = [NSHomeDirectory() stringByAppendingPathComponent:@"Library"];
         NSString *DestinationFolder =[LibrayDirectory stringByAppendingPathComponent:NEW_JOBS_IMAGES_FOLDER];
         
         if ([arrAttachmentsList count]>0)          
             if ([[NSFileManager defaultManager]removeItemAtPath:DestinationFolder error:nil])
                 NSLog(@"images folder deleted");
         
         UIAlertView  *alert = [[UIAlertView alloc] initWithTitle:APP_TITLE message:[NSString stringWithFormat:@"%@\n%@\nPlease Try again !",[[[arrData objectAtIndex:0]componentsSeparatedByString:@":"]objectAtIndex:1],[[[arrData objectAtIndex:1]componentsSeparatedByString:@":"]objectAtIndex:1]] delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
         [alert show];
         [alert release];
         
         
         
     }
     else 
    if ((!([[arrData objectAtIndex:1]rangeOfString:@"Success"].location==NSNotFound)) && (!([[arrData objectAtIndex:1]rangeOfString:@"Approval"].location==NSNotFound)))
        {
         if (!([[arrData objectAtIndex:0]rangeOfString:@"Success"].location==NSNotFound) && (!([[arrData objectAtIndex:0]rangeOfString:@"Raised"].location==NSNotFound)) )
            { 
                        
            //Save the attachments for Put Info in uploaded files Table
              if ([arrAttachmentsList count]>0)     
              {
                  
          //copy the attachments
          for (int i =0;i<[arrAttachmentsList count];i++)
          {
              [self copyIteminLocal: [[arrAttachmentsList objectAtIndex:i]valueForKey:@"Attachments"]];
              
          } 
                  
            [self SaveImageInDatabase:[NSString stringWithFormat:@"%d",[[[[arrData objectAtIndex:0]componentsSeparatedByString:@"-"]objectAtIndex:1]intValue]]];
              }

           //remove the file record from New Jobs table 
            [DataSource executeQuery:[NSString stringWithFormat:@"Delete from NewJobs where jid = %@",[[flage componentsSeparatedByString:@":"]objectAtIndex:1]]];         
          
                
                //Delete unwanted session Attachments
                NSString *LibrayDirectory = [NSHomeDirectory() stringByAppendingPathComponent:@"Library"];
                NSString *DestinationFolder =[LibrayDirectory stringByAppendingPathComponent:NEW_JOBS_IMAGES_FOLDER];
                
                 if ([arrAttachmentsList count]>0)          
                if ([[NSFileManager defaultManager]removeItemAtPath:DestinationFolder error:nil])
                    NSLog(@"images folder deleted");
                
                
//                @"this job requires approval, this job will download to your device once it has been approved"
                //and move back         

                UIAlertView *alert ;
              if ([txtService.text isEqualToString: @"This job is for myself"])   // self serviced job
              alert = [[UIAlertView alloc] initWithTitle:APP_TITLE message:@"This job requires approval, this job will download to your device once it has been approved" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                else    
                    alert = [[UIAlertView alloc] initWithTitle:APP_TITLE message:@"This job has been logged.\n Thank you" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                    
                alert.delegate = self;
                [alert show];
                [alert release];
                NSLog(@"Job Successfully sent for approval");
            }
            else 
            {

                NSLog(@"Problem in job creation webservice");  
            }
        }
        else 
        {
        
        NSLog(@"Problem in job creation webservice");  
    }
    }
else if ([arrData count]>0)  //job not for approval
 {

     if (!([[arrData objectAtIndex:0]rangeOfString:@"Error"].location==NSNotFound))
     {
         //remove the file record from New Jobs table 
         [DataSource executeQuery:[NSString stringWithFormat:@"Delete from NewJobs where jid = %@",[[flage componentsSeparatedByString:@":"]objectAtIndex:1]]];         
         
         
         //Delete unwanted session Attachments
         NSString *LibrayDirectory = [NSHomeDirectory() stringByAppendingPathComponent:@"Library"];
         NSString *DestinationFolder =[LibrayDirectory stringByAppendingPathComponent:NEW_JOBS_IMAGES_FOLDER];
         
         if ([arrAttachmentsList count]>0)          
             if ([[NSFileManager defaultManager]removeItemAtPath:DestinationFolder error:nil])
                 NSLog(@"images folder deleted");
         
         UIAlertView  *alert = [[UIAlertView alloc] initWithTitle:APP_TITLE message:[NSString stringWithFormat:@"%@\nPlease Try again!",[[[arrData objectAtIndex:0]componentsSeparatedByString:@":"]objectAtIndex:1]] delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
         
         [alert show];
         [alert release];
         
         
         
     }     
     else 
     if (!([[arrData objectAtIndex:0]rangeOfString:@"Success"].location==NSNotFound))
     {
         
         
             NSString *strJid = [NSString stringWithFormat:@"%d",[[[[arrData objectAtIndex:0]componentsSeparatedByString:@"-"]objectAtIndex:1]intValue]];   
         
         if ([arrAttachmentsList count]>0) 
         {
             //copy the attachments
             for (int i =0;i<[arrAttachmentsList count];i++)
             {
                 [self copyIteminLocal: [[arrAttachmentsList objectAtIndex:i]valueForKey:@"Attachments"]];
                 
             } 
             
             [self SaveImageInDatabase:strJid];
         }
         
         NSString *LibrayDirectory = [NSHomeDirectory() stringByAppendingPathComponent:@"Library"];
         NSString *DestinationFolder =[LibrayDirectory stringByAppendingPathComponent:NEW_JOBS_IMAGES_FOLDER];
         
         if ([[NSFileManager defaultManager]removeItemAtPath:DestinationFolder error:nil])
             NSLog(@"new images folder deleted");
         
         
         if ((!([strIsCustomerRequireApproval rangeOfString:@"N"].location == NSNotFound)) &&  ([[txtService text]isEqualToString:@"This job is for myself"]))
         {
           // navigate to job info screen
             //insert the raised job in jobs Table
             if ([self IsTextFieldEmpty:txtLocation.text])
                 txtLocation.text = @"";
             NSString *strCurrentTimeStamp = [CommonFunctions getCurrentTimeStampForDatabaseInsertion:strTimeStampToUpload];
             if ( [DataSource executeQuery: [NSString stringWithFormat:@"insert into jobs (jid,eid,cid,sid,description,location,job_type,priority,stt,created,IsSynced,eng_complete) values      (%@,%@,%@,%@,'%@','%@','Non-PM','%@','Assigned','%@',%@,'')",strJid,[ElogBooksAppDelegate getValueForKey:USER_ID],strCid,strServiceId,txtView_Description.text,txtLocation.text,strPriorityId,strCurrentTimeStamp,SYNCED_DATA]])
             {
                 
                 //delete the moved id
                  [DataSource executeQuery:[NSString stringWithFormat:@"Delete from NewJobs where jid = %@",[[flage componentsSeparatedByString:@":"]objectAtIndex:1]]];
                 
                 
                 JobInfoScreen* objJobInfo=[[JobInfoScreen alloc] initWithNibName:@"JobInfoScreen" bundle:nil];
                 objJobInfo.strJid = strJid;
                 [self.navigationController pushViewController:objJobInfo animated:YES];
                 [objJobInfo release];
             }
             else 
             {
                 [self filedWithError:@"Problem in jobs table webservice" forFlage:flage];
             }
             
             
         }
         else if ((!([strIsCustomerRequireApproval rangeOfString:@"N"].location == NSNotFound)) &&  (!([[txtService text]isEqualToString:@"This job is for myself"])))
         
         {
             
         //delete the moved id
         [DataSource executeQuery:[NSString stringWithFormat:@"Delete from NewJobs where jid = %@",[[flage componentsSeparatedByString:@":"]objectAtIndex:1]]];

             
           UIAlertView  *alert = [[UIAlertView alloc] initWithTitle:APP_TITLE message:@"This job has been logged.\n Thank you" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
             alert.delegate = self;
             [alert show];
             [alert release];

         }
         

         
         
     }
     else 
     {
         //Job Creation Failed
         //No Internet connection
         //get recently updating curr jobs id
         NSInteger currJobID = [[[flage componentsSeparatedByString:@":"]objectAtIndex:1]intValue];
         
         //save the attachments if available
         if ([arrAttachmentsList count]>0)
         {
             //copy the attachments
             for (int i =0;i<[arrAttachmentsList count];i++)
             {
                 [self copyIteminLocal: [[arrAttachmentsList objectAtIndex:i]valueForKey:@"Attachments"]];
                 
             }           
             //Delete unwanted session Attachments
             NSString *LibrayDirectory = [NSHomeDirectory() stringByAppendingPathComponent:@"Library"];
             NSString *DestinationFolder =[LibrayDirectory stringByAppendingPathComponent:NEW_JOBS_IMAGES_FOLDER];
             if ([[NSFileManager defaultManager]removeItemAtPath:DestinationFolder error:nil])
                 NSLog(@"new images folder deleted");   
         }
         
         if ((!([strIsCustomerRequireApproval rangeOfString:@"N"].location == NSNotFound)) &&  ([[txtService text]isEqualToString:@"This job is for myself"]))
         {
             if (currJobID>0)
             {
                 //jid from NewJobs Table
                 NSString *strJid =[NSString stringWithFormat:@"%@%d",NEW_JOB,currJobID];
                 NSString *strCurrentTimeStamp = [CommonFunctions getCurrentTimeStampForDatabaseInsertion:strTimeStampToUpload];
                 if ( [DataSource executeQuery: [NSString stringWithFormat:@"insert into jobs (jid,eid,cid,sid,description,location,job_type,priority,stt,created,IsSynced,eng_complete) values      (%@,%@,%@,%@,'%@','%@','Non-PM','%@','Assigned','%@',%@,'')",strJid,[ElogBooksAppDelegate getValueForKey:USER_ID],strCid,strServiceId,txtView_Description.text,txtLocation.text,strPriorityId,strCurrentTimeStamp,UN_SYNCED_DATA]])
                 {
                     JobInfoScreen* objJobInfo=[[JobInfoScreen alloc] initWithNibName:@"JobInfoScreen" bundle:nil];
                     objJobInfo.strJid = strJid;
                     [self.navigationController pushViewController:objJobInfo animated:YES];
                     [objJobInfo release];
                     
                 }
             }
             else 
             {              
                 NSLog(@"Unable to get current jobid ");
                 UIAlertView *alert = [[UIAlertView alloc] initWithTitle:APP_TITLE message:[NSString stringWithFormat:@"Please Try Again!"] delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                 [alert show];
                 [alert release];
                 
             }
         }
         else  if ((!([strIsCustomerRequireApproval rangeOfString:@"N"].location == NSNotFound)) &&  (!([[txtService text]isEqualToString:@"This job is for myself"])))
         {
             //move back
             UIAlertView *alert = [[UIAlertView alloc] initWithTitle:APP_TITLE message:@"No Internet Connection Available! \n This job will be sent on next Sync" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
             alert.delegate = self;
             [alert show];
             [alert release];
         }
         else // if (!([strIsCustomerRequireApproval rangeOfString:@"Y"].location == NSNotFound))
         {
             //move back
             UIAlertView *alert = [[UIAlertView alloc] initWithTitle:APP_TITLE message:@"No Internet Connection Available! This job will be sent for approval on next Sync" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
             alert.delegate = self;
             [alert show];
             [alert release];
         }
         
     }
 }
else  //job error 
{
    //remove the file record from New Jobs table 
    [DataSource executeQuery:[NSString stringWithFormat:@"Delete from NewJobs where jid = %@",[[flage componentsSeparatedByString:@":"]objectAtIndex:1]]];         
    
    
    //Delete unwanted session Attachments
    NSString *LibrayDirectory = [NSHomeDirectory() stringByAppendingPathComponent:@"Library"];
    NSString *DestinationFolder =[LibrayDirectory stringByAppendingPathComponent:NEW_JOBS_IMAGES_FOLDER];
    
    if ([arrAttachmentsList count]>0)          
        if ([[NSFileManager defaultManager]removeItemAtPath:DestinationFolder error:nil])
            NSLog(@"images folder deleted");
    
    UIAlertView  *alert = [[UIAlertView alloc] initWithTitle:APP_TITLE message:@" !" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    
    alert.delegate = self;
    [alert show];
    [alert release];
    
    
    
}     
//{
//      //Job Creation Failed
//      //No Internet connection
//      //get recently updating curr jobs id
//      NSInteger currJobID = [[[flage componentsSeparatedByString:@":"]objectAtIndex:1]intValue];
//      
//      //save the attachments if available
//      if ([arrAttachmentsList count]>0)
//      {
//          //copy the attachments
//          for (int i =0;i<[arrAttachmentsList count];i++)
//          {
//              [self copyIteminLocal: [[arrAttachmentsList objectAtIndex:i]valueForKey:@"Attachments"]];
//              
//          }           
//          //Delete unwanted session Attachments
//          NSString *LibrayDirectory = [NSHomeDirectory() stringByAppendingPathComponent:@"Library"];
//          NSString *DestinationFolder =[LibrayDirectory stringByAppendingPathComponent:NEW_JOBS_IMAGES_FOLDER];
//          if ([[NSFileManager defaultManager]removeItemAtPath:DestinationFolder error:nil])
//              NSLog(@"new images folder deleted");   
//      }
//      
//      if ((!([strIsCustomerRequireApproval rangeOfString:@"N"].location == NSNotFound)) &&  ([[txtService text]isEqualToString:@"This job is for myself"]))
//      {
//          if (currJobID>0)
//          {
//              //jid from NewJobs Table
//              NSString *strJid =[NSString stringWithFormat:@"%@%d",NEW_JOB,currJobID];
//              NSString *strCurrentTimeStamp = [CommonFunctions getCurrentTimeStampForDatabaseInsertion:strTimeStampToUpload];
//              if ( [DataSource executeQuery: [NSString stringWithFormat:@"insert into jobs (jid,eid,cid,sid,description,location,job_type,priority,stt,created,IsSynced) values      (%@,%@,%@,%@,'%@','%@','Non-PM','%@','Assigned','%@',%@)",strJid,[ElogBooksAppDelegate getValueForKey:USER_ID],strCid,strServiceId,txtView_Description.text,txtLocation.text,strPriorityId,strCurrentTimeStamp,UN_SYNCED_DATA]])
//              {
//                  JobInfoScreen* objJobInfo=[[JobInfoScreen alloc] initWithNibName:@"JobInfoScreen" bundle:nil];
//                  objJobInfo.strJid = strJid;
//                  [self.navigationController pushViewController:objJobInfo animated:YES];
//                  [objJobInfo release];
//                  
//              }
//          }
//          else 
//          {              
//              NSLog(@"Unable to get current jobid ");
//              UIAlertView *alert = [[UIAlertView alloc] initWithTitle:APP_TITLE message:[NSString stringWithFormat:@"Please Try Again!"] delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
//              [alert show];
//              [alert release];
//              
//          }
//      }
//      else  if ((!([strIsCustomerRequireApproval rangeOfString:@"N"].location == NSNotFound)) &&  (!([[txtService text]isEqualToString:@"This job is for myself"])))
//      {
//          //move back
//          UIAlertView *alert = [[UIAlertView alloc] initWithTitle:APP_TITLE message:@"No Internet Connection Available! \n This job will be sent on next Sync" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
//          alert.delegate = self;
//          [alert show];
//          [alert release];
//      }
//      else // if (!([strIsCustomerRequireApproval rangeOfString:@"Y"].location == NSNotFound))
//      {
//          //move back
//          UIAlertView *alert = [[UIAlertView alloc] initWithTitle:APP_TITLE message:@"No Internet Connection Available! This job will be sent for approval on next Sync" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
//          alert.delegate = self;
//          [alert show];
//          [alert release];
//      }
//      
//  }       
}
}


-(void)SaveImageInDatabase :(NSString *)strjid
{
    NSString *strTimeStampValue = [CommonFunctions getCurrentTimeStampForDatabaseInsertion:strTimeStampToUpload];
    for (int i=0;i<[arrAttachmentsList count];i++)
    {
        NSString *strImageTitle = [[arrAttachmentsList objectAtIndex:i]valueForKey:@"Attachments"]; 
    if ([DataSource executeQuery:[NSString stringWithFormat:@"INSERT INTO Uploaded_files (fid,uid,cid,iid,as_id,type,doc_type,as_type,expired,reveal,orig_name,title,dir,created,expiry,IsSynced)values('TEMP_FILE_ID',%@,0,0,'%@','','','J','','Y','%@','%@','jobs','%@','',%@)",[ElogBooksAppDelegate getValueForKey:USER_ID],strjid,[CommonFunctions ConvertDateToOriginalName:strTimeStampValue:strjid],strImageTitle,strTimeStampValue,UN_SYNCED_DATA ]] )
        NSLog(@"Uploaded file details stored in db");
    }
}






#pragma not Used Directory 
-(void)Emptydirectory 
{
    NSString *LibrayDirectory = [NSHomeDirectory() stringByAppendingPathComponent:@"Library"];
    NSString *DestinationFolder =[LibrayDirectory stringByAppendingPathComponent:NEW_JOBS_IMAGES_FOLDER];
    
    NSFileManager *fileMgr = [NSFileManager defaultManager];
    NSArray *fileArray = [fileMgr contentsOfDirectoryAtPath:DestinationFolder error:nil];
    for (NSString *filename in fileArray)  {
        
        [fileMgr removeItemAtPath:[DestinationFolder stringByAppendingPathComponent:filename] error:NULL];
    }
}

-(void)copyIteminLocal :(NSString *)Unique_imgName
{
    

    NSError*error;
    NSString *documentsDirectory = [NSHomeDirectory() stringByAppendingPathComponent:@"Library"];
    NSString *dataPath = @"";
    
        dataPath = [documentsDirectory stringByAppendingPathComponent:NEW_JOBS_IMAGES_FOLDER];

    NSString *strSourcePath = [dataPath stringByAppendingPathComponent: [NSString stringWithFormat:@"%@",Unique_imgName]] ;

    


    
    NSString *DestinationFolder =[documentsDirectory stringByAppendingPathComponent:UN_SYNCEDIMAGES_FOLDER];
    
    if (![[NSFileManager defaultManager] fileExistsAtPath:DestinationFolder])
        [[NSFileManager defaultManager]createDirectoryAtPath:DestinationFolder withIntermediateDirectories:NO attributes:nil error:&error];
    
    NSString *strDestinationPath = [DestinationFolder stringByAppendingPathComponent: [NSString stringWithFormat:@"%@",Unique_imgName]] ;
    
 if ([[NSFileManager defaultManager] fileExistsAtPath:dataPath])
 {
  
  if (  [ [NSFileManager defaultManager]copyItemAtPath:strSourcePath toPath:strDestinationPath error:&error])
     

     {
         if ([[NSFileManager defaultManager]removeItemAtPath:strSourcePath error:&error] )
         {
             NSLog(@"Source file deleted");             
         }
         else 
         {
             NSLog(@"Unable to delete sou:%@ ",[error description]);
         }
     }
     else 
     {
         
    NSLog(@"Unable To copy:%@ ",[error description]);         
     }
 }
else 
{
   NSLog(@"Unable To copy:%@ ",[error description]); 
}

}

#pragma mark UIPickerview Delegates
#pragma mark LoadPicker Picker Delegates
-(void)LoadPicker:(id)sender
{
    [txtLocation resignFirstResponder];
    if (txtView_Description!=nil)
    [txtView_Description resignFirstResponder];
    
    
 objPicker = [[PickerViewControl alloc] initWithFrame:[self.view frame]];

    
    UITextField *txtField = (UITextField *) sender;
    if (txtField == txt_Customer)
    {
    objPicker.arrPickerData = arrCustomers;
        objPicker.strSelectKey = CUSTOMERS_CUSTOMER;
    objPicker.selectedIndex=lastSelCustomer;
    objPicker._delegate=self;
    [objPicker setTag:CUSTOMER_TAG];
    [scrView setContentOffset:CGPointMake(0, 25) animated:YES];
    }
    else if (txtField == txtJobGroup)
    {
        objPicker.arrPickerData = arrJobGroup;
        objPicker.strSelectKey = JOB_GROUPS_DESCR;
        objPicker.selectedIndex=lastSelJobGroup;
        objPicker._delegate=self;
        [objPicker setTag:GROUP_TAG];
      [scrView setContentOffset:CGPointMake(0, 50) animated:YES];
    }
    else if (txtField == txtPriority)
    {
        objPicker.arrPickerData = arrPriority;
        objPicker.strSelectKey = CUST_PRIORITIES_PRIORITY;
        objPicker.selectedIndex=lastSelPriority;
        objPicker._delegate=self;
        [objPicker setTag:PRIORITY_TAG];
    [scrView setContentOffset:CGPointMake(0, 75) animated:YES];
    }
    else if (txtField == txtService)
    {
        objPicker.arrPickerData = arrServices;
        objPicker.strSelectKey = SERVICE_NAME;
        objPicker.selectedIndex=lastSelService;
        objPicker._delegate=self;
        [objPicker setTag:SERVICE_TAG];
        [scrView setContentOffset:CGPointMake(0, 100) animated:YES];
    } 
    [objPicker setPicker];
    [self.view addSubview:objPicker];
}
-(void)pickerCloseWithTag:(int)tag
{
    [scrView setContentOffset:CGPointMake(0, 0) animated:YES];
    
    if (tag == CUSTOMER_TAG)
    {
        [self LoadServicesArray];
        [self LoadPriorityArray];
    }
      else if (tag == GROUP_TAG)
        [self LoadPriorityArray];
}
-(void)selectedRow:(int)row andValue:(NSString *)strVal andTag:(int)tag selectedRow:(int)selRow
{
    if (tag == CUSTOMER_TAG)
    {
        lastSelCustomer = selRow;
        strCid =  [[arrCustomers objectAtIndex:selRow]valueForKey:CUSTOMERS_ID];
        txt_Customer.text = [[arrCustomers objectAtIndex:selRow]valueForKey:CUSTOMERS_CUSTOMER];
        

    }
    else if (tag == GROUP_TAG)
    {
        lastSelJobGroup = selRow;
        
//        strJob_groupsId =  [[arrJobGroup objectAtIndex:selRow]valueForKey:JOB_GROUPS_JGPID];
                strJob_groupsId =  [[arrJobGroup objectAtIndex:selRow]valueForKey:JOB_GROUPS_ID];
        txtJobGroup.text = [[arrJobGroup objectAtIndex:selRow]valueForKey:JOB_GROUPS_DESCR];        
    }
    else if (tag == PRIORITY_TAG)
    {
        lastSelPriority = selRow;
        strPriorityId =  [[arrPriority objectAtIndex:selRow]valueForKey:PRIORITIES_ID];
        txtPriority.text = [[arrPriority objectAtIndex:selRow]valueForKey:CUST_PRIORITIES_PRIORITY];        
    }
    else if (tag == SERVICE_TAG)
    {
        lastSelService = selRow;
        strServiceId =  [[arrServices objectAtIndex:selRow]valueForKey:SERVICE_ID];
        txtService.text = [[arrServices objectAtIndex:selRow]valueForKey:SERVICE_NAME];        
        
    }
}

#pragma mark BtnCamera Tapped
-(IBAction)btnPhotoTapped:(id)Sender 
{
    
    UploadImageScreen* objNav=[[UploadImageScreen alloc] initWithNibName:@"UploadImageScreen" bundle:nil];
    objNav.strIsToCreateJob = @"YES";
    objNav.strIsTakePhoto = @"YES";
    [self.navigationController pushViewController:objNav animated:YES];
    [objNav release];
    
}
-(IBAction)btnCameraTapped:(id)Sender 
{
    UploadImageScreen* objNav=[[UploadImageScreen alloc] initWithNibName:@"UploadImageScreen" bundle:nil];
    objNav.strIsToCreateJob = @"YES";
    objNav.strIsTakeCamera = @"YES";
    [self.navigationController pushViewController:objNav animated:YES];
    [objNav release];
}


#pragma mark UITextField Delegates
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
   
    if (textField == txtLocation)
    {
    [scrView setContentOffset:CGPointMake(0, 50) animated:YES];  
    return YES;       
    }
    else 
    {
        if ( (textField == txt_Customer) ||  (textField == txtJobGroup) ||  (textField == txtPriority))
        {
            if( ([textField.text rangeOfString:@"Available"].location == NSNotFound)  )
            [self LoadPicker:textField];   
        }
        else if (textField == txtService)
        {
            if ([arrServices count]>1)
            [self LoadPicker:textField];                   
        }
        else if (textField == txtLocationBarcode)
        {
            [self btnBarcodeTapped];
        }
    }
    return NO;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
   [scrView setContentOffset:CGPointMake(0, 0) animated:YES];
    [textField resignFirstResponder];
    return YES;
}

#pragma mark UITextView Delegate
- (BOOL)textViewShouldBeginEditing:(UITextView *)textView
{
    [scrView setContentOffset:CGPointMake(0, 0) animated:YES];
    return YES;
}
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text 
{    
    if([text isEqualToString:@"\n"]) {
        [textView resignFirstResponder];
        return NO;
    }
    return YES;
}


#pragma BtnBarcode Tapped
-(IBAction)btnBarcodeTapped
{
    UpdatePointScreen* objNav=[[UpdatePointScreen alloc] initWithNibName:@"UpdatePointScreen" bundle:nil];
    objNav.strIsCreatingJob = @"YES";
    [self.navigationController pushViewController:objNav animated:YES];
    [objNav release];
}
- (void)viewDidUnload
{
    [super viewDidUnload];

    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
@end
