

#import <UIKit/UIKit.h>

@interface UIView (ModalAnimationHelper)
+ (void) commitModalAnimations;
@end
