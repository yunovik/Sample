//
//  MEAlertView.h
//  MEDENTRY
//
//  Created by Mac-1 on 11/22/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//


#import <UIKit/UIKit.h>
@protocol MEAlertViewDelegate

@optional
-(IBAction)btnUnableTocomplete:(UIButton *)Sender andTag:(int)alertTag;
-(IBAction)btnOk_Tapped:(UIButton *)Sender andTag:(int)alertTag;
-(IBAction)btnCancel_Tapped:(UIButton *)Sender andTag:(int)alertTag;
@end


@interface MEAlertView : UIView {
	UIView *transImage;
	
	UIActivityIndicatorView *actView;
	
	BOOL isAnimating;
	
    UIViewController *_self;
    id <MEAlertViewDelegate> delegate;
}
@property (nonatomic, assign) id <MEAlertViewDelegate> delegate;
@property (assign, readwrite) BOOL isAnimating;
//@property (nonatomic,assign)BOOL isHavingAttachment;
@property (nonatomic,retain)NSString *strLabelMessage;
- (id)initWithIndicatorMessage:(NSString *)strMessage delegate:(UIViewController *)_delegate;

- (id)initWithMessage:(NSString *)strMessage delegate:(UIViewController *)_delegate cancelButtonTitle:(NSString *)cancelTitle otherButtonTitles:(NSString *)otherTitle;


-(BOOL)isAnimatingFun;

-(void)Show;
-(void)SingleShow;
//-(void)remove;
-(void)removeFrom:(UIViewController *)_delegate;
-(void)btnUnableTocompleteTapped:(id)Sender;
-(IBAction)btnNo_Tapped:(id)Sender;
//- (id)initWithMessage:(NSString *)strMessage;
@end
