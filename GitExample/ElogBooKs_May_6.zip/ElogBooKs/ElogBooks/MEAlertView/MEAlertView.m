//
//  MEAlertView.m
//  MEDENTRY
//
//  Created by Mac-1 on 11/22/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MEAlertView.h"
#import <UIKit/UIKit.h>
#import "UIView-ModalAnimationHelper.h"

static float ALPHA=0.8;

static float ALERT_Y=110;

@implementation MEAlertView
@synthesize delegate,isAnimating,strLabelMessage;

- (id)initWithMessage:(NSString *)strMessage  delegate:(UIViewController *)_delegate cancelButtonTitle:(NSString *)cancelTitle otherButtonTitles:(NSString *)otherTitle
{
    
	isAnimating=NO;
    
	float x=22,y=ALERT_Y,w=276,h=105;
	//x=320-w;
	
	float btnGap=7.5;
	//float btnW = (w-(3*btnGap))/2;
	float btnW = 127;
	float btnL = 42;
	
    //    otherTitle = @"Unable to complete,Completed";
    
	UIFont *fnt=[UIFont fontWithName:@"Arial" size:16];
    
	CGSize textSize = [strMessage sizeWithFont:fnt constrainedToSize:CGSizeMake(w-25, 20000.00f) lineBreakMode:UILineBreakModeWordWrap];
	float alertL=h + textSize.height;
    
    if(alertL<=161 )
    {
        alertL=161;
    }
    
	CGRect frame=CGRectMake(x, y, w,alertL);
    
    if ([otherTitle length]>0)
        self = [super initWithFrame:CGRectMake(0, y, 320, alertL)];
    else
        self = [super initWithFrame:frame];
    
    if (self) {
        
		[_delegate.navigationController.navigationBar setUserInteractionEnabled:NO];
        
		transImage = [[UIView alloc] initWithFrame:[_delegate.view frame]];
		[transImage setAlpha:0.0];
		[transImage setBackgroundColor:[UIColor blackColor]];
		[transImage setAlpha:ALPHA];
		[_delegate.view addSubview:transImage];
        
        //        [UIView beginAnimations:nil context:nil];
        //		[UIView setAnimationDuration:0.1f];
        //		[UIView commitAnimations];
		
		//[_delegate.view bringSubviewToFront:transImage];
        
        [self setBackgroundColor:[UIColor clearColor]];
        //- (UIImage *)stretchableImageWithLeftCapWidth:(NSInteger)leftCapWidth topCapHeight:(NSInteger)topCapHeight;
        
        UIImage *img = [[UIImage imageNamed:@"alert-bg.png"] stretchableImageWithLeftCapWidth:0 topCapHeight:50];
        
        UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];
        [imgView setImage:img];
        [self addSubview:imgView];
        
        
        UILabel *lblTitle = [[UILabel alloc]initWithFrame:CGRectMake(12, 17, 250, 30)];
        [lblTitle setFont:FONT_NEUE_BOLD_SIZE(14) ];
		[lblTitle setTextColor:[UIColor whiteColor]];
		[lblTitle setTextAlignment:UITextAlignmentCenter];
		[lblTitle setBackgroundColor:[UIColor clearColor]];
		[self addSubview:lblTitle];
        
		
		UILabel *lblMesssage = [[UILabel alloc] init];
        
		[lblMesssage setFont:FONT_NEUE_SIZE(12)];
		[lblMesssage setTextColor:[UIColor whiteColor]];
		[lblMesssage setTextAlignment:UITextAlignmentCenter];
        
		[lblMesssage setMultipleTouchEnabled:YES];
		[lblMesssage setBackgroundColor:[UIColor clearColor]];
		[lblMesssage setFrame:CGRectMake(5, 52, 266, 50)];
		[lblMesssage setText:strMessage];
        [lblMesssage setNumberOfLines:0];
        [lblMesssage setLineBreakMode:UILineBreakModeWordWrap];
		[self addSubview:lblMesssage];
        
		if([otherTitle isEqualToString:@""] || [otherTitle length]<=0)
        {
			
            [lblTitle setText:@"Sorry! Wrong Order"];
            [lblMesssage setFont:fnt];
            [lblMesssage setText:@"You must complete the patrol points in the correct order."];
            
			UIButton *btnNo = [[UIButton alloc] initWithFrame:CGRectMake((w/2) - (btnW/2) ,alertL -(btnL+btnGap),btnW,btnL)];
			[btnNo setImage:[CommonFunctions AlertButton:cancelTitle andFrame:[btnNo frame] image:@"light-red.png"] forState:UIControlStateNormal];
			[btnNo setTag:1];
			[btnNo addTarget:self action:@selector(btnNo_Tapped:) forControlEvents:UIControlEventTouchUpInside];
			[self addSubview:btnNo];
            [btnNo release];
            
		}else
        {
            //move lables accordingly
            CGRect Frame = [lblMesssage frame];
            Frame.origin.x = Frame.origin.x +20;
            [lblMesssage setFrame:Frame];
            
            CGRect Frame1 = [lblTitle frame];
            Frame1.origin.x = Frame1.origin.x +20;
            [lblTitle setFrame:Frame1];
            
            [lblTitle setText:@"Patrol Point"];
            NSLog(@"%@",[strLabelMessage description]);
            [lblMesssage setText:strMessage];
            NSArray *arrTitlenames = [[NSArray alloc]initWithArray:[otherTitle componentsSeparatedByString:@","]];
            
            
            
            UIButton *btnUnableTocomplete = [[UIButton alloc] initWithFrame:CGRectMake(5,alertL -(btnL+btnGap),110,btnL)];
			[btnUnableTocomplete setImage:[CommonFunctions AlertButton:[arrTitlenames objectAtIndex:0]  andFrame:[btnUnableTocomplete frame] image:@"light-red.png"] forState:UIControlStateNormal];
			[btnUnableTocomplete setTag:0];
			[btnUnableTocomplete addTarget:self action:@selector(btnUnableTocompleteTapped:) forControlEvents:UIControlEventTouchUpInside];
			[self addSubview:btnUnableTocomplete];
            
            
            
			UIButton *btncomplete = [[UIButton alloc] initWithFrame:CGRectMake(5+110+btnGap, alertL -(btnL+btnGap),90,btnL)];
			[btncomplete setImage:[CommonFunctions AlertButton:[arrTitlenames objectAtIndex:1] andFrame:[btncomplete frame] image:@"light-red.png"] forState:UIControlStateNormal];
			[btncomplete setTag:0];
			[btncomplete addTarget:self action:@selector(btnCompleteTapped:) forControlEvents:UIControlEventTouchUpInside];
			
			[self addSubview:btncomplete];
			
            
			UIButton *btnNo = [[UIButton alloc] initWithFrame:CGRectMake(btnGap+5+200+btnGap,alertL -(btnL+btnGap) ,91,btnL)];
			[btnNo setImage:[CommonFunctions AlertButton:cancelTitle andFrame:[btnNo frame] image:@"dark-red.png"] forState:UIControlStateNormal];
			[btnNo setTag:1];
			[btnNo addTarget:self action:@selector(btnNo_Tapped:) forControlEvents:UIControlEventTouchUpInside];
			[self addSubview:btnNo];
            
            
            [btnUnableTocomplete release];
            [btnNo release];
            // YES : UIButton *btnYes = [[UIButton alloc] initWithFrame:CGRectMake(btnGap,alertL -(btnL+btnGap) ,btnW,btnL)];
            // NO  : UIButton *btnNo = [[UIButton alloc] initWithFrame:CGRectMake(btnW+(btnGap*2),alertL -(btnL+btnGap),btnW,btnL)];
		}
        
        //[self setBackgroundColor:[CommonFunctions getBackAlertImageColor:[self frame] andImage:@"alert-bg.png"]];
        
        //        [self setBackgroundColor:[UIColor blackColor]];
        //		[self setClipsToBounds:YES];
        //		[[self layer] setBorderColor:[[UIColor whiteColor] CGColor]];
        //		[[self layer] setCornerRadius:2];
        //		[[self layer] setBorderWidth:2.0];
		
        
        [lblTitle release];
        //        [lblMesssage release];
        if (_delegate !=nil)
            _self = _delegate;
		[_delegate.view addSubview:self];
    }
	
    return self;
}

- (id)initWithIndicatorMessage:(NSString *)strMessage delegate:(UIViewController *)_delegate
{
	
	float x=22,y=ALERT_Y,w=276,h=110;
    
	//float x=320,y=200,w=250,h=90;
	//x=320-w;
	
	UIFont *fnt=FONT_NEUE_SIZE(14);
	
	CGSize textSize = [strMessage sizeWithFont:fnt constrainedToSize:CGSizeMake(w-10, 20000.00f) lineBreakMode:UILineBreakModeWordWrap];
	
	float alertL=h + textSize.height;
    
    if(alertL<=143 )
    {
        alertL=143;
    }
    
	CGRect frame=CGRectMake(x, y, w,alertL);
	
    self = [super initWithFrame:frame];
	
    if (self) {
		
		[_delegate.navigationController.navigationBar setUserInteractionEnabled:NO];
		
		transImage = [[UIView alloc] initWithFrame:[_delegate.view frame]];
		[transImage setBackgroundColor:[UIColor blackColor]];
		[transImage setAlpha:ALPHA];
		[_delegate.view addSubview:transImage];
        
        
        //		[transImage setAlpha:0.0];
        //      [UIView beginAnimations:nil context:nil];
        //		[UIView setAnimationDuration:0.5f];
        //		[UIView commitAnimations];
		
        //      [_delegate.view bringSubviewToFront:transImage];
		
        //		UIImageView *titleImage = [[UIImageView alloc] initWithFrame:CGRectMake(0, 12, 200, 28)];
        //		titleImage.center=CGPointMake(w/2, titleImage.center.y);
        //		[titleImage setContentMode:UIViewContentModeCenter];
        //		[titleImage setImage:[UIImage imageNamed:@"AlertTitle.png"]];
        //		[self addSubview:titleImage];
        
        
        
        UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];
        [imgView setImage:[UIImage imageNamed:@"alert-bg.png"]];
        [self addSubview:imgView];
        
        
        UILabel *lblTitle = [[UILabel alloc]initWithFrame:CGRectMake(0, 17, 276, 18)];
        [lblTitle setFont:FONT_NEUE_SIZE(14)];
		[lblTitle setTextColor:[UIColor whiteColor]];
		[lblTitle setTextAlignment:UITextAlignmentCenter];
		[lblTitle setBackgroundColor:[UIColor clearColor]];
		[lblTitle setText:@"One Moment"];
		[self addSubview:lblTitle];
        
		UILabel *lblMesssage = [[UILabel alloc] init];
		[lblMesssage setFont:fnt];
		[lblMesssage setTextColor:[UIColor whiteColor]];
		[lblMesssage setTextAlignment:UITextAlignmentCenter];
		[lblMesssage setNumberOfLines:0];
		[lblMesssage setMultipleTouchEnabled:YES];
		[lblMesssage setBackgroundColor:[UIColor clearColor]];
		[lblMesssage setFrame:CGRectMake(5, 46, 266, textSize.height+10)];
		[lblMesssage setText:strMessage];
		
		[self addSubview:lblMesssage];
		
		actView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite];
		
		NSLog(@"------ : %f",textSize.height+10);
		[actView setCenter:CGPointMake(138, textSize.height+70)];
		
		[actView startAnimating];
		
		[self addSubview:actView];
        
        
        
        
        [self setBackgroundColor:[UIColor clearColor]];
		//[self setBackgroundColor:[CommonFunctions getBackAlertImageColor:[self frame] andImage:@"alert-bg.png"]];
        
        
        //		[self setClipsToBounds:YES];
        //		[[self layer] setBorderColor:[[UIColor whiteColor] CGColor]];
        //		[[self layer] setCornerRadius:2];
        //		[[self layer] setBorderWidth:2.0];
        
        [lblTitle release];
        [lblMesssage release];
        
		[_delegate.view addSubview:self];
    }
	
    return self;
}


-(BOOL)isAnimatingFun
{
	return isAnimating;
}



-(void)SingleShow{
	
	isAnimating=YES;
    
	// Return back to 100%
	[UIView beginAnimations:nil context:UIGraphicsGetCurrentContext()];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
	[UIView setAnimationDuration:0.1f];
	self.transform = CGAffineTransformMakeScale(1.0f, 1.0f);
	//[UIView commitModalAnimations];
    [UIView commitAnimations];
}

-(void)Show{
	
	isAnimating=YES;
    
    // Bounce to 115% of the normal size
	[UIView beginAnimations:nil context:UIGraphicsGetCurrentContext()];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
	[UIView setAnimationDuration:0.3f];
	self.transform = CGAffineTransformMakeScale(1.10f, 1.10f);
	//[UIView commitModalAnimations];
    [UIView commitAnimations];
    
    
	// Return back to 100%
	[UIView beginAnimations:nil context:UIGraphicsGetCurrentContext()];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
	[UIView setAnimationDuration:0.2f];
	self.transform = CGAffineTransformMakeScale(1.0f, 1.0f);
	//[UIView commitModalAnimations];
    [UIView commitAnimations];
    
}


-(void)removeFrom:(UIViewController *)_delegate{
	
	isAnimating=NO;
    
	if(_delegate!=nil)
		[_delegate.navigationController.navigationBar setUserInteractionEnabled:YES];
    
    if (_self !=nil)
        [_self.navigationController.navigationBar setUserInteractionEnabled:YES];
    //[UIView beginAnimations:nil context:UIGraphicsGetCurrentContext()];
    [UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.5];
	//self.transform = CGAffineTransformMakeScale(1.0f, 1.0f);
    self.alpha = 0.0f;
	//[UIView commitModalAnimations];
    [UIView commitAnimations];
    
    // Restore the bar button
    
    //	CGRect frm = [self frame];
    //	frm.origin.x=320;
    //	frm.size.width=0;
    //
    //	[UIView beginAnimations:@"flipview" context:nil];
    //	[UIView setAnimationDuration:0.5f];
    //
    //	[self setFrame:frm];
    //	[transImage setAlpha:0.00];
    //
    //	[UIView commitAnimations];
	
    if(transImage != nil)
        [transImage removeFromSuperview];
    
	[transImage release];
	
}

-(IBAction)btnCompleteTapped:(id)Sender{
	
	
	[self removeFrom:nil];
	
	NSLog(@"Tapped : %d",[Sender tag]);
	[delegate btnOk_Tapped:Sender andTag:[self tag]];
    
}

-(void)btnUnableTocompleteTapped:(id)Sender
{
    [self removeFrom:nil];
    [delegate btnUnableTocomplete:Sender andTag:[self tag]];
    
}
-(IBAction)btnNo_Tapped:(id)Sender
{
    
	[self removeFrom:nil];
	NSLog(@"Tapped : %d",[Sender tag]);
	[delegate btnCancel_Tapped:Sender andTag:[self tag]];
	//[delegate btnNo_Tapped:Sender];
}

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect {
 // Drawing code.
 }
 */

- (void)dealloc {
	
    [super dealloc];
}


@end
