
//
//  CommonFunctions.m
//  TestTagFast
//
//  Created by Mac-1 on 7/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "CommonFunctions.h"

@implementation CommonFunctions


-(id)init
{
self = [super init];
   if (self) 
    {
       
    }
    return self;
}


+(UIView*)AlertWithMessage:(NSString *)msg
{
	
	UIView *alertView = [[UIView alloc] init];
    
    [alertView setBackgroundColor:[UIColor clearColor]];
    
	UIView *tempView = [[UIView alloc] init];
	
	UIView *backImage = [[UIView alloc] init];
	
	UIActivityIndicatorView *actView = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(50, 50, 20, 20)];
	
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    
	if(UI_USER_INTERFACE_IDIOM()==UIUserInterfaceIdiomPad)
	{
		[alertView setFrame:screenBounds];
		[tempView setFrame:CGRectMake(0, 0, 200, 200)];
		[actView setFrame:CGRectMake(alertView.center.x-20, alertView.center.y-30, 40, 40)];
		[[tempView layer] setCornerRadius:40];
 	}
    else
    {
		[alertView setFrame:screenBounds];
		[tempView setFrame:CGRectMake(0, 0, 100, 100)];
		[actView setFrame:CGRectMake(alertView.center.x-10, alertView.center.y-30, 20, 20)];
		[[tempView layer] setCornerRadius:10];
 	}
    
	
	[backImage setFrame:[alertView frame]];
	[backImage setBackgroundColor:[UIColor blackColor]];
    [backImage setAlpha:0.5];
	[alertView addSubview:backImage];
	
	[tempView setBackgroundColor:[UIColor blackColor]];
	
	tempView.center = alertView.center;
	UILabel *lblMessage = [CommonFunctions LabelWithText:msg andFrame:0 :tempView.frame.size.height-50 :tempView.frame.size.width :50];
	[lblMessage setTextColor:[UIColor whiteColor]];

	[lblMessage setTextAlignment:UITextAlignmentCenter];
	[tempView addSubview:lblMessage];
	
	[alertView addSubview:tempView];
	[alertView addSubview:actView];
    
	[actView startAnimating];
	
	[lblMessage release];
	[backImage release];
    
	return alertView;
    
}



+(BOOL)AllocCooridnates
{

            if ([CommonFunctions isNetAvailable])
            {
                CLLocationManager *locationManager;
                locationManager = [[CLLocationManager alloc] init];
                id tempself =   [[CommonFunctions alloc]init];
                locationManager.delegate =  tempself;
                locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters;
                locationManager.distanceFilter = kCLDistanceFilterNone;
                [locationManager startUpdatingLocation];

    if ((([CLLocationManager authorizationStatus] == kCLAuthorizationStatusDenied) || ([CLLocationManager authorizationStatus] == kCLAuthorizationStatusRestricted)) &&([CLLocationManager locationServicesEnabled]))
                    {
                        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:APP_TITLE message:@"Please Enable Location Services For ElogBooks in Settings!" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                        [alert show];
                        [alert release]; 
                        return YES;
                    }
                 [locationManager  performSelector:@selector(stopUpdatingLocation) withObject:nil afterDelay:3.0];
            }
            else 
            {
                //No net Available
            }
    
    
            return  YES;
}
#pragma mark CClocation Manager delegates
- (void)locationManager:(CLLocationManager *)manager
    didUpdateToLocation:(CLLocation *)newLocation
           fromLocation:(CLLocation *)oldLocation
{
    // Configure the new event with information from the location
    CLLocationCoordinate2D coordinate = [newLocation coordinate];
    [ElogBooksAppDelegate SetGlobalObject: [NSValue valueWithBytes:&coordinate objCType:@encode(CLLocationCoordinate2D)]:GEO_LOCATION];
    
    NSString *lat =  [NSString stringWithFormat:@"%f",coordinate.latitude];
    NSString *lon =  [NSString stringWithFormat:@"%f",coordinate.longitude];
    NSLog(@"lat = %@: Lon = %@",lat,lon);
    
    
    
//    LLocationCoordinate2D new_coordinate = { latitude, longitude };
//    [points addObject:[NSValue valueWithBytes:&new_coordinate objCType:@encode(CLLocationCoordinate2D)]];
//    
//    To retrieve the value use the following code:
//    
//    CLLocationCoordinate2D old_coordinate;
//    [[points objectAtIndex:0] getValue:&old_coordinate];
    
    
   [manager  performSelector:@selector(stopUpdatingLocation) withObject:nil afterDelay:3.0];
}
- (void)locationManager:(CLLocationManager *)manager
       didFailWithError:(NSError *)error
{
    NSLog(@"ERROR GEO LOCATION OCCURED%@",[error description]);
}
////////////////////////////////////////////////////////////////////////////////////////////////
+(CLLocationCoordinate2D)GetCoordinates 
{
    CLLocationCoordinate2D coordinate;
    [[ElogBooksAppDelegate getValueForKey:GEO_LOCATION]getValue:&coordinate];
    return  coordinate;  

}

+(NSString *)getUniqueName
{
    NSDate *today = [NSDate date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    //	[dateFormatter setDateFormat:@"YYYY-MM-DD hh:mm:ss"];
    [dateFormatter setDateFormat:@"ddMMYYYYHHmmss"];
    NSString *currentDate = [dateFormatter stringFromDate:today];
	[dateFormatter release];
	return currentDate;
}

+(NSString *)getCurrentTimeStamp
{
    NSDate *today = [NSDate date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    //	[dateFormatter setDateFormat:@"YYYY-MM-DD hh:mm:ss"];
    [dateFormatter setDateFormat:@"dd/MM/YYYY HH:mm:ss"];
    NSString *currentDate = [dateFormatter stringFromDate:today];
	[dateFormatter release];
	return currentDate;
}

+(NSString *)getCurrentTimeStamp:(NSString *)strDate
{
    //2013-11-31 18:00:00 YYYY-MM-dd HH:mm:ss
    NSDate *dateTemp;
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"YYYY-MM-dd HH:mm:ss"];
    dateTemp = [dateFormatter dateFromString:strDate];
    [dateFormatter setDateFormat:@"dd/MM/YYYY HH:mm:ss"];
    NSString *currentDate = [dateFormatter stringFromDate:dateTemp];
    [dateFormatter release];
	return currentDate;
}

+(NSString *)getCurrentTimeStampForDatabaseInsertion:(NSString *)strDate
{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"dd/MM/yyyy HH:mm:ss"];
    NSDate *date = [dateFormatter dateFromString:strDate];
    
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSString *dateWithNewFormat = [dateFormatter stringFromDate:date];
    //    NSLog(@"dateWithNewFormat: %@", dateWithNewFormat);
    return dateWithNewFormat;
}



+(NSString *)getCurrentTimeStampForDatabaseInsertion //For upload
{
    NSDate *today = [NSDate date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"YYYY-MM-dd HH:mm:ss"];
    //    [dateFormatter setDateFormat:@"dd/MM/YYYYHH:mm:ss"];
    NSString *currentDate = [dateFormatter stringFromDate:today];
	[dateFormatter release];
	return currentDate;
}

+(void )changeJobIdToOriginal : (NSString *)OldValue :(NSString*)NewValue
{

    NSMutableArray *arrTables = [DataSource getRecordsFromQuery:@"SELECT name  FROM sqlite_master WHERE sql LIKE '%jid%'  and name !='NewJobs'"];
    for (int i =0;i<[arrTables count];i++)
    {
        NSString *StrQuery = [NSString stringWithFormat:@"Update %@ set jid = '%@' where jid ='%@'",[[arrTables objectAtIndex:i]valueForKey:@"name"],NewValue,OldValue];
        [DataSource executeQuery:StrQuery];
    }
    
    [DataSource executeQuery:[NSString stringWithFormat:@"Update Uploaded_files set as_id = '%@' where as_id ='%@'",NewValue,OldValue]];
    
}

+(BOOL)isNetAvailable
{
    Reachability *internetReach;
    internetReach = [Reachability reachabilityForInternetConnection];
    [internetReach startNotifier];
    NetworkStatus netStatus = [internetReach currentReachabilityStatus];
    [internetReach stopNotifier];
    if(netStatus == NotReachable)
    {
        NSLog(@"Network Unavailable");
        return NO;
    }
    else
        return YES;
}

+(UIImage *)AlertButton:(NSString*)txt andFrame:(CGRect)frame image:(NSString *)imageName
{
    
	int x=frame.origin.x,y=frame.origin.y,w=frame.size.width,h=frame.size.height;
    
    //	UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(x, y, w, h)];
    
	UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(3, 3, w-6, h-6)];
	lbl.text = txt;
	[lbl setMultipleTouchEnabled:YES];
	lbl.numberOfLines=0;
    lbl.textAlignment = UITextAlignmentCenter;
    
    //	lbl.font = [UIFont boldSystemFontOfSize:18];
    lbl.font = FONT_NEUE_BOLD_SIZE(15);
    
    
	[lbl setBackgroundColor:[UIColor clearColor]];
    //    lbl.shadowOffset=CGSizeMake(0,1);
//    [lbl setShadowOffset:CGSizeMake(1,0)];
    [lbl setTextColor:[UIColor whiteColor]];
    
    
    
    /*
    [lbl setShadowColor:[UIColor blackColor]];
    lbl.shadowOffset=CGSizeMake(0,-1);
    lbl.shadowColor = [UIColor blackColor];
	*/
    
    
    
    
    
    
    
     //[btn setShowsTouchWhenHighlighted:YES];
	
	UIImageView *viewImage = [[UIImageView alloc] initWithFrame:CGRectMake(x, y, w, h)];
	if(UI_USER_INTERFACE_IDIOM()==UIUserInterfaceIdiomPad){
		//[viewImage setBackgroundColor:[CommonFunctions getColorForImage:imageName]];
		[viewImage setImage:[UIImage imageNamed:imageName]];
	}
	else {
		//[viewImage setBackgroundColor:[CommonFunctions getColorForImage:imageName]];
		[viewImage setImage:[UIImage imageNamed:imageName]];
	}
	[viewImage addSubview:lbl];
	
	UIGraphicsBeginImageContext(viewImage.bounds.size);
	[viewImage.layer renderInContext:UIGraphicsGetCurrentContext()];
	UIImage *Image = UIGraphicsGetImageFromCurrentImageContext();
	UIGraphicsEndImageContext();
	
    [lbl release];
	[viewImage release];
	return Image;
}

+(NSMutableDictionary *)getDicAsParameter:(NSMutableDictionary *)dicWithExistingKeys
{
    NSMutableDictionary *dicForParsing = dicWithExistingKeys;
    NSArray *arrkeys = [dicForParsing allKeys];
    for (int i =0; i < [arrkeys count];i++)
    {
        [dicForParsing setObject:[dicForParsing objectForKey:[arrkeys objectAtIndex:i]] forKey:[NSString stringWithFormat:@"%d:%@",i,[arrkeys objectAtIndex:i]]];
        [dicForParsing removeObjectForKey:[arrkeys objectAtIndex:i]];
        
    }
    return dicForParsing;
}


+(NSString *)getBaseUrl
{
    return [DataSource getStringFromQuery:@"SELECT 'http://' || Account || '.' || Domain || '/'  AS BaseUrl FROM EnteredUserData"];
}

+(NSMutableArray *)getWebservicesArray
{
    
    NSMutableArray *arrWebserviceslist = [[NSMutableArray alloc]init];

    

    
    
    //webservices table names
    NSArray *arrWebservicesnames = [[[NSArray alloc]initWithObjects:TBL_JOBS,TBL_JOB_MATERIALS,TBL_SUPPLIERS,TBL_CUSTOMERS,TBL_ASSETS,TBL_JOBLINES,TBL_PRIORITIES,TBL_ASSET_NOTES,TBL_SUBASSETS,TBL_SUBASSETS_HISTORY,TBL_LEGCOMPTYPES,TBL_UPLOADEDFILES,TBL_JOBPATROLSCHEDULES,TBL_JOBPATROLSCHEDULEPOINTS,TBL_JOB_GROUPS, TBL_JOB_GROUP_PRIORITIES,TBL_CUST_PRIORITIES,TBL_SERVICE,TBL_CUST_SERVICES,TBL_ENG_SERVICES,TBL_ALL_USERS,TBL_SERVICE_ROUTINE,TBL_SERVICE_ROUTINE_LINES,nil]autorelease];
    
    //for reference
    //    NSArray *arrWebservicesnames = [[[NSArray alloc]initWithObjects:@"Jobs",@"Job_materials",@"Suppliers",@"Customers",@"Assets",@"Job_lines",@"Priorities",@"Asset_notes",@"Assets_sub",@"Assets_sub_history",@"Legcomp_types",@"Uploaded_files",@"Job_patrol_schedules",@"Job_patrol_schedule_points",nil]autorelease];
    
    //parent nodes
    NSArray *arrWebservicesparentNode = [[[NSArray alloc]initWithObjects:JOB_PARENT_NODE,JOB_MATERIAL_PARENT_NODE,SUPPLIERS_PARENT_NODE,CUSTOMERS_PARENT_NODE,ASSETS_PARENT_NODE,JOB_LINES_PARENT_NODE,PRIORITIES_PARENT_NODE,ASSET_NOTES_PARENT_NODE,ASSETS_SUB_PARENT_NODE,ASSET_SUB_HISTORY_PARENT_NODE,LEGCOMP_TYPE_PARENT_NODE,UPLOADED_FILES_PARENT_NODE,JOB_PATROL_SCHEDULES_PARENT_NODE,JOB_PATROL_SCHEDULES_POINT_PARENT_NODE ,JOB_GROUPS_PARENT_NODE,JOB_GROUP_PRIORITIES_PARENT_NODE,CUST_PRIORITIES_PARENT_NODE,SERVICE_PARENT_NODE,CUST_SERVICES_PARENT_NODE,ENG_SERVICES_PARENT_NODE, ALL_USERS_PARENT_NODE,SERVICE_ROUTINE_PARENT_NODE,SERVICE_ROUTINE_LINES_PARENT_NODE,nil]autorelease];
    //child nodes
    NSArray *arrWebserviceschildNode = [[[NSArray alloc]initWithObjects:JOB_CHILD_NODE,JOB_MATERIAL_CHILD_NODE,SUPPLIERS_CHILD_NODE,CUSTOMERS_CHILD_NODE,ASSETS_CHILD_NODE,JOB_LINES_CHILD_NODE,PRIORITIES_CHILD_NODE,ASSET_NOTES_CHILD_NODE,ASSETS_SUB_CHILD_NODE,ASSET_SUB_HISTORY_CHILD_NODE,LEGCOMP_TYPE_CHILD_NODE,UPLOADED_FILES_CHILD_NODE,JOB_PATROL_SCHEDULES_CHILD_NODE,JOB_PATROL_SCHEDULES_POINT_CHILD_NODE ,JOB_GROUPS_CHILD_NODE,JOB_GROUP_PRIORITIES_CHILD_NODE,CUST_PRIORITIES_CHILD_NODE,SERVICE_CHILD_NODE,CUST_SERVICES_CHILD_NODE,ENG_SERVICES_CHILD_NODE,ALL_USERS_CHILD_NODE,SERVICE_ROUTINE_CHILD_NODE,SERVICE_ROUTINE_LINES_CHILD_NODE, nil]autorelease];
    
    for (int i=0; i<[arrWebservicesnames count]; i++) 
    {
        NSMutableDictionary *dicServiceDetails= [[[NSMutableDictionary alloc]init]autorelease];
        [dicServiceDetails setObject:[arrWebservicesnames objectAtIndex:i] forKey:WEB_SERVICE_TABLENAME];
        [dicServiceDetails setObject:[arrWebservicesparentNode objectAtIndex:i] forKey:PARENT_NODE];
        [dicServiceDetails setObject:[arrWebserviceschildNode objectAtIndex:i] forKey:CHILD_NODE];
        [arrWebserviceslist addObject:dicServiceDetails];
    }
    return arrWebserviceslist;
}
//*--------------------------------------------------------------------------------------------------------------------------------------------------------*//
//*                                                            When UpdateType JOBS.                                                                *//
//*--------------------------------------------------------------------------------------------------------------------------------------------------------*//

+(NSMutableArray *)getArrayJobs:(NSMutableArray *)arrPutInfo
{

    NSString *strUserId = [ElogBooksAppDelegate getValueForKey:USER_ID];

    //    // When UpdateType is jobs...
    //    //*--------------------------------------------------------------------------------------------------------------------------------------------------------*//
    //
    //    //*                                                            When UpdateType is start jobs...                                                                *//
    //
    //    //*--------------------------------------------------------------------------------------------------------------------------------------------------------*//
    //
    //
    //
    /*            //Update the Job start Job URL
     http://code.elogbooks.co.uk/users/jack/WOM/api/put-info.php?uid=38&UpdateType=jobs&qd=Start&tstamp=08/12/2012%2011:19:12&jid=7953
     */
    //complete the job
    /*http://code.elogbooks.co.uk/users/jack/WOM/api/put-info.php?uid=38&UpdateType=jobs&qd=Update&tstamp=27/12/2012%2018:35:20&jid=2824&eng_complete=27/12/2012%2018:35:20&description=testeddesc&miles=2&travel=3&hours=4&aid=261&condition=5&risk=3 */
    
//    NSMutableArray *arrStartedJobs = [DataSource getRecordsFromQuery:
//                                      [NSString stringWithFormat:
//                                       @" Select jobs.jid,job_lines.description,job_lines.miles,job_lines.travel,job_lines.hours, jobs.escalation as  escalation,jobs.eng_complete,jobs.aid,assets.cond,assets.risk,Jobs.eng_on_site, tstamp  from jobs Left Join Job_lines On Job_lines.jid = Jobs.jid Left Join Assets On Assets.aid = Jobs.aid Where jobs.isSynced=0 and jobs.eng_on_site!='' and eng_complete='' or  job_lines.IsSynced=0"]];
//    NSMutableArray *arrStartedJobs = [DataSource getRecordsFromQuery:
//                                      [NSString stringWithFormat:
//                                       @"Select jobs.jid,job_lines.description,job_lines.miles,job_lines.travel,job_lines.hours, jobs.escalation as escalation,jobs.eng_complete,jobs.aid,assets.cond,assets.risk,Jobs.eng_on_site, tstamp from jobs Left Join Job_lines On Job_lines.jid = Jobs.jid Left Join Assets On Assets.aid = Jobs.aid Where jobs.isSynced=0 and jobs.eng_on_site!='' and eng_complete='' and job_lines.IsSynced=0 UNION select jobs.jid,'Patrol Started' as description, '0' as miles,'0' as travel,'0' as hours, jobs.escalation as escalation,jobs.eng_complete,jobs.aid,assets.cond,assets.risk,Jobs.eng_on_site,Jobs.eng_on_site as tstamp from jobs Left Join Assets On Assets.aid = Jobs.aid where job_type= 'Patrol' and jobs.IsSynced = 0"]];
    
//    NSMutableArray *arrStartedJobs = [DataSource getRecordsFromQuery:
//                                          [NSString stringWithFormat: @"Select jobs.jid,job_lines.description,job_lines.miles,job_lines.travel,job_lines.hours, jobs.escalation as escalation,jobs.eng_complete,jobs.aid,assets.cond,assets.risk,Jobs.eng_on_site, tstamp from jobs Left Join Job_lines On Job_lines.jid = Jobs.jid Left Join Assets On Assets.aid = Jobs.aid Where jobs.isSynced=0 and jobs.eng_on_site!='' and eng_complete='' and job_lines.IsSynced=0 UNION select jobs.jid,'Patrol Started' as description, '0' as miles,'0' as travel,'0' as hours, jobs.escalation as escalation,jobs.eng_complete,jobs.aid,assets.cond,assets.risk,Jobs.eng_on_site,Jobs.eng_on_site as tstamp from jobs Left Join Assets On Assets.aid = Jobs.aid where job_type= 'Patrol' and jobs.IsSynced = 0 UNION select jobs.jid,'Patrol Started' as description, '0' as miles,'0' as travel,'0' as hours, jobs.escalation as escalation,jobs.eng_complete,jobs.aid,assets.cond,assets.risk,Jobs.eng_on_site,Jobs.eng_on_site as tstamp from jobs Left Join Assets On Assets.aid = Jobs.aid where job_type= 'PM' and jobs.IsSynced = 0 UNION select jobs.jid,'Patrol Started' as description, '0' as miles,'0' as travel,'0' as hours, jobs.escalation as escalation,jobs.eng_complete,jobs.aid,assets.cond,assets.risk,Jobs.eng_on_site,Jobs.eng_on_site as tstamp from jobs Left Join Assets On Assets.aid = Jobs.aid where job_type= 'Non-PM' and jobs.IsSynced = 0"]];

//    NSMutableArray *arrStartedJobs = [DataSource getRecordsFromQuery:
//                                      [NSString stringWithFormat: @"Select jobs.jid,job_lines.description,job_lines.miles,job_lines.travel,job_lines.hours, jobs.escalation as escalation,jobs.eng_complete,jobs.aid,assets.cond,assets.risk,Jobs.eng_on_site, tstamp from jobs Left Join Job_lines On Job_lines.jid = Jobs.jid Left Join Assets On Assets.aid = Jobs.aid Where jobs.isSynced=0 and jobs.eng_on_site!='' and eng_complete='' and job_lines.IsSynced=0 UNION select jobs.jid,'Patrol Started' as description, '0' as miles,'0' as travel,'0' as hours, jobs.escalation as escalation,jobs.eng_complete,jobs.aid,assets.cond,assets.risk,Jobs.eng_on_site,Jobs.eng_on_site as tstamp from jobs Left Join Assets On Assets.aid = Jobs.aid where job_type= 'Patrol' and jobs.IsSynced = 0 UNION select jobs.jid,'Patrol Started' as description, '0' as miles,'0' as travel,'0' as hours, jobs.escalation as escalation,jobs.eng_complete,jobs.aid,assets.cond,assets.risk,Jobs.eng_on_site,Jobs.eng_on_site as tstamp from jobs Left Join Assets On Assets.aid = Jobs.aid where job_type= 'PM' and jobs.IsSynced = 0 UNION select jobs.jid,'Patrol Started' as description, '0' as miles,'0' as travel,'0' as hours, jobs.escalation as escalation,jobs.eng_complete,jobs.aid,assets.cond,assets.risk,Jobs.eng_on_site,Jobs.eng_on_site as tstamp from jobs Left Join Assets On Assets.aid = Jobs.aid where job_type= 'Non-PM' and jobs.IsSynced = 0"]];
    
    
   NSMutableArray *arrStartedJobs =  [DataSource getRecordsFromQuery:[NSString stringWithFormat:@"select jobs.jid,'Patrol Started' as description, '0' as miles,'0' as travel,'0' as hours, jobs.escalation as escalation,jobs.eng_complete,jobs.aid,assets.cond,assets.risk,Jobs.eng_on_site,Jobs.eng_on_site as tstamp from jobs Left Join Assets On Assets.aid = Jobs.aid where job_type= 'Patrol' and jobs.IsSynced = 0 and jobs.jid not like '%NEWJOB_%' UNION select jobs.jid,'Planned Job Started' as description, '0' as miles,'0' as travel,'0' as hours, jobs.escalation as escalation,jobs.eng_complete,jobs.aid,assets.cond,assets.risk,Jobs.eng_on_site,Jobs.eng_on_site as tstamp from jobs Left Join Assets On Assets.aid = Jobs.aid where job_type= 'PM' and jobs.IsSynced = 0  and IsJobStarted ='N' and jobs.jid not like '%NEWJOB_%' UNION select jobs.jid,'Reactive Job Started' as description, '0' as miles,'0' as travel,'0' as hours, jobs.escalation as escalation,jobs.eng_complete,jobs.aid,assets.cond,assets.risk,Jobs.eng_on_site,Jobs.eng_on_site as tstamp from jobs Left Join Assets On Assets.aid = Jobs.aid where job_type= 'Non-PM' and jobs.IsSynced = 0 and IsJobStarted ='N' and jobs.jid not like '%NEWJOB_%'" ]];
    
    for (NSMutableDictionary *rec in arrStartedJobs)
    {
        
        NSString* _Jid = [rec objectForKey:@"jid"];
        NSString* _Desc = [rec objectForKey:@"description"];
        NSString* _Miles = [rec objectForKey:@"miles"];
        NSString* _traves = [rec objectForKey:@"travel"];
        NSString* _hours = [rec objectForKey:@"hours"];
        NSString* _escalation = [rec objectForKey:@"escalation"];
        NSString* _eng_complete = [rec objectForKey:@"eng_complete"];
        NSString* _aid = [rec objectForKey:@"aid"];
        NSString* _cond = [rec objectForKey:@"cond"];
        NSString* _risk = [rec objectForKey:@"risk"];
        NSString*_eng_on_site = [rec objectForKey:@"eng_on_site"];
        
        
        NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
        
        if([_Jid length]<=0) _Jid=@"0";
        
        [dic setObject:strUserId forKey:@"01:uid"];
        [dic setObject:@"jobs" forKey:@"02:UpdateType"];
        [dic setObject:@"Start" forKey:@"03:qd"];
        
        
        if ([_eng_on_site length]>0)
            [dic setObject:[CommonFunctions getCurrentTimeStamp:_eng_on_site] forKey:@"04:tstamp"];
        
        [dic setObject:_Jid forKey:@"04:jid"];
        
        if([_Desc length]>0)
            [dic setObject:_Desc forKey:@"04:description"];        //job_lines.description
        
        if([_escalation length]>0)
            [dic setObject:_escalation forKey:@"05:escalation"];         // Y or No
        
        
        if([_eng_complete length]>0)
            [dic setObject:_eng_complete forKey:@"06:eng_complete"];       // DD/MM/YYYY HH:mm:ss
        
        if([_aid length]>0)
            [dic setObject:_aid forKey:@"07:aid"];                // assets.aid
        
        if([_cond length]>0)
        {
            [dic setObject:_cond forKey:@"08:condition"];          // assets.cond
            
            if([_risk length]>0)
                [dic setObject:_risk forKey:@"09:risk"];               // assets.risk
            else
                [dic setObject:@"0" forKey:@"09:risk"];               // assets.risk
        }
        
        
        
        if([_Miles length]>0)
            [dic setObject:_Miles forKey:@"10:miles"];              // job_lines.miles
        else
            [dic setObject:@"0.0" forKey:@"10:miles"];              // job_lines.miles
        if([_traves length]>0)
            [dic setObject:_traves forKey:@"11:travel"];             // job_lines.travel
        else
            [dic setObject:@"0.0" forKey:@"11:travel"];              // job_lines.miles
        if([_hours length]>0)
            [dic setObject:_hours forKey:@"12:hours"];             // job_lines.hours
        else
            [dic setObject:@"0.0" forKey:@"12:hours"];              // job_lines.miles
        
        // job_lines.eng_on_site
        
        
        PutInfoClass *objJobsService = [[PutInfoClass alloc] init];
        objJobsService.argsDic = dic;
        
        objJobsService.ParentNode = @"Responses";
        objJobsService.ChildNode = @"Response";
        
        objJobsService.strWebService=[NSString stringWithFormat:@"%@:%@",START_JOB,_Jid];
        
        objJobsService.strUrl= [NSString stringWithFormat:@"%@%@",[ElogBooksAppDelegate getValueForKey:BASE_URL],PUT_INFO_API];
        //        objJobsService.strUrl= @"http://code.elogbooks.co.uk/users/jack/WOM/api/put-info.php";
        
        [arrPutInfo addObject:objJobsService];
        
    }
    //
    
    
    //    // When UpdateType is jobs...
    //    //*--------------------------------------------------------------------------------------------------------------------------------------------------------*//
    //
    //    //*                                                            When UpdateType is updating the  jobs...                                                                *//
    //
    //    //*--------------------------------------------------------------------------------------------------------------------------------------------------------*//
    
    
    
//    NSMutableArray *arrUpdatingJobs = [DataSource getRecordsFromQuery:
//                                       [NSString stringWithFormat:
//                                        @"Select jobs.jid,job_lines.description,job_lines.miles,job_lines.travel,job_lines.hours,jobs.escalation As 'escalation',jobs.eng_complete,jobs.aid,assets.cond,assets.risk,jobs.eng_on_site from jobs Left Join Job_lines On Job_lines.jid = Jobs.jid Left Join Assets On Assets.aid = Jobs.aid Where jobs.isSynced=0  and Job_lines.IsSynced = 0 and    eng_on_site !=''  and eng_complete=''"]];
    
    NSMutableArray *arrUpdatingJobs = [DataSource getRecordsFromQuery:
                                       [NSString stringWithFormat:
                                        @"Select jobs.jid,job_lines.description,job_lines.miles,job_lines.travel,job_lines.hours,jobs.escalation As 'escalation',jobs.eng_complete,jobs.aid,assets.cond,assets.risk,jobs.eng_on_site from jobs Left Join Job_lines On Job_lines.jid = Jobs.jid Left Join Assets On Assets.aid = Jobs.aid Where jobs.isSynced=0 and Job_lines.IsSynced = 0 and eng_on_site !='' and eng_complete='' and jobs.jid not like '%NEWJOB_%'"]];
    
    
    
    for (NSMutableDictionary *rec in arrUpdatingJobs)
    {
        
        NSString* _Jid = [rec objectForKey:@"jid"];
        NSString* _Desc = [rec objectForKey:@"description"];
        NSString* _Miles = [rec objectForKey:@"miles"];
        NSString* _traves = [rec objectForKey:@"travel"];
        NSString* _hours = [rec objectForKey:@"hours"];
        NSString* _escalation = [rec objectForKey:@"escalation"];
        NSString* _eng_complete = [rec objectForKey:@"eng_complete"];
        NSString* _aid = [rec objectForKey:@"aid"];
        NSString* _cond = [rec objectForKey:@"cond"];
        NSString* _risk = [rec objectForKey:@"risk"];
        NSString*_eng_on_site = [rec objectForKey:@"eng_on_site"];
        
        
        NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
        
        if([_Jid length]<=0) _Jid=@"0";
        
        [dic setObject:strUserId forKey:@"01:uid"];
        [dic setObject:@"jobs" forKey:@"02:UpdateType"];
        [dic setObject:@"Update" forKey:@"03:qd"];
        if ([_eng_on_site length]>0)
            [dic setObject: [CommonFunctions getCurrentTimeStamp:_eng_on_site] forKey:@"04:tstamp"];
        
        [dic setObject:_Jid forKey:@"04:jid"];
        
        if([_Desc length]>0)
            [dic setObject:_Desc forKey:@"04:description"];        //job_lines.description
        
        if([_escalation length]>0)
            [dic setObject:_escalation forKey:@"05:escalation"];         // Y or No
        
        
        if([_eng_complete length]>0)
            [dic setObject: [CommonFunctions getCurrentTimeStamp:_eng_complete] forKey:@"06:eng_complete"];       // DD/MM/YYYY HH:mm:ss
        
        if([_aid length]>0)
            [dic setObject:_aid forKey:@"07:aid"];                // assets.aid
        
        if([_cond length]>0)
        {
            [dic setObject:_cond forKey:@"08:condition"];          // assets.cond
            
            if([_risk length]>0)
                [dic setObject:_risk forKey:@"09:risk"];               // assets.risk
            else
                [dic setObject:@"0" forKey:@"09:risk"];               // assets.risk
        }
        
        
        
        if([_Miles length]>0)
            [dic setObject:_Miles forKey:@"10:miles"];              // job_lines.miles
        
        if([_traves length]>0)
            [dic setObject:_traves forKey:@"11:travel"];             // job_lines.travel
        
        if([_hours length]>0)
            [dic setObject:_hours forKey:@"12:hours"];             // job_lines.hours
        // job_lines.eng_on_site
        
        
        PutInfoClass *objJobsService = [[PutInfoClass alloc] init];
        objJobsService.argsDic = dic;
        
        objJobsService.ParentNode = @"Responses";
        objJobsService.ChildNode = @"Response";
        //0-Jid  ==  1--eng_on_site
        objJobsService.strWebService=[NSString stringWithFormat:@"%@:%@:%@",UPDATE_JOB,_Jid,_eng_on_site];
        
        objJobsService.strUrl= [NSString stringWithFormat:@"%@%@",[ElogBooksAppDelegate getValueForKey:BASE_URL],PUT_INFO_API];
        //        objJobsService.strUrl= @"http://code.elogbooks.co.uk/users/jack/WOM/api/put-info.php";
        [arrPutInfo addObject:objJobsService];
        
    }
    
    
    
    
    
    
    //    // When UpdateType is jobs...
    //    //*--------------------------------------------------------------------------------------------------------------------------------------------------------*//
    //
    //    //*                                                            When UpdateType is Complete jobs...                                                                *//
    //
    //    //*--------------------------------------------------------------------------------------------------------------------------------------------------------*//
    //
    //
    //
    
    //complete the job
    /*http://code.elogbooks.co.uk/users/jack/WOM/api/put-info.php?uid=38&UpdateType=jobs&qd=Update&tstamp=27/12/2012%2018:35:20&jid=2824&eng_complete=27/12/2012%2018:35:20&description=testeddesc&miles=2&travel=3&hours=4&aid=261&condition=5&risk=3 */
    /*jobs query */
    /*Also check the start of job with Jobs.eng_on_site*/
    /*select
     jobs.jid,job_type,
     job_lines.description,
     job_lines.miles,
     job_lines.travel,
     job_lines.hours,
     'Y-N' As 'escalation',
     jobs.eng_complete,
     jobs.aid,
     assets.cond,
     assets.risk
     from jobs
     Left Join Job_lines On Job_lines.jid = Jobs.jid
     Left Join Assets On Assets.aid = Jobs.aid
     Where jobs.isSynced=0*/

    
//    NSMutableArray *arrCompltedJobs = [DataSource getRecordsFromQuery:
//                                       [NSString stringWithFormat:
//                                        @" Select jobs.jid,job_lines.description,job_lines.miles,job_lines.travel,job_lines.hours,jobs.escalation As 'escalation',jobs.eng_complete,jobs.aid,assets.cond,assets.risk from jobs Left Join Job_lines On Job_lines.jid = Jobs.jid Left Join Assets On Assets.aid = Jobs.aid Where jobs.isSynced=0  and eng_complete!=''"]];

    NSMutableArray *arrCompltedJobs = [DataSource getRecordsFromQuery:
                                       [NSString stringWithFormat:
                                        @"Select jobs.jid,job_lines.description,job_lines.miles,job_lines.travel,job_lines.hours,jobs.escalation As 'escalation',jobs.eng_complete,jobs.aid,assets.cond,assets.risk from jobs Left Join Job_lines On Job_lines.jid = Jobs.jid Left Join Assets On Assets.aid = Jobs.aid Where jobs.isSynced=0 and eng_complete!='' and job_lines.IsSynced=0 and jobs.jid not like '%NEWJOB_%'"]];
    
    
    for (NSMutableDictionary *rec in arrCompltedJobs)
    {
        
        NSString* _Jid = [rec objectForKey:@"jid"];
        NSString* _Desc = [rec objectForKey:@"description"];
        NSString* _Miles = [rec objectForKey:@"miles"];
        NSString* _traves = [rec objectForKey:@"travel"];
        NSString* _hours = [rec objectForKey:@"hours"];
        NSString* _escalation = [rec objectForKey:@"escalation"];
        NSString* _eng_complete = [rec objectForKey:@"eng_complete"];
        NSString* _aid = [rec objectForKey:@"aid"];
        NSString* _cond = [rec objectForKey:@"cond"];
        NSString* _risk = [rec objectForKey:@"risk"];
        
        
        NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
        
        if([_Jid length]<=0) _Jid=@"0";
        
        [dic setObject:strUserId forKey:@"01:uid"];
        [dic setObject:@"jobs" forKey:@"02:UpdateType"];
        [dic setObject:@"Update" forKey:@"03:qd"];
        if ([_eng_complete length]>0)
            [dic setObject:[CommonFunctions getCurrentTimeStamp:_eng_complete] forKey:@"04:tstamp"];
        
        [dic setObject:_Jid forKey:@"04:jid"];
        
        if([_Desc length]>0)
            [dic setObject:_Desc forKey:@"04:description"];        //job_lines.description
        
        if([_escalation length]>0)
            [dic setObject:_escalation forKey:@"05:escalation"];         // Y or No
        
        if([_eng_complete length]>0)
            [dic setObject: [CommonFunctions getCurrentTimeStamp:_eng_complete] forKey:@"06:eng_complete"];       // DD/MM/YYYY HH:mm:ss
        
        if([_aid length]>0)
            [dic setObject:_aid forKey:@"07:aid"];                // assets.aid
        
        if([_cond length]>0)
        {
            [dic setObject:_cond forKey:@"08:condition"];          // assets.cond
            
            if([_risk length]>0)
                [dic setObject:_risk forKey:@"09:risk"];               // assets.risk
            else
                [dic setObject:@"0" forKey:@"09:risk"];               // assets.risk
        }
        
        
        
        if([_Miles length]>0)
            [dic setObject:_Miles forKey:@"10:miles"];              // job_lines.miles
        
        if([_traves length]>0)
            [dic setObject:_traves forKey:@"11:travel"];             // job_lines.travel
        
        if([_hours length]>0)
            [dic setObject:_hours forKey:@"12:hours"];             // job_lines.hours
        
        
        
        PutInfoClass *objJobsService = [[PutInfoClass alloc] init];
        objJobsService.argsDic = dic;
        
        objJobsService.ParentNode = @"Responses";
        objJobsService.ChildNode = @"Response";
        
        objJobsService.strWebService=[NSString stringWithFormat:@"%@:%@",COMPLETE_JOB,_Jid];
        
        //        objJobsService.strUrl= @"http://code.elogbooks.co.uk/users/jack/WOM/api/put-info.php";
        objJobsService.strUrl= [NSString stringWithFormat:@"%@%@",[ElogBooksAppDelegate getValueForKey:BASE_URL],PUT_INFO_API];
        
        [arrPutInfo addObject:objJobsService];
        
    }

    return arrPutInfo;
}
//*--------------------------------------------------------------------------------------------------------------------------------------------------------*//
//*                                                            When UpdateType is sub_assets...                                                                *//
//*--------------------------------------------------------------------------------------------------------------------------------------------------------*//        
+(NSMutableArray *)getArraySubAssets:(NSMutableArray *)arrPutInfo
{

//    NSString *strUserId = [ElogBooksAppDelegate getValueForKey:USER_ID];

    /*Param (Required): include_xx = Y / N
     Param (Optional): location_xx = assets_sub.location
     Param (Optional): name_xx = assets_sub.sname
     Param (Optional): description_xx = assets_sub.sdescr
     Param (Optional): type_xx = assets_sub.stype
     Param (Optional): cond_xx = assets_sub.cond
     Param (Optional): risk_xx = assets_sub.risk
     http://code.elogbooks.co.uk/users/jack/WOM/api/put-info.php?UpdateType=sub_assets&uid=38&jid=7686&include_5699=Y&location_5699=New%20Location&name_5699=New%20Name&cond_5699=5&risk_5699=4&qd=Update%20Sub%20Assets&type_5699=New%20Type&description_5699=New%20description&notes_5699=New%20Notes
     */
    
    
    NSMutableArray *arrSubAssets = [DataSource getRecordsFromQuery:
                                    [NSString stringWithFormat:
                                     @"select Assets_sub.loc,Assets_sub.said,Assets_sub.model,Assets_sub.serialno,Assets_sub.sname,Assets_sub.stype,Assets_sub.sdescr,Assets_sub.notes,Assets_sub_history.jid,Assets_sub_history.hiid,Assets_sub_history.cond,Assets_sub_history.risk  from Assets_sub left join Assets_sub_history on Assets_sub.said= Assets_sub_history.said where Assets_sub.IsSynced=0 and Assets_sub_history.IsSynced=0"]];
    
    
    for (NSMutableDictionary *rec in arrSubAssets)
    {
        NSMutableDictionary *dicc=[[NSMutableDictionary alloc] init];
        
        [dicc setObject:@"sub_assets" forKey:@"UpdateType"];
        [dicc setObject:[ElogBooksAppDelegate getValueForKey:USER_ID] forKey:USER_ID];
        [dicc setObject:[rec valueForKey:JOBS_ID]  forKey:JOBS_ID];     
        [dicc setObject:@"Update Sub Assets" forKey:@"qd"];
        
        NSString *str_XX = [rec valueForKey:ASSETS_SUB_ID];
        [dicc setObject:@"Y" forKey: [NSString stringWithFormat:@"include_%@",str_XX]];
        
       if([[[rec valueForKey:ASSETS_SUB_LOCATION ]stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0)
          [dicc setObject:[rec valueForKey:ASSETS_SUB_LOCATION]  forKey:[NSString stringWithFormat:@"location_%@",str_XX]];  
        
        if([[[rec valueForKey:ASSETS_SUB_SNAME ]stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0)
            [dicc setObject:[rec valueForKey:ASSETS_SUB_SNAME]  forKey:[NSString stringWithFormat:@"name_%@",str_XX]]; 
        
        if([[[rec valueForKey:ASSETS_SUB_HISTORY_COND ]stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0)
            [dicc setObject:[rec valueForKey:ASSETS_SUB_HISTORY_COND]  forKey:[NSString stringWithFormat:@"cond_%@",str_XX]]; 
        
        if([[[rec valueForKey:ASSETS_SUB_HISTORY_RISK ]stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0)
            [dicc setObject:[rec valueForKey:ASSETS_SUB_HISTORY_RISK]  forKey:[NSString stringWithFormat:@"risk_%@",str_XX]]; 
        
        if([[[rec valueForKey:ASSETS_SUB_STYPE ]stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0)
            [dicc setObject:[rec valueForKey:ASSETS_SUB_STYPE]  forKey:[NSString stringWithFormat:@"type_%@",str_XX]]; 
        
        if([[[rec valueForKey:ASSETS_SUB_SDESCR ]stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0)
            [dicc setObject:[rec valueForKey:ASSETS_SUB_SDESCR]  forKey:[NSString stringWithFormat:@"description_%@",str_XX]]; 
        
        if([[[rec valueForKey:ASSETS_SUB_NOTES ]stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0)
            [dicc setObject:[rec valueForKey:ASSETS_SUB_NOTES]  forKey:[NSString stringWithFormat:@"notes_%@",str_XX]]; 
        
       
        
        
        PutInfoClass *objJobsService = [[PutInfoClass alloc] init];
        NSMutableDictionary *dicTemp = [CommonFunctions getDicAsParameter:dicc];
        objJobsService.argsDic=dicTemp;
        
        objJobsService.ParentNode = @"Responses";
        objJobsService.ChildNode = @"Response";
        //00-->said ===1-->hiid
        objJobsService.strWebService=[NSString stringWithFormat:@"SubAssets:%@:%@",[rec objectForKey:ASSETS_SUB_ID],[rec objectForKey:HISTORY_ID]];
        
//        objJobsService.strUrl= @"http://code.elogbooks.co.uk/users/jack/WOM/api/put-info.php";
        objJobsService.strUrl = [NSString stringWithFormat:@"%@%@",[ElogBooksAppDelegate getValueForKey:BASE_URL],PUT_INFO_API];
        //        objJobsService.strUrl= [NSString stringWithFormat:@"%@%@",[ElogBooksAppDelegate getValueForKey:BASE_URL],PUT_INFO_API];
        [arrPutInfo addObject:objJobsService];
        
        [dicc release];
 
    }

    return arrPutInfo;
}
//*--------------------------------------------------------------------------------------------------------------------------------------------------------*//    
//*                                             When UpdateType is Job Patrol Schedule Points...                                                           *//
//*--------------------------------------------------------------------------------------------------------------------------------------------------------*//  

+(NSMutableArray *)getArraySchedulePoints:(NSMutableArray *)arrPutInfo
{

    NSString *strUserId = [ElogBooksAppDelegate getValueForKey:USER_ID];
//
//    NSMutableArray *arrJobSchedulePoints = [DataSource getRecordsFromQuery:[NSString stringWithFormat:@"select Job_patrol_schedules.schedule_id,Job_patrol_schedules.jid,Job_patrol_schedule_points.sort As 'order',Job_patrol_schedule_points.date_complete,Job_patrol_schedule_points.require_unable As 'unable',Job_patrol_schedule_points.point_id,"
//                                                                            "\nCASE WHEN  ( Job_patrol_schedule_points.require_unable ='N' ) THEN"
//                                                                            /* check for require_type here in future */
//                                                                            "\nJob_patrol_schedule_points.barcode"
//                                                                            "\nWHEN  ( Job_patrol_schedule_points.require_unable ='Y' ) THEN 'NO_DATA'"
//                                                                            "\nEND As barcode"
//                                                                            "\nfrom Job_patrol_schedules"
//                                                                            "\njoin Job_patrol_schedule_points on  Job_patrol_schedules.schedule_id = Job_patrol_schedule_points.schedule_id"
//                                                                            "\nwhere Job_patrol_schedules.Issynced=0 or Job_patrol_schedule_points.Issynced=0"]];
    
    
    NSMutableArray *arrJobSchedulePoints = [DataSource getRecordsFromQuery: [NSString stringWithFormat:@"select Job_patrol_schedules.schedule_id,Job_patrol_schedules.jid,Job_patrol_schedule_points.sort As 'order',Job_patrol_schedule_points.date_complete,Job_patrol_schedule_points.require_unable As 'unable',Job_patrol_schedule_points.point_id,CASE WHEN ( Job_patrol_schedule_points.require_type = 'B' ) THEN CASE WHEN  ( Job_patrol_schedule_points.require_unable ='N' ) THEN Job_patrol_schedule_points.barcode WHEN  ( Job_patrol_schedule_points.require_unable ='Y' ) THEN 'NO_DATA' END ELSE 'NO_DATA' END As barcode from Job_patrol_schedules join Job_patrol_schedule_points on  Job_patrol_schedules.schedule_id = Job_patrol_schedule_points.schedule_id where Job_patrol_schedules.Issynced=0 or Job_patrol_schedule_points.Issynced=0 order by Job_patrol_schedule_points.schedule_id, Job_patrol_schedule_points.sort"]];

//    NSMutableArray *arrJobSchedulePoints = [DataSource getRecordsFromQuery:[NSString stringWithFormat:@"select Job_patrol_schedules.schedule_id,Job_patrol_schedules.jid,Job_patrol_schedule_points.sort As 'order',Job_patrol_schedule_points.date_complete,Job_patrol_schedule_points.require_unable As 'unable',Job_patrol_schedule_points.point_id,"
//                                                                            "\nCASE WHEN  ( Job_patrol_schedule_points.require_unable ='N' ) THEN"
//                                                                            /* check for require_type here in future */
//                                                                            "\nJob_patrol_schedule_points.barcode"
//                                                                            "\nWHEN  ( Job_patrol_schedule_points.require_unable ='Y' ) THEN 'NO_DATA'"
//                                                                            "\nEND As barcode"
//                                                                            "\nfrom Job_patrol_schedules"
//                                                                            "\njoin Job_patrol_schedule_points on  Job_patrol_schedules.schedule_id = Job_patrol_schedule_points.schedule_id"
//                                                                            "\nwhere Job_patrol_schedules.Issynced=1 and Job_patrol_schedule_points.Issynced=1"]];

    
    for (NSMutableDictionary *recordDic in arrJobSchedulePoints)
    {
        NSString* jid = [recordDic objectForKey:@"jid"];
        
        NSString* point_id = [recordDic objectForKey:@"point_id"];
        NSString* order = [recordDic objectForKey:@"order"];
        NSString* unable = [recordDic objectForKey:@"unable"];
        NSString* barcode = [recordDic objectForKey:@"barcode"];
        NSString* schedule_id = [recordDic objectForKey:@"schedule_id"];
        
        
        NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
        
        [dic setObject:strUserId forKey:@"01:uid"];
        [dic setObject:@"patrol_point" forKey:@"02:UpdateType"];
        [dic setObject:@"Update" forKey:@"03:qd"];
        
        
        //static value for date_complete
        if ([[recordDic objectForKey:@"date_complete"]length]>0)
        [dic setObject:[CommonFunctions getCurrentTimeStamp:[recordDic objectForKey:@"date_complete"]]   forKey:@"04:tstamp"];

        
        if([jid length]>0)
            [dic setObject:jid forKey:@"05:jid"];
        
        if([point_id length]>0)
            [dic setObject:point_id forKey:@"06:point_id"];
        
        if([order length]>0)
            [dic setObject:order forKey:@"07:order"];
        
        if([schedule_id length]>0)
            [dic setObject:schedule_id forKey:@"08:schedule_id"];
        
        if([unable length]>0)
        {
            if ([unable isEqualToString:@"Y"])
                [dic setObject:unable forKey:@"09:unable"];
            else
            {
                if(!([barcode isEqualToString:@"NO_DATA"]))
                    [dic setObject:barcode forKey:@"09:barcode"];
                else
                    [dic setObject:unable forKey:@"09:unable"];
                
            }
        }
        
        
        PutInfoClass *objJobsService = [[PutInfoClass alloc] init];
        objJobsService.argsDic = dic;
        
        objJobsService.ParentNode = @"Responses";
        objJobsService.ChildNode = @"Response";
        
        objJobsService.strWebService=[NSString stringWithFormat:@"patrol_point:%@:%@",jid,point_id];
        
//        objJobsService.strUrl= @"http://code.elogbooks.co.uk/users/jack/WOM/api/put-info.php";
        
                objJobsService.strUrl = [NSString stringWithFormat:@"%@%@",[ElogBooksAppDelegate getValueForKey:BASE_URL],PUT_INFO_API];
        
        [arrPutInfo addObject:objJobsService];
        
        [dic release];
        //
        
    }

    return arrPutInfo;
}
//*--------------------------------------------------------------------------------------------------------------------------------------------------------*//
//*                                                            When UpdateType is image....                                                                *//
//*--------------------------------------------------------------------------------------------------------------------------------------------------------*//
+(NSMutableArray *)getArrayImage:(NSMutableArray *)arrPutInfo
{
    
    /*    http://code.elogbooks.co.uk/users/jack/WOM/api/put-info.php?uid=38&UpdateType=patrol_point&qd=Update&tstamp=27/12/2012%2018:35:20&jid=7811&point_id=50&order=3&schedule_id=240&unable=N */
    
    
    //	Param (Required):	 = jobs.jid
    //	Param (Required) :	 = [base64_string_of_image_file]
    //	Param (Optional):	 = [string]
    //	Param (Optional):	 = [job_patrol_schedule_points.point_id]
    //	Param (Optional):	 = [job_patrol_schedule_points.sort]
    //	Param (Optional):	 = [job_patrol_schedule_points.schedule_id]
    
    //	Success return for this will include the uploaded_files.fid field for the new image
    
    // NSString *strUserId = [ElogBooksAppDelegate getValueForKey:USER_ID];
    
    
    
    
    
    
NSMutableArray *arrImgListToUpload = [DataSource getRecordsFromQuery:[NSString stringWithFormat:@"SELECT uid,as_id as jid,title,created FROM Uploaded_files where IsSynced=0"]];
    
    for (NSMutableDictionary *dicRec in arrImgListToUpload)
    {
        /* NSString *documentsDirectory = [NSHomeDirectory() stringByAppendingPathComponent:@"Library"];
         NSString *dataPath = [documentsDirectory stringByAppendingPathComponent:@"EditCardImage"];
         dataPathdataPath stringByAppendingPathComponent[_arrCard objectAtIndex:0] valueForKey:C_QuestionImage]];
         if ([[NSFileManager defaultManager] fileExistsAtPath:dataPath])
         {
         [imgView setImageUIImage imageWithContentsOfFile:dataPath]];
         }
         */
        
        NSString *strBase64;
        NSString *documentsDirectory = [NSHomeDirectory() stringByAppendingPathComponent:@"Library"];
        NSString *dataPath = [documentsDirectory stringByAppendingPathComponent:UN_SYNCEDIMAGES_FOLDER];
        dataPath = [dataPath stringByAppendingPathComponent:[dicRec objectForKey:FILE_TITLE]];
        if ([[NSFileManager defaultManager]fileExistsAtPath:dataPath])
        {
            UIImage *_img = [[UIImage alloc]initWithContentsOfFile:dataPath];
            NSData *_data = UIImagePNGRepresentation(_img);
            strBase64 = [Base64 encode:_data];
        }
        
        NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
        [dic setObject:[dicRec objectForKey:USER_ID]  forKey:@"01:uid"];
        [dic setObject:@"image" forKey:@"02:UpdateType"];
        
        [dic setObject:[dicRec objectForKey:JOBS_ID] forKey:@"03:jid"];
        [dic setObject:strBase64 forKey:@"04:ImageString"];
        [dic setObject:[dicRec objectForKey:FILE_TITLE] forKey:@"03:Title"];
        
        //    [dic setObject:@"0.00023" forKey:@"04:point_id"];
        //    [dic setObject:@"0.00012" forKey:@"03:order"];
        //    [dic setObject:@"0.00023" forKey:@"04:schedule_id"];
        
        NSString *strTimeStampToUpload = [CommonFunctions getCurrentTimeStamp:[dicRec objectForKey:FILE_CREATED]]; 
        
        [dic setObject:strTimeStampToUpload forKey:@"05:tstamp"];
        
        PutInfoClass *objJobsService = [[PutInfoClass alloc] init];
        objJobsService.argsDic = dic;
        
        objJobsService.ParentNode = @"Responses";
        objJobsService.ChildNode = @"Response";
        //0-->upload Image === 1-->file_title unique parameter
        objJobsService.strWebService=[NSString stringWithFormat:@"%@:%@",UPLOAD_IMAGE,[dicRec objectForKey:FILE_TITLE]];
        objJobsService.isImage = TRUE;
        
//        objJobsService.strUrl= @"http://code.elogbooks.co.uk/users/jack/WOM/api/put-info.php";
        objJobsService.strUrl= [NSString stringWithFormat:@"%@%@",[ElogBooksAppDelegate getValueForKey:BASE_URL],PUT_INFO_API];

        [arrPutInfo addObject:objJobsService];
        
        [dic release];
    }
    return arrPutInfo;
}


+(NSMutableArray *)getArraynewReactiveJobs
{
    NSMutableArray  *arrPutInfo = [[NSMutableArray alloc]init];
    NSMutableArray *arrNewJobs = [DataSource getRecordsFromQuery:@"SELECT * FROM NewJobs"];
    for (int i =0;i<[arrNewJobs count];i++)
    {
       
        NSMutableDictionary *recDicFromDb = [arrNewJobs objectAtIndex:i];
        NSMutableDictionary *diccRecordToUpload  =[[[NSMutableDictionary alloc] init]autorelease];
        [diccRecordToUpload setObject:[ElogBooksAppDelegate getValueForKey:USER_ID] forKey:USER_ID];
        [diccRecordToUpload setObject:@"reactive" forKey:@"UpdateType"];
        [diccRecordToUpload setObject:@"Create" forKey:@"qd"];
        
        [diccRecordToUpload setObject:[recDicFromDb valueForKey:@"cid"]  forKey:@"cid"]; //quantity-->Job_materials.rate
        [diccRecordToUpload setObject:[recDicFromDb valueForKey:@"description"] forKey:@"description"]; //Price -->job_materials.charge
        
        [diccRecordToUpload setObject:[recDicFromDb valueForKey:@"jgid"] forKey:@"jgid"];
        [diccRecordToUpload setObject:[recDicFromDb valueForKey:@"sid"] forKey:@"sid"];
        [diccRecordToUpload setObject:[recDicFromDb valueForKey:@"priority"]  forKey:@"priority"];
        
        if ([recDicFromDb valueForKey:@"location"]!=nil)
            [diccRecordToUpload setObject:[recDicFromDb valueForKey:@"location"] forKey:@"location"];   
        if ([recDicFromDb valueForKey:@"barcode"]!=nil)
             [diccRecordToUpload setObject:[recDicFromDb valueForKey:@"barcode"] forKey:@"barcode"]; 
        NSString *strTimeStampToUpload =  [CommonFunctions getCurrentTimeStamp:[recDicFromDb valueForKey:@"tstamp"]];
        [diccRecordToUpload setObject:strTimeStampToUpload forKey:@"tstamp"];
        
        PutInfoClass *objJobsService = [[PutInfoClass alloc] init];
        objJobsService.argsDic=[CommonFunctions getDicAsParameter:diccRecordToUpload] ;
        //special Array: Create Job : currentJobId : sid ::--> 1.jid : 2.sid
        objJobsService.strWebService=[NSString stringWithFormat:@"%@:%@:%@",CREATE_JOB,[recDicFromDb valueForKey:@"jid"],[recDicFromDb valueForKey:@"sid"]];
        objJobsService.strUrl= [NSString stringWithFormat:@"%@%@",[ElogBooksAppDelegate getValueForKey:BASE_URL],PUT_INFO_API];
        objJobsService.ParentNode=@"Responses";
        objJobsService.ChildNode=@"Response";
        [arrPutInfo addObject:objJobsService];
    }

    return  arrPutInfo;
}




#pragma mark Put_info Array Creation
+(NSMutableArray *)getArrayForPutInfo
{
    
    NSString *strUserId = [ElogBooksAppDelegate getValueForKey:USER_ID];

    NSMutableArray *arrPutInfo = [[NSMutableArray alloc] init];
    //*--------------------------------------------------------------------------------------------------------------------------------------------------------*//
    //*                                                            When UpdateType Create Reactive Jobs.                                                          *//
    //*--------------------------------------------------------------------------------------------------------------------------------------------------------*//
//    arrPutInfo = [self getArraynewReactiveJobs:arrPutInfo];;
    
    
    
    //*--------------------------------------------------------------------------------------------------------------------------------------------------------*//
    //*                                                            When UpdateType JOBS.                                                                *//
    //*--------------------------------------------------------------------------------------------------------------------------------------------------------*//
    
    arrPutInfo = [self getArrayJobs:arrPutInfo];
    
    
    //*--------------------------------------------------------------------------------------------------------------------------------------------------------*//
    //*                                                            When UpdateType is sub_assets...                                                                *//
    //*--------------------------------------------------------------------------------------------------------------------------------------------------------*//        

    arrPutInfo = [self getArraySubAssets:arrPutInfo];

    //*--------------------------------------------------------------------------------------------------------------------------------------------------------*//    
    //*                                             When UpdateType is Job Patrol Schedule Points...                                                           *//
    //*--------------------------------------------------------------------------------------------------------------------------------------------------------*//        

    arrPutInfo = [self getArraySchedulePoints:arrPutInfo];

    //*--------------------------------------------------------------------------------------------------------------------------------------------------------*//
    //*                                                            When UpdateType is image....                                                                *//
    //*--------------------------------------------------------------------------------------------------------------------------------------------------------*//

    
    arrPutInfo = [self getArrayImage:arrPutInfo];

    
    //*--------------------------------------------------------------------------------------------------------------------------------------------------------*//
    //*                                                            When UpdateType is latlon...                                                                *//
    //*--------------------------------------------------------------------------------------------------------------------------------------------------------*//        
    
    //    Param (Required):	lat = [latitude]
    //    Param (Required):	lon = [longitude]
    //    Param (Requred):	tstamp = DD/MM/YYYY HH:mm:ss
  //temporarily put info blocked  
/*    
//    NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
//    
//    [dic setObject:strUserId forKey:@"01:uid"];
//    [dic setObject:@"latlon" forKey:@"02:UpdateType"];
////    [dic setObject:@"0.00012" forKey:@"03:lat"];        
////    [dic setObject:@"0.00023" forKey:@"04:lon"];  
//    
//    CLLocationCoordinate2D coordinate = [CommonFunctions GetCoordinates];
//    [dic setObject:[NSString stringWithFormat:@"%f",coordinate.latitude] forKey:@"03:lat"];
//    [dic setObject:[NSString stringWithFormat:@"%f",coordinate.longitude]forKey:@"04:lon"];
//    
//    [dic setObject:[CommonFunctions getCurrentTimeStamp] forKey:@"05:tstamp"];        
//    
//    PutInfoClass *objJobsService = [[PutInfoClass alloc] init];
//    objJobsService.argsDic = dic;
//    
//    objJobsService.ParentNode = @"Responses";
//    objJobsService.ChildNode = @"Response";
//    
//    objJobsService.strWebService=[NSString stringWithFormat:@"LatLon"];
//    
////    objJobsService.strUrl= @"http://code.elogbooks.co.uk/users/jack/WOM/api/put-info.php";
//            objJobsService.strUrl= [NSString stringWithFormat:@"%@%@",[ElogBooksAppDelegate getValueForKey:BASE_URL],PUT_INFO_API];
//    
//    [arrPutInfo addObject:objJobsService];
//    
//    [dic release];
    
 */   

    return arrPutInfo;
        
}

+(NSString *)ConvertDateToOriginalName:(NSString *)strReceivedDate:(NSString *)strJid
{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"dd/MM/yyyyHH:mm:ss"];
    NSDate *date = [dateFormatter dateFromString:strReceivedDate];
    
    [dateFormatter setDateFormat:@"yyyy-MM-dd-HH-mm-ss"];
    NSString *strOriginalName = [NSString stringWithFormat:@"%@-%@.png",[dateFormatter stringFromDate:date],strJid];
    //    NSLog(@"dateWithNewFormat: %@", dateWithNewFormat);
    return strOriginalName;
}


+(BOOL)iSReadyForCompletion:(NSString *)StrScheduleId
{

    NSString *strUncompletedPointCount =   [DataSource getStringFromQuery:[NSString stringWithFormat:@"select COUNT(ManualStatusHandler) from job_patrol_schedule_points join job_patrol_schedules on job_patrol_schedule_points.schedule_id = job_patrol_schedules.schedule_id where job_patrol_schedule_points.schedule_id = '%@' and ManualStatusHandler = 'NOT_STARTED'",StrScheduleId]];
    if ([strUncompletedPointCount intValue]>0)
        return NO;
    else 
        return YES;
}


+(BOOL)isLastPointWithoutCompleted:(NSString *)StrScheduleId
{
    
    NSString *strUncompletedPointCount =   [DataSource getStringFromQuery:[NSString stringWithFormat:@"select COUNT(ManualStatusHandler) from job_patrol_schedule_points join job_patrol_schedules on job_patrol_schedule_points.schedule_id = job_patrol_schedules.schedule_id where job_patrol_schedule_points.schedule_id = '%@' and ManualStatusHandler = 'NOT_STARTED'",StrScheduleId]];
    if ([strUncompletedPointCount intValue]==1)
        return YES;
    else 
        return NO;
}

+(CGSize )getSize:(NSString *)text Font:(UIFont *)_fnt constrainedToSize:(CGSize)_cSize LineBreakMode:(UILineBreakMode)_lbMode min:(int)_min
{
    CGSize _returnSize =[text sizeWithFont:_fnt constrainedToSize:_cSize lineBreakMode:_lbMode];
    
    if(_returnSize.height < _min)
    {
        _returnSize.height = _min;
    }else {
        _returnSize.height +=5 ;
    }

    return _returnSize;

}

+(UIButton *)buttonWithTitle:(NSString*)txt andFrame:(CGRect)frame
{
	return [self buttonWithTitle:txt andFrame:frame.origin.x :frame.origin.y :frame.size.width :frame.size.height];
}

+(UIButton *)buttonWithTitle:(NSString*)txt andFrame:(float)x :(float)y :(float)w :(float)h{
	
	h=29;
	
	UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(x, y, w, h)];
	UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(2, 1, w-4, h-4)];
	lbl.text = txt;
	lbl.textColor = [UIColor blackColor];
	lbl.textAlignment = UITextAlignmentCenter;
//	lbl.font = [UIFont boldSystemFontOfSize:13];
    lbl.font = [UIFont systemFontOfSize:13];
	[lbl setBackgroundColor:[UIColor clearColor]];
//	lbl.shadowOffset=CGSizeMake(0,2);
//	lbl.shadowColor = [UIColor blackColor];
	
	UIImageView *viewImage = [[UIImageView alloc] initWithFrame:CGRectMake(x, y, w, h)];
	[viewImage setImage:[[UIImage imageNamed:@"RoundedBtn.png"] stretchableImageWithLeftCapWidth:25 topCapHeight:15]];
	[viewImage setBackgroundColor:[UIColor clearColor]];
	[viewImage addSubview:lbl];
	
	UIGraphicsBeginImageContext(viewImage.bounds.size);
	[viewImage.layer renderInContext:UIGraphicsGetCurrentContext()];
	UIImage *Image = UIGraphicsGetImageFromCurrentImageContext();
	UIGraphicsEndImageContext();
	
	[viewImage release];
	
	[btn setImage:Image forState:UIControlStateNormal];
	
	[btn setClipsToBounds:YES];
	
	//[btn addSubview:lbl];
	return btn;
}

+(UIView *)getLableWithTitle:(NSString *)strTitle andDesc:(NSString *)strDesc WithFrame:(CGRect)_frame
{
    
    // [_title sizeWithFont:FONT_NEUE_SIZE(20)];
    
    strTitle = [NSString stringWithFormat:@"%@: ",strTitle];
    
    UIView *returnView = [[UIView alloc] initWithFrame:_frame];
    
    CGSize _titleSize = [strTitle sizeWithFont:FONT_NEUE_BOLD_SIZE(12)];
    
    UILabel *lblTitle = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, _titleSize.width, 20)];
    lblTitle.text = strTitle;
    lblTitle.backgroundColor =[UIColor clearColor];
    lblTitle.font = FONT_NEUE_BOLD_SIZE(12);
    [returnView addSubview:lblTitle];
    [lblTitle release];
    
    UILabel *lblDesc = [[UILabel alloc] initWithFrame:CGRectMake(_titleSize.width,0,_frame.size.width - _titleSize.width, 20)];
    lblDesc.textColor = DEFAULT_FONT_COLOR;
    [lblDesc setFont:FONT_NEUE_SIZE(12)];
    [lblDesc setBackgroundColor: [UIColor clearColor]];
    lblDesc.text = strDesc;
    [returnView addSubview:lblDesc];
    [lblDesc release];
    
    return returnView;
    
}

+(void)setTitleView:(UIViewController *)_self amdtitle:(NSString *)_title
{

    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    
    UIImageView *imgBack = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, screenBounds.size.width, screenBounds.size.height)];
    
//    [imgBack setImage:[UIImage imageNamed:@"Default-568h@2x.png"]];
    [_self.view addSubview:imgBack];
    [_self.view sendSubviewToBack:imgBack];
    
    
    CGRect frame = CGRectMake(0, 0, [_title sizeWithFont:FONT_NEUE_SIZE(20)].width, 44);
    UILabel *label = [[UILabel alloc] initWithFrame:frame];
    label.backgroundColor = [UIColor clearColor];
    label.font = FONT_NEUE_SIZE(20);
    label.textAlignment = UITextAlignmentLeft;
    [label setTextColor:DEFAULT_FONT_COLOR];
    
    //label.shadowOffset=CGSizeMake(0,1);
	//label.shadowColor = [UIColor whiteColor];

    _self.navigationItem.titleView = label;
    
    
    label.text = _title;
    [label release];
}

+(void)setBack:(UIViewController *)_self target:(SEL)_sel
{

    //Back Button On Navigation
    UIImage *buttonImage = getImage(@"btnBack.png");
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    
    [button setTag:143];
    
    [button setImage:buttonImage forState:UIControlStateNormal];
    button.frame = CGRectMake(0, 0, buttonImage.size.width, buttonImage.size.height);
    [button addTarget:_self action:_sel forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *customBarItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    _self.navigationItem.leftBarButtonItem = customBarItem;
    [customBarItem release];
    
}


+(BOOL)SetLeftViewMode:(UITextField *)TextFieldName:(CGFloat)LeftInsetValue
{    
    CGFloat leftInset = LeftInsetValue;
    UIView *leftView = [[[UIView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, leftInset, TextFieldName.bounds.size.height)]autorelease];
    TextFieldName.leftView= leftView;
    TextFieldName.leftViewMode = UITextFieldViewModeAlways;
    return  YES;
}
+(BOOL)SetRightViewMode:(UITextField *)TextFieldName:(CGFloat)RightInsetValue
{  
    CGFloat rightInset = RightInsetValue;
    UIView *leftView = [[[UIView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, rightInset, TextFieldName.bounds.size.height)]autorelease];
    TextFieldName.leftView= leftView;
    TextFieldName.leftViewMode = UITextFieldViewModeAlways;
    return  YES;
    
}

+(NSString *)getWebServicePath{
    return @"http://plusaimit.com/paytrieval/checkForLogin.php";
	//return @"http://www.test.medentry-hpat.ie/web_service.php";
}

+(NSString *)getTimeFromDate:(NSDate *)DateTime
{
    
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDateComponents *components = [calendar components:(NSHourCalendarUnit | NSMinuteCalendarUnit) fromDate:DateTime];
    NSInteger hour = [components hour];
    NSInteger minute = [components minute];
    return [NSString stringWithFormat:@"%02d:%02d",hour,minute];
    
    
}


+(NSString *)getTime:(NSString *)strDateTime
{
    NSDateFormatter *formatter = [[[NSDateFormatter alloc] init] autorelease];
    [formatter setDateFormat:@"YYYY-MM-dd HH:mm:ss"];    
    
    NSDate *eDate = [formatter dateFromString:strDateTime];
    
    
    
    
    
    
    [formatter setDateFormat:@"HH:MM"];
    NSString *time = [formatter stringFromDate:eDate];
    
    return time;

}
+(NSString *)getDate:(NSString *)strDateTime
{

    NSDateFormatter *formatter = [[[NSDateFormatter alloc] init] autorelease];
    [formatter setDateFormat:@"YYYY-MM-dd HH:mm:ss"];    
    
    NSDate *eDate = [formatter dateFromString:strDateTime];

    [formatter setDateFormat:@"dd/MM/yy"];
    NSString *date = [formatter stringFromDate:eDate];
    
    return date;

}


+(NSString *)getTitleDate:(NSString *)strEDate
{
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"dd/MM/yyyy"];
    
    NSDate *eDate = [formatter dateFromString:strEDate];

    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    [df setDateFormat:@"EE"];
    
    NSString *day = [NSString stringWithFormat:@"%@",
                   [df stringFromDate:eDate]];
    
    [df setDateFormat:@"dd"];
    
    NSString *month = [NSString stringWithFormat:@"%@",
                     [df stringFromDate:eDate]];
    
    [df setDateFormat:@"MM"];
    
    NSString *year = [NSString stringWithFormat:@"%@",
                    [df stringFromDate:eDate]];
    
    [df release];

    
    NSString *_strEDate = [NSString stringWithFormat:@"%@ %@/%@",day,month,year];
    
    return _strEDate;
    
}


+(NSString *)getCurrentPayPeriodFrom:(NSMutableArray *)arr withDate:(NSString *)strCDate
{
  
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"dd/MM/yyyy"];

    for(NSMutableDictionary *_rec in arr)
    {
        
        NSString *strCurrentPay = [_rec objectForKey:@"PayPeriod"];
        
        NSRange end = [strCurrentPay rangeOfString:@"-"];

        NSString *strSDate=[strCurrentPay substringToIndex:end.location];
		NSString *strEDate=[strCurrentPay substringFromIndex:end.location+1];

        NSLog(@"\n %@ : S:%@ E:%@",strCurrentPay,strSDate,strEDate);
        
        [formatter setDateFormat:@"dd/MM/yyyy"];
        

        NSDate *cDate = [formatter dateFromString:strCDate];
        NSDate *sDate = [formatter dateFromString:strSDate];
        NSDate *eDate = [formatter dateFromString:strEDate];
    
        NSLog(@"\n %@ \n %@ ",sDate,eDate);

        
        NSLog(@"\n %@ \n %@  Current:%@",[formatter stringFromDate:sDate],[formatter stringFromDate:eDate],[formatter stringFromDate:cDate]);
        
        if([self is:cDate inBetween:sDate and:eDate])
        {
            return strCurrentPay;
        }
        
    }

    return [[arr objectAtIndex:0] objectForKey:@"PayPeriod"];

}

+(BOOL)is:(NSDate *)cDate inBetween:(NSDate *)sDate and:(NSDate *)eDate
{
    
    NSComparisonResult result1 = [sDate compare:cDate];
    
    NSComparisonResult result2 = [eDate compare:cDate];

    if((result1 == NSOrderedAscending||result1==NSOrderedSame) && (result2 == NSOrderedDescending || result2==NSOrderedSame))
    {
        return YES;
    }

    return NO;
}


+(NSDate *)dateFromString:(NSString *)strDate
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"dd/MM/yyyy"];
    
    return [formatter dateFromString:strDate];

}


+(UILabel*)LabelWithText:(NSString*)txt andFrame:(float)x :(float)y :(float)w :(float)h
{
	UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(x, y, w, h)];
	lbl.text = txt;
	if(UI_USER_INTERFACE_IDIOM()==UIUserInterfaceIdiomPad)
	{
		lbl.font = [UIFont fontWithName:@"Arial" size:18];
 	}else {
		lbl.font = [UIFont fontWithName:@"Arial" size:13];
 	}
	lbl.numberOfLines=0;
	lbl.lineBreakMode=UILineBreakModeWordWrap;
	[lbl setBackgroundColor:[UIColor clearColor]];
	
    return lbl;
    
}
+(UIColor *)getBackgroundColor{

	UIColor *tempColor;
	
	if(UI_USER_INTERFACE_IDIOM()==UIUserInterfaceIdiomPad)
	{
		tempColor = [[UIColor alloc] initWithPatternImage:[UIImage imageNamed:@"Home-screen.png"]];
 	}else {
		tempColor = [[UIColor alloc] initWithPatternImage:[UIImage imageNamed:@"iPhoneBG.png"]];
 	}
	
	return tempColor;
}

+(UIColor *)getColorForImage:(NSString*)string{
	UIColor *tempColor;
	tempColor = [[UIColor alloc] initWithPatternImage:[UIImage imageNamed:string]];
	return tempColor;
}

+(UIImage *)strachableImage:(NSString *)imgName
{

	UIImage *img = [UIImage imageNamed:imgName];
	UIImage *imgNew = [img stretchableImageWithLeftCapWidth:49 topCapHeight:0];
	
	return imgNew;
	
}



+(UIImage *)ButtonImageWithTitle:(NSString*)txt andFrame:(CGRect)frame textAlignment:(NSString *)alnmnt image:(NSString *)imageName andIsBorder:(BOOL)isBorber andFontSize:(int)fSize
{

	int x=frame.origin.x,y=frame.origin.y,w=frame.size.width,h=frame.size.height;
	
//	UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(x, y, w, h)];
	
	UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(3, 3, w-6, h-6)];
	lbl.text = txt;
	[lbl setMultipleTouchEnabled:YES];
	lbl.numberOfLines=0;
	lbl.textColor = [UIColor whiteColor];
	if([alnmnt isEqualToString:@"CENTER"]){
		lbl.textAlignment = UITextAlignmentCenter;
	}else if([alnmnt isEqualToString:@"LEFT"]){
		lbl.textAlignment = UITextAlignmentLeft;
	}else if([alnmnt isEqualToString:@"RIGHT"]){
		lbl.textAlignment = UITextAlignmentRight;
	}else {
		lbl.textAlignment = UITextAlignmentCenter;
	}

//	lbl.font = [UIFont fontWithName:FONT_NEUE_BOLD size:fSize];
	
	[lbl setBackgroundColor:[UIColor clearColor]];
//	lbl.shadowOffset=CGSizeMake(0,2);
//	lbl.shadowColor = [UIColor blackColor];
	
	//[btn setShowsTouchWhenHighlighted:YES];
	
	UIImageView *viewImage = [[UIImageView alloc] initWithFrame:CGRectMake(x, y, w, h)];
	if(UI_USER_INTERFACE_IDIOM()==UIUserInterfaceIdiomPad){
		//[viewImage setBackgroundColor:[CommonFunctions getColorForImage:imageName]];
		[viewImage setImage:[UIImage imageNamed:imageName]];
	}
	else {
		//[viewImage setBackgroundColor:[CommonFunctions getColorForImage:imageName]];	
		[viewImage setImage:[UIImage imageNamed:imageName]];
	}
	
	[viewImage addSubview:lbl];
	
	if(isBorber){
		[[viewImage layer] setBorderWidth:0.0];
		[viewImage setClipsToBounds:YES];
		[[viewImage layer] setBorderColor:[[UIColor whiteColor] CGColor]];
		[[viewImage layer] setCornerRadius:10];
		
	}

	
	
	UIGraphicsBeginImageContext(viewImage.bounds.size);
	[viewImage.layer renderInContext:UIGraphicsGetCurrentContext()];
	UIImage *Image = UIGraphicsGetImageFromCurrentImageContext();
	UIGraphicsEndImageContext();
	
	[viewImage release];
	return Image;

//	[btn setImage:Image forState:UIControlStateNormal];
//	
//	[btn setClipsToBounds:YES];
//	[[btn layer] setBorderColor:[[UIColor blackColor] CGColor]];
//	[[btn layer] setCornerRadius:10];
//	[[btn layer] setBorderWidth:1.0];
	
}

+(UIImageView *)ImageOfView:(UIView *)viewImage
{
	UIImageView *returnView = [[UIImageView alloc] initWithFrame:[viewImage frame]];
	
	[returnView setBackgroundColor:[UIColor clearColor]];
	
	UIGraphicsBeginImageContext(viewImage.bounds.size);
	[viewImage.layer renderInContext:UIGraphicsGetCurrentContext()];
	UIImage *Image = UIGraphicsGetImageFromCurrentImageContext();
	UIGraphicsEndImageContext();

	returnView.layer.cornerRadius = 8;
	returnView.layer.shadowOffset = CGSizeMake(9,9);
	returnView.layer.shadowRadius = 5;
	returnView.layer.masksToBounds = NO;
	returnView.layer.shadowOpacity = 0.7;

	returnView.layer.borderWidth=1;

	returnView.layer.borderColor = [[UIColor whiteColor]CGColor];
	
	
	[returnView setImage:Image];
	
	return returnView;
	
}
+(BOOL)checkTextField:(UITextField *)textField{
	
	if([textField.text isEqualToString:@""]||
	   [[textField.text stringByReplacingOccurrencesOfString:@" " withString:@""] length] <=0 ){
		
		return YES;
	}
	
	return NO;
}

+(NSString *)getCurrentTime{
	
	// get current date/time
	NSDate *today = [NSDate date];
	NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
	
//	[dateFormatter setDateFormat:DATE_FORMAT_DEFAULT];
//	[dateFormatter setDateFormat:@"YYYY-MM-DD hh:mm:ss"];
	
	NSString *currentDate = [dateFormatter stringFromDate:today];
	[dateFormatter release];
//	//NSLog(@"User's current date in their preference format:%@",currentDate);
//	
//	dateFormatter = [[NSDateFormatter alloc] init];
//	[dateFormatter setTimeStyle:NSDateFormatterMediumStyle];
//	NSString *currentTime = [dateFormatter stringFromDate:today];
//	[dateFormatter release];
//	//NSLog(@"User's current time in their preference format:%@",currentTime);
//	
//	NSLog(@"User's current time in their preference format:%@",[NSString stringWithFormat:@"%@ %@",currentDate,currentTime]);
	
	return currentDate;
	
}

+(NSString*)getMMDDYY:(NSString*)strDate{
	
	NSDateFormatter *df = [[NSDateFormatter alloc] init];
	[df setDateFormat:@"dd-MM-YYYY"];
	
	NSDate *date = [df dateFromString:strDate];
	[df setDateFormat:@"MM/dd/YYYY"];
	
	return [df stringFromDate:date];
}

+(NSString*)getDDMMYY:(NSString*)strDate
{
	NSDateFormatter *df = [[NSDateFormatter alloc] init];
	[df setDateFormat:@"MM/dd/YYYY"];
	NSDate *date = [df dateFromString:strDate];
	[df setDateFormat:@"dd/MM/YYYY"];
    
	return [df stringFromDate:date];
}

+(NSString*)getUniqName
{
	NSDateFormatter *dateStartFormatter = [[[NSDateFormatter alloc] init] autorelease];
	[dateStartFormatter setDateFormat:@"ddMMyyHHMMSS"];
	//,[[NSDate date] timeIntervalSince1970]
	return [NSString stringWithFormat:@"%@.jpg",[dateStartFormatter stringFromDate:[NSDate date]]];
}


@end