//
//  LogNewJobViewController.h
//  ElogBooks
//
//  Created by i-verve10 on 26/02/13.
//  Copyright (c) 2013 nayanmist@gmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LogNewJobViewController : UIViewController <UITextFieldDelegate,UITextViewDelegate,PickerViewControlDelegate,UIAlertViewDelegate,PutInfoDelegate>
{
    IBOutlet UIScrollView *scrView;
    IBOutlet UITextView *txtView_Description;
    IBOutlet UITextField *txt_Customer,*txtJobGroup,*txtPriority,*txtLocation,*txtLocationBarcode,*txtService;
    IBOutlet UIButton *btnPhoto,*btnCamera,*btnCreateJob,*btnBarcode,*btnAttachments;
    NSMutableArray *arrCustomers,*arrJobGroup,*arrPriority,*arrServices,*arrAttachmentsList;
    NSString *strCid,*strJob_groupsId,*strPriorityId,*strServiceId;
     

    PickerViewControl *objPicker;
    NSInteger lastSelCustomer,lastSelJobGroup,lastSelPriority,lastSelService;

    //Webservice Delegates
    PutInfoClass *objService;
    NSString *strTimeStampToUpload;
    NSString *strIsCustomerRequireApproval;
}
-(NSString *)ConvertDateToOriginalName:(NSString *)strReceivedDate:(NSString *)strJid;
-(void)LoadPriorityArray;
-(IBAction)btnBarcodeTapped;
-(IBAction)btnPhotoTapped:(id)Sender ;
-(IBAction)btnCameraTapped:(id)Sender ;
-(IBAction)btnCreateJobTapped:(id)Sender ;

@end
