//
//  AddMaterials.h
//  ELogBooks
//
//  Created by I-VERVE5 on 06/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#define  TAG_TEXTFIELD 100

@interface AddMaterials : UIViewController<UITextFieldDelegate,UIScrollViewDelegate,PickerViewControlDelegate,PutInfoDelegate>
{
    UIScrollView *mainScroll;
    UITextField *tmpTextField;
    NSMutableArray *labelArray;
    UITextField *txtPrice,*txtsupplierManualOption,*txtDesc,*txtQua,*txtseleSupp;
    UIScrollView *subScroll;
    
    int cnt;
    
    bool addDone,buttonAdded;
    UIButton *doneButton;
    NSMutableArray *arrSuppliers;
    NSInteger lastSelType,ChargeType;
    CGSize prevScrollContentSize;
    
    NSMutableArray *arrCharge_type;
    PickerViewControl *objPicker;
    UITextField *txtChargeType;
    NSString *strCurrentTimeStamp;
    //Webservice Delegates
    PutInfoClass *objService;
}
@property(retain,nonatomic)NSString *strJid;
@end
