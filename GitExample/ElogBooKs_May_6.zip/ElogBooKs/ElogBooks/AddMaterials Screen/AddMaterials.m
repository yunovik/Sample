//
//  AddMaterials.m
//  ELogBooks
//
//  Created by I-VERVE5 on 06/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import "AddMaterials.h"
#import "CommonFunctions.h"

#define SCROLLVIEW_HEIGHT 460
#define SCROLLVIEW_WIDTH  320
//#define LABEL_TAG 1000
//#warning @"Considering Job_materials.Rate as Quantity and Job_materials.Price as Charge"
@interface AddMaterials ()

@end

@implementation AddMaterials
@synthesize strJid;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    //self.title = @"Add Materials";
    [CommonFunctions setTitleView:self amdtitle:@"Add Materials"];
    
    
    //static
    //    strJid = @"8063";
    
    //Show Navigation
    [self.navigationController.navigationBar setHidden:NO];
    
    [CommonFunctions setBack:self target:@selector(btnBackTapped:)];
    
    
//    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"Background.png"]];

    [self.view setBackgroundColor:[UIColor whiteColor]];
    // first UIScrollView
    
    mainScroll = [[UIScrollView alloc] init];
//    mainScroll.frame = CGRectMake(0, 0, SCROLLVIEW_WIDTH, SCROLLVIEW_HEIGHT);
    mainScroll.frame = CGRectMake(0, 0, SCROLLVIEW_WIDTH, [[UIScreen mainScreen] bounds].size.height-20);
    mainScroll.showsHorizontalScrollIndicator = NO;
    mainScroll.showsVerticalScrollIndicator = NO;
    mainScroll.scrollsToTop = NO;
    mainScroll.delegate = self;
    [self.view addSubview:mainScroll];
    
    //get JobId , JobStatus  and Description
    NSMutableArray *arrJobInfo = [DataSource getRecordsFromQuery: [NSString stringWithFormat:@"select jid||' - '|| stt As JobDetail,description from jobs where jid=%@",strJid]];
    
    //UIimageview
    UIImageView *imgViewLbl = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 320, 50)];
    imgViewLbl.image = [UIImage imageNamed:@"Label.png"];
    imgViewLbl.contentMode = UIViewContentModeCenter;
    [mainScroll addSubview: imgViewLbl];
    
    //UIlabel Job Status
    UILabel *lblJobstatus = [[UILabel alloc]initWithFrame:CGRectMake(20, 5,230, 20)];
    lblJobstatus.backgroundColor = [UIColor clearColor];
    [lblJobstatus setFont:FONT_NEUE_BOLD_SIZE(15)];
    [lblJobstatus setTextColor:DEFAULT_FONT_COLOR];
    if ([arrJobInfo count]>0)
        [lblJobstatus setText:[[arrJobInfo objectAtIndex:0]valueForKey:@"JobDetail"]];
    [mainScroll addSubview:lblJobstatus];
    
    //UIlabel Job Description
    
    UILabel *lblJobDes = [[UILabel alloc]initWithFrame:CGRectMake(20, 26, 230, 12)];
    lblJobDes.backgroundColor = [UIColor clearColor];
    if ([arrJobInfo count]>0)
        [lblJobDes setText:[[arrJobInfo objectAtIndex:0]valueForKey:JOBS_DESC]];
    [lblJobDes setFont:FONT_NEUE_SIZE(12)];
    [lblJobDes setTextColor:DEFAULT_FONT_COLOR];
    [mainScroll addSubview:lblJobDes];
    
    
    //UIlabel Add Materials to Job
    
    UILabel *lblAddMaterials = [[UILabel alloc]initWithFrame:CGRectMake(20, 60, 200, 20)];
    lblAddMaterials.backgroundColor = [UIColor clearColor];
    [lblAddMaterials setText:@"Add Materials to This Job:"];
    [lblAddMaterials setFont:FONT_NEUE_MEDIUM_SIZE(12)];
    [lblAddMaterials setTextColor:DEFAULT_FONT_COLOR_DARK];
    [mainScroll addSubview:lblAddMaterials];
    
    //UIlabel Desctiption
    
    UILabel *lblDecs = [[UILabel alloc]initWithFrame:CGRectMake(20, 80, 200, 20)];
    lblDecs.backgroundColor = [UIColor clearColor];
    [lblDecs setText:@"Description:"];
    [lblDecs setFont:FONT_NEUE_MEDIUM_SIZE(12)];
    [lblDecs setTextColor:DEFAULT_FONT_COLOR_DARK];
    [mainScroll addSubview:lblDecs];
    
    
    //UITextField Desctiption
    
    txtDesc = [[UITextField alloc] initWithFrame:CGRectMake(20, 100, 290, 25)];
    txtDesc.borderStyle = UITextBorderStyleNone;
//    txtDesc.background = [UIImage imageNamed:@"TxtMaterial.png"];
    [txtDesc setTextAlignment:UITextAlignmentLeft];
    txtDesc.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    txtDesc.font = [UIFont systemFontOfSize:15];
    [CommonFunctions SetLeftViewMode:txtDesc :10.0f];
    txtDesc.delegate = self;
    [mainScroll addSubview:txtDesc];
    txtDesc.layer.borderWidth = 1.0;
    
    //UIlabel Quantity
    
    
    UILabel *lblQua = [[UILabel alloc]initWithFrame:CGRectMake(20, 140, 60, 20)];
    lblQua.backgroundColor = [UIColor clearColor];
    [lblQua setText:@"Quantity:"];
    [lblQua setFont:FONT_NEUE_MEDIUM_SIZE(12)];
    [lblQua setTextColor:DEFAULT_FONT_COLOR_DARK];
    [mainScroll addSubview:lblQua];
    
    //UITextField Quantity . . . . . . .
    txtQua = [[UITextField alloc] initWithFrame:CGRectMake(95, 135, 118, 25)];
    txtQua.borderStyle = UITextBorderStyleNone;
    txtQua.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    [CommonFunctions SetLeftViewMode:txtQua :10.0f];
    txtQua.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
//    txtQua.background = [UIImage imageNamed:@"TxtMaterialsmall.png"];
    [txtQua.layer setBorderWidth:1.0];
    [txtQua setTextAlignment:UITextAlignmentLeft];
    txtQua.font = [UIFont systemFontOfSize:15];
    txtQua.delegate = self;
    [mainScroll addSubview:txtQua];
    
    //UIlabel Price
    
    UILabel *lblPrice = [[UILabel alloc]initWithFrame:CGRectMake(20, 173, 50, 20)];
    lblPrice.backgroundColor = [UIColor clearColor];
    [lblPrice setText:@"Price:"];
    [lblPrice setFont:FONT_NEUE_MEDIUM_SIZE(12)];
    [lblPrice setTextColor:DEFAULT_FONT_COLOR_DARK];
    [mainScroll addSubview:lblPrice];
    
    //UITextField Price
    txtPrice = [[UITextField alloc] initWithFrame:CGRectMake(95, 168, 118, 25)];
    txtPrice.borderStyle = UITextBorderStyleNone;
    [CommonFunctions SetLeftViewMode:txtPrice :10.0f];
    txtPrice.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    txtPrice.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
//    txtPrice.background = [UIImage imageNamed:@"TxtMaterialsmall.png"];
    [txtPrice setTextAlignment:UITextAlignmentLeft];
    txtPrice.font = [UIFont systemFontOfSize:15];
    [txtPrice.layer setBorderWidth:1.0];
    txtPrice.delegate = self;
    [mainScroll addSubview:txtPrice];
    
    //UIlabel Select Supplier
    UILabel *lblChargeType = [[UILabel alloc]initWithFrame:CGRectMake(20, 200, 75, 20)];
    lblChargeType.backgroundColor = [UIColor clearColor];
    [lblChargeType setText:@"ChargeType:"];
    [lblChargeType setFont:FONT_NEUE_MEDIUM_SIZE(12)];
    [lblChargeType setTextColor:DEFAULT_FONT_COLOR_DARK];
    [mainScroll addSubview:lblChargeType];
    //    
    // UITextfield Charge Type...
    txtChargeType = [[UITextField alloc] initWithFrame:CGRectMake(95, 200, 118, 25)];
    txtChargeType.borderStyle = UITextBorderStyleNone;
    [CommonFunctions SetLeftViewMode:txtChargeType :10.0f];
    txtChargeType.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    [txtChargeType setTextAlignment:UITextAlignmentLeft];
//    txtChargeType.background = [UIImage imageNamed:@"TxtMaterial.png"];
    [txtChargeType.layer setBorderWidth:1.0];
    [txtChargeType setPlaceholder:@"select chargeType"];
    txtChargeType.font = [UIFont systemFontOfSize:15];
    txtChargeType.delegate = self;
    [mainScroll addSubview:txtChargeType];
    //    
    //UIbutton Transparent for picker
    UIButton *btnSelectChargeType = [UIButton buttonWithType:UIButtonTypeCustom];
    [btnSelectChargeType setFrame:CGRectMake(80, 200, 118, 25)];
    [btnSelectChargeType setBackgroundColor:[UIColor clearColor]];
    [btnSelectChargeType addTarget:self action:@selector(btnSelectChargeTypeTapped:) forControlEvents:UIControlEventTouchUpInside];
    [mainScroll addSubview:btnSelectChargeType];
    //UIlabel Select Supplier
    
    UILabel *lblseleSupp = [[UILabel alloc]initWithFrame:CGRectMake(20, 230, 100, 20)];
    lblseleSupp.backgroundColor = [UIColor clearColor];
    [lblseleSupp setText:@"Select Supplier:"];
    [lblseleSupp setFont:FONT_NEUE_MEDIUM_SIZE(12)];
    [lblseleSupp setTextColor:DEFAULT_FONT_COLOR_DARK];
    [mainScroll addSubview:lblseleSupp];
    //    
    //UITextField Select Supplier
    
    txtseleSupp = [[UITextField alloc] initWithFrame:CGRectMake(20, 250, 290, 25)];
    txtseleSupp.borderStyle = UITextBorderStyleNone;
    [CommonFunctions SetLeftViewMode:txtseleSupp :10.0f];
    txtseleSupp.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    [txtseleSupp setTextAlignment:UITextAlignmentLeft];
//    txtseleSupp.background = [UIImage imageNamed:@"TxtMaterial.png"];
    [txtseleSupp setPlaceholder:@"--select Supplier--"];
    txtseleSupp.font = [UIFont systemFontOfSize:15];
    txtseleSupp.delegate = self;
    [txtseleSupp.layer setBorderWidth:1.0];
    [mainScroll addSubview:txtseleSupp];
    
    
    //UIbutton Transparent for picker
    UIButton *btnSelectSupplier = [UIButton buttonWithType:UIButtonTypeCustom];
    [btnSelectSupplier setFrame:CGRectMake(20, 250, 295, 25)];
    [btnSelectSupplier setBackgroundColor:[UIColor clearColor]];
    [btnSelectSupplier addTarget:self action:@selector(LoadPicker:) forControlEvents:UIControlEventTouchUpInside];
    [mainScroll addSubview:btnSelectSupplier];
    
    
    //UIlabel Select Supplier drop down
    
    UILabel *lbldropDown = [[UILabel alloc]initWithFrame:CGRectMake(20, 280, 250, 20)];
    lbldropDown.backgroundColor = [UIColor clearColor];
    [lbldropDown setText:@"Supplier (text) if not avaiable in drop down:"];
    [lbldropDown setFont:FONT_NEUE_MEDIUM_SIZE(12)];
    [lbldropDown setTextColor:DEFAULT_FONT_COLOR_DARK];
    [mainScroll addSubview:lbldropDown];
    
    //UITextField Select Supplier drop down
    
    txtsupplierManualOption= [[UITextField alloc] initWithFrame:CGRectMake(20, 300, 290, 25)];
    txtsupplierManualOption.borderStyle = UITextBorderStyleNone;
    [CommonFunctions SetLeftViewMode:txtsupplierManualOption :10.0f];
    txtsupplierManualOption.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    [txtsupplierManualOption setTextAlignment:UITextAlignmentLeft];
    //txtsupplierManualOption.background = [UIImage imageNamed:@"TxtMaterial.png"];
    txtsupplierManualOption.font = [UIFont systemFontOfSize:15];
    
    [txtsupplierManualOption.layer setBorderWidth:1.0];
    txtsupplierManualOption.delegate = self;
    [mainScroll addSubview:txtsupplierManualOption];
    
    
    //UIButton Click To Add Materials
    
    UIButton *btnAddMaterial = [UIButton buttonWithType:UIButtonTypeCustom];
    [btnAddMaterial addTarget:self action:@selector(AddMaterial:) forControlEvents:UIControlEventTouchDown];
    UIImage * buttonImage = [UIImage imageNamed:@"Addmaterialbtn.png"];
    [btnAddMaterial setBackgroundImage:buttonImage forState:UIControlStateNormal];
    [btnAddMaterial setTitle:@"Click to add material" forState:UIControlStateNormal];
    [btnAddMaterial.titleLabel setFont:FONT_NEUE_BOLD_SIZE(12) ];
    [btnAddMaterial setTitleColor:DEFAULT_FONT_COLOR forState:UIControlStateNormal ];
    
    btnAddMaterial.frame = CGRectMake(20, 330, 291, 37);
    [mainScroll addSubview:btnAddMaterial];
    
    
    //UIimageview Current Materials
    UIImageView *imgCurrMat = [[UIImageView alloc] initWithFrame:CGRectMake(0, 370, 329, 29)];
    imgCurrMat.image = [UIImage imageNamed:@"lblCurrMat.png"];
    imgCurrMat.contentMode = UIViewContentModeCenter;
    [mainScroll addSubview: imgCurrMat];
    
    //UIlabel Current Materials
    
    UILabel *lblCurrMat = [[UILabel alloc]initWithFrame:CGRectMake(20, 374, 329, 29)];
    lblCurrMat.backgroundColor = [UIColor clearColor];
    [lblCurrMat setFont:FONT_NEUE_SIZE(14)];
    [lblCurrMat setTextColor:DEFAULT_FONT_COLOR];
    [lblCurrMat setText:@"Current Materials"];
    [mainScroll addSubview:lblCurrMat];
    
    //UIimageview DSQP
    UIImageView *imgDSQP = [[UIImageView alloc] initWithFrame:CGRectMake(0, 373, 323, 51)];
    imgDSQP.image = [UIImage imageNamed:@"DSQP.png"];
    imgDSQP.contentMode = UIViewContentModeCenter;
    [mainScroll addSubview: imgDSQP];
    
    //UIlabel DSQP
    
    UILabel *lblD = [[UILabel alloc]initWithFrame:CGRectMake(20, 395, 65, 29)];
    lblD.backgroundColor = [UIColor clearColor];
    [lblD setText:@"Description"];
    [lblD setFont:FONT_NEUE_SIZE(12)];
    [lblD setTextColor:DEFAULT_FONT_COLOR];
    [mainScroll addSubview:lblD];
    
    //UIlabel DSQP
    
    UILabel *lblS = [[UILabel alloc]initWithFrame:CGRectMake(120, 395, 60, 29)];
    lblS.backgroundColor = [UIColor clearColor];
    [lblS setFont:FONT_NEUE_SIZE(12)];
    [lblS setTextColor:DEFAULT_FONT_COLOR];
    [lblS setText:@"Supplier"];
    [mainScroll addSubview:lblS];
    //UIlabel DSQP
    
    UILabel *lblQ = [[UILabel alloc]initWithFrame:CGRectMake(210, 395, 30, 29)];
    lblQ.backgroundColor = [UIColor clearColor];
    [lblQ setFont:FONT_NEUE_SIZE(12)];
    [lblQ setTextColor:DEFAULT_FONT_COLOR];
    [lblQ setText:@"Qty"];
    [mainScroll addSubview:lblQ];
    
    //UIlabel DSQP
    
    UILabel *lblP = [[UILabel alloc]initWithFrame:CGRectMake(260, 395, 30, 29)];
    lblP.backgroundColor = [UIColor clearColor];
    [lblP setText:@"Price"];
    [lblP setFont:FONT_NEUE_SIZE(12)];
    [lblP setTextColor:DEFAULT_FONT_COLOR];
    [mainScroll addSubview:lblP];
    
    
    //Init lastSelType
    lastSelType =0;
    //get Array
    arrSuppliers  = [DataSource getRecordsFromQuery:@"select iid,name from Suppliers"];
    //Add Temp Others value
    NSMutableDictionary *dicData = [[[NSMutableDictionary alloc]init]autorelease];
    [dicData setObject:@"Others" forKey:@"name"];
    [arrSuppliers addObject:dicData];
    
    if ([arrSuppliers count]>1)
        [txtsupplierManualOption setUserInteractionEnabled:FALSE];
    else
    {
        txtseleSupp.text = @"Others";
        [txtsupplierManualOption setUserInteractionEnabled:TRUE];
    }
    
    
    //Show Current Materials
    [self addCurrentMaterials];
    
    
    
    // NSMutable array for charge_type
    
    arrCharge_type = [[NSMutableArray alloc] initWithObjects:@"Account",@"Sub Contract",@"Stock",@"Client Stock",@"Cash",@"Cheque",@"Credit Card",@"Online", nil];
    
}

#pragma mark LoadPicker Picker Delegates
-(void)LoadPicker:(id)sender
{
    if (tmpTextField !=nil)
    {
        [tmpTextField resignFirstResponder];
        [mainScroll setContentSize:prevScrollContentSize];
    }
    
    
    [mainScroll setContentOffset:CGPointMake(0, 50) animated:YES];
    
    //    PickerViewControl *objPicker = [[PickerViewControl alloc] initWithFrame:[self.view frame]];
    objPicker = [[PickerViewControl alloc] initWithFrame:[self.view frame]];
    objPicker.arrPickerData = arrSuppliers;
    objPicker.strSelectKey = @"name";
    objPicker.selectedIndex=lastSelType;
    objPicker._delegate=self;
    [objPicker setTag:1];
    [objPicker setPicker];
    
    [self.view addSubview:objPicker];
}
-(void)pickerCloseWithTag:(int)tag
{
    [mainScroll setContentOffset:CGPointMake(0, 0) animated:YES];
   
    
    NSLog(@"PickerClosed:");
    if (tag ==1)
    {
  [txtseleSupp setText:[[arrSuppliers objectAtIndex:lastSelType]valueForKey:@"name"]];
    if ([txtseleSupp.text isEqualToString:@"Others"])
    {
        [txtsupplierManualOption setUserInteractionEnabled:TRUE];
        [txtsupplierManualOption becomeFirstResponder];
    }
    else
    {
        [txtsupplierManualOption setText:@""];
        [txtsupplierManualOption setUserInteractionEnabled:FALSE];
    }
    }
    else
    {
          [txtChargeType setText:[arrCharge_type objectAtIndex:ChargeType]];
    }
        
}
-(void)selectedRow:(int)row andValue:(NSString *)strVal andTag:(int)tag selectedRow:(int)selRow
{
    
    if (tag ==1) {
        lastSelType = selRow;
        txtseleSupp.text = [[arrSuppliers objectAtIndex:lastSelType]valueForKey:@"name"];
        
    }else if (tag==2) {
        ChargeType = selRow;
        txtChargeType.text = [arrCharge_type objectAtIndex:ChargeType];
    }
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

#pragma mark -addCurrentMaterials
-(void)addCurrentMaterials
{
    NSMutableArray *arrMaterialInfo = [DataSource getRecordsFromQuery:[NSString stringWithFormat:@" SELECT Job_materials.description,Job_materials.charge,Job_materials.rate,Job_materials.supplier FROM Job_materials where Job_materials.jid=%@",strJid]];
    //    int y =389,height= 25,gap=5;
    int y =419,height= 25,gap=5;
    
    for (int i=0;i<[arrMaterialInfo count];i++)
    {
        
        UILabel *LabelDesc = [[UILabel alloc] initWithFrame:CGRectMake(0, y, 110, height)];
          [LabelDesc setTextColor:DEFAULT_FONT_COLOR];
        LabelDesc.text= [NSString stringWithFormat:@"         %@",[[arrMaterialInfo objectAtIndex:i]valueForKey:JOB_MATERIAL_DESC]];
        LabelDesc.font = FontSize;
        LabelDesc.numberOfLines =0;
        [LabelDesc setLineBreakMode:UILineBreakModeWordWrap];
        LabelDesc.backgroundColor = [UIColor whiteColor];
        [mainScroll addSubview:LabelDesc];
        
        UILabel *LabelSupp = [[UILabel alloc] initWithFrame:CGRectMake(105, y, 90, height)];
          [LabelSupp setTextColor:DEFAULT_FONT_COLOR];
        LabelSupp.text=[NSString stringWithFormat:@"     %@",[[arrMaterialInfo objectAtIndex:i]valueForKey:JOB_MATERIAL_SUPPLIER]];
        LabelSupp.backgroundColor = [UIColor whiteColor];
        LabelSupp.font = FontSize;
        [mainScroll addSubview:LabelSupp];
        
        UILabel *LabelQty = [[UILabel alloc] initWithFrame:CGRectMake(190, y, 90, height)];
          [LabelQty setTextColor:DEFAULT_FONT_COLOR];
        LabelQty.text=[NSString stringWithFormat:@"         %@",[[arrMaterialInfo objectAtIndex:i]valueForKey:@"rate"]];
        LabelQty.font = FontSize;
        LabelQty.backgroundColor = [UIColor whiteColor];
        [mainScroll addSubview:LabelQty];
        
        UILabel *LabelPrice = [[UILabel alloc] initWithFrame:CGRectMake(250, y, 90, height)];
         [LabelPrice setTextColor:DEFAULT_FONT_COLOR];
        LabelPrice.text=[NSString stringWithFormat:@"        %@",[[arrMaterialInfo objectAtIndex:i]valueForKey:@"charge"]];
        LabelPrice.font = FontSize;
        LabelPrice.backgroundColor = [UIColor whiteColor];
        [mainScroll addSubview:LabelPrice];
        
        y = y + height +gap;
    }
    if ([[UIScreen mainScreen] bounds].size.height == 568) {
        [mainScroll setContentSize:CGSizeMake(0,150+y)];
    }
    else
    {
        [mainScroll setContentSize:CGSizeMake(0,50+y)];
    }
    prevScrollContentSize = [mainScroll contentSize];
}
#pragma mark AddMaterial Methods

-(IBAction)AddMaterial:(id)sender
{
    NSLog(@"clicked");
    if (tmpTextField !=nil)
    {
        [tmpTextField resignFirstResponder];
    }
    NSString *strMsg=@"Ok";
    
    
    if([CommonFunctions checkTextField:txtDesc])
    {
        strMsg = @"Please enter Description";
    }else if([CommonFunctions checkTextField:txtQua])
    {
        strMsg = @"Please enter Quantity";
    }else if([CommonFunctions checkTextField:txtPrice])
    {
        strMsg = @"Please enter Price";
    }
    else if([CommonFunctions checkTextField:txtseleSupp])
    {
        strMsg = @"Please select Supplier";
    }
    else if([txtseleSupp.text isEqualToString:@"Others"])
    {
        
        if([CommonFunctions checkTextField:txtsupplierManualOption])
        {
            strMsg = @"Please enter Supplier";
        }
    }
    else if([CommonFunctions checkTextField:txtChargeType])
    {
        strMsg = @"Please select Charge Type";
    }
    
    if([strMsg isEqualToString:@"Ok"])
    {
    NSString *strQuery = @"";
    if ([[txtseleSupp text]length]>0)
    {
        strCurrentTimeStamp = [CommonFunctions getCurrentTimeStampForDatabaseInsertion];
        [strCurrentTimeStamp retain];
        if ([txtseleSupp.text isEqualToString:@"Others"])
        {
            //get supplier from txtsupplierManualOption
            strQuery = [NSString stringWithFormat:@"INSERT INTO Job_materials (jid,uid,rate,charge,supplier,description,cr_date,charge_type,ref_id,sid,IsSynced)  VALUES ('%@','%@','%@','%@','%@','%@','%@','%@','%@','%@',%@)",strJid,[ElogBooksAppDelegate getValueForKey:USER_ID],txtQua.text,txtPrice.text,txtsupplierManualOption.text,txtDesc.text,strCurrentTimeStamp,txtChargeType.text,strCurrentTimeStamp,[[arrSuppliers objectAtIndex:lastSelType]valueForKey:SUPPLIERS_ID],UN_SYNCED_DATA];
        }else
        {
            
            //get supplier from    txtseleSupp
            strQuery = [NSString stringWithFormat:@"INSERT INTO Job_materials (jid,uid,rate,charge,supplier,description,cr_date,charge_type,ref_id,IsSynced)  VALUES ('%@','%@','%@','%@','%@','%@','%@','%@','%@',%@)",strJid,[ElogBooksAppDelegate getValueForKey:USER_ID],txtQua.text,txtPrice.text,txtseleSupp.text,txtDesc.text,strCurrentTimeStamp,txtChargeType.text,strCurrentTimeStamp,UN_SYNCED_DATA];
        }
        if ([DataSource executeQuery:strQuery])
        {
            NSLog(@"Value inserted");
            //show current Materials
            [self addCurrentMaterials];
            //Scroll to bottom
            CGPoint bottomOffset = CGPointMake(0, mainScroll.contentSize.height - mainScroll.bounds.size.height);
            [mainScroll setContentOffset:bottomOffset animated:YES];
            
        }
         
        if ([CommonFunctions isNetAvailable])
        {
            //sample url
            /*http://code.elogbooks.co.uk/users/jack/WOM/api/put-info.php?uid=38&UpdateType=materials&description=Mat%20Description&quantity=2&quoted=6.55&sid=1&charge_type=Account&jid=7687&qd=Add%20Materials&tstamp=07/01/2013%2010:15:00*/
            /*http://code.elogbooks.co.uk/users/jack/WOM/api/put-info.php?description=DemoDescription&uid=38&qd=Add%20Materials&quoted=1&jid=2802&sid=1&rate=100&UpdateType=materials&charge_type=Account&tstamp=09/01/201305:03:37*/
            objService=[[PutInfoClass alloc] init];
            objService._delegate=self;
            
            NSMutableDictionary *dicc=[[[NSMutableDictionary alloc] init]autorelease];
            [dicc setObject:[ElogBooksAppDelegate getValueForKey:USER_ID] forKey:USER_ID];
            [dicc setObject:@"materials" forKey:@"UpdateType"];
            [dicc setObject:txtDesc.text forKey:JOB_MATERIAL_DESC];
            [dicc setObject:txtQua.text forKey:@"quantity"]; //quantity-->Job_materials.rate
            [dicc setObject:txtPrice.text forKey:@"quoted"]; //Price -->job_materials.charge
          
            [dicc setObject:txtChargeType.text forKey:JOB_MATERIAL_CHARGE_TYPE];
            [dicc setObject:strJid forKey:JOBS_ID];
            [dicc setObject:@"Add Materials" forKey:@"qd"];
            [dicc setObject: [CommonFunctions getCurrentTimeStamp:strCurrentTimeStamp] forKey:@"tstamp"];

            if ([txtseleSupp.text isEqualToString:@"Others"])
            {
            [dicc setObject:txtsupplierManualOption.text forKey:@"supplier"];             
                
            }
            else
            {
       [dicc setObject:txtseleSupp.text forKey:@"supplier"];             
        [dicc setObject:[[arrSuppliers objectAtIndex:lastSelType]valueForKey:SUPPLIERS_ID] forKey: @"sid" ];
            }

            
            objService.argsDic=[CommonFunctions getDicAsParameter:dicc] ;
            
            objService.strWebService=[NSString stringWithFormat:@"Material:%@:%@",strJid,strCurrentTimeStamp];
            objService.strUrl= [NSString stringWithFormat:@"%@%@",[ElogBooksAppDelegate getValueForKey:BASE_URL],PUT_INFO_API];
            objService.ParentNode=@"Responses";
            objService.ChildNode=@"Response";
            objService.retType=isArray;
            [objService performSelector:@selector(setArray) withObject:nil afterDelay:0.1];
            

            
            
            
        }
        else 
        {
        [self clearAllFields]; 
        }
          
    }
    }
else
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:APP_TITLE message:strMsg delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    [alert show];
    [alert release];
}

}


#pragma mark Parsing delegates
-(void)filedWithError:(NSString *)strMsg forFlage:(NSString *)flage
{
    NSLog(@"Failed to upload the material:forjob:%@",strJid);
        [self clearAllFields];
}
-(void)EndParsingArray:(NSMutableArray *)arrData forFlage:(NSString *)flage
{
    if ([arrData count]>0)
    {
        if (!([[arrData objectAtIndex:0]rangeOfString:@"Success"].location==NSNotFound))
        {
            NSString *str_iid = [[[arrData objectAtIndex:0]componentsSeparatedByString:@":"]objectAtIndex:2];
            //update the received materials_id
            if ([str_iid length]>0)
            if ([DataSource executeQuery:[NSString stringWithFormat:@"Update Job_materials set iid='%@',IsSynced=%@ ,ref_id='' where ref_id='%@'",str_iid,SYNCED_DATA,strCurrentTimeStamp]])
                NSLog(@"Materials Value updated ");
            
        }
    }
    else 
    NSLog(@"Failed to upload the material:forjob:%@",strJid);    
    [self clearAllFields];
}

-(void)clearAllFields
{
    txtsupplierManualOption.text = @"";
    txtDesc.text = @"";
    txtQua.text = @"";
    txtPrice.text = @"";
    txtseleSupp.text = @"";
    txtChargeType.text = @"";
}
-(void)btnSelectChargeTypeTapped:(id)sender
{
    NSLog(@"@button clicked");
    
    if (tmpTextField !=nil)
    {
        [tmpTextField resignFirstResponder];
        [mainScroll setContentSize:prevScrollContentSize];
    }
    
    
    [mainScroll setContentOffset:CGPointMake(0, 50) animated:YES];
    
    //PickerViewControl *objPicker = [[PickerViewControl alloc] initWithFrame:[self.view frame]];
    objPicker = [[PickerViewControl alloc] initWithFrame:[self.view frame]];
    objPicker.arrPickerData = arrCharge_type;
    //objPicker.strSelectKey = @"name";
    objPicker.selectedIndex=ChargeType;
    objPicker._delegate=self;
    [objPicker setTag:2];
    
    [objPicker setPicker];
    
    [self.view addSubview:objPicker];
    
}
#pragma mark - backTapped Method

-(IBAction)btnBackTapped:(id)sender
{
    
    [self.navigationController popViewControllerAnimated:YES];
}


#pragma mark -
#pragma mark UITextField Methods

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    tmpTextField = textField;
    [mainScroll setContentOffset:CGPointMake(0,textField.center.y-100) animated:YES];
    [mainScroll setContentSize:CGSizeMake(320, 700)];
    
    
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    if (textField == txtQua || textField == txtPrice)
    {
        static NSCharacterSet *charSet = nil;
        if(!charSet) {
            charSet = [[[NSCharacterSet characterSetWithCharactersInString:@"0123456789."] invertedSet] retain];
        }
        NSRange location = [string rangeOfCharacterFromSet:charSet];
        return (location.location == NSNotFound);
        return YES;
    }
    else
        return  YES;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    
    [UIView animateWithDuration:0.5 animations:^{
        [textField resignFirstResponder];
        [mainScroll setContentSize:prevScrollContentSize];
    }];
    [mainScroll setContentOffset:CGPointMake(0,0) animated:YES];
    return YES;
}

#pragma mark -
#pragma mark UIToolbar Methods



- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
