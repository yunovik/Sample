//
//  AssetsListScreen.m
//  ElogBooks
//
//  Created by i-Verve on 11/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import "AssetsListScreen.h"
#import "AssetsInfoScreen.h"

#define PICKER_TAG 1000


@interface AssetsListScreen ()

@end

@implementation AssetsListScreen

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    
    if (self) {
        // Custom initialization
    }
    
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    
    self.title = @"Assets";  
    [CommonFunctions setTitleView:self amdtitle:@"Assets"];

    
    //UIview for Planned and Due Job
    UIView *backView = [[[UIView alloc] init] autorelease];
    backView.frame = CGRectMake(0, 0, 320, 41);
    backView.backgroundColor = getImageColor(@"Cell_Stripe.png");
    //    [View setBackgroundColor:[UIColor brownColor]];
    //[View release];
    
    
    //Back Button On Navigation
    [CommonFunctions setBack:self target:@selector(btnBackTapped:)];

    //UIButton  btnPicker
    btnPicker = [UIButton buttonWithType:UIButtonTypeCustom];
    [btnPicker addTarget:self action:@selector(OpenPicker:)forControlEvents:UIControlEventTouchUpInside];
    [btnPicker setTitleColor:[UIColor blackColor] forState:UIControlStateNormal ];
    btnPicker.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
    [btnPicker.titleLabel setFont:FONT_NEUE_SIZE(14) ];  
    [btnPicker setTitleColor:DEFAULT_FONT_COLOR forState:UIControlStateNormal ];
    [btnPicker setBackgroundImage:[UIImage imageNamed:@"Btn_JobInfo.png"] forState:UIControlStateNormal];
    btnPicker.frame = CGRectMake(7.0, 6.0, 300.0, 29);
    //    btnPicker.tag = btnPicker_TAG;
    btnPicker.backgroundColor = [UIColor clearColor];
    [backView addSubview:btnPicker];
    
    [self.view addSubview:backView];
    


    //NSMutableArrayy
    
    //arrPickerData = [[NSMutableArray alloc]initWithObjects:@"The Mall 1 ",@"The Mall 2  ",@"The Mall 3  ",@"The Mall 4  ",@"The Mall 5  ", nil];
    
    arrPickerData  =  [DataSource getRecords:@"cid,customer" From:@"Customers"];

    if([arrPickerData count] > 0){
        [btnPicker setTitle:[NSString stringWithFormat:
                         @"%@  ",[[arrPickerData objectAtIndex:0] objectForKey:CUSTOMERS_CUSTOMER]] forState:UIControlStateNormal];
        
        strCId = [[arrPickerData objectAtIndex:0] objectForKey:CUSTOMERS_ID];

    }
    else
    {
        [btnPicker setTitle:[NSString stringWithFormat:
                             @"--  "] forState:UIControlStateNormal];
        [btnPicker setEnabled:NO];
    }

    arrAssets = [DataSource getRecordsFromQuery:[NSString stringWithFormat:
                                                 @"Select * from Assets Where cid = %@",strCId]];
    
    
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    screenBounds.origin.y=41;
    screenBounds.size.height=screenBounds.size.height-104;
    
    tblView = [[UITableView alloc] initWithFrame:screenBounds style:UITableViewStylePlain];
//    [tblView setShowsVerticalScrollIndicator:NO];
    [tblView setDataSource:self];
    [tblView setDelegate:self];
//    [tblView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    [self.view addSubview:tblView];
    [tblView setBackgroundColor:[UIColor clearColor]];
//    [self.view setBackgroundColor:getImageColor(@"Default.png")];
    [self.view setBackgroundColor:[UIColor whiteColor]];

}


#pragma mark -
#pragma mark - OpenPicker Method

-(IBAction)OpenPicker:(id)sender
{
    PickerViewControl *objPicker = [[PickerViewControl alloc] initWithFrame:[self.view frame]];
    objPicker.arrPickerData = arrPickerData;
    objPicker.strSelectKey = @"customer";
    objPicker._delegate=self;
    objPicker.selectedIndex=lastSelectedIndex;
    [objPicker setPicker];
    [self.view addSubview:objPicker];
}

-(void)pickerCloseWithTag:(int)tag 
{
    NSLog(@"PickerClosed:");
}

-(void)selectedRow:(int)row andValue:(NSString *)strVal andTag:(int)tag selectedRow:(int)selRow
{
    
    lastSelectedIndex=selRow;
    
    strCId = [[arrPickerData objectAtIndex:selRow] objectForKey:CUSTOMERS_ID];
    
    NSLog(@"\n %@ : %@",strCId,strVal);
    
    arrAssets = [DataSource getRecordsFromQuery:[NSString stringWithFormat:
                                                 @"Select * from Assets Where cid = %@",strCId]];
    [tblView reloadData];

    [btnPicker setTitle:[NSString stringWithFormat:@"%@  ",strVal] forState:UIControlStateNormal];

}


#pragma mark -
#pragma mark Table view methods

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrAssets.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 61;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSString *CellIdentifier = [NSString stringWithFormat:@"Cel_%d",indexPath.row];
    
    NSMutableDictionary *redDic = [arrAssets objectAtIndex:indexPath.row];
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    cell = nil;
    if (cell == nil) {
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] ;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
//        [cell.contentView setBackgroundColor:getImageColor(@"Cell_Stripe.png")];
        
        
        UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(10, 5, 40, 15)];
        label.backgroundColor = [UIColor clearColor];
        [label setFont:FONT_NEUE_BOLD_SIZE(12)];
        [label setTextColor:DEFAULT_FONT_COLOR];
        label.text = [redDic objectForKey:ASSETS_ID];
        [cell.contentView addSubview:label];
        [label release];
        
        UILabel *lblFloor = [[UILabel alloc] initWithFrame:CGRectMake(10, 20, 130, 15)];
        lblFloor.backgroundColor = [UIColor clearColor];
        lblFloor.numberOfLines = 0;
        [lblFloor setFont:FONT_NEUE_SIZE(12)];
        [lblFloor setTextColor:DEFAULT_FONT_COLOR];
        lblFloor.text = [redDic objectForKey:ASSETS_LOCATION];
        [cell.contentView addSubview:lblFloor];
        [lblFloor release];
        //        
        UILabel *lblAssetsDesc = [[UILabel alloc] initWithFrame:CGRectMake(50, 5, 200, 15)];
        lblAssetsDesc.backgroundColor = [UIColor clearColor];
        lblAssetsDesc.numberOfLines = 0;
        [lblAssetsDesc setFont:FONT_NEUE_BOLD_SIZE(12) ];
        [lblAssetsDesc setTextColor:DEFAULT_FONT_COLOR];
        lblAssetsDesc.text = [redDic objectForKey:ASSETS_DESC];
        [cell.contentView addSubview:lblAssetsDesc];
        [lblAssetsDesc release];
        //        
        
        UIButton *btnInfo = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        btnInfo = [[UIButton alloc]init];
        btnInfo=[UIButton buttonWithType:UIButtonTypeCustom];
        [btnInfo setFrame:CGRectMake(260,5,50,50)];
        UIImage *newButtonImage = [UIImage imageNamed:@"Info.png"];        
        [btnInfo setImage:newButtonImage forState:UIControlStateNormal];
        [btnInfo addTarget:self action:@selector(btnInfoTapped:) forControlEvents:UIControlEventTouchUpInside];
        [btnInfo setTitle:@"-" forState:UIControlStateNormal];
        [btnInfo setEnabled:YES];
        [btnInfo setTag:indexPath.row];
        [cell.contentView addSubview:btnInfo];
        [btnInfo release];

//        UIView *selectedView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 61)];
//        [selectedView setBackgroundColor:getImageColor(@"Cell_Stripe_Sel.png")];
//        //[selectedView setBackgroundColor:[UIColor greenColor]];
//        [cell setSelectedBackgroundView:selectedView];
    }
    
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
//    AssetsInfoScreen *objNav = [[AssetsInfoScreen alloc] initWithNibName:@"AssetsInfoScreen" bundle:nil];
//    [self.navigationController pushViewController:objNav animated:YES];
//    [objNav release];
    
}

- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath
{
//    [[tableView cellForRowAtIndexPath:indexPath] setBackgroundView:[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"cellUnselected"]]];
}


-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 60;
}

-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:   (NSInteger)section{
    
    UIView *FooterView =[[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 44)];
    FooterView.backgroundColor = getImageColor(@"Cell_Stripe.png");
    
    UILabel *lblSerchServer = [[UILabel alloc] initWithFrame:CGRectMake(60 , 7, 200, 40)];
    lblSerchServer.backgroundColor = [UIColor clearColor];
    [lblSerchServer setText:@"Continue Searching on server"];
    [lblSerchServer setFont:FONT_NEUE_BOLD_SIZE(12) ];
    [lblSerchServer setTextColor:DEFAULT_FONT_COLOR];
    [FooterView addSubview:lblSerchServer];    
    
    UIButton  *btnSearch = [UIButton buttonWithType:UIButtonTypeCustom];
    [btnSearch addTarget:self action:@selector(btnSearchTapped:)forControlEvents:UIControlEventTouchUpInside];
    [btnSearch setTag:111];
    btnSearch.frame = CGRectMake(0, 0, 320, 44);
    //    btnFind.tag = btnFind_TAG;
    btnSearch.backgroundColor = [UIColor clearColor];
    [FooterView addSubview:btnSearch];

    return FooterView;
    
}

-(void)EndParsing:(NSMutableArray *)arrData forFlage:(NSString *)flage
{
    if ([flage isEqualToString:@"searchForAssets"] || [flage isEqualToString:@"searchForJobs"]) //latlon parsing result
    {
        
        if ([arrData count]>0)

        {
        NSMutableArray *arrTempAssets = [[[NSMutableArray alloc]initWithArray:arrData]autorelease];
        NSLog(@"Deleting %@ values..",flage);
        [DataSource deleteArray:arrTempAssets toTable:TBL_ASSETS CompareKey:ASSETS_ID ];
        NSLog(@"Inserting %@ values..",flage);
       DataSource *dataObj = [[DataSource alloc]init];
        [dataObj insertArray:arrTempAssets toTable:TBL_ASSETS :SYNCED_DATA];
        [dataObj release];
        
        [arrAssets removeAllObjects];
        arrAssets = arrData;
        [tblView reloadData];
        }
        else 
        {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:APP_TITLE message:@"No Data Available!" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
            [alert show];
            [alert release]; 
        }
    }
}


#pragma mark -
#pragma mark - backTapped Method

-(IBAction)btnSearchTapped:(id)sender
{
    objWebService=[[getWebService alloc] init];
    objWebService._delegate=self;
    NSMutableDictionary *dicc=[[[NSMutableDictionary alloc] init]autorelease];
    [dicc setObject:[ElogBooksAppDelegate getValueForKey:USER_ID] forKey:@"01:uid"];
    
    
    
    [dicc setObject:strCId forKey:@"03:cid"];
    
    NSString *strSearchFor;
    strSearchFor = @"Assets";
    [dicc setObject:strSearchFor forKey:@"02:DataTable"];
    objWebService.strWebService=@"searchForAssets";
    objWebService.strParent=SEARCH_PARENT_NODE_ASSETS;
    objWebService.strSubParent=SEARCH_CHILD_NODE_ASSETS;
    
    objWebService.argsDic=dicc;
//    objWebService.strUrl= [NSString stringWithFormat:@"http://code.elogbooks.co.uk/users/jack/WOM/%@",SEARCH_URL];
    objWebService.strUrl = [NSString stringWithFormat:@"%@%@", [ElogBooksAppDelegate getValueForKey:BASE_URL],SEARCH_URL];
    [objWebService performSelector:@selector(setArray) withObject:nil afterDelay:0.1];
}

-(void)filedWithError:(NSString *)strMsg forFlage:(NSString *)flage
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:APP_TITLE message:strMsg delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    [alert show];
    [alert release]; 
    
} 

-(IBAction)btnBackTapped:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}


#pragma mark ButtonInfoTapped
-(IBAction)btnInfoTapped:(id)sender
{
    NSLog(@"clicked Info");
    
    NSString *strAId = [[arrAssets objectAtIndex:[sender tag]] objectForKey:ASSETS_ID];
    
    AssetsInfoScreen *objNav = [[AssetsInfoScreen alloc] initWithNibName:@"AssetsInfoScreen" bundle:nil];
    objNav.strAId=strAId;
    [self.navigationController pushViewController:objNav animated:YES];
    [objNav release];

}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
