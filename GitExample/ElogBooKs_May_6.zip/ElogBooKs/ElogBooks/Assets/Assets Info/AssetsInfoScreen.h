//
//  AssetsInfoScreen.h
//  ElogBooks
//
//  Created by i-Verve on 13/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AssetsInfoScreen : UIViewController<UIScrollViewDelegate,UITableViewDelegate,UITableViewDataSource>
{
    UIScrollView *scrVertical;
    NSMutableArray  *arrItems;
    NSMutableArray *arrData;
    NSMutableArray *arrWorkDone;
    NSMutableArray *arrAssetsInfoKey,*arrAttachmentKey;
    
    NSMutableArray *arrAttachment;
    
    
    CGSize _stringWork;
    UITableView *tblView;
    
    BOOL isShow1,isShow2,isShow3;
    
}

@property(retain,nonatomic)NSString *strAId;
@end
