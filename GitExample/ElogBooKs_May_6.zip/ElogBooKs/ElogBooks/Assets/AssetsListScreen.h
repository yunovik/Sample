//
//  AssetsListScreen.h
//  ElogBooks
//
//  Created by i-Verve on 11/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AssetsListScreen : UIViewController <
UITableViewDataSource,
UITableViewDelegate,
PickerViewControlDelegate,
MYXMLParserDelegate>
{
    UIButton *btnPicker;
    
    UITableView *tblView;
    
    NSMutableArray *arrPickerData;
    
    NSMutableArray *arrAssets;
    
    getWebService *objWebService;

    int lastSelectedIndex;
    
    NSString *strCId;
}
@end
