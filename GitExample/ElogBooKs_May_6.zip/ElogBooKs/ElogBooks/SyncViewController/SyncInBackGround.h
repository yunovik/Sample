//
//  SyncInBackGround.h
//  ElogBooks
//
//  Created by Rajan on 17/01/13.
//  Copyright (c) 2013 nayanmist@gmail.com. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "UploadDatabase.h"
#import "RefreshDatabase.h"

@interface SyncInBackGround : NSObject
<
UploadDataBaseDelegate,
RefreshDatabaseDelegate
>
{
    NSTimer *_timer;

    int counter;
}

-(void)setTimerDuration;
-(void)InValidate;

@end
