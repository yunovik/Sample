//
//  SyncViewController.m
//  ElogBooks
//
//  Created by Rajan on 17/01/13.
//  Copyright (c) 2013 nayanmist@gmail.com. All rights reserved.
//

#import "SyncViewController.h"
#import "HomeScreen.h"
#import "SyncInBackGround.h"
@interface SyncViewController ()

@end

@implementation SyncViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
                [lblStatus setTextColor:DEFAULT_FONT_COLOR];
//    [self.view setBackgroundColor:getImageColor(@"Default.png")];
    self.navigationController.navigationBar.hidden = YES;
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    
    UIImageView *imgBack = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, screenBounds.size.width, screenBounds.size.height)];
//    [imgBack setImage:[UIImage imageNamed:@"Default-568h@2x.png"]];
    [self.view addSubview:imgBack];
    [self.view sendSubviewToBack:imgBack];
      
    NSString *strNewJobsCount = nil;
    strNewJobsCount = [DataSource getStringFromQuery:@"select COUNT(*) from NewJobs"];
    if ([strNewJobsCount intValue]>0)
    {
            [self UpdateNewJobs];
    }
    else 
    {
            [self Start_Update];
    }

    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

-(void)UpdateNewJobs
{
    NSMutableArray *arrPutInfo = [CommonFunctions getArraynewReactiveJobs];
    UploadDatabase *objPutInfo = [[UploadDatabase alloc] init];
    objPutInfo.arrWebServiceObjects = arrPutInfo;
    objPutInfo._delegate=self;
    [objPutInfo Uploading:@"START"];
}

-(void)Start_Update
{
    NSMutableArray *arrPutInfo = [CommonFunctions getArrayForPutInfo];
    UploadDatabase *objPutInfo = [[UploadDatabase alloc] init];
    objPutInfo.arrWebServiceObjects = arrPutInfo;
    objPutInfo._delegate=self;
    [objPutInfo Uploading:@"START"];
}

#pragma mark DataInserted
-(void)DataInserted
{
    //Enable view
    [progressBar setProgress:1.0 animated:YES];
    NSLog(@"values successfully inserted");
    
    //set settings Label text "settings_TimeStamp"
    
    [DataSource executeQuery:[NSString stringWithFormat:@"Update Upload_Info set settings_Timestamp = '%@' where rowid =1",[CommonFunctions getCurrentTimeStampForDatabaseInsertion]]];
    
    SyncInBackGround *objSync = (SyncInBackGround *)[ElogBooksAppDelegate getSyncInBackGroundObj];
    [objSync setTimerDuration];
    
    HomeScreen  *objNav = [[[HomeScreen alloc] initWithNibName:@"HomeScreen" bundle:nil]autorelease];
    [self.navigationController pushViewController:objNav animated:YES];

}

#pragma mark TaskAborted
-(void)TaskAborted
{
    [progressBar setProgress:1.0 animated:YES];
    NSLog(@"values not inserted--failed");
    
    HomeScreen  *objNav = [[[HomeScreen alloc] initWithNibName:@"HomeScreen" bundle:nil]autorelease];
    [self.navigationController pushViewController:objNav animated:YES];
}


#pragma -
#pragma -UploadDataBaseDelegate

-(void)UploadComplete:(NSMutableDictionary *)_responceDic;
{
    if ([_responceDic objectForKey:CREATE_JOB]!=nil) //is uploaded job creation status
    {
    [self Start_Update];
    }
    else  //normal uploading return
    {
    NSLog(@"Upload Response \n %@",[_responceDic description]);
    
    refreshObj = [[RefreshDatabase alloc]init];
    refreshObj._delegate =self;
    
    [refreshObj refreshDataBase:@"START"];
    
    [progressBar setProgress:0.00];
    }

}

-(void)setProgress:(float)val forFlag:(NSString *)strFlag
{
    
    [lblStatus setText:strFlag];
    NSLog(@" \n Current Progress: %f",val);
    [progressBar setProgress:val/100.00];
    
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
