//
//  SyncInBackGround.m
//  ElogBooks
//
//  Created by Rajan on 17/01/13.
//  Copyright (c) 2013 nayanmist@gmail.com. All rights reserved.
//

#import "SyncInBackGround.h"

@implementation SyncInBackGround

-(void)InValidate
{
    if (_timer!=nil)
    {
    [_timer invalidate];
         _timer = nil;
    }
}
-(void)setTimerDuration
{
    

    
    counter=0;
    
    NSString *strMinutes = [DataSource getStringFromQuery:
                            [NSString stringWithFormat:
                             @"Select Time from Setting"]];
    if ([strMinutes isEqualToString:@"Manual"])
    {
      
        if (_timer!=nil)
            [_timer invalidate];
            _timer = nil;
    }
    else {
        
        //Invalidate the previous timer
        if (_timer!=nil)
        {
            [_timer invalidate];
            _timer = nil;
        }
        float seconds = [strMinutes intValue]*60;
      //static value
//  seconds = 30;
    _timer = [NSTimer scheduledTimerWithTimeInterval:seconds target:self selector:@selector(SyncStart) userInfo:nil repeats:YES];        
    }
    
}

-(void)SyncStart
{
    
    counter++;
    
    
    //NSLog(@"Timer Called.... %d",counter);
    if ([CommonFunctions isNetAvailable])
    {
        
        //Allocate Co-ordinates
      [CommonFunctions performSelectorOnMainThread:@selector(AllocCooridnates) withObject:nil waitUntilDone:NO];
        
        //if normal
        NSString *strNewJobsCount = nil;
        strNewJobsCount = [DataSource getStringFromQuery:@"select COUNT(*) from NewJobs"];
        if ([strNewJobsCount intValue]>0)
        {
            [self UpdateNewJobs];
        }
        else 
        {
            [self Start_Update];
        }
             
    }
  
}


#pragma -
#pragma -UploadDataBaseDelegate
-(void)UpdateNewJobs
{
    //set isSync_ON key ON
    [ElogBooksAppDelegate SetGlobalObject:@"YES" :IsSync_ON];
    NSMutableArray *arrPutInfo = [CommonFunctions getArraynewReactiveJobs];
    UploadDatabase *objPutInfo = [[UploadDatabase alloc] init];
    objPutInfo.arrWebServiceObjects = arrPutInfo;
    objPutInfo._delegate=self;
    [objPutInfo Uploading:@"START"];
}

-(void)UploadComplete:(NSMutableDictionary *)_responceDic;
{
    
    if ([_responceDic objectForKey:CREATE_JOB]!=nil) //is uploaded job creation status
    {
        [self Start_Update];
    }
    else
    {
    NSLog(@"Upload Response \n %@",[_responceDic description]);
    
    RefreshDatabase *refreshObj = [[RefreshDatabase alloc]init];
     refreshObj.IsExecutingBackground = @"YES";   
    refreshObj._delegate =self;
    
    [refreshObj refreshDataBase:@"START"];
    }
    
}

-(void)setProgress:(float)val forFlag:(NSString *)strFlag
{
    NSLog(@" \n Current Progress: %f",val);
}



-(void)Start_Update
{
    //set isSync_ON key ON
    [ElogBooksAppDelegate SetGlobalObject:@"YES" :IsSync_ON];
    
    NSMutableArray *arrPutInfo = [CommonFunctions getArrayForPutInfo];
    UploadDatabase *objPutInfo = [[UploadDatabase alloc] init];
    objPutInfo.arrWebServiceObjects = arrPutInfo;
    objPutInfo._delegate=self;
    [objPutInfo Uploading:@"START"];
}

#pragma mark DataInserted
-(void)DataInserted
{
    
    [[NSNotificationCenter defaultCenter] 
     postNotificationName:@"TestNotification" 
     object:self];
    //Set Settings label text content "settings_Timestamp"
    [DataSource executeQuery:[NSString stringWithFormat:@"Update Upload_Info set settings_Timestamp = '%@' where rowid =1",[CommonFunctions getCurrentTimeStampForDatabaseInsertion]]];
    
    //set isSync_ON key OFF
    [ElogBooksAppDelegate SetGlobalObject:@"NO" :IsSync_ON];
    
    NSLog(@"values successfully inserted");
}

#pragma mark TaskAborted
-(void)TaskAborted
{
    //set isSync_ON key OFF
    [ElogBooksAppDelegate SetGlobalObject:@"NO" :IsSync_ON];

    NSLog(@"values not inserted--failed");
    
}


@end
