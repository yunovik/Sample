//
//  SplashScreenViewController.m
//  ELogBooks
//
//  Created by nayan mistry on 04/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import "SplashScreenViewController.h"
#import "LoginScreen.h"
#import "SyncViewController.h"

@interface SplashScreenViewController ()

@end

@implementation SplashScreenViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{

    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    
    if (self) 
    {
        // Custom initialization
    }
    
    return self;
}

-(void)viewWillAppear:(BOOL)animated
{
         //Hide Navigation Bar 
         self.navigationController.navigationBar.hidden = YES;
     //Start animating
    [activityIndicator startAnimating];
     [super viewWillAppear:animated];
}

- (void)viewDidLoad
{
    CGRect screenBounds = [[UIScreen mainScreen] bounds];

    UIImageView *imgBack = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, screenBounds.size.width, screenBounds.size.height)];
    [imgBack setImage:[UIImage imageNamed:@"Default-568h@2x.png"]];
    [self.view addSubview:imgBack];
    [self.view sendSubviewToBack:imgBack];

    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self performSelector:@selector(MoveToLogin) withObject:nil afterDelay:0.2];
}


-(void)MoveToLogin
{
    
    [activityIndicator stopAnimating];
    self.navigationController.navigationBar.hidden = NO;
    
    //Push
//    SyncViewController *objNav = [[[SyncViewController alloc] initWithNibName:@"SyncViewController" bundle:nil]autorelease];
    LoginScreen  *objNav = [[[LoginScreen alloc] initWithNibName:@"LoginScreen" bundle:nil]autorelease];
    //UploadFile  *objNav = [[[UploadFile alloc] initWithNibName:@"UploadFile" bundle:nil]autorelease];
    objNav.navigationItem.hidesBackButton = YES;
    [self.navigationController pushViewController:objNav animated:YES];

}

- (void)viewDidUnload
{
    [super viewDidUnload];
    activityIndicator = nil;
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
