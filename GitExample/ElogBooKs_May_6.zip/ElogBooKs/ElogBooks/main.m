//
//  main.m
//  ElogBooks
//
//  Created by nayan mistry on 07/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ElogBooksAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool
    {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ElogBooksAppDelegate class]));
    }
    
}


































































