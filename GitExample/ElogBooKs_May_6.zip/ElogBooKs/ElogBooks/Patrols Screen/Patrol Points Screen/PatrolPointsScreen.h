//
//  PatrolPointsScreen.h
//  ElogBooks
//
//  Created by I-VERVE5 on 12/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PatrolsInfoScreen.h"
#import "MEAlertView.h"
@interface PatrolPointsScreen : UIViewController<UITableViewDelegate,UITableViewDataSource,MEAlertViewDelegate,PutInfoDelegate,UIAlertViewDelegate>

{
    UITableView *tblPatrolInfo;
    NSMutableArray *arrPatrolList;
    MEAlertView *objAlert;
    NSMutableArray *arrJobInfo;
    //Webservice Delegates
    PutInfoClass *objService;
    NSString *strCurrentTimeStamp;
    BOOL isUploadingLastPoint,isJobStarted;
    UILabel *lblPatrolcurrentStatus;
}

@property(retain,nonatomic)NSString *strJid,*strTimeRange,*strIsPatrolUnordered;
@property(nonatomic,assign)BOOL isPushedFromInfo;
-(NSString *)CheckRequiredValue:(NSString *)currentValue;
-(void)CompletePatrol:(NSMutableDictionary *)dicSelected;
-(void)completePoint:(NSMutableDictionary *)dicCurrentRecord;
-(IBAction)CompleteInOrderTapped:(id)sender;
-(IBAction)ComplteWithoutOrderTapped:(id)sender;
@end
