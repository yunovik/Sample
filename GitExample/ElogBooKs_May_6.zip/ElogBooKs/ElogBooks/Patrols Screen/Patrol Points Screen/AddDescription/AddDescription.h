//
//  AddDescription.h
//  ElogBooks
//
//  Created by nayan mistry on 04/01/13.
//  Copyright (c) 2013 nayanmist@gmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PutInfoClass.h"
@interface AddDescription : UIViewController <UITextViewDelegate,PutInfoDelegate>
{
    
    UIScrollView *ScrView;
      UITextView *txtView;
    Reachability *reachObj;
    //Webservice Delegates
    PutInfoClass *objService;
    UIView *alertView;
    
}
-(void)btnSave_Tapped:(id)sender;
@property (nonatomic,retain)NSString *strJid;
@property (nonatomic,retain)NSMutableDictionary *dicRecord;
@property (readwrite,assign)BOOL isNotMissedAnyPoint;
@end
