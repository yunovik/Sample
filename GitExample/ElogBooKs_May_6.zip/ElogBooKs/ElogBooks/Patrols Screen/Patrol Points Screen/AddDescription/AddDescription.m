//
//  AddDescription.m
//  ElogBooks
//
//  Created by nayan mistry on 04/01/13.
//  Copyright (c) 2013 nayanmist@gmail.com. All rights reserved.
//

#import "AddDescription.h"
#import "PatrolsScreen.h"
@interface AddDescription ()

@end

@implementation AddDescription
@synthesize strJid,dicRecord,isNotMissedAnyPoint;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [CommonFunctions setTitleView:self amdtitle:@"Complete Patrol"];
    [CommonFunctions setBack:self target:@selector(btnBackTapped:)];
//    [self.navigationController.navigationBar setUserInteractionEnabled:NO];

//    [self.view setBackgroundColor:getImageColor(@"Default.png")];
    [self.view setBackgroundColor:[UIColor whiteColor]];
    
    ScrView= [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, 320, 280)];
    [ScrView setBackgroundColor:[UIColor clearColor]]; 
    [ScrView setScrollEnabled:YES];
    [ScrView setScrollEnabled:NO];
    [ScrView setContentSize:CGSizeMake(320, 340)];
    [self.view addSubview:ScrView];
    
    
    txtView = [[UITextView alloc] initWithFrame:CGRectMake(10, 10, 300, 170)];
    [[txtView layer] setBorderColor:[[UIColor blackColor] CGColor]];
    [[txtView layer] setBorderWidth:2.0f];
    [[txtView layer] setCornerRadius:5.0f];
    [txtView setFont:FONT_NEUE_BOLD_SIZE(20)];
    txtView.textColor = [UIColor grayColor];
    [txtView setText:@"Tap to begin Description"];
    
    CGFloat topCorrect = ([txtView bounds].size.height - [txtView contentSize].height * [txtView zoomScale])/2.0;
    topCorrect = ( topCorrect < 0.0 ? 0.0 : topCorrect );
    txtView.contentOffset = (CGPoint){.x = 0, .y = -topCorrect};
    
    
    [txtView setTextAlignment:UITextAlignmentCenter];
    
    [txtView setContentMode:UIViewContentModeCenter];
    [txtView setDelegate:self];
    [ScrView addSubview:txtView];
    
    //UIButton *btnSave = [[UIButton alloc] initWithFrame:CGRectMake(10, 175, 300, 25)];
    UIButton *btnSave = [CommonFunctions buttonWithTitle:@"Complete Patrol" andFrame:CGRectMake(10, 195, 300, 30)];
    [btnSave addTarget:self action:@selector(btnSave_Tapped:) forControlEvents:UIControlEventTouchUpInside];
    [btnSave setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [[btnSave layer] setBorderColor:[[UIColor colorWithPatternImage:[UIImage imageNamed:@"Assets_Stripe_Sel.png"]] CGColor]];
    [[btnSave layer] setBorderWidth:2.0f];
    [[btnSave layer] setCornerRadius:5.0f];
    [btnSave setTitle:@"Complete Job" forState:UIControlStateNormal];
    
    [ScrView addSubview:btnSave];
    
    
    
    
    // Do any additional setup after loading the view from its nib.
}

-(void)viewDidAppear:(BOOL)animated
{
    if (isNotMissedAnyPoint)
    {
        alertView = [CommonFunctions AlertWithMessage:@"Please wait ..."];
        [self.view addSubview:alertView];
        [self UploadJobDetails];
    }
}

#pragma mark UploadDirectly
-(void)UploadJobDetails
{

        NSString *strCurrentTimeStamp = [CommonFunctions getCurrentTimeStampForDatabaseInsertion];
        
        if ([DataSource executeQuery:[NSString stringWithFormat:@"insert into Job_lines (jid,eid,tstamp,hours,travel,miles,name,helpdesk,call_type,IsSynced)values(%@,%@,'%@',0,0,0,'%@','N/A','N/A',%@)",strJid,[ElogBooksAppDelegate getValueForKey:USER_ID],strCurrentTimeStamp,[ElogBooksAppDelegate getValueForKey:USER_NAME],UN_SYNCED_DATA]])
        {
            NSLog(@"Job Lines Description Inserted");
            //now insert eng_complete
            if ([DataSource executeQuery:[NSString stringWithFormat:@"Update Jobs set eng_complete='%@',IsSynced=%@ where jid=%@",strCurrentTimeStamp,UN_SYNCED_DATA,strJid]])
                NSLog(@"Eng_complete value set ");
            
        }
        
        if ([CommonFunctions isNetAvailable])
        {
            
            //Upload the completed JOb
            /*http://code.elogbooks.co.uk/users/jack/WOM/api/put-info.php?uid=38&UpdateType=jobs&qd=Update&tstamp=27/12/2012%2018:35:20&jid=2824&eng_complete=27/12/2012%2018:35:20&description=testeddesc */
            
            objService=[[PutInfoClass alloc] init];
            objService._delegate=self;
            
            NSMutableDictionary *dicc=[[[NSMutableDictionary alloc] init]autorelease];
            [dicc setObject:[ElogBooksAppDelegate getValueForKey:USER_ID] forKey:USER_ID];
            [dicc setObject:@"jobs" forKey:@"UpdateType"];
            [dicc setObject:@"Update" forKey:@"qd"];
            [dicc setObject: [CommonFunctions getCurrentTimeStamp:strCurrentTimeStamp] forKey:@"tstamp"];
            [dicc setObject:strJid forKey:JOBS_ID];
            [dicc setObject:[CommonFunctions getCurrentTimeStamp:strCurrentTimeStamp] forKey:JOBS_ENG_COMPLETE];
            
            
            objService.argsDic=[CommonFunctions getDicAsParameter:dicc] ;
            
            objService.strWebService=[NSString stringWithFormat:@"JobsComplete:%@",strJid];
            objService.strUrl= [NSString stringWithFormat:@"%@%@",[ElogBooksAppDelegate getValueForKey:BASE_URL],PUT_INFO_API];
            objService.ParentNode=@"Responses";
            objService.ChildNode=@"Response";
            objService.retType=isArray;
            [objService performSelector:@selector(setArray) withObject:nil afterDelay:0.1];
            
            
        }
        else   //job completed 
        {
            if ([DataSource executeQuery:[NSString stringWithFormat:@"Update Jobs set eng_complete='%@',IsSynced=%@ where jid=%@",strCurrentTimeStamp,UN_SYNCED_DATA,strJid]])
                NSLog(@"Eng_complete value set ");
            
                //Remove the alert view
                [alertView removeFromSuperview];
                alertView = nil;
            
            NSArray *arrviewControllers = [self.navigationController viewControllers];
            PatrolsScreen *obj;
            for (int i=0;i<[arrviewControllers count];i++)
            {
                if ([[arrviewControllers objectAtIndex:i]isKindOfClass:[PatrolsScreen class]])
                {
                    obj = (PatrolsScreen *)[arrviewControllers objectAtIndex:i];
                    break; 
                    
                }
            }
            
            
            if (obj !=nil)
            {
                
                [self.navigationController popToViewController:obj animated:NO];
            }else
            {
                NSLog(@"navigation controller crashed");
            }
        }
}

#pragma  mark btnSave_Tapped
-(void)btnSave_Tapped:(id)sender
{
    
    
   if (([[txtView.text stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0) && (!([txtView.text isEqualToString:@"Tap to begin Description"])))
   {
       NSString *strCurrentTimeStamp = [CommonFunctions getCurrentTimeStampForDatabaseInsertion];

       if ([DataSource executeQuery:[NSString stringWithFormat:@"insert into Job_lines (jid,eid,tstamp,hours,travel,miles,description,name,helpdesk,call_type,IsSynced)values(%@,%@,'%@',0,0,0,'%@','%@','N/A','N/A',%@)",strJid,[ElogBooksAppDelegate getValueForKey:USER_ID],strCurrentTimeStamp,txtView.text,[ElogBooksAppDelegate getValueForKey:USER_NAME],UN_SYNCED_DATA]])
       {
           NSLog(@"Job Lines Description Inserted");
           //now insert eng_complete
    if ([DataSource executeQuery:[NSString stringWithFormat:@"Update Jobs set eng_complete='%@',IsSynced=%@ where jid=%@",strCurrentTimeStamp,UN_SYNCED_DATA,strJid]])
        NSLog(@"Eng_complete value set ");
           
       }
       
      if ([CommonFunctions isNetAvailable])
        {
           
            //Upload the completed JOb
            /*http://code.elogbooks.co.uk/users/jack/WOM/api/put-info.php?uid=38&UpdateType=jobs&qd=Update&tstamp=27/12/2012%2018:35:20&jid=2824&eng_complete=27/12/2012%2018:35:20&description=testeddesc */
            
            objService=[[PutInfoClass alloc] init];
            objService._delegate=self;
            
            NSMutableDictionary *dicc=[[[NSMutableDictionary alloc] init]autorelease];
            [dicc setObject:[ElogBooksAppDelegate getValueForKey:USER_ID] forKey:USER_ID];
            [dicc setObject:@"jobs" forKey:@"UpdateType"];
            [dicc setObject:@"Update" forKey:@"qd"];
            [dicc setObject: [CommonFunctions getCurrentTimeStamp:strCurrentTimeStamp] forKey:@"tstamp"];
            [dicc setObject:strJid forKey:JOBS_ID];
            [dicc setObject:[CommonFunctions getCurrentTimeStamp:strCurrentTimeStamp] forKey:JOBS_ENG_COMPLETE];
            
            if ([txtView.text length]>0)
            [dicc setObject:txtView.text forKey:JOBS_DESC];
            
            objService.argsDic=[CommonFunctions getDicAsParameter:dicc] ;
            
            objService.strWebService=[NSString stringWithFormat:@"JobsComplete:%@",strJid];
            objService.strUrl= [NSString stringWithFormat:@"%@%@",[ElogBooksAppDelegate getValueForKey:BASE_URL],PUT_INFO_API];
            objService.ParentNode=@"Responses";
            objService.ChildNode=@"Response";
            objService.retType=isArray;
            [objService performSelector:@selector(setArray) withObject:nil afterDelay:0.1];
           

        }
    else   //job completed 
        {
            if ([DataSource executeQuery:[NSString stringWithFormat:@"Update Jobs set eng_complete='%@',IsSynced=%@ where jid=%@",strCurrentTimeStamp,UN_SYNCED_DATA,strJid]])
                NSLog(@"Eng_complete value set ");
            NSArray *arrviewControllers = [self.navigationController viewControllers];
            PatrolsScreen *obj;
            for (int i=0;i<[arrviewControllers count];i++)
            {
                if ([[arrviewControllers objectAtIndex:i]isKindOfClass:[PatrolsScreen class]])
                {
                    obj = (PatrolsScreen *)[arrviewControllers objectAtIndex:i];
                    break; 
                    
                }
            }
            
            
            if (obj !=nil)
            {
            
                [self.navigationController popToViewController:obj animated:YES];
            }else
            {
                NSLog(@"navigation controller crashed");
            }
            
            
        }
       
       
       

   }
    else 
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:APP_TITLE message:@"Please enter a Description !" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        [alert show];
        [alert release];  
    }
    
    
    
}





#pragma mark Parsing delegates
-(void)filedWithError:(NSString *)strMsg forFlage:(NSString *)flage
{
    
    //If fails mark as unsynced one
    //ManualStatusHandler
    if ([DataSource executeQuery:[NSString stringWithFormat:@"Update Jobs set IsSynced=%@ where jid=%@",UN_SYNCED_DATA,strJid]])
        NSLog(@"Eng_complete value set ");
    
    if (isNotMissedAnyPoint)
    {
        //Remove the alert view
        [alertView removeFromSuperview];
        alertView = nil;
    }
    
    NSArray *arrviewControllers = [self.navigationController viewControllers];
    PatrolsScreen *obj;
    for (int i=0;i<[arrviewControllers count];i++)
    {
        if ([[arrviewControllers objectAtIndex:i]isKindOfClass:[PatrolsScreen class]])
        {
            obj = (PatrolsScreen *)[arrviewControllers objectAtIndex:i];
            break; 
            
        }
    }
    
    
    if (obj !=nil)
    {
        [self.navigationController popToViewController:obj animated:YES];
    }else
    {
        NSLog(@"navigation controller crashed");
    }
                        
}
-(void)EndParsingArray:(NSMutableArray *)arrData forFlage:(NSString *)flage
{
//    NSLog(@"%@",[[arrData objectAtIndex:0]description]);
  
    
    //if success delete all jid values 
    [DataSource executeQuery:[NSString stringWithFormat:@"DELETE FROM Job_lines WHERE jid= %@",strJid]];
    [DataSource executeQuery:[NSString stringWithFormat:@"DELETE FROM Jobs WHERE jid= %@",strJid]];
    [DataSource executeQuery:[NSString stringWithFormat:@"DELETE FROM Job_patrol_schedule_points WHERE schedule_id in (select schedule_id from Job_patrol_schedules where jid = %@)",strJid]];
    [DataSource executeQuery:[NSString stringWithFormat:@"DELETE FROM Job_patrol_schedules WHERE jid= %@",strJid]];
    [DataSource executeQuery:[NSString stringWithFormat:@"DELETE FROM Job_materials WHERE jid= %@",strJid]];
    
    if (isNotMissedAnyPoint)
    {
        //Remove the alert view
        [alertView removeFromSuperview];
    alertView = nil;
    }
    
    NSArray *arrviewControllers = [self.navigationController viewControllers];
    PatrolsScreen *obj;
    for (int i=0;i<[arrviewControllers count];i++)
    {
        if ([[arrviewControllers objectAtIndex:i]isKindOfClass:[PatrolsScreen class]])
        {
             obj = (PatrolsScreen *)[arrviewControllers objectAtIndex:i];
             break; 
            
        }
    }
    
     
    if (obj !=nil)
    {
        [self.navigationController popToViewController:obj animated:YES];
    }else
    {
        NSLog(@"navigation controller crashed");
    }
    
}


#pragma mark TextView Delegates
- (BOOL)textViewShouldBeginEditing:(UITextView *)textView
{
    if ([textView.text isEqualToString:@"Tap to begin Description"])
    {
        textView.textColor = [UIColor blackColor];
         textView.text =@"";
    }
 [ScrView setScrollEnabled:YES];
    return YES;
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if([text isEqualToString:@"\n"]) 
    {

        [textView resignFirstResponder];
    [ScrView scrollRectToVisible:CGRectMake(0, 0, 320, 40) animated:YES];
    [ScrView setScrollEnabled:NO];
     return NO;
    }
    return YES;
}

-(IBAction)btnBackTapped:(id)sender
{
    if (txtView!=nil)
    [txtView resignFirstResponder];
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)viewWillDisappear:(BOOL)animated
{
[self.navigationController.navigationBar setUserInteractionEnabled:YES];
}

- (void)viewDidUnload
{
    [self.navigationController.navigationBar setUserInteractionEnabled:YES];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
