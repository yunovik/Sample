//
//  PatrolPointsScreen.m
//  ElogBooks
//
//  Created by I-VERVE5 on 12/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import "PatrolPointsScreen.h"
#import "AddDescription.h"
#import "UpdatePointScreen.h"
#import "UploadImageScreen.h"
#import "SignViewController.h"

#define  UN_ORDER @"UnOrdered"
#define  ORDER @"Ordered"

#define POINT_START_TIME @"start_time"
#define TAG_Btn_Check 7000
#define TAG_START_PATROL 3456
#define  BTN_START_PATROL 293

@interface PatrolPointsScreen ()
@end

@implementation PatrolPointsScreen

@synthesize strJid,isPushedFromInfo,strTimeRange,strIsPatrolUnordered;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.title = @"Patrols";
    
    [CommonFunctions setTitleView:self amdtitle:@"Patrols"];
    
    //UIview
    UIView *backView = [[[UIView alloc] init] autorelease];
    backView.frame = CGRectMake(0, 0, 320, 110);
        backView.backgroundColor = getImageColor(@"PatrolInfo_Row_Stripe.png");
//    backView.backgroundColor = getImageColor(@"Cell_Stripe.png");
    [self.view addSubview:backView];
    //[View release];
    
    //Back Button On Navigation
    [CommonFunctions setBack:self target:@selector(btnBackTapped:)];
    [self.view setBackgroundColor:[UIColor whiteColor]];
    
//    arrJobInfo = [DataSource getRecordsFromQuery:
//                  [NSString stringWithFormat:
//                   @"select jid,stt,location,date_due from jobs Where jid = %@",strJid]];

////    static
//  strJid = @"20060540";
    arrJobInfo = [DataSource getRecordsFromQuery:
                  [NSString stringWithFormat:
                   @"select Jobs.jid||' - '||Jobs.stt as stt,Job_patrol_schedules.name,Job_patrol_schedules.description,date_due,CASE Job_patrol_schedules.unordered WHEN 'Y' THEN 'UnOrdered' ELSE 'Ordered' END as unordered from Jobs left  join Job_patrol_schedules on Jobs.jid = Job_patrol_schedules.jid where Jobs.jid = '%@'",strJid]];
if ([arrJobInfo count]>0)
{
    if ([[[arrJobInfo objectAtIndex:0] objectForKey:SCHEDULE_UNORDERED] isEqualToString:UN_ORDER])
        strIsPatrolUnordered = UN_ORDER;
}
    else 
        strIsPatrolUnordered = ORDER;
    [strIsPatrolUnordered retain];
    
    

    
    UILabel *lblPatrolId = [[UILabel alloc]initWithFrame:CGRectMake(10, 8 ,70+40, 15)];
    lblPatrolId.backgroundColor = [UIColor clearColor];
    [lblPatrolId setFont:FONT_NEUE_BOLD_SIZE(14) ];
    [lblPatrolId setTextColor:DEFAULT_FONT_COLOR];
    [lblPatrolId setText:@"Patrol Info:"];
    //    lblAsstId.text = [redDic objectForKey:@"id"];
    [backView addSubview:lblPatrolId];
    [lblPatrolId release];
    
    UILabel *lblPatrolStatus = [[UILabel alloc]initWithFrame:CGRectMake(10, 25, 200, 20)];
    lblPatrolStatus.backgroundColor = [UIColor clearColor];
    [lblPatrolStatus setFont:FONT_NEUE_BOLD_SIZE(15) ];
    [lblPatrolStatus setTextColor:DEFAULT_FONT_COLOR];
    if ([arrJobInfo count]>0)
    [lblPatrolStatus setText:[[arrJobInfo objectAtIndex:0] objectForKey:JOBS_STT]];
    [backView addSubview:lblPatrolStatus];
    [lblPatrolStatus release];
    
    UILabel *lblPatrolname = [[UILabel alloc]initWithFrame:CGRectMake(10, 45, 200, 20)];
    lblPatrolname.backgroundColor = [UIColor clearColor];
    [lblPatrolname setFont:FONT_NEUE_SIZE(13) ];
    [lblPatrolname setTextColor:DEFAULT_FONT_COLOR];
    if ([[[arrJobInfo objectAtIndex:0] objectForKey:SCHEDULE_NAME]length]>0)
    [lblPatrolname setText:[NSString stringWithFormat: @"%@-%@",[[arrJobInfo objectAtIndex:0] objectForKey:SCHEDULE_NAME],[[arrJobInfo objectAtIndex:0] objectForKey:SCHEDULE_UNORDERED]]];
    //    lblPatrolDesc.text = [redDic objectForKey:@"id"];
    [backView addSubview:lblPatrolname];
    [lblPatrolname release];
    

    UILabel *lblPatrolDesc = [[UILabel alloc]initWithFrame:CGRectMake(10, 65, 250, 40)];
    lblPatrolDesc.backgroundColor = [UIColor clearColor];
    lblPatrolDesc.numberOfLines = 0;
    [lblPatrolDesc setLineBreakMode:UILineBreakModeWordWrap];
    [lblPatrolDesc setFont:FONT_NEUE_SIZE(10) ];
    [lblPatrolDesc setTextColor:DEFAULT_FONT_COLOR];
    if ([[[arrJobInfo objectAtIndex:0] objectForKey:JOBS_DESC]length]>0)
        [lblPatrolDesc setText:[[arrJobInfo objectAtIndex:0] objectForKey:JOBS_DESC]];
    [lblPatrolDesc sizeToFit];
    //    lblPatrolDesc.text = [redDic objectForKey:@"id"];
    [backView addSubview:lblPatrolDesc];
    [lblPatrolDesc release];
  
    strTimeRange = [strTimeRange stringByReplacingOccurrencesOfString:@"- -" withString:@"-"];
    
    UILabel *lblTimeRange = [[UILabel alloc]initWithFrame:CGRectMake(255, 10, 100, 15)];
    lblTimeRange.backgroundColor = [UIColor clearColor];
  
    [lblTimeRange setFont:FONT_NEUE_SIZE(11) ];
    [lblTimeRange setTextColor:DEFAULT_FONT_COLOR];
        [lblTimeRange setText:strTimeRange];
    [backView addSubview:lblTimeRange];
    [lblTimeRange release];

    if ([[DataSource getStringFromQuery:[NSString stringWithFormat:@"select stt from Jobs where jid = %@",strJid]]rangeOfString:@"In Progress"].location == NSNotFound)
        isJobStarted = FALSE;
    else
        isJobStarted = TRUE;

    
    UIButton *btnStartPatrol = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    btnStartPatrol = [[UIButton alloc]init];
    btnStartPatrol=[UIButton buttonWithType:UIButtonTypeCustom];
    btnStartPatrol.tag = BTN_START_PATROL;
    [btnStartPatrol setFrame:CGRectMake(260,30,50,50)];
    UIImage *InfoImage;
    if (isJobStarted)
    InfoImage =getImage(@"btnComplete.png");
    else
    InfoImage = getImage(@"Playbtn.png");
    [btnStartPatrol setImage:InfoImage forState:UIControlStateNormal];
    [btnStartPatrol addTarget:self action:@selector(btnstartPatrolTapped:) forControlEvents:UIControlEventTouchUpInside];
    [btnStartPatrol setEnabled:YES];
    [backView addSubview:btnStartPatrol];
    
    
    
    
    lblPatrolcurrentStatus = [[UILabel alloc]initWithFrame:CGRectMake(255, 80, 55, 20)];
    lblPatrolcurrentStatus.backgroundColor = [UIColor clearColor];
        [lblPatrolcurrentStatus setTextAlignment:UITextAlignmentCenter];
    [lblPatrolcurrentStatus setFont:FONT_NEUE_SIZE(12) ];
    [lblPatrolcurrentStatus setTextColor:DEFAULT_FONT_COLOR];
    if (isJobStarted)
        [lblPatrolcurrentStatus setText:@"Complete"];  
    else
        [lblPatrolcurrentStatus setText:@"Start"];

    //    lblPatrolDesc.text = [redDic objectForKey:@"id"];
    [backView addSubview:lblPatrolcurrentStatus];
    [lblPatrolcurrentStatus release];
    
    
    //    [self refreshData];
    
    
    
    
    
}

-(void)viewWillAppear:(BOOL)animated
{
    
    [self refreshData];
    [super viewWillAppear:YES];
}

-(void)refreshData
{
    //    if (tblPatrolInfo !=nil)
    [tblPatrolInfo removeFromSuperview];
    
    if ([[DataSource getStringFromQuery:[NSString stringWithFormat:@"select stt from Jobs where jid = %@",strJid]]rangeOfString:@"In Progress"].location == NSNotFound)
        isJobStarted = FALSE;
    else
        isJobStarted = TRUE;
    
    arrPatrolList = [DataSource getRecordsFromQuery:
                     [NSString stringWithFormat:
                      @"SELECT jobs.date_due,Job_patrol_schedule_points.name,Job_patrol_schedule_points.instruction,Job_patrol_schedule_points.require_unable,Job_patrol_schedule_points.bfloor,Job_patrol_schedule_points.building,Job_patrol_schedule_points.location,Job_patrol_schedule_points.time_allowed,Job_patrol_schedule_points.point_id,Job_patrol_schedule_points.schedule_id,job_patrol_schedule_points.sort,job_patrol_schedule_points.barcode,"
                      "\nCASE WHEN (Job_patrol_schedule_points.ManualStatusHandler = '') THEN 'NOT_STARTED'"
                      "\nWHEN (Job_patrol_schedule_points.ManualStatusHandler = 'NOT_COMPLETE') THEN Job_patrol_schedule_points.ManualStatusHandler"
                      "\nWHEN (Job_patrol_schedule_points.ManualStatusHandler = 'COMPLETE') THEN Job_patrol_schedule_points.ManualStatusHandler"
                      "\nWHEN (Job_patrol_schedule_points.ManualStatusHandler = 'MISSED') THEN Job_patrol_schedule_points.ManualStatusHandler"
                      "\nELSE "
                      "\n'NOT_STARTED'"
                      "\nEND As PatrolPointStatus"
                      "\n,"
                      "\nCASE"
                      "\nWHEN (Job_patrol_schedule_points.require_type='B') THEN 'Barcode'"
                      "\nWHEN (Job_patrol_schedule_points.require_type='P') THEN 'Photo'"
                      "\nWHEN (Job_patrol_schedule_points.require_type='S') THEN 'Signature'"
/*                      "\nWHEN (Job_patrol_schedule_points.require_type='A') THEN 'Attachment'" */
                      "\nELSE 'N/A'"
                      "\nEND As require_type"
                      "\nFROM Jobs "
                      "\njoin Job_patrol_schedules"
                      "\non Jobs.jid = Job_patrol_schedules.jid"
                      "\njoin Job_patrol_schedule_points"
                      "\non Job_patrol_schedules.schedule_id = Job_patrol_schedule_points.schedule_id"
                      "\nwhere Jobs.jid=%@ order by job_patrol_schedule_points.sort",strJid]];
    
    //Allocate Date-Formatter
    NSDateFormatter *dateFormatterUnix = [[[NSDateFormatter alloc] init]autorelease];
    [dateFormatterUnix setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSDate *dateGlobal = [[[NSDate alloc]init]autorelease];
    dateGlobal =[dateFormatterUnix dateFromString:[[arrJobInfo objectAtIndex:0]valueForKey:JOBS_DATE_DUE]];
    //set Point Start Time
    
    
    for (int i=0;i<[arrPatrolList count];i++)
    {
        dateGlobal = [dateGlobal dateByAddingTimeInterval:[[[arrPatrolList objectAtIndex:i]valueForKey:SCHEDULE_TIME_ALLOWED]intValue]*60];
        [[arrPatrolList objectAtIndex:i]setObject:[CommonFunctions getTimeFromDate:dateGlobal] forKey:POINT_START_TIME];
    }
    
    
    NSLog(@"%@",[arrPatrolList description]);
    // UITableView
    
    //    tblPatrolInfo = [[[UITableView alloc] initWithFrame:CGRectMake(0,61,320,399) style:UITableViewStylePlain]autorelease];
    tblPatrolInfo = [[[UITableView alloc] initWithFrame:CGRectMake(0,110,320,[[UIScreen mainScreen] bounds].size.height-140) style:UITableViewStylePlain]autorelease];
    UIEdgeInsets myInsets = {0, 0, 44, 0};
    tblPatrolInfo.contentInset = myInsets;
    tblPatrolInfo.dataSource = self;
    [tblPatrolInfo setShowsVerticalScrollIndicator:NO];
    tblPatrolInfo.delegate = self;
    [tblPatrolInfo setBackgroundColor:[UIColor clearColor]];
    [tblPatrolInfo setSeparatorStyle:UITableViewCellSeparatorStyleSingleLine];
    
    [self.view addSubview:tblPatrolInfo];
}

#pragma mark CheckRequiredValue
-(NSString *)CheckRequiredValue:(NSString *)currentValue
{
    NSString *strCurrentValue = @"";
    currentValue = [currentValue stringByReplacingOccurrencesOfString:@" " withString:@""];
    strCurrentValue = currentValue;
    if ([strCurrentValue isEqualToString:@"B"])
        return @"Barcode";
    else if ([strCurrentValue isEqualToString:@"P"])
        return @"Photo";
    else if ([strCurrentValue isEqualToString:@"S"])
        return @"Signature";
    else if ([strCurrentValue isEqualToString:@"A"])
        return @"Attachment";
    else
        return @"N/A";
}



#pragma mark - Table view data source

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *CellIdentifier = [NSString stringWithFormat:@"Cel_%d",indexPath.row];
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    NSDictionary *redDic = [arrPatrolList objectAtIndex:indexPath.row ];
    
    if(cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] ;
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
        
        /*        CGSize _size = [[NSString stringWithFormat:@"Description: %@",[redDic objectForKey:JOBS_DESC]] sizeWithFont:FONT_NEUE_SIZE(12) constrainedToSize:CGSizeMake(250,MAXFLOAT) lineBreakMode:UILineBreakModeWordWrap];
         UIImageView *imgView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 320, 38.0f+_size.height)];
         
         
         imgBg = [UIImage imageNamed:@"Cell_Stripe.png"];
         if (cellRect.size.height >imgBg.size.height)
         imgBg = [imgBg stretchableImageWithLeftCapWidth:imgBg.size.width/2 topCapHeight: (cellRect.size.height - imgBg.size.height)];
         NSLog(@" after Image height:%f:width:%f",imgBg.size.height,imgBg.size.width);
         [imgView setImage:imgBg];
         [cell.contentView addSubview:imgView];
         
         */
  

//      CGRect cellRect = [tblPatrolInfo rectForRowAtIndexPath:indexPath];
//        NSString *strInstruction = nil;      
//        strInstruction = [NSString stringWithFormat:@"Instruction : %@",[redDic objectForKey:JOB_PATROL_SCHEDULE_POINT_INSTRUCTION]];
//        CGSize _size = CGSizeZero;
//        if (strInstruction!=nil)
//            _size = [strInstruction sizeWithFont:FONT_NEUE_BOLD_SIZE(10) constrainedToSize:CGSizeMake(250,MAXFLOAT) lineBreakMode:UILineBreakModeWordWrap];
        
        
//        UIImage *img = [UIImage imageNamed:@"Cell_Stripe.png"];
//         if (cellRect.size.height >img.size.height)
//        img = [img stretchableImageWithLeftCapWidth:img.size.width/2 topCapHeight: (cellRect.size.height - img.size.height)];
        
//        UIImageView *backImgview = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 320,90.0f+_size.height)];
//        [backImgview setImage:img];
//        [cell.contentView addSubview:backImgview];
        
        
        UILabel *lblname = [[UILabel alloc] initWithFrame:CGRectMake(10, 4, 250, 14)];
        lblname.backgroundColor = [UIColor clearColor];
        lblname.numberOfLines = 0;
        [lblname setFont:FONT_NEUE_BOLD_SIZE(10) ];
        [lblname setTextColor:DEFAULT_FONT_COLOR];
        lblname.text = [NSString stringWithFormat:@"Point Name: %@",[redDic objectForKey:SCHEDULE_NAME]];
        [cell.contentView addSubview:lblname];
        [lblname release];
        
        
        UILabel *lblbuilding = [[UILabel alloc] initWithFrame:CGRectMake(10, 19, 250, 14)];
        lblbuilding.backgroundColor = [UIColor clearColor];
        lblbuilding.numberOfLines = 0;
        [lblbuilding setFont:FONT_NEUE_BOLD_SIZE(10)];
        [lblbuilding setTextColor:DEFAULT_FONT_COLOR];
        lblbuilding.text = [NSString stringWithFormat:@"Building : %@",[redDic objectForKey:JOB_PATROL_SCHEDULE_POINT_BUILDING]];
        [cell.contentView addSubview:lblbuilding];
        [lblbuilding release];
        
        
        
        UILabel *lblBfloor = [[UILabel alloc] initWithFrame:CGRectMake(10, 34, 250, 14)];
        lblBfloor.backgroundColor = [UIColor clearColor];
        lblBfloor.numberOfLines = 0;
        [lblBfloor setFont:FONT_NEUE_BOLD_SIZE(10)];
        [lblBfloor setTextColor:DEFAULT_FONT_COLOR];
        lblBfloor.text = [NSString stringWithFormat:@"Floor : %@",[redDic objectForKey:JOB_PATROL_SCHEDULE_POINT_BFLOOR]];
        [cell.contentView addSubview:lblBfloor];
        [lblBfloor release];
        
        
        UILabel *lblLocation = [[UILabel alloc] initWithFrame:CGRectMake(10, 49, 250, 14)];
        lblLocation.backgroundColor = [UIColor clearColor];
        lblLocation.numberOfLines = 0;
        [lblLocation setFont:FONT_NEUE_BOLD_SIZE(10) ];
        [lblLocation setTextColor:DEFAULT_FONT_COLOR];
        lblLocation.text = [NSString stringWithFormat:@"Location : %@",[redDic objectForKey:SCHEDULE_LOCATION]];
        [cell.contentView addSubview:lblLocation];
        [lblLocation release];
        
        
        UILabel *lblInstruction = [[UILabel alloc] initWithFrame:CGRectMake(10, 64, 250, 0)];
        lblInstruction.backgroundColor = [UIColor clearColor];
        [lblInstruction setFont:FONT_NEUE_BOLD_SIZE(10) ];
        [lblInstruction setTextColor:DEFAULT_FONT_COLOR];
                lblInstruction.numberOfLines = 0; 
        [lblInstruction setLineBreakMode:UILineBreakModeWordWrap];
        lblInstruction.text = [NSString stringWithFormat:@"Instruction : %@",[redDic objectForKey:JOB_PATROL_SCHEDULE_POINT_INSTRUCTION]];
        [lblInstruction sizeToFit];
        [cell.contentView addSubview:lblInstruction];
        [lblInstruction release];
        
        
        UILabel *lblAllocatedTime = [[UILabel alloc] initWithFrame:CGRectMake(10, 64+lblInstruction.frame.size.height+1, 250, 12)];
        lblAllocatedTime.backgroundColor = [UIColor clearColor];
        lblAllocatedTime.numberOfLines = 0;
        [lblAllocatedTime setFont:FONT_NEUE_BOLD_SIZE(10) ];
        [lblAllocatedTime setTextColor:DEFAULT_FONT_COLOR];
        lblAllocatedTime.text = [NSString stringWithFormat:@"Time Allocated : %@ mins",[redDic objectForKey:SCHEDULE_TIME_ALLOWED]];
        [cell.contentView addSubview:lblAllocatedTime];
        [lblAllocatedTime release];
        
        
        
        UILabel *lblRequired = [[UILabel alloc] initWithFrame:CGRectMake(10, 77+lblInstruction.frame.size.height, 250, 12)];
        lblRequired.backgroundColor = [UIColor clearColor];
        lblRequired.numberOfLines = 0;
        [lblRequired setFont:FONT_NEUE_BOLD_SIZE(10)];
        [lblRequired setTextColor:DEFAULT_FONT_COLOR];
        lblRequired.text = [NSString stringWithFormat:@"Requirement : %@",[redDic objectForKey:REQUIRED_TYPE]];
        [cell.contentView addSubview:lblRequired];
        [lblRequired release];
        
        UILabel *lblPointstartTime = [[UILabel alloc] initWithFrame:CGRectMake(220,30, 80, 50)];
        lblPointstartTime.backgroundColor = [UIColor clearColor];
        lblPointstartTime.numberOfLines = 0;
        [lblPointstartTime setFont:FONT_NEUE_BOLD_SIZE(12) ];
        [lblPointstartTime setTextColor:DEFAULT_FONT_COLOR];
        lblPointstartTime.text = [redDic objectForKey:POINT_START_TIME];
        [cell.contentView addSubview:lblPointstartTime];
        [lblPointstartTime release];
        
        
        
        if (isJobStarted)
        {
        //
        UIButton *btnCheck = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        btnCheck = [[UIButton alloc]init];
        btnCheck=[UIButton buttonWithType:UIButtonTypeCustom];
        [btnCheck setFrame:CGRectMake(260,30,50,50)];
        
        //set the respective image
        UIImage *CheckImage;
        if ([[redDic objectForKey:@"PatrolPointStatus"]isEqualToString:@"NOT_STARTED"])
            CheckImage= getImage(@"btnComplete.png");
        else if (([[redDic objectForKey:@"PatrolPointStatus"]isEqualToString:@"NOT_COMPLETE"]) && (!([[redDic objectForKey:REQUIRED_TYPE]isEqualToString:@"N/A"])))
            CheckImage= getImage(@"new_unable.png");
        else if (([[redDic objectForKey:@"PatrolPointStatus"]isEqualToString:@"NOT_COMPLETE"]) && (([[redDic objectForKey:REQUIRED_TYPE]isEqualToString:@"N/A"])))
            CheckImage= getImage(@"missed.png");
        else if ([[redDic objectForKey:@"PatrolPointStatus"]isEqualToString:@"MISSED"])
            CheckImage= getImage(@"missed.png");
        else  if ([[redDic objectForKey:@"PatrolPointStatus"]isEqualToString:@"COMPLETE"])
            CheckImage= getImage(@"Done_btn.png");
        else
            CheckImage= getImage(@"btnComplete.png");
        
        [btnCheck setImage:CheckImage forState:UIControlStateNormal];
        [btnCheck setTag:TAG_Btn_Check+indexPath.row];
        if ([strIsPatrolUnordered isEqualToString:UN_ORDER])
        {
        
        [btnCheck addTarget:self action:@selector(ComplteWithoutOrderTapped:) forControlEvents:UIControlEventTouchUpInside];
        }
        else 
        [btnCheck addTarget:self action:@selector(CompleteInOrderTapped:) forControlEvents:UIControlEventTouchUpInside];
        [btnCheck setEnabled:YES];
        [cell.contentView addSubview:btnCheck];
        [btnCheck release];
        }
        
        //
        //        UIView *selectedView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 61)];
        //        [selectedView setBackgroundColor:getImageColor(@"Cell_Stripe_Sel.png")];
        //        //[selectedView setBackgroundColor:[UIColor greenColor]];
        //        [cell setSelectedBackgroundView:selectedView];
        
    }
    
    return cell;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return arrPatrolList.count;
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary *redDic = [arrPatrolList objectAtIndex:indexPath.row ];
    
    CGSize _size = [[NSString stringWithFormat:@"Instruction : %@",[redDic objectForKey:JOB_PATROL_SCHEDULE_POINT_INSTRUCTION]] sizeWithFont:FONT_NEUE_BOLD_SIZE(10) constrainedToSize:CGSizeMake(250,MAXFLOAT) lineBreakMode:UILineBreakModeWordWrap];
    return 90.0f+_size.height;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    // this is temp code. please delete this code
    
    
    //    PatrolsInfoScreen* objNav=[[PatrolsInfoScreen alloc] initWithNibName:@"PatrolsInfoScreen" bundle:nil];
    //    objNav.strJid=strJid;
    //    [self.navigationController pushViewController:objNav animated:YES];
    //    [objNav release];
    //
    
    //
    
    //    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}



#pragma mark -ComplteWithoutOrderTapped
-(IBAction)ComplteWithoutOrderTapped:(id)sender
{
    int currentRow = [sender tag]-TAG_Btn_Check;
    NSMutableDictionary *dicSelected = [arrPatrolList objectAtIndex:currentRow];
    
    NSString *strPatrolPointStatus = [dicSelected valueForKey:@"PatrolPointStatus"];
    NSString *strRequiredBarcode = [dicSelected valueForKey:@"barcode"];    
    NSString *strRequireType = [dicSelected objectForKey:REQUIRED_TYPE];
    if ([strPatrolPointStatus isEqualToString:@"MISSED"] || [strPatrolPointStatus isEqualToString:@"NOT_COMPLETE"] || [strPatrolPointStatus isEqualToString:@"COMPLETE"])//point already completed
    {
          if ([CommonFunctions iSReadyForCompletion:[dicSelected valueForKey:SCHEDULE_ID]])
          {
             
              //Complete Last point 
              if ([strRequireType isEqualToString:@"N/A"])
              {

                  [self CompletePatrol:dicSelected];
              }
              else  if ([strRequireType isEqualToString:@"Barcode"])
              {
                  UpdatePointScreen* objNav=[[UpdatePointScreen alloc] initWithNibName:@"UpdatePointScreen" bundle:nil];
                  objNav.dicPatrolPointRecord = dicSelected;
                  objNav.strRequiredBarcode=strRequiredBarcode;
                  objNav.strPatrolJobId = strJid;
                  objNav.strIsUNorderedPoint = @"YES";
                  objNav.isUploadingLastPoint = YES;
                  [self.navigationController pushViewController:objNav animated:YES];
                  [objNav release];
                  
              }
              else  if ([strRequireType isEqualToString:@"Photo"])
              {
                  UploadImageScreen *objNav = [[UploadImageScreen alloc] initWithNibName:@"UploadImageScreen" bundle:nil];
                  objNav.strPatrolJobId=strJid;
                objNav.strIsUNorderedPoint = @"YES";
                  objNav.strPoint_id =[dicSelected valueForKey:POINT_ID] ;
                  objNav.strOrder = [dicSelected valueForKey:JOB_PATROL_SCHEDULE_POINT_SORT];
                  objNav.strSchedule_id = [dicSelected valueForKey:SCHEDULE_ID];
                  objNav.dicCurrentPatrolRecord = dicSelected;
                  objNav.isUploadingLastPoint = YES;
                  [self.navigationController pushViewController:objNav animated:YES];
                  [objNav release];
              }
              else  if ([strRequireType isEqualToString:@"Signature"])
              {
                  SignViewController *objNav = [[SignViewController alloc] initWithNibName:@"SignViewController" bundle:nil];
                  objNav.strPatrolJobId=strJid;
                                  objNav.strIsUNorderedPoint = @"YES";
                  objNav.strPoint_id =[dicSelected valueForKey:POINT_ID] ;
                  objNav.strOrder = [dicSelected valueForKey:JOB_PATROL_SCHEDULE_POINT_SORT];
                  objNav.strSchedule_id = [dicSelected valueForKey:SCHEDULE_ID];
                  objNav.dicCurrentPatrolRecord = dicSelected;
                  objNav.isUploadingLastPoint = YES;
                  [self.navigationController pushViewController:objNav animated:YES];
                  [objNav release];
              }
              
              
          }
         else 
          {
        //sort in right order
        objAlert = [[MEAlertView alloc] initWithMessage:@"" delegate:self cancelButtonTitle:@"Close" otherButtonTitles:nil];
        objAlert.delegate=self;
        [objAlert Show];
        [objAlert release];
    }
    }
    else // Normal completion  
    {
        if ([strRequireType isEqualToString:@"N/A"])
        {
            
            //Complete the job
            objAlert = [[MEAlertView alloc] initWithMessage:@"As this patrol has no requirement for a photo,signature or barcode.Please select the correct option below." delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Point Missed,Point Completed"];
             if ([CommonFunctions isLastPointWithoutCompleted:[dicSelected valueForKey:SCHEDULE_ID]]) //Check is it last point without completion
                 isUploadingLastPoint = TRUE;
            else 
                 isUploadingLastPoint = FALSE;
            
            objAlert.tag=[sender tag];
            objAlert.delegate=self;
            [objAlert Show];
            [objAlert release];
        }
        else  if ([strRequireType isEqualToString:@"Barcode"])
        {
            
            UpdatePointScreen* objNav=[[UpdatePointScreen alloc] initWithNibName:@"UpdatePointScreen" bundle:nil];
            objNav.dicPatrolPointRecord = dicSelected;
            objNav.strPatrolJobId = strJid;
                            objNav.strIsUNorderedPoint = @"YES";
            objNav.strRequiredBarcode=strRequiredBarcode;
            if ([CommonFunctions isLastPointWithoutCompleted:[dicSelected valueForKey:SCHEDULE_ID]]) //Check is it last point without completion
                objNav.isUploadingLastPoint = YES;
            [self.navigationController pushViewController:objNav animated:YES];
            [objNav release];
            
        }
        else  if ([strRequireType isEqualToString:@"Photo"])
        {
            UploadImageScreen *objNav = [[UploadImageScreen alloc] initWithNibName:@"UploadImageScreen" bundle:nil];
            objNav.strPatrolJobId=strJid;
                            objNav.strIsUNorderedPoint = @"YES";
            objNav.strPoint_id =[dicSelected valueForKey:POINT_ID] ;
            objNav.strOrder = [dicSelected valueForKey:JOB_PATROL_SCHEDULE_POINT_SORT];
            objNav.strSchedule_id = [dicSelected valueForKey:SCHEDULE_ID];
            objNav.dicCurrentPatrolRecord = dicSelected;
                    if ([CommonFunctions isLastPointWithoutCompleted:[dicSelected valueForKey:SCHEDULE_ID]]) //Check is it last point without completion
                objNav.isUploadingLastPoint = YES;
            [self.navigationController pushViewController:objNav animated:YES];
            [objNav release];
        }
        else  if ([strRequireType isEqualToString:@"Signature"])
        {
            
            SignViewController *objNav = [[SignViewController alloc] initWithNibName:@"SignViewController" bundle:nil];
            objNav.strPatrolJobId=strJid;
                            objNav.strIsUNorderedPoint = @"YES";
            objNav.strPoint_id =[dicSelected valueForKey:POINT_ID] ;
            objNav.strOrder = [dicSelected valueForKey:JOB_PATROL_SCHEDULE_POINT_SORT];
            objNav.strSchedule_id = [dicSelected valueForKey:SCHEDULE_ID];
            objNav.dicCurrentPatrolRecord = dicSelected;
                if ([CommonFunctions isLastPointWithoutCompleted:[dicSelected valueForKey:SCHEDULE_ID]]) //Check is it last point without completion
                objNav.isUploadingLastPoint = YES;
            [self.navigationController pushViewController:objNav animated:YES];
            [objNav release];
            
        }

    }
    
}


#pragma mark - backTapped Method

-(IBAction)CompleteInOrderTapped:(id)sender
{
    int currentRow = [sender tag]-TAG_Btn_Check;
    NSMutableDictionary *dicSelected = [arrPatrolList objectAtIndex:currentRow];
    
    NSString *strPatrolPointStatus = [dicSelected valueForKey:@"PatrolPointStatus"];
    NSString *strRequiredBarcode = [dicSelected valueForKey:@"barcode"];    
    NSString *strRequireType = [dicSelected objectForKey:REQUIRED_TYPE];
    if ([strPatrolPointStatus isEqualToString:@"MISSED"] || [strPatrolPointStatus isEqualToString:@"NOT_COMPLETE"] || [strPatrolPointStatus isEqualToString:@"COMPLETE"])//point already completed
    {
        
        if (currentRow == ([arrPatrolList count]-1))
        {
            if ([strRequireType isEqualToString:@"N/A"])
            {
//w                 if ([strPatrolPointStatus isEqualToString:@"COMPLETE"])
                [self CompletePatrol:dicSelected];
            }
            else  if ([strRequireType isEqualToString:@"Barcode"])
            {
                UpdatePointScreen* objNav=[[UpdatePointScreen alloc] initWithNibName:@"UpdatePointScreen" bundle:nil];
                objNav.dicPatrolPointRecord = dicSelected;
                objNav.strRequiredBarcode=strRequiredBarcode;
                objNav.strPatrolJobId = strJid;
                objNav.isUploadingLastPoint = YES;
                [self.navigationController pushViewController:objNav animated:YES];
                [objNav release];
                
            }
            else  if ([strRequireType isEqualToString:@"Photo"])
            {
                UploadImageScreen *objNav = [[UploadImageScreen alloc] initWithNibName:@"UploadImageScreen" bundle:nil];
                objNav.strPatrolJobId=strJid;
                objNav.strPoint_id =[dicSelected valueForKey:POINT_ID] ;
                objNav.strOrder = [dicSelected valueForKey:JOB_PATROL_SCHEDULE_POINT_SORT];
                objNav.strSchedule_id = [dicSelected valueForKey:SCHEDULE_ID];
                objNav.dicCurrentPatrolRecord = dicSelected;
                objNav.isUploadingLastPoint = YES;
                [self.navigationController pushViewController:objNav animated:YES];
                [objNav release];
            }
            else  if ([strRequireType isEqualToString:@"Signature"])
            {
                SignViewController *objNav = [[SignViewController alloc] initWithNibName:@"SignViewController" bundle:nil];
                objNav.strPatrolJobId=strJid;
                objNav.strPoint_id =[dicSelected valueForKey:POINT_ID] ;
                objNav.strOrder = [dicSelected valueForKey:JOB_PATROL_SCHEDULE_POINT_SORT];
                objNav.strSchedule_id = [dicSelected valueForKey:SCHEDULE_ID];
                objNav.dicCurrentPatrolRecord = dicSelected;
                objNav.isUploadingLastPoint = YES;
                [self.navigationController pushViewController:objNav animated:YES];
                [objNav release];
            }
            
        }
        else {
            //sort in right order
            objAlert = [[MEAlertView alloc] initWithMessage:@"" delegate:self cancelButtonTitle:@"Close" otherButtonTitles:nil];
            objAlert.delegate=self;
            [objAlert Show];
            [objAlert release];
        }
    }
    else
    {
        
        
        if ([strRequireType isEqualToString:@"N/A"])
        {
            
            //Complete the job
            objAlert = [[MEAlertView alloc] initWithMessage:@"As this patrol has no requirement for a photo,signature or barcode.Please select the correct option below." delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Point Missed,Point Completed"];
            
            
            
            objAlert.tag=[sender tag];
            objAlert.delegate=self;
            [objAlert Show];
            [objAlert release];
        }
        else  if ([strRequireType isEqualToString:@"Barcode"])
        {
            
            UpdatePointScreen* objNav=[[UpdatePointScreen alloc] initWithNibName:@"UpdatePointScreen" bundle:nil];
            objNav.dicPatrolPointRecord = dicSelected;
            objNav.strPatrolJobId = strJid;
            objNav.strRequiredBarcode=strRequiredBarcode;
            if (currentRow == ([arrPatrolList count]-1)) //Check is it last row
                objNav.isUploadingLastPoint = YES;
            [self.navigationController pushViewController:objNav animated:YES];
            [objNav release];
            
        }
        else  if ([strRequireType isEqualToString:@"Photo"])
        {
            UploadImageScreen *objNav = [[UploadImageScreen alloc] initWithNibName:@"UploadImageScreen" bundle:nil];
            objNav.strPatrolJobId=strJid;
            objNav.strPoint_id =[dicSelected valueForKey:POINT_ID] ;
            objNav.strOrder = [dicSelected valueForKey:JOB_PATROL_SCHEDULE_POINT_SORT];
            objNav.strSchedule_id = [dicSelected valueForKey:SCHEDULE_ID];
            objNav.dicCurrentPatrolRecord = dicSelected;
            if (currentRow == ([arrPatrolList count]-1)) //Check is it last row
                objNav.isUploadingLastPoint = YES;
            [self.navigationController pushViewController:objNav animated:YES];
            [objNav release];
        }
        else  if ([strRequireType isEqualToString:@"Signature"])
        {
            
            SignViewController *objNav = [[SignViewController alloc] initWithNibName:@"SignViewController" bundle:nil];
            objNav.strPatrolJobId=strJid;
            objNav.strPoint_id =[dicSelected valueForKey:POINT_ID] ;
            objNav.strOrder = [dicSelected valueForKey:JOB_PATROL_SCHEDULE_POINT_SORT];
            objNav.strSchedule_id = [dicSelected valueForKey:SCHEDULE_ID];
            objNav.dicCurrentPatrolRecord = dicSelected;
            if (currentRow == ([arrPatrolList count]-1)) //Check is it last row
                objNav.isUploadingLastPoint = YES;
            [self.navigationController pushViewController:objNav animated:YES];
            [objNav release];
            
        }
        
    }
}

/*
 
 
 */

-(IBAction)btnstartPatrolTapped:(id)sender
{
    if (isJobStarted)
    {
 
        //complete the job 
        //push for description
        
        NSString *strScheduleId = [DataSource getStringFromQuery: [NSString stringWithFormat:@"select schedule_id from job_patrol_schedules where jid=%@",strJid]];
        if ([DataSource executeQuery:[NSString stringWithFormat:@"update Job_patrol_schedules set IsSynced=%@ where schedule_id=%@",UN_SYNCED_DATA,strScheduleId]])
            NSLog(@"Patrol Point updated");
        else
            NSLog(@"Failed to update the current schedule_id");
        //Call webservice here
        NSLog(@"Value updated");
        AddDescription* objNav=[[AddDescription alloc] initWithNibName:@"AddDescription" bundle:nil];
        objNav.strJid=strJid;
        [self.navigationController pushViewController:objNav animated:YES];
        [objNav release];
        
    }
    else 
    {
        //check any patrol already started
        
        int startedJobCount = [[DataSource getStringFromQuery:@"select COUNT(*) from Jobs where job_type = 'Patrol' and stt='In Progress' and eng_complete=''"]intValue];
        if (startedJobCount >0)
        {
            //one job is started
            UIAlertView *alert=[[[UIAlertView alloc] initWithTitle:APP_TITLE message:@"Complete the Patrol in Progress!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]autorelease];
            [alert show];
        }
        else //no Job is started
        {
            //start the fresh patrol
            NSLog(@"you can start this patrol");
            
            //start the job 
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Start Patrol?" message:@"Are you sure you want to start this Patrol."
                                                           delegate:self cancelButtonTitle:@"Start Patrol" otherButtonTitles:@"Cancel", nil];
            alert.tag = TAG_START_PATROL;
            [alert show];
            [alert release];  

        }
        
        
        
       
        
    }
    
    
//    PatrolsInfoScreen* objNav=[[PatrolsInfoScreen alloc] initWithNibName:@"PatrolsInfoScreen" bundle:nil];
//    objNav.strJid = strJid;
//    [self.navigationController pushViewController:objNav animated:YES];
//    [objNav release];
}

#pragma alertview Delegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == TAG_START_PATROL)
    {
        NSLog(@"%d",buttonIndex);
        if (buttonIndex == 0)
        {
            /*http://code.elogbooks.co.uk/users/jack/WOM/api/put-info.php?uid=38&UpdateType=jobs&qd=Start&tstamp=08/12/2012%2011:19:12&jid=7953 */
  
            strCurrentTimeStamp = [CommonFunctions getCurrentTimeStampForDatabaseInsertion];
            [strCurrentTimeStamp retain];
            //update the job temporarily
            if ([DataSource executeQuery:[NSString stringWithFormat:@"update jobs set stt='In Progress',eng_on_site='%@',IsSynced='%@' where jid=%@",strCurrentTimeStamp,UN_SYNCED_DATA,strJid]])
            {
                NSLog(@"eng_on_site value set ");
                UIButton *tmpButton = (UIButton *)[self.view viewWithTag:BTN_START_PATROL];
                [tmpButton setImage:getImage(@"btnComplete.png") forState:UIControlStateNormal];
                isJobStarted = YES;
                [lblPatrolcurrentStatus setText:@"Complete"];
            }
            
            if ([CommonFunctions isNetAvailable])
            {
                objService=[[PutInfoClass alloc] init];
                objService._delegate=self;
                objService.retType=isArray;
                NSMutableDictionary *dicc=[[[NSMutableDictionary alloc] init]autorelease];
                [dicc setObject:[ElogBooksAppDelegate getValueForKey:USER_ID] forKey:USER_ID];
                [dicc setObject:@"jobs" forKey:@"UpdateType"];
                [dicc setObject:@"Start" forKey:@"qd"];
                [dicc setObject: [CommonFunctions getCurrentTimeStamp:strCurrentTimeStamp] forKey:@"tstamp"];
                [dicc setObject:strJid forKey:JOBS_ID];
                
                
                
                objService.argsDic=[CommonFunctions getDicAsParameter:dicc] ;
                
                objService.strWebService=[NSString stringWithFormat:@"START_Job:%@",strJid];
                objService.strUrl= [NSString stringWithFormat:@"%@%@",[ElogBooksAppDelegate getValueForKey:BASE_URL],PUT_INFO_API];
                objService.ParentNode=@"Responses";
                objService.ChildNode=@"Response";
                [objService performSelector:@selector(setArray) withObject:nil afterDelay:0.1];
            }
            else
            {
                [DataSource executeQuery:[NSString stringWithFormat:@"update jobs set stt='In Progress',eng_on_site='%@',IsSynced='%@' where jid=%@",strCurrentTimeStamp,UN_SYNCED_DATA,strJid]];
                NSLog(@"eng_on_site value set ");
                
                PatrolPointsScreen* objNav=[[PatrolPointsScreen alloc] initWithNibName:@"PatrolPointsScreen" bundle:nil];
                objNav.strJid = strJid;
                objNav.isPushedFromInfo = TRUE;
                [self.navigationController pushViewController:objNav animated:YES];
                [objNav release];
                
            }               
            
        }
    }
}
-(IBAction)btnBackTapped:(id)sender
{
    if (isPushedFromInfo) //pushed from info screen
    {
        [self.navigationController popToViewController:[[self.navigationController viewControllers]objectAtIndex:[[self.navigationController viewControllers]count]-3]  animated:YES];
        isPushedFromInfo = FALSE;
    }
    else
        [self.navigationController popViewControllerAnimated:YES];
}

#pragma OptionOk OrderedCompletion
-(void)Option_Unable_Selected_OrderedCompletion:(UIButton*)sender  andTag:(int)alertTag
{
    //missed.png
    NSLog(@"btnUnableTocomplete Clicked");
    NSMutableDictionary *dicSelected = [arrPatrolList objectAtIndex:alertTag-TAG_Btn_Check];
    strCurrentTimeStamp = [CommonFunctions getCurrentTimeStampForDatabaseInsertion];
    [strCurrentTimeStamp retain];
    if (([DataSource executeQuery:[NSString stringWithFormat:@"Update Job_patrol_schedule_points SET date_complete ='',ManualStatusHandler='NOT_COMPLETE' where schedule_id= %@ and point_id = %@ and sort = %@;",[dicSelected objectForKey:SCHEDULE_ID],[dicSelected objectForKey:POINT_ID],[dicSelected objectForKey:JOB_PATROL_SCHEDULE_POINT_SORT]]]) && ([DataSource executeQuery:[NSString stringWithFormat:@"Update Job_patrol_schedule_points SET date_complete ='',ManualStatusHandler='MISSED' where  sort < %@ and ManualStatusHandler != 'NOT_COMPLETE' and  ManualStatusHandler != 'COMPLETE' and schedule_id = %@;",[dicSelected objectForKey:JOB_PATROL_SCHEDULE_POINT_SORT],[dicSelected objectForKey:SCHEDULE_ID]]]))
    {
        NSLog(@"record updated");
        //no internet connection available
        if ((alertTag-TAG_Btn_Check)==([arrPatrolList count]-1)) //last point row
        {
            //Complete Patrol
            [self CompletePatrol:dicSelected];
        }
        else
        {
            [self refreshData];
        }
        
    }
    else
        NSLog(@"Unable to update the record ");
    
}
#pragma OptionOk UnOrderedCompletion
-(void)Option_Unable_Selected_UnOrderedCompletion:(UIButton*)sender  andTag:(int)alertTag
{
    //missed.png
    NSLog(@"btnUnableTocomplete Clicked");
    NSMutableDictionary *dicSelected = [arrPatrolList objectAtIndex:alertTag-TAG_Btn_Check];
    strCurrentTimeStamp = [CommonFunctions getCurrentTimeStampForDatabaseInsertion];
    [strCurrentTimeStamp retain];
    if (([DataSource executeQuery:[NSString stringWithFormat:@"Update Job_patrol_schedule_points SET date_complete ='',ManualStatusHandler='NOT_COMPLETE' where schedule_id= %@ and point_id = %@ and sort = %@;",[dicSelected objectForKey:SCHEDULE_ID],[dicSelected objectForKey:POINT_ID],[dicSelected objectForKey:JOB_PATROL_SCHEDULE_POINT_SORT]]]) )
    {
        NSLog(@"record updated");
        //no internet connection available
   if (isUploadingLastPoint) //last point row //last point row
        {
            //Complete Patrol
            [self CompletePatrol:dicSelected];
        }
        else
        {
            [self refreshData];
        }
        
    }
    else
        NSLog(@"Unable to update the record ");
    
}

-(IBAction)btnUnableTocomplete:(UIButton *)Sender andTag:(int)alertTag
{
    if ([strIsPatrolUnordered isEqualToString:UN_ORDER])
    {
        [self Option_Unable_Selected_UnOrderedCompletion:Sender andTag:alertTag];
    }
    else 
    {
        [self Option_Unable_Selected_OrderedCompletion:Sender andTag:alertTag];

    }
}
#pragma OptionOk OrderedCompletion
-(void)OptionOkSelected_OrderedCompletion:(UIButton*)sender  andTag:(int)alertTag
{
    
    NSLog(@"btnOk_Tapped Clicked");
    NSMutableDictionary *dicSelected = [arrPatrolList objectAtIndex:alertTag-TAG_Btn_Check];
    strCurrentTimeStamp = [CommonFunctions getCurrentTimeStampForDatabaseInsertion];
    [strCurrentTimeStamp retain];
    if (([DataSource executeQuery:[NSString stringWithFormat:@"Update Job_patrol_schedule_points SET IsSynced=%@,require_unable='N',date_complete ='%@',ManualStatusHandler='COMPLETE' where schedule_id= %@ and point_id = %@ and sort=%@",UN_SYNCED_DATA,strCurrentTimeStamp,[dicSelected objectForKey:SCHEDULE_ID],[dicSelected objectForKey:POINT_ID],[dicSelected objectForKey:JOB_PATROL_SCHEDULE_POINT_SORT]]]) && ([DataSource executeQuery:[NSString stringWithFormat:@"Update Job_patrol_schedule_points SET date_complete ='',require_unable='N',ManualStatusHandler='MISSED' where  sort < %@ and ManualStatusHandler != 'NOT_COMPLETE' and  ManualStatusHandler != 'COMPLETE' and schedule_id = %@;",[dicSelected objectForKey:JOB_PATROL_SCHEDULE_POINT_SORT],[dicSelected objectForKey:SCHEDULE_ID]]]))
    {
        NSLog(@"record updated");
        
        if ([CommonFunctions isNetAvailable])
        {
            if ((alertTag-TAG_Btn_Check)==([arrPatrolList count]-1))  //last point row
                isUploadingLastPoint = TRUE;
            else
                isUploadingLastPoint = FALSE;
            [self completePoint:dicSelected];
        }
        else
        {
            //no internet connection available
            if ((alertTag-TAG_Btn_Check)==([arrPatrolList count]-1))  //last point row
            {
                //Complete Patrol
                [self CompletePatrol:dicSelected];
            }
            else
            {
                [self refreshData];
            }
        }
    }
    else
        NSLog(@"Unable to update the record");
}
#pragma OptionOk UnOrderedCompletion
-(void)OptionOkSelected_UnOrderedCompletion:(UIButton*)sender  andTag:(int)alertTag
{
    
    NSLog(@"btnOk_Tapped Clicked");
    NSMutableDictionary *dicSelected = [arrPatrolList objectAtIndex:alertTag-TAG_Btn_Check];
    strCurrentTimeStamp = [CommonFunctions getCurrentTimeStampForDatabaseInsertion];
    [strCurrentTimeStamp retain];
    if (([DataSource executeQuery:[NSString stringWithFormat:@"Update Job_patrol_schedule_points SET IsSynced=%@,require_unable='N',date_complete ='%@',ManualStatusHandler='COMPLETE' where schedule_id= %@ and point_id = %@ and sort=%@",UN_SYNCED_DATA,strCurrentTimeStamp,[dicSelected objectForKey:SCHEDULE_ID],[dicSelected objectForKey:POINT_ID],[dicSelected objectForKey:JOB_PATROL_SCHEDULE_POINT_SORT]]]) )
    {
        NSLog(@"record updated");
        
        if ([CommonFunctions isNetAvailable])
        {

            [self completePoint:dicSelected :alertTag-TAG_Btn_Check];
        }
        else
        {
            //no internet connection available
            if (isUploadingLastPoint) //last point row
            {
                //Complete Patrol
                [self CompletePatrol:dicSelected];
            }
            else
            {
                [self refreshData];
            }
        }
    }
    else
        NSLog(@"Unable to update the record");
}
-(IBAction)btnOk_Tapped:(UIButton *)Sender andTag:(int)alertTag
{
    
if ([strIsPatrolUnordered isEqualToString:UN_ORDER])
{
    [self OptionOkSelected_UnOrderedCompletion:Sender andTag:alertTag];
}
else 
{
    [self OptionOkSelected_OrderedCompletion:Sender andTag:alertTag];    
}
    
  
}

#pragma mark completePoint in unordered mode
-(void)completePoint:(NSMutableDictionary *)dicCurrentRecord :(NSInteger)CurrentIndex
{
    /*http://code.elogbooks.co.uk/users/jack/WOM/api/put-info.php?uid=38&UpdateType=patrol_point&qd=Update&tstamp=27/12/2012%2018:35:20&jid=7811&point_id=50&order=3&schedule_id=240&unable=N */
    
    
    
    objService=[[PutInfoClass alloc] init];
    objService._delegate=self;
    objService.retType=isArray;
    NSMutableDictionary *dicc=[[[NSMutableDictionary alloc] init]autorelease];
    [dicc setObject:[ElogBooksAppDelegate getValueForKey:USER_ID] forKey:USER_ID];
    [dicc setObject:@"patrol_point" forKey:@"UpdateType"];
    [dicc setObject:@"Update" forKey:@"qd"];
    [dicc setObject: [CommonFunctions getCurrentTimeStamp:strCurrentTimeStamp] forKey:@"tstamp"];
    [dicc setObject:strJid forKey:JOBS_ID];
    
    [dicc setObject:[dicCurrentRecord objectForKey:POINT_ID]  forKey:POINT_ID];
    [dicc setObject:[dicCurrentRecord objectForKey:SCHEDULE_ID]  forKey:SCHEDULE_ID];
    [dicc setObject:[dicCurrentRecord objectForKey:JOB_PATROL_SCHEDULE_POINT_SORT]  forKey:@"order"];
    [dicc setObject:[dicCurrentRecord objectForKey:JOB_PATROL_SCHEDULE_POINT_REQUIRE_UNABLE]  forKey:@"unable"];
    
    
    objService.argsDic=[CommonFunctions getDicAsParameter:dicc] ;
    //point_id-->1 ===SCHEDULE_ID-->3 ====sort-->5=====Index====>7
    objService.strWebService=[NSString stringWithFormat:@"point_id:%@:schedule_id:%@:sort:%@:Index:%d",[dicCurrentRecord objectForKey:POINT_ID],[dicCurrentRecord objectForKey:SCHEDULE_ID],[dicCurrentRecord objectForKey:JOB_PATROL_SCHEDULE_POINT_SORT],CurrentIndex];
    objService.strUrl= [NSString stringWithFormat:@"%@%@",[ElogBooksAppDelegate getValueForKey:BASE_URL],PUT_INFO_API];
    objService.ParentNode=@"Responses";
    objService.ChildNode=@"Response";
    [objService performSelector:@selector(setArray) withObject:nil afterDelay:0.1];
    
    
}

#pragma mark completePoint
-(void)completePoint:(NSMutableDictionary *)dicCurrentRecord
{
    /*http://code.elogbooks.co.uk/users/jack/WOM/api/put-info.php?uid=38&UpdateType=patrol_point&qd=Update&tstamp=27/12/2012%2018:35:20&jid=7811&point_id=50&order=3&schedule_id=240&unable=N */
    
    
    
    objService=[[PutInfoClass alloc] init];
    objService._delegate=self;
    objService.retType=isArray;
    NSMutableDictionary *dicc=[[[NSMutableDictionary alloc] init]autorelease];
    [dicc setObject:[ElogBooksAppDelegate getValueForKey:USER_ID] forKey:USER_ID];
    [dicc setObject:@"patrol_point" forKey:@"UpdateType"];
    [dicc setObject:@"Update" forKey:@"qd"];
    [dicc setObject: [CommonFunctions getCurrentTimeStamp:strCurrentTimeStamp] forKey:@"tstamp"];
    [dicc setObject:strJid forKey:JOBS_ID];
    
    [dicc setObject:[dicCurrentRecord objectForKey:POINT_ID]  forKey:POINT_ID];
    [dicc setObject:[dicCurrentRecord objectForKey:SCHEDULE_ID]  forKey:SCHEDULE_ID];
    [dicc setObject:[dicCurrentRecord objectForKey:JOB_PATROL_SCHEDULE_POINT_SORT]  forKey:@"order"];
    [dicc setObject:[dicCurrentRecord objectForKey:JOB_PATROL_SCHEDULE_POINT_REQUIRE_UNABLE]  forKey:@"unable"];
    
    
    objService.argsDic=[CommonFunctions getDicAsParameter:dicc] ;
    //point_id-->1 ===SCHEDULE_ID-->3 ====sort-->5
    objService.strWebService=[NSString stringWithFormat:@"point_id:%@:schedule_id:%@:sort:%@",[dicCurrentRecord objectForKey:POINT_ID],[dicCurrentRecord objectForKey:SCHEDULE_ID],[dicCurrentRecord objectForKey:JOB_PATROL_SCHEDULE_POINT_SORT]];
    objService.strUrl= [NSString stringWithFormat:@"%@%@",[ElogBooksAppDelegate getValueForKey:BASE_URL],PUT_INFO_API];
    objService.ParentNode=@"Responses";
    objService.ChildNode=@"Response";
    [objService performSelector:@selector(setArray) withObject:nil afterDelay:0.1];
    
    
}


#pragma mark Parsing delegates
-(void)filedWithError:(NSString *)strMsg forFlage:(NSString *)flage
{
  if (!([flage rangeOfString:@"START_Job"].location == NSNotFound))
      {
          //start patro section
        if ([DataSource executeQuery:[NSString stringWithFormat:@"Update Jobs set stt='In Progress',eng_on_site='%@',IsSynced=%@ where jid=%@",strCurrentTimeStamp,UN_SYNCED_DATA,strJid]])
        {
            NSLog(@"eng_on_site value set ");
        }
        else
            NSLog(@"eng_on_site value not set ");
      } 
   else 
   {
       
       //patrol point sectin
    if (isUploadingLastPoint)
    {
          if ([strIsPatrolUnordered isEqualToString:UN_ORDER])
          {
              NSArray *arrIdValues = [flage componentsSeparatedByString:@":"];
              NSString *StrIndex_Value = [arrIdValues objectAtIndex:7];
              [self CompletePatrol:[arrPatrolList objectAtIndex:[StrIndex_Value intValue]]];
              
          }
        else 
        [self CompletePatrol:[arrPatrolList objectAtIndex:[arrPatrolList count]-1]];
    }
    else
        [self refreshData];
   }
}
-(void)EndParsingArray:(NSMutableArray *)arrData forFlage:(NSString *)flage
{
    NSLog(@"%@",[arrData description]);
    //    If success remove set Issynced to 1
    
    if (!([flage rangeOfString:@"START_Job"].location == NSNotFound))
    {
     //start job section
        if (!([[arrData objectAtIndex:0] rangeOfString:@"Success"].location == NSNotFound))
        {
            if([DataSource executeQuery:[NSString stringWithFormat:@"Update Jobs set  IsJobStarted='Y' where jid=%@",strJid]])
                NSLog(@"Job :%@:synced",flage); 
            else 
                NSLog(@"Job :%@:failed to synce",flage);  
            
            if ([DataSource executeQuery:[NSString stringWithFormat:@"Update Jobs set stt='In Progress',eng_on_site='%@',IsSynced=%@ where jid=%@",strCurrentTimeStamp,SYNCED_DATA,strJid]])
                
            {
                NSLog(@"eng_on_site value set ");
            }
            else
            {
                NSLog(@"eng_on_site value not set ");
            }
        }
        [self refreshData];
    }
    else 
    {
        //patrol points section
         NSArray *arrIdValues = [flage componentsSeparatedByString:@":"];
        if ([arrData count]>0)
        {
            if (!([[arrData objectAtIndex:0]rangeOfString:@"Success"].location==NSNotFound))
            {
                if ([flage length]>0) // if success
                {
                    //   //point_id-->1 ===SCHEDULE_ID-->3 ====sort-->5=====Index====>7
                   
                    NSString *strPointId=[arrIdValues objectAtIndex:1];
                    NSString *strScheduleId=[arrIdValues objectAtIndex:3];
                    NSString *strSortValue=[arrIdValues objectAtIndex:5];
                    if ([DataSource executeQuery:[NSString stringWithFormat:@"update Job_patrol_schedule_points set IsSynced=%@ where schedule_id=%@ and point_id=%@ and sort=%@",SYNCED_DATA,strScheduleId,strPointId,strSortValue]])
                        NSLog(@"pointId :%@ synced from webservice to local",strPointId);
                    else
                        NSLog(@"pointId :%@  not synced",strPointId);
                }
            }
            }
        

        
        if (isUploadingLastPoint)
        {
             if ([strIsPatrolUnordered isEqualToString:UN_ORDER])
            {
                NSString *StrIndex_Value = [arrIdValues objectAtIndex:7];
              [self CompletePatrol:[arrPatrolList objectAtIndex:[StrIndex_Value intValue]]];
            }
             else 
            [self CompletePatrol:[arrPatrolList objectAtIndex:[arrPatrolList count]-1]];
        }
        else
            [self refreshData];
    }
}




-(IBAction)btnCancel_Tapped:(UIButton *)Sender andTag:(int)alertTag
{

    NSLog(@"btnCancel_Tapped Clicked");
}

#pragma mark CompletePatrol
-(void)CompletePatrol:(NSMutableDictionary *)dicSelected 
{
    //update the schedule as unsynced
    //Check whether any unsynced point exists ,if yes then set schedule_id as unsynced
    //select COUNT(Job_patrol_schedule_points.point_id) from Jobs join Job_patrol_schedules on Jobs.jid = Job_patrol_schedules.jid join Job_patrol_schedule_points on Job_patrol_schedule_points.schedule_id=Job_patrol_schedules.schedule_id where jobs.jid=7798 and Job_patrol_schedule_points.IsSynced=0
    
    
    int UnsyncedDatacount =  [[DataSource getStringFromQuery:[NSString stringWithFormat:@"select COUNT(Job_patrol_schedule_points.point_id) from Jobs join Job_patrol_schedules on Jobs.jid = Job_patrol_schedules.jid join Job_patrol_schedule_points on Job_patrol_schedule_points.schedule_id=Job_patrol_schedules.schedule_id where jobs.jid=%@ and Job_patrol_schedule_points.IsSynced=%@",strJid,UN_SYNCED_DATA]]intValue];
    if (UnsyncedDatacount >0) //Check any unsynced data available
    {
        if ([DataSource executeQuery:[NSString stringWithFormat:@"update Job_patrol_schedules set IsSynced=%@ where schedule_id=%@",UN_SYNCED_DATA,[dicSelected objectForKey:SCHEDULE_ID]]])
            NSLog(@"Patrol Point updated");
        else
            NSLog(@"Failed to update the current schedule_id");
    }
    
    int MissedValuesCount = [[DataSource getStringFromQuery:[NSString stringWithFormat:@" select COUNT(*) as MissedCount from Jobs join Job_patrol_schedules on Jobs.jid = Job_patrol_schedules.jid join Job_patrol_schedule_points on Job_patrol_schedule_points.schedule_id=Job_patrol_schedules.schedule_id where                                                             jobs.jid='%@' and  ( Job_patrol_schedule_points.ManualStatusHandler ='NOT_COMPLETE' or Job_patrol_schedule_points.ManualStatusHandler = 'MISSED' )",strJid]]intValue];
    
    
    
    //Call webservice here
    NSLog(@"Value updated");
    AddDescription* objNav=[[AddDescription alloc] initWithNibName:@"AddDescription" bundle:nil];
    objNav.strJid=strJid;
    objNav.dicRecord = dicSelected;
    if (MissedValuesCount == 0)
    {
        objNav.isNotMissedAnyPoint = YES;   
    }
    [self.navigationController pushViewController:objNav animated:YES];
    [objNav release];
    
    
    
}

- (void)viewDidUnload
{
    strIsPatrolUnordered =  nil;
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
