//
//  PatrolsScreen.h
//  ElogBooks
//
//  Created by I-VERVE5 on 11/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PatrolsScreen : UIViewController<UIPickerViewDataSource,UIPickerViewDelegate,UITableViewDelegate,UITableViewDataSource,PickerViewControlDelegate>
{

    UIButton *BtnPickr;
    NSMutableArray *arrPickerData,*arrPatrolJobs;
    UITableView *tblView;

    NSString *strPreviousFilterMode;
    int lastSelectedIndex;
    UIButton  *btnCountLabel;

//    BOOL isTableLoaded;
    
}


-(UITableViewCell *)getCellForDic:(NSMutableDictionary *)redDic cell:(UITableViewCell *)cell andIndexPath:(NSIndexPath *)indexPath isBold:(BOOL)isBold;
@end
