//
//  PatrolsInfoScreen.h
//  ElogBooks
//
//  Created by iphone on 13/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PatrolsInfoScreen : UIViewController<UIScrollViewDelegate,UITableViewDelegate,UITableViewDataSource,PutInfoDelegate>
{
    UIScrollView *scrVertical;
    NSMutableArray  *arrItems;
    UITableView *tblView;
    
    NSMutableArray *arrJobInfoKey;
    NSMutableArray *arrTableDataData;
    
    BOOL isShow1,isShow2,isJobStarted;
    
    NSMutableArray *arrCallHistory,*arrAttachment;
    //Webservice Delegates
    PutInfoClass *objService;
    
    int CELL_HEIGHT;
    NSString *strCurrentTimeStamp;
}

@property(retain,nonatomic)NSString *strJid;
-(IBAction)ItemSelect:(id)button;
@end
