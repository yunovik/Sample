//
//  PatrolsInfoScreen.m
//  ElogBooks
//
//  Created by iphone on 13/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import "PatrolsInfoScreen.h"

#import "SubAssetScreen.h"
#import "SignViewController.h"
#import "AddMaterials.h"
#import "UpdatePointScreen.h"
#import "PatrolPointsScreen.h"
#import "AddDescription.h"
#define Scroll_Btn_TAG 1000


@interface PatrolsInfoScreen ()
@end


@implementation PatrolsInfoScreen

@synthesize strJid;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    CELL_HEIGHT=25;
    
    
    self.title = @"Patrols Info";
    [CommonFunctions setTitleView:self amdtitle:@"Patrols Info"];
    
    //Top ScrollView
    
    scrVertical= [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, 320, 75)];
    scrVertical.backgroundColor = getImageColor(@"ScrollMenu_Stripe.png");
    scrVertical.alpha = 0.8;
    scrVertical.pagingEnabled = YES;
    scrVertical.scrollEnabled = YES;
    scrVertical.delegate = self;
    scrVertical.hidden=NO;
    scrVertical.showsHorizontalScrollIndicator = NO;
    [self.view addSubview:scrVertical];
    
    if ([[DataSource getStringFromQuery:[NSString stringWithFormat:@"select stt from Jobs where jid = %@",strJid]]rangeOfString:@"In Progress"].location == NSNotFound)
        isJobStarted = FALSE;
    else
        isJobStarted = TRUE;
    arrItems = [[NSMutableArray alloc] init];
    
    NSMutableDictionary *dicItem;
    
    dicItem  = [[NSMutableDictionary alloc] init];
    [dicItem setObject:@"Start Patrol" forKey:@"Title"];
    if (isJobStarted)
        [dicItem setObject:@"Disable_PlatBtn.png" forKey:@"Image"];
    else
        [dicItem setObject:@"Playbtn.png" forKey:@"Image"];
    [arrItems addObject:dicItem];
    
    dicItem  = [[NSMutableDictionary alloc] init];
    [dicItem setObject:@"Complete" forKey:@"Title"];
    [dicItem setObject:@"Complete.png" forKey:@"Image"];
    [arrItems addObject:dicItem];
    
    int xx = 15;
    int gape = 7;
    int ww =57;
    int hh = 60;
    
    for(int i=0;i<[arrItems count];i++)
    {
        
        NSMutableDictionary *dicItem = [arrItems objectAtIndex:i];
        
        UIView *itemView = [[UIView alloc] initWithFrame:CGRectMake(xx, gape, ww, hh)];
        [itemView setBackgroundColor:[UIColor clearColor]];
        
        
        UIButton *btnItem = [[UIButton alloc] initWithFrame:CGRectMake(5, 0, ww-10, 48)];
        [btnItem addTarget:self  action:@selector(ItemSelect:)forControlEvents:UIControlEventTouchDown];
        
        //      [btnItem setBackgroundColor:[UIColor whiteColor]];
        [btnItem setImage:getImage([dicItem objectForKey:@"Image"]) forState:UIControlStateNormal];
        [btnItem setTag:i+Scroll_Btn_TAG];
        [itemView addSubview:btnItem];
        
        UILabel *lblItem = [[UILabel alloc] initWithFrame:CGRectMake(0, 50, ww, 12)];
        [lblItem setText:[dicItem objectForKey:@"Title"]];
        [lblItem setBackgroundColor:[UIColor clearColor]];
        //      [lblItem setFont:[UIFont fontWithName:@"helvetica" size:11]];
        [lblItem setFont:FONT_NEUE_SIZE(11)];
        [lblItem setLineBreakMode:UILineBreakModeWordWrap];
            [lblItem setTextColor:DEFAULT_FONT_COLOR];
        [lblItem setTextAlignment:UITextAlignmentCenter];
        [itemView addSubview:lblItem];
        
        [scrVertical addSubview:itemView];
        
        xx += ww + gape;
        
        NSLog(@"%i",xx);
    }
    
    [scrVertical setContentSize:CGSizeMake(xx, 0)];
    
    [self.view addSubview:scrVertical];
    [self.view setClipsToBounds:YES];
    
    tblView = [[UITableView alloc]init];
    tblView.frame = CGRectMake(0, 75, 320, [[UIScreen mainScreen] bounds].size.height-140);
    tblView.delegate = self;
    tblView.dataSource = self;
    
    [tblView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    
    [self.view addSubview:tblView];
    
    //strJid = @"7687";
        arrTableDataData = [[NSMutableArray alloc]initWithArray:[DataSource getRecordsFromQuery:[NSString stringWithFormat:@"SELECT jid,stt,priority,description,date_due,date_due_comp,eng_on_site,eng_complete FROM jobs Where jid=%@",strJid]]];

    
    
    [CommonFunctions setBack:self target:@selector(btnBackTapped:)];
}

#pragma mark -viewwillappear
-(void)viewWillAppear:(BOOL)animated
{
    
    
    //set navigation controller enable 
    [self.navigationController.navigationBar setUserInteractionEnabled:YES];
    
    arrTableDataData = [[NSMutableArray alloc]initWithArray:[DataSource getRecordsFromQuery:[NSString stringWithFormat:@"SELECT jid,stt,priority,description,date_due,date_due_comp,eng_on_site,eng_complete FROM jobs Where jid=%@",strJid]]];
    
    arrCallHistory = [[NSMutableArray alloc]initWithArray:[DataSource getRecordsFromQuery:[NSString stringWithFormat:@"Select * from Job_Lines Where jid=%@ AND helpdesk LIKE 'N/A'",strJid]]];
    
    arrAttachment = [[NSMutableArray alloc]initWithArray:[DataSource getRecordsFromQuery:[NSString stringWithFormat:@"Select * from Uploaded_files Where as_id LIKE '%@'",strJid]]];
    
    NSMutableArray *arrKeys = [[NSMutableArray alloc]initWithObjects:JOBS_ID,JOBS_STT,JOBS_PRIORITY,JOBS_DESC,JOBS_DATE_DUE,JOBS_DATE_DUE_COMP,JOBS_ENG_ON_SITE,JOBS_ENG_COMPLETE, nil];
    
    NSMutableArray *arrValues = [[NSMutableArray alloc]initWithObjects:@"Job Number",@"Status",@"Priority",@"Description",@"Attend Due",@"Complete Due",@"Attended",@"Completed", nil];
    
    arrJobInfoKey  = [[NSMutableArray alloc] init];
    
    for (int i=0;i<[arrKeys count]; i++)
    {
        NSMutableDictionary *dic;
        dic = [[NSMutableDictionary alloc] init];
        [dic setObject:[arrKeys objectAtIndex:i] forKey:@"Key"];
        [dic setObject:[arrValues objectAtIndex:i] forKey:@"Value"];
        [arrJobInfoKey addObject:dic];
        [dic release];
    }
    if (tblView !=nil)
    [tblView reloadData];
    [super viewWillAppear:YES];
    
}


#pragma mark - backTapped Method

-(IBAction)btnBackTapped:(id)sender
{
    
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark -
#pragma mark Tableview Delegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    switch (section)
    {
        case 0:
            return [arrJobInfoKey count];
        case 1:
            
            if(isShow1)
                return arrCallHistory.count;
            else
                return 0;
        case 2:
            
            if(isShow2)
                return arrAttachment.count;
            else
                return 0;
        default:
            return 0;
    }
    
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *CellIdentifier = [NSString stringWithFormat:@"CellId_%i_%i",indexPath.row,indexPath.section];
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    cell = nil;
    if(cell == nil)
    {
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] ;
        
        [cell setSelectionStyle:UITableViewCellEditingStyleNone];
        
        if (indexPath.section == 0) {
            
            
            NSMutableDictionary *dicRec = [arrTableDataData objectAtIndex:0];
            
            
            NSMutableDictionary *dic = [arrJobInfoKey objectAtIndex:indexPath.row];
            
            NSLog(@"%@",[arrJobInfoKey description]);
            
            NSString *str = [dic objectForKey:@"Key"];
            NSString *strTitle = [dic objectForKey:@"Value"];
            
            NSString *strVal = [dicRec objectForKey:str];
            
            
            if(indexPath.row==3 && indexPath.section == 0)
            {
                UILabel *lbl = [[UILabel alloc]initWithFrame:CGRectMake(20, 5, 120, 20)];
                lbl.text = strTitle;
                lbl.backgroundColor =[UIColor clearColor];
                lbl.font = FONT_NEUE_BOLD_SIZE(12);
                [cell.contentView addSubview:lbl];
                CGSize _stringSize =[strVal sizeWithFont:FONT_NEUE_SIZE(12) constrainedToSize:CGSizeMake(270,MAXFLOAT) lineBreakMode:UILineBreakModeCharacterWrap];
                
                UILabel *lblJobDesc = [[UILabel alloc] initWithFrame:CGRectMake(20, 27, 270, _stringSize.height)];
                lblJobDesc.backgroundColor = [UIColor clearColor];
                lblJobDesc.numberOfLines = 0;
                lblJobDesc.textColor = DEFAULT_FONT_COLOR;
                [lblJobDesc setFont:FONT_NEUE_SIZE(12)];
                lblJobDesc.text = strVal;
                [cell.contentView addSubview:lblJobDesc];
                [lblJobDesc release];
                
                
            }else
            {
                [cell.contentView addSubview:
                 [CommonFunctions getLableWithTitle:strTitle andDesc:strVal WithFrame:CGRectMake(20, 5, 300, 20)]];
            }
            
            
        }
        
        else if (indexPath.section == 1)
        {
            
            NSMutableDictionary *recDic;
            
            recDic = [arrCallHistory objectAtIndex:indexPath.row];
            
            UILabel *lblDate = [[UILabel alloc]initWithFrame:CGRectMake(20,0, 70, CELL_HEIGHT)];
            [lblDate setText:[CommonFunctions getDate:[recDic objectForKey:J_LINE_TSTAMP]]];
            lblDate.textColor = DEFAULT_FONT_COLOR;
            lblDate.backgroundColor = [UIColor clearColor];
            lblDate.font=FONT_NEUE_SIZE(14);
            [cell.contentView addSubview:lblDate];
            
            
            CGSize _size = [[recDic objectForKey:J_LINE_NAME] sizeWithFont:FONT_NEUE_SIZE(14) constrainedToSize:CGSizeMake(50,MAXFLOAT) lineBreakMode:UILineBreakModeCharacterWrap];
            
            UILabel *lblEng = [[UILabel alloc]initWithFrame:CGRectMake(90, 2, 50, _size.height)];
            [lblEng setText:[recDic objectForKey:J_LINE_NAME]];
            [lblEng setNumberOfLines:0];
            lblEng.textColor = DEFAULT_FONT_COLOR;
            lblEng.font =FONT_NEUE_SIZE(14);
            [lblEng setClipsToBounds:YES];
            [lblEng setBackgroundColor:[UIColor clearColor]];
            [cell.contentView addSubview:lblEng];
            
            
            _size = [[recDic objectForKey:J_LINE_DESC] sizeWithFont:FONT_NEUE_SIZE(14) constrainedToSize:CGSizeMake(100,MAXFLOAT) lineBreakMode:UILineBreakModeCharacterWrap];
            
            UILabel *lblDescription = [[UILabel alloc]initWithFrame:CGRectMake(150, 2, 100, _size.height)];
            [lblDescription setText:[recDic objectForKey:J_LINE_DESC]];
            lblDescription.textColor = DEFAULT_FONT_COLOR;
            lblDescription.font = FONT_NEUE_SIZE(14);
            lblDescription.numberOfLines = 0;
            [lblDescription setClipsToBounds:YES];
            lblDescription.backgroundColor = [UIColor clearColor];
            [cell.contentView addSubview:lblDescription];
            
            UILabel *lblH = [[UILabel alloc]initWithFrame:CGRectMake(255, 0, 20, CELL_HEIGHT)];
            [lblH setText:[recDic objectForKey:J_LINE_H]];
            lblH.textColor = DEFAULT_FONT_COLOR;
            lblH.font=FONT_NEUE_SIZE(14);
            lblH.backgroundColor = [UIColor clearColor];
            [cell.contentView addSubview:lblH];
            
            UILabel *lblT = [[UILabel alloc]initWithFrame:CGRectMake(275,0, 20, CELL_HEIGHT)];
            [lblT setText:[recDic objectForKey:J_LINE_T]];
            lblT.textColor = DEFAULT_FONT_COLOR;
            lblT.font=FONT_NEUE_SIZE(14);
            lblT.backgroundColor = [UIColor clearColor];
            [cell.contentView addSubview:lblT];
            
            UILabel *lblM = [[UILabel alloc]initWithFrame:CGRectMake(295, 0, 20, CELL_HEIGHT)];
            [lblM setText:[recDic objectForKey:J_LINE_M]];
            lblM.textColor = DEFAULT_FONT_COLOR;
            lblM.font=FONT_NEUE_SIZE(14);
            lblM.backgroundColor = [UIColor clearColor];
            [cell.contentView addSubview:lblM];
            
        }
        else if (indexPath.section == 2)
        {
            
            NSMutableDictionary *recDic = [arrAttachment objectAtIndex:indexPath.row];
            
            UILabel *lblDate = [[UILabel alloc]initWithFrame:CGRectMake(20, 0, 75, 25)];
            [lblDate setText:[CommonFunctions getDate:[recDic objectForKey:FILE_CREATED]]];
            lblDate.textColor = DEFAULT_FONT_COLOR;
            lblDate.font=FONT_NEUE_SIZE(14);
            lblDate.backgroundColor = [UIColor clearColor];
            [cell.contentView addSubview:lblDate];
            
            UILabel *lblFileName = [[UILabel alloc]initWithFrame:CGRectMake(93, 2, 200, 25)];
            [lblFileName setText:[recDic objectForKey:FILE_TITLE]];
            lblFileName.textColor = DEFAULT_FONT_COLOR;
            lblFileName.font=FONT_NEUE_SIZE(14);
            lblFileName.backgroundColor = [UIColor clearColor];
            [cell.contentView addSubview:lblFileName];
            
        }
    }
    
    return cell;
    
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 3;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if(indexPath.row==3 && indexPath.section == 0)
    {
        
        NSLog(@"%i",indexPath.row);
        NSString *txtForLable;
        
        if ([arrTableDataData count]>0) {
            txtForLable =[[[arrTableDataData objectAtIndex:0] objectForKey:JOBS_DESC] retain];
        }
        else {
            txtForLable=@"";
        }
        
        CGSize constraintSize;
        constraintSize.width = 270;
        constraintSize.height = MAXFLOAT;
        
        CGSize _stringSize =[txtForLable sizeWithFont:FONT_NEUE_SIZE(14) constrainedToSize: constraintSize lineBreakMode: UILineBreakModeCharacterWrap];
        NSLog(@"%f",_stringSize.height);
        
        if(_stringSize.height < CELL_HEIGHT)
        {
            _stringSize.height = CELL_HEIGHT + 25;
        }
        else
        {
            _stringSize.height+=40;
        }
        
        return _stringSize.height;
    }
    else if(indexPath.section == 1 )
    {
        
        NSString *txtDesc = @"";
        NSString *txtName = @"";
        
        
        if ([arrCallHistory count]>0) {
            txtDesc =[[[arrCallHistory objectAtIndex:indexPath.row] objectForKey:J_LINE_DESC] retain];
            txtName =[[[arrCallHistory objectAtIndex:indexPath.row] objectForKey:J_LINE_NAME] retain];
        }
        
        
        CGSize _size = [CommonFunctions getSize:txtDesc Font:FONT_NEUE_SIZE(14) constrainedToSize:CGSizeMake(100,MAXFLOAT) LineBreakMode:UILineBreakModeCharacterWrap min:CELL_HEIGHT];
        
        float _descH = _size.height;
        
        _size = [CommonFunctions getSize:txtName Font:FONT_NEUE_SIZE(14) constrainedToSize:CGSizeMake(70,MAXFLOAT) LineBreakMode:UILineBreakModeCharacterWrap min:CELL_HEIGHT];
        
        float _nameH = _size.height;
        
        if(_descH > _nameH)
            return _descH;
        else
            return _nameH;
        
    }
    
    return CELL_HEIGHT;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    
    if(section==1)
    {
        if(isShow1) return 51;
    }
    else if(section==2)
    {
        if(isShow2) return 51;
    }
    return 26;
}
- (UIView *) tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *headerView = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 26)] autorelease];
    [headerView setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"jobInfo_HeaderStripe.png"]]];
    
    UILabel *lblHeaderTitle= [[UILabel alloc]initWithFrame:CGRectMake(20, 2, 300, 20)];
    lblHeaderTitle.font = FONT_NEUE_SIZE(14);
    lblHeaderTitle.backgroundColor = [UIColor clearColor];
    
    
    UIButton *btnPlusMinus = [[UIButton alloc]initWithFrame:CGRectMake(285, 0, 25, 25)];
    [btnPlusMinus setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    btnPlusMinus.backgroundColor = [UIColor clearColor];
    [btnPlusMinus setTag:section];
    [btnPlusMinus addTarget:self action:@selector(btnPlusMinusTapped:) forControlEvents:UIControlEventTouchUpInside];
    
    
    
    [headerView addSubview:btnPlusMinus];
    
    
    if(section == 0)
    {
        lblHeaderTitle.text = @"Job Info";
        
    }
    else if(section == 1 )
    {
        if([arrCallHistory count]<=0){
            [btnPlusMinus setHidden:YES];
            lblHeaderTitle.text = @"Call History - Not available";
            
        }
        else {
            [btnPlusMinus setHidden:NO];
            lblHeaderTitle.text = @"Call History";
            
        }
        
        if(isShow1)
        {
            [btnPlusMinus setTitle:@"-" forState:UIControlStateNormal];
            
            UIView *titleView = [[UIView alloc]initWithFrame:CGRectMake(0, 26, 320,25)];
            titleView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"jobInfo_Row_Stripe.png"]];
            [headerView addSubview:titleView];
            
            UILabel *lblDate = [[UILabel alloc]initWithFrame:CGRectMake(20, 2, 75, 20)];
            lblDate.text = @"Date";
            lblDate.textColor = DEFAULT_FONT_COLOR;
            lblDate.backgroundColor = [UIColor clearColor];
            [titleView addSubview:lblDate];
            
            UILabel *lblEng = [[UILabel alloc]initWithFrame:CGRectMake(90, 2, 50, 20)];
            lblEng.text = @"Eng";
            lblEng.textColor = DEFAULT_FONT_COLOR;
            lblEng.backgroundColor = [UIColor clearColor];
            [titleView addSubview:lblEng];
            
            
            UILabel *lblDescription = [[UILabel alloc]initWithFrame:CGRectMake(150, 2, 100, 20)];
            lblDescription.text = @"Description";
            lblDescription.textColor = DEFAULT_FONT_COLOR;
            lblDescription.backgroundColor = [UIColor clearColor];
            [titleView addSubview:lblDescription];
            
            UILabel *lblHTM = [[UILabel alloc]initWithFrame:CGRectMake(252, 2, 60, 20)];
            lblHTM.text = @"H  T  M";
            lblHTM.textColor = DEFAULT_FONT_COLOR;
            lblHTM.backgroundColor = [UIColor clearColor];
            [titleView addSubview:lblHTM];
            
        }
        else
        {
            [btnPlusMinus setTitle:@"+" forState:UIControlStateNormal];
        }
        
    }
    else if(section == 2)
    {
        if([arrAttachment count]<=0){
            [btnPlusMinus setHidden:YES];
            lblHeaderTitle.text = @"Attachments - Not available";
            
        }
        else {
            [btnPlusMinus setHidden:NO];
            lblHeaderTitle.text = @"Attachments ";
            
        }
        
        
        
        if(isShow2)
        {
            [btnPlusMinus setTitle:@"-" forState:UIControlStateNormal];
            
            UIView *titleView = [[UIView alloc]initWithFrame:CGRectMake(0, 26, 320,25)];
            titleView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"jobInfo_Row_Stripe.png"]];
            [headerView addSubview:titleView];
            
            UILabel *lblDate = [[UILabel alloc]initWithFrame:CGRectMake(20, 0, 75, 25)];
            lblDate.text = @"Date";
            lblDate.textColor = DEFAULT_FONT_COLOR;
            lblDate.backgroundColor = [UIColor clearColor];
            [titleView addSubview:lblDate];
            
            UILabel *lblFileName = [[UILabel alloc]initWithFrame:CGRectMake(93, 2, 200, 25)];
            lblFileName.text = @"File Name";
            lblFileName.textColor = DEFAULT_FONT_COLOR;
            lblFileName.backgroundColor = [UIColor clearColor];
            [titleView addSubview:lblFileName];
            
        }
        else
        {
            [btnPlusMinus setTitle:@"+" forState:UIControlStateNormal];
        }
        
    }
    else
    {
        lblHeaderTitle.text =nil;
        
    }
    
    
    [headerView addSubview:lblHeaderTitle];
    return headerView;
}
#pragma mark -
#pragma mark Button Method


-(IBAction)btnPlusMinusTapped:(UIButton *)sender
{
    
    if(sender.tag == 1)
    {
        isShow1=!isShow1;
        
        [tblView reloadSections:[NSIndexSet indexSetWithIndex:sender.tag] withRowAnimation:UITableViewRowAnimationFade];
        
        if (isShow1)
        {
            [tblView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:sender.tag] atScrollPosition:UITableViewScrollPositionTop animated:YES];
        }
        
    }
    if(sender.tag == 2)
    {
        isShow2=!isShow2;
        
        [tblView reloadSections:[NSIndexSet indexSetWithIndex:sender.tag] withRowAnimation:UITableViewRowAnimationFade];
        
        if (isShow2)
        {
            [tblView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:sender.tag] atScrollPosition:UITableViewScrollPositionTop animated:YES];
        }
        
    }
    
    
    
    
    
}
-(IBAction)btnCallHistory:(id)sender{
    NSLog(@"btnCallHistory clicked");
}
-(IBAction)btnAttachment:(id)sender{
    NSLog(@"btnAttachment clicked");
}

-(IBAction)ItemSelect:(id)button
{
    int currentTag = [button tag]-Scroll_Btn_TAG;
    
    if(currentTag == 0)
    {
        //start job section
        if (!isJobStarted) //job is not started
        {
            
            //check whether any patrol is started , if not then push to point screen
            //          int startedJobCount = [DataSource getNumberFromQuery:@"select COUNT(*) from Jobs where job_type = 'Patrol' and stt='In Progress'"];
            int startedJobCount = [[DataSource getStringFromQuery:@"select COUNT(*) from Jobs where job_type = 'Patrol' and stt='In Progress' and eng_complete=''"]intValue];
            if (startedJobCount >0)
            {
                //one job is started
                UIAlertView *alert=[[[UIAlertView alloc] initWithTitle:APP_TITLE message:@"Complete the Patrol in Progress!" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil]autorelease];
                [alert show];
            }
            else //no Job is started
            {
                //start the fresh patrol
                NSLog(@"you can start this patrol");
                /*http://code.elogbooks.co.uk/users/jack/WOM/api/put-info.php?uid=38&UpdateType=jobs&qd=Start&tstamp=08/12/2012%2011:19:12&jid=7953 */
                
                
                
                strCurrentTimeStamp = [CommonFunctions getCurrentTimeStampForDatabaseInsertion];
                [strCurrentTimeStamp retain];
                //update the job temporarily
                if ([DataSource executeQuery:[NSString stringWithFormat:@"update jobs set stt='In Progress',eng_on_site='%@',IsSynced='%@' where jid=%@",strCurrentTimeStamp,UN_SYNCED_DATA,strJid]])
                {
                NSLog(@"eng_on_site value set ");
             
                }
                
                if ([CommonFunctions isNetAvailable])
                {
                    objService=[[PutInfoClass alloc] init];
                    objService._delegate=self;
                    objService.retType=isArray;
                    NSMutableDictionary *dicc=[[[NSMutableDictionary alloc] init]autorelease];
                    [dicc setObject:[ElogBooksAppDelegate getValueForKey:USER_ID] forKey:USER_ID];
                    [dicc setObject:@"jobs" forKey:@"UpdateType"];
                    [dicc setObject:@"Start" forKey:@"qd"];
                    [dicc setObject: [CommonFunctions getCurrentTimeStamp:strCurrentTimeStamp] forKey:@"tstamp"];
                    [dicc setObject:strJid forKey:JOBS_ID];
                    
                    
                    
                    objService.argsDic=[CommonFunctions getDicAsParameter:dicc] ;
                    
                    objService.strWebService=[NSString stringWithFormat:@"Job:%@",strJid];
                    objService.strUrl= [NSString stringWithFormat:@"%@%@",[ElogBooksAppDelegate getValueForKey:BASE_URL],PUT_INFO_API];
                    objService.ParentNode=@"Responses";
                    objService.ChildNode=@"Response";
                    [objService performSelector:@selector(setArray) withObject:nil afterDelay:0.1];
                }
                else
                {
                    [DataSource executeQuery:[NSString stringWithFormat:@"update jobs set stt='In Progress',eng_on_site='%@',IsSynced='%@' where jid=%@",strCurrentTimeStamp,UN_SYNCED_DATA,strJid]];
                        NSLog(@"eng_on_site value set ");
                    
                    PatrolPointsScreen* objNav=[[PatrolPointsScreen alloc] initWithNibName:@"PatrolPointsScreen" bundle:nil];
                    objNav.strJid = strJid;
                    objNav.isPushedFromInfo = TRUE;
                    [self.navigationController pushViewController:objNav animated:YES];
                    [objNav release];
                    
                }                
                
            }
        }
    }
    else if(currentTag == 1)
    {
        //complete job section
        if (isJobStarted)
        {
            //push for description
            
            NSString *strScheduleId = [DataSource getStringFromQuery: [NSString stringWithFormat:@"select schedule_id from job_patrol_schedules where jid=%@",strJid]];
            if ([DataSource executeQuery:[NSString stringWithFormat:@"update Job_patrol_schedules set IsSynced=%@ where schedule_id=%@",UN_SYNCED_DATA,strScheduleId]])
                NSLog(@"Patrol Point updated");
            else
                NSLog(@"Failed to update the current schedule_id");
            //Call webservice here
            NSLog(@"Value updated");
            AddDescription* objNav=[[AddDescription alloc] initWithNibName:@"AddDescription" bundle:nil];
            objNav.strJid=strJid;
            [self.navigationController pushViewController:objNav animated:YES];
            [objNav release];
            
            
        }
        else 
        {
            UIAlertView *alert=[[[UIAlertView alloc] initWithTitle:APP_TITLE message:@"Job Not Started!" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil]autorelease];
            [alert show];
        }
        
        
    }
    
    
    NSLog(@"@Item clicked");
}

#pragma mark Parsing delegates
-(void)filedWithError:(NSString *)strMsg forFlage:(NSString *)flage
{
    if ([DataSource executeQuery:[NSString stringWithFormat:@"Update Jobs set stt='In Progress',eng_on_site='%@',IsSynced=%@ where jid=%@",strCurrentTimeStamp,UN_SYNCED_DATA,strJid]])
    {
        NSLog(@"eng_on_site value set ");
    }
    else
        NSLog(@"eng_on_site value not set ");
    
    PatrolPointsScreen* objNav=[[PatrolPointsScreen alloc] initWithNibName:@"PatrolPointsScreen" bundle:nil];
    objNav.strJid = strJid;
     objNav.isPushedFromInfo = TRUE;
    [self.navigationController pushViewController:objNav animated:YES];
    [objNav release];
        
    
}
-(void)EndParsingArray:(NSMutableArray *)arrData forFlage:(NSString *)flage
{
    
    if (!([[arrData objectAtIndex:0] rangeOfString:@"Success"].location == NSNotFound))
    {
    if ([DataSource executeQuery:[NSString stringWithFormat:@"Update Jobs set stt='In Progress',eng_on_site='%@',IsSynced=%@ where jid=%@",strCurrentTimeStamp,SYNCED_DATA,strJid]])

    {
        NSLog(@"eng_on_site value set ");
    }
    else
        {
            NSLog(@"eng_on_site value not set ");
        }
    }
    
    PatrolPointsScreen* objNav=[[PatrolPointsScreen alloc] initWithNibName:@"PatrolPointsScreen" bundle:nil];
    objNav.strJid = strJid;
     objNav.isPushedFromInfo = TRUE;
    [self.navigationController pushViewController:objNav animated:YES];
    [objNav release];
}
//-(void)EndParsing:(NSMutableArray *)arrData forFlage:(NSString *)flage
//{
//    
//
//    
//    
//}

#pragma mark -
#pragma mark scrollView

- (void)scrollViewDidScroll:(UIScrollView *)sender
{
    
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    arrTableDataData=nil;
    arrCallHistory=nil;
    arrAttachment=nil;
    
    
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
