//
//  PatrolsScreen.m
//  ElogBooks
//
//  Created by I-VERVE5 on 11/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import "PatrolsScreen.h"
#import "PatrolPointsScreen.h"
#define PICKERTAG 10000
@interface PatrolsScreen ()
@end

@implementation PatrolsScreen

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)viewWillAppear:(BOOL)animated
{
    //set navigation controller enable
    [self.navigationController.navigationBar setUserInteractionEnabled:YES];
    //   if (!isTableLoaded)
    [self FilterPatrolsJob:All];
    
    [super viewWillAppear:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    
    self.title = @"Patrols";
    [CommonFunctions setTitleView:self amdtitle:@"Patrols"];
    
    //    [self.view setBackgroundColor:getImageColor(@"Background.png")];
    [self.view setBackgroundColor:[UIColor whiteColor]];
    UIView *backView = [[[UIView alloc] init] autorelease];
    backView.frame = CGRectMake(0, 0, 320, 41);
    backView.backgroundColor = getImageColor(@"Cell_Stripe.png");
    [self.view addSubview:backView];
    //[View release];
    
    //[View release];
    
    //NSMutableArrayy
    arrPickerData = [[NSMutableArray alloc]initWithObjects:@"All  ",@"This Morning ",@"This Afternoon  ",@"Tomorrow  ",@"This Week  ", nil];
    
    arrPatrolJobs = [[NSMutableArray alloc] init];
    
    //Reset Picker
    lastSelectedIndex = 0;
    
    //UIButton  Picker
    
    BtnPickr = [UIButton buttonWithType:UIButtonTypeCustom];
    [BtnPickr addTarget:self action:@selector(OpenPicker:)forControlEvents:UIControlEventTouchDown];
    [BtnPickr setTitleColor:[UIColor blackColor] forState:UIControlStateNormal ];
    BtnPickr.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
    [BtnPickr setTitle:@"All   " forState:UIControlStateNormal];
    [BtnPickr setBackgroundImage:[UIImage imageNamed:@"Btn_JobInfo.png"] forState:UIControlStateNormal];
    [BtnPickr.titleLabel setFont:FONT_NEUE_SIZE(14) ];
    [BtnPickr setTitleColor:DEFAULT_FONT_COLOR forState:UIControlStateNormal];
    
    BtnPickr.frame = CGRectMake(7.0, 6.0, 300.0, 29);
    //    BtnPickr.tag = BtnPckr_TAG;
    BtnPickr.backgroundColor = [UIColor clearColor];
    [backView addSubview:BtnPickr];
    
    
    btnCountLabel = [UIButton buttonWithType:UIButtonTypeCustom];
    [btnCountLabel.titleLabel setFont:FONT_NEUE_SIZE(14) ];  
    btnCountLabel.enabled = FALSE;
    [btnCountLabel setBackgroundImage:[UIImage imageNamed:@"Btn_JobInfo.png"] forState:UIControlStateNormal];
    [btnCountLabel setTitleColor:DEFAULT_FONT_COLOR forState:UIControlStateNormal ];
    btnCountLabel.frame = CGRectMake(0 , 41, 320, 41);
    btnCountLabel.backgroundColor = [UIColor clearColor];
    [self.view addSubview:btnCountLabel];
    
    
    //    isTableLoaded = TRUE;
    [self FilterPatrolsJob:All];
    
    //    tblView = [[[UITableView alloc] initWithFrame:CGRectMake(0,41,320,375) style:UITableViewStylePlain]autorelease];
    //    tblView = [[[UITableView alloc] initWithFrame:CGRectMake(0,41,320,[[UIScreen mainScreen] bounds].size.height-105) style:UITableViewStylePlain]autorelease];
    //    [tblView setShowsVerticalScrollIndicator:YES];
    //    [tblView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    //    [tblView setBackgroundColor:[UIColor clearColor]];
    //    tblView.dataSource = self;
    //    tblView.delegate = self;
    //    [self.view addSubview:tblView];
    
    [CommonFunctions setBack:self target:@selector(btnBackTapped:)];
    
    
}

-(IBAction)btnBackTapped:(id)Sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)FilterPatrolsJob:(JobFilterMode )_fltterMode
{
    
    UIView *alertView = [CommonFunctions AlertWithMessage:@"Please wait.."];
    [self.view addSubview:alertView];
    
    NSString *strQuery = @"";
    NSString *currentFilterMode = nil;
    switch (_fltterMode)
    {
        case ThisMorning:
        {
            currentFilterMode = @"ThisMorning";
            strQuery = [NSString stringWithFormat:
                        @"select * from (select jobs.jid,stt,name,jobs.description,CASE WHEN  date(jobs.date_due) < date('now') THEN 'Yes' ELSE 'No' END AS isDue,strftime('%%H',jobs.date_due)||':'||strftime('%%M',jobs.date_due)||'- -'||strftime('%%H',datetime(strftime('%%s',datetime(jobs.date_due) ) + CAST( job_patrol_schedules.duration AS INTEGER)*60,'unixepoch') )||':'||strftime('%%M',datetime(strftime('%%s',datetime(jobs.date_due) )+CAST(job_patrol_schedules.duration AS INTEGER)*60,'unixepoch') ) As TimeRange,jobs.date_due,job_patrol_schedules.duration from jobs  left join job_patrol_schedules on jobs.jid = job_patrol_schedules.jid  where job_type = 'Patrol' and stt LIKE '%In Progress%' and eng_complete ='' UNION  Select TempJobs.jid AS jid,TempJobs.stt AS stt,TempJobs.name as name,TempJobs.Description AS description,TempJobs.COLORFLAG AS isDue,strftime('%%H',TempJobs.StartDateTime)||':'||strftime('%%M',TempJobs.StartDateTime)||'- -'||strftime('%%H',TempJobs.EndDateTime)||':'||strftime('%%M',TempJobs.EndDateTime) As TimeRange, CASE WHEN date(TempJobs.StartDateTime)=date('now') THEN CASE WHEN CAST(strftime('%%H',datetime(TempJobs.StartDateTime)) AS INTEGER) <12 THEN TempJobs.StartDateTime ELSE 0 END ELSE 0 END AS 'date_due',TempJobs.duration AS duration from (select jobs.jid,jobs.stt,jobs.description,job_patrol_schedules.name,job_patrol_schedules.duration,jobs.date_due As StartDateTime , datetime(strftime('%%s',datetime(jobs.date_due) ) + CAST( job_patrol_schedules.duration AS INTEGER)*60,'unixepoch')   As  EndDateTime,CASE  WHEN  date(jobs.date_due) < date('now') THEN 'Yes' ELSE 'No' END AS COLORFLAG from jobs left join job_patrol_schedules on jobs.jid=job_patrol_schedules.jid where jobs.job_type='Patrol' and eng_complete='' and stt NOT LIKE '%In Progress%' )As TempJobs  where date_due!=0 ORDER BY   date_due   ) As FinalTable ORDER BY CASE stt WHEN  'In Progress' THEN 0 ELSE 100 END "];
        }
            break;
            
        case ThisAfternoon:
        {
            currentFilterMode = @"ThisAfternoon";
            strQuery = [NSString stringWithFormat:
                        @"select * from (select jobs.jid,stt,name,jobs.description,CASE WHEN  date(jobs.date_due) < date('now') THEN 'Yes' ELSE 'No' END AS isDue,strftime('%%H',jobs.date_due)||':'||strftime('%%M',jobs.date_due)||'- -'||strftime('%%H',datetime(strftime('%%s',datetime(jobs.date_due) ) + CAST( job_patrol_schedules.duration AS INTEGER)*60,'unixepoch') )||':'||strftime('%%M',datetime(strftime('%%s',datetime(jobs.date_due) ) + CAST(job_patrol_schedules.duration AS INTEGER)*60,'unixepoch') ) As TimeRange,jobs.date_due,job_patrol_schedules.duration from jobs  left join job_patrol_schedules on jobs.jid = job_patrol_schedules.jid  where job_type = 'Patrol' and stt LIKE '%In Progress%' and eng_complete ='' UNION  select TempJobs.jid AS jid,TempJobs.stt AS stt,TempJobs.name as name,TempJobs.Description AS description,TempJobs.COLORFLAG AS isDue,strftime('%%H',TempJobs.StartDateTime)||':'||strftime('%%M',TempJobs.StartDateTime)||'- -'||strftime('%%H',TempJobs.EndDateTime)||':'||strftime('%%M',TempJobs.EndDateTime) As TimeRange,CASE WHEN date('now') = date(TempJobs.StartDateTime) THEN CASE WHEN CAST (strftime('%%H',TempJobs.StartDateTime) AS INTEGER)>=12 THEN TempJobs.StartDateTime ELSE 0 END ELSE 0  END AS 'date_due',TempJobs.duration AS duration from(select jobs.jid,jobs.stt,jobs.description,job_patrol_schedules.name,job_patrol_schedules.duration As Duration,jobs.date_due As StartDateTime , datetime(strftime('%%s',datetime(jobs.date_due) ) + CAST( job_patrol_schedules.duration AS INTEGER)*60,'unixepoch')   As  EndDateTime,CASE WHEN  date(jobs.date_due) < date('now') THEN 'Yes' ELSE 'No' END AS COLORFLAG from jobs left join job_patrol_schedules on jobs.jid=job_patrol_schedules.jid where jobs.job_type='Patrol' and eng_complete=''  and stt NOT LIKE '%In Progress%')As TempJobs  where date_due!=0 ORDER BY   date_due  ) As FinalTable ORDER BY CASE stt WHEN  'In Progress' THEN 0 ELSE 100 END"];
        }
            break;
            
        case Tomorrow:
        {
            currentFilterMode = @"Tomorrow";
            strQuery = [NSString stringWithFormat:
                        @"select * from (select jobs.jid,stt,name,jobs.description,CASE WHEN  date(jobs.date_due) < date('now') THEN 'Yes' ELSE 'No' END AS isDue,strftime('%%H',jobs.date_due)||':'||strftime('%%M',jobs.date_due)||'- -'||strftime('%%H',datetime(strftime('%%s',datetime(jobs.date_due) ) + CAST( job_patrol_schedules.duration AS INTEGER)*60,'unixepoch') )||':'||strftime('%%M',datetime(strftime('%%s',datetime(jobs.date_due) ) +CAST(job_patrol_schedules.duration AS INTEGER)*60,'unixepoch') ) As TimeRange ,jobs.date_due,job_patrol_schedules.duration from jobs  left join job_patrol_schedules on jobs.jid = job_patrol_schedules.jid  where job_type = 'Patrol' and stt LIKE '%In Progress%' and eng_complete ='' UNION select TempJobs.jid  AS jid,TempJobs.stt As stt,TempJobs.name as name,TempJobs.Description as description, TempJobs.COLORFLAG as isDue,strftime('%%H',TempJobs.StartDateTime)||':'||strftime('%%M',TempJobs.StartDateTime)||'- -'||strftime('%%H',TempJobs.EndDateTime)||':'||strftime('%%M',TempJobs.EndDateTime) As TimeRange,TempJobs.StartDateTime  As date_due, duration from (select jobs.jid,jobs.stt,jobs.description,job_patrol_schedules.name,jobs.date_due As StartDateTime,job_patrol_schedules.duration, datetime(strftime('%%s',datetime(jobs.date_due) ) + CAST( job_patrol_schedules.duration AS INTEGER)*60,'unixepoch')   As  EndDateTime, CASE  WHEN  date(jobs.date_due) < date('now') THEN 'Yes' ELSE 'No' END AS COLORFLAG from jobs left join job_patrol_schedules on jobs.jid=job_patrol_schedules.jid where date(date_due) = date('now','1 day') and  jobs.job_type='Patrol' and eng_complete='' and stt NOT LIKE '%In Progress%')As TempJobs order by date_due   ) As FinalTable ORDER BY CASE stt WHEN  'In Progress' THEN 0 ELSE 100 END"];
        }
            break;
            
        case ThisWeek:
        {
            currentFilterMode = @"ThisWeek";
            strQuery = [NSString stringWithFormat:
                        @"select * from (select jobs.jid,stt,name,jobs.description,CASE WHEN  date(jobs.date_due) < date('now') THEN 'Yes' ELSE 'No' END AS isDue,strftime('%%H',jobs.date_due)||':'||strftime('%%M',jobs.date_due)||'- -'||strftime('%%H',datetime(strftime('%%s',datetime(jobs.date_due) ) + CAST( job_patrol_schedules.duration AS INTEGER)*60,'unixepoch') )||':'||strftime('%%M',datetime(strftime('%%s',datetime(jobs.date_due) ) + CAST( job_patrol_schedules.duration AS INTEGER)*60,'unixepoch') ) As TimeRange,jobs.date_due,job_patrol_schedules.duration from jobs  left join job_patrol_schedules on jobs.jid = job_patrol_schedules.jid  where job_type = 'Patrol' and stt LIKE '%In Progress%' and eng_complete ='' UNION select  TempJobs.jid  AS jid,TempJobs.stt As stt,TempJobs.name as name,TempJobs.Description as description, TempJobs.COLORFLAG as isDue,strftime('%%H',TempJobs.StartDateTime)||':'||strftime('%%M',TempJobs.StartDateTime)||'- -'||strftime('%%H',TempJobs.EndDateTime)||':'||strftime('%%M',TempJobs.EndDateTime) As TimeRange,TempJobs.StartDateTime  As date_due, duration from (select jobs.jid,jobs.stt,jobs.description,job_patrol_schedules.name,jobs.date_due As StartDateTime,job_patrol_schedules.duration, datetime(strftime('%%s',datetime(jobs.date_due) ) + CAST( job_patrol_schedules.duration AS INTEGER)*60,'unixepoch')   As  EndDateTime,CASE  WHEN  date(jobs.date_due) < date('now') THEN 'Yes' ELSE 'No' END AS COLORFLAG from jobs left join job_patrol_schedules on jobs.jid=job_patrol_schedules.jid where date(date_due) BETWEEN date('now') and date('now','7 day') and  jobs.job_type='Patrol' and eng_complete='' and stt NOT LIKE '%In Progress%')As TempJobs order by date_due ) As FinalTable ORDER BY CASE stt WHEN  'In Progress' THEN 0 ELSE 100 END"];
        }
            break;
            
        case All:
        {
            currentFilterMode = @"All";
            strQuery = [NSString stringWithFormat:@"select * from  ( select jobs.jid,stt,name,jobs.description,CASE WHEN  date(jobs.date_due) < date('now') THEN 'Yes' ELSE 'No' END AS isDue,strftime('%%H',jobs.date_due)||':'||strftime('%%M',jobs.date_due)||'- -'||strftime('%%H',datetime(strftime('%%s',datetime(jobs.date_due) ) + CAST( job_patrol_schedules.duration AS INTEGER)*60,'unixepoch'))||':'||strftime('%%M',datetime(strftime('%%s',datetime(jobs.date_due))+CAST(job_patrol_schedules.duration AS INTEGER)*60,'unixepoch') ) As TimeRange,jobs.date_due,job_patrol_schedules.duration from jobs  left join job_patrol_schedules on jobs.jid = job_patrol_schedules.jid  where job_type = 'Patrol' and stt LIKE '%In Progress%' and eng_complete =''  UNION select  TempJobs.jid  AS jid,TempJobs.stt As stt,TempJobs.name as name,TempJobs.Description as description, TempJobs.COLORFLAG as isDue,strftime('%%H',TempJobs.StartDateTime)||':'||strftime('%%M',TempJobs.StartDateTime)||'- -'||strftime('%%H',TempJobs.EndDateTime)||':'||strftime('%%M',TempJobs.EndDateTime) As TimeRange,TempJobs.StartDateTime  As date_due, duration from(select jobs.jid,jobs.stt,jobs.description,job_patrol_schedules.name,jobs.date_due As StartDateTime,job_patrol_schedules.duration,datetime(strftime('%%s',datetime(jobs.date_due) ) + CAST( job_patrol_schedules.duration AS INTEGER)*60,'unixepoch')   As  EndDateTime,CASE WHEN  date(jobs.date_due) < date('now') THEN 'Yes' ELSE 'No' END AS COLORFLAG from jobs left join job_patrol_schedules on jobs.jid=job_patrol_schedules.jid where jobs.job_type='Patrol' and eng_complete='' and stt NOT LIKE '%In Progress%' )As TempJobs  order by date_due ) As FinalTable ORDER BY CASE stt WHEN  'In Progress' THEN 0 ELSE 100 END"];
        }
            break;
            
        default:
            
            break;
            
            
    }
    
    if([strQuery length]>0)
    {
        if ((![strPreviousFilterMode isEqualToString:currentFilterMode]) || (strPreviousFilterMode == nil))
        {
            strPreviousFilterMode = currentFilterMode;
            arrPatrolJobs = [DataSource getRecordsFromQuery:strQuery];
            
//            NSLog(@"%@",[[arrPatrolJobs objectAtIndex:0] description]);
//            for(NSMutableDictionary *d in arrPatrolJobs)
//            {
//                [d setObject:@"Thanks for your instant reply.Since , the previously mentioned URL worked before a while but just now it had stopped working .So, I think it was unstable. But now, its working fine with the newly added 'Timestamp' Parameter." forKey:@"description"];
//            }
//            NSLog(@"%@",[[arrPatrolJobs objectAtIndex:0] description]);
            
            btnCountLabel.titleLabel.lineBreakMode = UILineBreakModeWordWrap;
            
            NSString *strTitleContent  = @"";
            if ([arrPatrolJobs count]>0)
            {
                

            strTitleContent = [NSString stringWithFormat: @"You have %d jobs matching the criteria \n Patrol Jobs and %@!",[arrPatrolJobs count],BtnPickr.titleLabel.text];
               
                 [btnCountLabel setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
            }
            else
            {
              
            strTitleContent = [NSString stringWithFormat: @"You currently have no jobs matching the criteria \n Patrol Jobs and %@!",BtnPickr.titleLabel.text];
            [btnCountLabel setTitleColor:[UIColor redColor] forState:UIControlStateNormal];     

            }
                [btnCountLabel setTitle:strTitleContent  forState:UIControlStateNormal];           
            

            
            [tblView removeFromSuperview];
            tblView = nil;
            tblView = [[[UITableView alloc] initWithFrame:CGRectMake(0,41+41,320,[[UIScreen mainScreen] bounds].size.height-105-41) style:UITableViewStylePlain]autorelease];
            [tblView setShowsVerticalScrollIndicator:YES];
            [tblView setSeparatorStyle:UITableViewCellSeparatorStyleSingleLine];
            [tblView setBackgroundColor:[UIColor whiteColor]];
            tblView.dataSource = self;
            tblView.delegate = self;
            [self.view addSubview:tblView];
        }
    }
    
    [alertView removeFromSuperview];
    
}


#pragma mark -
#pragma mark - Table view data source


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

//- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
//{
//    return 10;
//}

//- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section;   // custom view for footer. will be adjusted to default or specified footer height

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    NSMutableDictionary *redDic = [arrPatrolJobs objectAtIndex:indexPath.row ];
    NSString *CellIdentifier = [NSString stringWithFormat:@"Cel_%d",indexPath.row];
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if(cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] ;
        NSString *strStatus = [[arrPatrolJobs objectAtIndex:indexPath.row] objectForKey:JOBS_STT];
        if ([strStatus isEqualToString:@"In Progress"])
            cell = [self getCellForDic:redDic cell:cell andIndexPath:indexPath isBold:YES];
        else
            cell = [self getCellForDic:redDic cell:cell andIndexPath:indexPath isBold:NO];
    }
    return cell;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return arrPatrolJobs.count;
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSMutableDictionary *redDic = [arrPatrolJobs objectAtIndex:indexPath.row ];
    CGSize _size = [[NSString stringWithFormat:@"Description: %@",[redDic objectForKey:JOBS_DESC]] sizeWithFont:FONT_NEUE_SIZE(12) constrainedToSize:CGSizeMake(250,MAXFLOAT) lineBreakMode:UILineBreakModeWordWrap];
    
    
    return 38.0f+_size.height;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    
//    NSString *strStatus = [[arrPatrolJobs objectAtIndex:indexPath.row] objectForKey:JOBS_STT];
    NSString *strJid = [[arrPatrolJobs objectAtIndex:indexPath.row] objectForKey:JOBS_ID];
   NSString *strTimeRange =  [[arrPatrolJobs objectAtIndex:indexPath.row] objectForKey:@"TimeRange"];
//    if([strStatus isEqualToString:@"In Progress"])
    {
        PatrolPointsScreen* objNav=[[PatrolPointsScreen alloc] initWithNibName:@"PatrolPointsScreen" bundle:nil];
        objNav.strJid = strJid;
        objNav.strTimeRange = strTimeRange;               
        [self.navigationController pushViewController:objNav animated:YES];
        [objNav release];
    }
//    else
//    {
//        PatrolsInfoScreen* objNav=[[PatrolsInfoScreen alloc] initWithNibName:@"PatrolsInfoScreen" bundle:nil];
//        objNav.strJid = strJid;
//        [self.navigationController pushViewController:objNav animated:YES];
//        [objNav release];
//    }
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}


-(UITableViewCell *)getCellForDic:(NSMutableDictionary *)redDic cell:(UITableViewCell *)cell andIndexPath:(NSIndexPath *)indexPath isBold:(BOOL)isBold
{
    
    cell.selectionStyle = UITableViewCellSelectionStyleBlue;
    
    //        CGSize _size = [[NSString stringWithFormat:@"Description: %@",[redDic objectForKey:JOBS_DESC]] sizeWithFont:FONT_NEUE_SIZE(12) constrainedToSize:CGSizeMake(250,MAXFLOAT) lineBreakMode:UILineBreakModeWordWrap];
    
    
    //    UIImageView *imgView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 320, 38.0f+_size.height)];
    //    CGRect cellRect = [tblView rectForRowAtIndexPath:indexPath];
    //    UIImage *imgBg = nil;
    
    //    if(!isBold)
    //    {
    //     imgBg = [UIImage imageNamed:@"Cell_Stripe.png"];
    //      if (cellRect.size.height >imgBg.size.height)
    //        imgBg = [imgBg stretchableImageWithLeftCapWidth:imgBg.size.width/2 topCapHeight: (cellRect.size.height - imgBg.size.height)];
    //    }
    //    else
    //    {
    //        imgBg = [UIImage imageNamed:@"Cell_Stripe_Sel.png"];
    //        if (cellRect.size.height >imgBg.size.height)
    //        imgBg = [imgBg stretchableImageWithLeftCapWidth:imgBg.size.width/2 topCapHeight: (cellRect.size.height - imgBg.size.height)+5];
    //    }
    //    [imgView setImage:imgBg];
    //
    //    [cell.contentView addSubview:imgView];
    
    
    
    UILabel *lblId = [[UILabel alloc]initWithFrame:CGRectMake(10, 8.5, 35+50, 14)];
    lblId.backgroundColor = [UIColor clearColor];
    [lblId setFont:FONT_NEUE_BOLD_SIZE(12) ];
    [lblId setTextColor:DEFAULT_FONT_COLOR];
    lblId.text = [redDic objectForKey:JOBS_ID];
    [cell.contentView addSubview:lblId];
    [lblId release];
    
    UILabel *lblStatus = [[UILabel alloc] initWithFrame:CGRectMake(46+50, 8.5, 275, 14)];
    lblStatus.backgroundColor = [UIColor clearColor];
    lblStatus.numberOfLines = 0;
    [lblStatus setFont:FONT_NEUE_BOLD_SIZE(12) ];
    [lblStatus setTextColor:DEFAULT_FONT_COLOR];
    lblStatus.text = [redDic objectForKey:JOBS_STT];
    [cell.contentView addSubview:lblStatus];
    [lblStatus release];
    
    UILabel *lblPatrolName = [[UILabel alloc] initWithFrame:CGRectMake(10, 23.5, 250, 14)];
    lblPatrolName.backgroundColor = [UIColor clearColor];
    lblPatrolName.numberOfLines = 0;
    [lblPatrolName setFont:FONT_NEUE_SIZE(12) ];
    [lblPatrolName setTextColor:DEFAULT_FONT_COLOR];
    lblPatrolName.text = [NSString stringWithFormat:@"Name : %@",[redDic objectForKey:@"name"]];
    [cell.contentView addSubview:lblPatrolName];
    [lblPatrolName release];
    
    UILabel *lblPatrolDesc = [[UILabel alloc] initWithFrame:CGRectMake(10, 38.5, 250,0)];
    lblPatrolDesc.backgroundColor = [UIColor clearColor];
    [lblPatrolDesc setFont:FONT_NEUE_SIZE(12) ];
    [lblPatrolDesc setTextColor:DEFAULT_FONT_COLOR];
    lblPatrolDesc.numberOfLines = 0;
    [lblPatrolDesc setLineBreakMode:UILineBreakModeWordWrap];
    lblPatrolDesc.text = [NSString stringWithFormat:@"Description: %@",[redDic objectForKey:JOBS_DESC]];
    [cell.contentView addSubview:lblPatrolDesc];
    [lblPatrolDesc sizeToFit];
    [lblPatrolDesc release];
    
    UILabel *lblTime = [[UILabel alloc] initWithFrame:CGRectMake(250, 0, 42.5, 61)];
    lblTime.backgroundColor = [UIColor clearColor];
    lblTime.numberOfLines = 0;
    [lblTime setFont:FONT_NEUE_BOLD_SIZE(12) ];
    
    if([[redDic objectForKey:@"isDue"] isEqualToString:@"Yes"])
    {
        [lblTime setTextColor:[UIColor redColor]];
        
    }else {
        [lblTime setTextColor:DEFAULT_FONT_COLOR];
        
    }
    
    
    lblTime.text =[redDic objectForKey:@"TimeRange"];
    [cell.contentView addSubview:lblTime];
    [lblTime release];
    
    //    UIView *selectedView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 61)];
    //    [selectedView setBackgroundColor:getImageColor(@"Cell_Stripe_Sel.png")];
    //    [cell setSelectedBackgroundView:selectedView];
    
    return cell;
}


#pragma mark -
#pragma mark - OpenPicker Method

-(IBAction)OpenPicker:(id)sender{
    
    PickerViewControl *objPicker = [[PickerViewControl alloc] initWithFrame:[self.view frame]];
    
    NSLog(@"%@",[arrPickerData description]);
    
    objPicker.arrPickerData = arrPickerData;
    objPicker.selectedIndex=lastSelectedIndex;
    objPicker._delegate=self;
    
    [objPicker setPicker];
    
    [self.view addSubview:objPicker];
}

-(void)pickerCloseWithTag:(int)tag
{
    NSLog(@"PickerClosed:");
    if(lastSelectedIndex == 0)
    {
        [self FilterPatrolsJob:All];
    }else if(lastSelectedIndex == 1)
    {
        [self FilterPatrolsJob:ThisMorning];
    }
    else if(lastSelectedIndex == 2)
    {
        [self FilterPatrolsJob:ThisAfternoon];
    }
    else if(lastSelectedIndex == 3)
    {
        [self FilterPatrolsJob:Tomorrow];
    }
    else if(lastSelectedIndex == 4)
    {
        [self FilterPatrolsJob:ThisWeek];
    }
}

-(void)selectedRow:(int)row andValue:(NSString *)strVal andTag:(int)tag selectedRow:(int)selRow
{
    
    lastSelectedIndex = selRow;
    // arrPickerData = [[NSMutableArray alloc]initWithObjects:@"This Morning ",@"This Afternoon  ",@"Tomorrow  ",@"This Week  ",@"All  ", nil];
    
    //    if(selRow == 0)
    //    {
    //        [self FilterPatrolsJob:All];
    //    }else if(selRow == 1)
    //    {
    //        [self FilterPatrolsJob:ThisMorning];
    //    }
    //    else if(selRow == 2)
    //    {
    //        [self FilterPatrolsJob:ThisAfternoon];
    //    }
    //    else if(selRow == 3)
    //    {
    //        [self FilterPatrolsJob:Tomorrow];
    //    }
    //    else if(selRow == 4)
    //    {
    //        [self FilterPatrolsJob:ThisWeek];
    //    }
    
    [BtnPickr setTitle:strVal forState:UIControlStateNormal];
    
    // NSLog(@"%@",strVal);
    
}

#pragma mark -
#pragma mark pickerView delegate
-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 1;
}

-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
	
    return  [arrPickerData count];
}
-(NSString *) pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    
    return  [arrPickerData objectAtIndex:row];
    
    
}
-(void) pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    NSString *pck_title = [arrPickerData objectAtIndex:row];
    [BtnPickr setTitle:pck_title forState:UIControlStateNormal];
    
}

-(void)viewWillDisappear:(BOOL)animated
{
    //    isTableLoaded = FALSE;
    strPreviousFilterMode = nil;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    tblView = nil;
    strPreviousFilterMode = nil;
    //    isTableLoaded = FALSE;
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
