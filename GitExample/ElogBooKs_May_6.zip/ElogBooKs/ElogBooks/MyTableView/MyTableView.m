//
//  MyTableView.m
//  Paytrieval
//
//  Created by i-Verve on 01/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "MyTableView.h"

#define ANIM_DURATION 0.3
#define SEC_TAG 4545
#define ROW_TAG 6767


@implementation MyTableView

@synthesize _tblDelegate;
@synthesize Seperator,heightOfSeperator;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        
        _selfFrame = frame;
        
        self.showsVerticalScrollIndicator = NO;
        self.showsHorizontalScrollIndicator = NO;
        
        // Set Default Value here,,    
        Seperator = YES;
        heightOfSeperator=1;
        // Initialization code
    }
    return self;
}

NSComparisonResult compareViews(id firstView, id secondView, void *context) { 
    int firstTag = [firstView tag];
    int secondTag = [secondView tag];
    
    if (firstTag == secondTag) {
        return NSOrderedSame;
    } else {
        if (firstTag < secondTag) {
            return NSOrderedAscending;
        } else { 
            return NSOrderedDescending;
        }
    }
}


-(void)removeRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    CGContextRef context = UIGraphicsGetCurrentContext();
	[UIView beginAnimations:nil context:context];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
	[UIView setAnimationDuration:ANIM_DURATION];
    
    //    [UIView commitAnimations];
    
    int _row = indexPath.row;
    int _sec = indexPath.section;
    
    float _height = [_tblDelegate heightCell_forRow:indexPath.row andSection:indexPath.section];
    
    UIView *currentSectionView = [self viewWithTag:SEC_TAG + _sec];
    
    NSArray *arrRowView = [currentSectionView subviews];    
    
    NSLog(@"\n%@",[arrRowView description]);
    
    arrRowView = [arrRowView sortedArrayUsingFunction:(NSComparisonResult (*)(id, id, void*))compareViews context:nil];
    
    NSLog(@"\n%@",[arrRowView description]);
    
    [[arrRowView objectAtIndex:_row] removeFromSuperview];
    
    for(int curRow = _row ; curRow < [arrRowView count]; curRow ++)
    {
        UIView *rowView = [arrRowView objectAtIndex:curRow];
        
        NSLog(@" First :%@",[rowView description]);
        
        int curTag = [rowView tag];
        [rowView setTag:curTag + 1];
        
        CGRect _newFrame = [rowView frame];
        _newFrame.origin.y = _newFrame.origin.y - _height;
        
        [rowView setFrame:_newFrame];
        
        
        NSLog(@" After :%@",[rowView description]);
    }
    
    
    CGRect _newFrame = [currentSectionView frame];
    _newFrame.size.height = _newFrame.size.height - _height;
    
    [currentSectionView setFrame:_newFrame];
    
    NSArray *arrSecView = [self subviews];
    
    arrSecView = [arrSecView sortedArrayUsingFunction:(NSComparisonResult (*)(id, id, void*))compareViews context:nil];
    
    for(int curSec = _sec+1; curSec < [arrSecView count]; curSec ++)
    {
        UIView *secView = [arrSecView objectAtIndex:curSec];
        
        NSLog(@"%@",[secView description]);
        
        CGRect _newFrame = [secView frame];
        _newFrame.origin.y = _newFrame.origin.y - _height;
        
        [secView setFrame:_newFrame];
    }
    
    CGSize _cSize = [self contentSize];
    
    [self setContentSize:CGSizeMake(_cSize.width, _cSize.height - _height)];
    
    [UIView commitAnimations];
    
    
}
-(void)insertRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    //    [UIView commitAnimations];
    
    int _row = indexPath.row;
    int _sec = indexPath.section;
    
    float _height = [_tblDelegate heightCell_forRow:indexPath.row andSection:indexPath.section];
    
    UIView *currentSectionView = [self viewWithTag:SEC_TAG + _sec];
    
    NSArray *arrRowView = [currentSectionView subviews];    
    
   // NSLog(@"\n%@",[arrRowView description]);
    
    arrRowView = [arrRowView sortedArrayUsingFunction:(NSComparisonResult (*)(id, id, void*))compareViews context:nil];
    
  //  NSLog(@"\n%@",[arrRowView description]);
    
    if([arrRowView count] > _row)
    {
        
        CGRect _frame = [[arrRowView objectAtIndex:_row ] frame];
        UIView *rowView = [[UIView alloc] initWithFrame:CGRectMake(0, _frame.origin.y, _selfFrame.size.width, _height)];
        [rowView setTag:ROW_TAG+_row];
        
        NSIndexPath *curIndPath = [NSIndexPath indexPathForRow:_row inSection:_sec];
        
        rowView = [_tblDelegate currentRow:rowView forIndexPath:curIndPath];
        
        
        
        CGContextRef context = UIGraphicsGetCurrentContext();
        [UIView beginAnimations:nil context:context];
        [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
        [UIView setAnimationDuration:ANIM_DURATION];
        
        [currentSectionView addSubview:rowView];
        //[currentSectionView insertSubview:rowView atIndex:_row];
        
        float _rowY = _frame.origin.y+_height;
        
        if(Seperator)
        {
            UILabel *lblSep = [[UILabel alloc] initWithFrame:CGRectMake(0, _rowY + _height, _selfFrame.size.width, heightOfSeperator)];
            [lblSep setBackgroundColor:[UIColor blackColor]];
            //[currentSectionView addSubview:lblSep];
            
            _rowY = _rowY+heightOfSeperator;
        }
        
        
        [currentSectionView addSubview:rowView];
        
    }
    
    for(int curRow = _row ; curRow < [arrRowView count]; curRow ++)
    {
        UIView *rowView = [arrRowView objectAtIndex:curRow];
        
       // NSLog(@" First :%@",[rowView description]);
        
        int curTag = [rowView tag];
        [rowView setTag:curTag + 1];
        
        CGRect _newFrame = [rowView frame];
        _newFrame.origin.y = _newFrame.origin.y + _height;
        
        [rowView setFrame:_newFrame];
        
        
       // NSLog(@" After :%@",[rowView description]);
    }
    
    
    CGRect _newFrame = [currentSectionView frame];
    _newFrame.size.height = _newFrame.size.height + _height;
    
    [currentSectionView setFrame:_newFrame];
    
    NSArray *arrSecView = [self subviews];
    
    arrSecView = [arrSecView sortedArrayUsingFunction:(NSComparisonResult (*)(id, id, void*))compareViews context:nil];

    
    for(int curSec = _sec+1; curSec < [arrSecView count]; curSec ++)
    {
        UIView *secView = [arrSecView objectAtIndex:curSec];
        
        //NSLog(@"%@",[secView description]);
        
        CGRect _newFrame = [secView frame];
        _newFrame.origin.y = _newFrame.origin.y + _height;
        
        [secView setFrame:_newFrame];
    }
    
    CGSize _cSize = [self contentSize];
    
    [self setContentSize:CGSizeMake(_cSize.width, _cSize.height + _height)];
    
    
    //    NSLog(@"%@",[arrRowView description]);
    //    NSLog(@"%@",[[currentSectionView subviews] description]);
    [UIView commitAnimations];
    
    
}


-(void)insertSection_at:(int)_sec
{

    section = [_tblDelegate numberOfSection];
    NSArray *arrSecView = [self subviews];
    
    NSLog(@"%@",[arrSecView description]);
    
    arrSecView = [arrSecView sortedArrayUsingFunction:(NSComparisonResult (*)(id, id, void*))compareViews context:nil];

        NSLog(@"%@",[arrSecView description]);
    
    if(_sec < section)
    {
        
        UIView *currentSectionView = [[UIView alloc] init];
        [currentSectionView setTag:SEC_TAG+_sec];
        
        int _rowY=0;
        
        NSInteger rowInSec = [_tblDelegate numberOfRowInSection:_sec];
        
        for(int _row=0; _row<rowInSec; _row++)
        {
            
            float _height = [_tblDelegate heightCell_forRow:_row andSection:_sec];
            
            UIView *rowView = [[UIView alloc] initWithFrame:CGRectMake(0, _rowY, _selfFrame.size.width, _height)];
            [rowView setTag:ROW_TAG+_row];
            
            
            NSIndexPath *curIndPath = [NSIndexPath indexPathForRow:_row inSection:_sec];
            
            rowView = [_tblDelegate currentRow:rowView forIndexPath:curIndPath];
            

            
            [currentSectionView addSubview:rowView];
            
            [UIView commitAnimations];

            _rowY = _rowY+_height;
            
            if(Seperator)
            {
                UILabel *lblSep = [[UILabel alloc] initWithFrame:CGRectMake(0, _rowY + _height, _selfFrame.size.width, heightOfSeperator)];
                [lblSep setBackgroundColor:[UIColor blackColor]];
                // [currentSectionView addSubview:lblSep];
                
                _rowY = _rowY+heightOfSeperator;
            }

        }
        
        
        CGRect _lastFrame = [[arrSecView objectAtIndex:_sec ] frame];
        
        float _secY= _lastFrame.origin.y  ;
        
        
        [currentSectionView setFrame:CGRectMake(0, _secY, 320, _rowY)];
        
        [self addSubview:currentSectionView];
        
        
        CGRect _visibleRect = [currentSectionView frame];
        
        float _height = currentSectionView.frame.size.height;
        
        for(int curSec = _sec; curSec < [arrSecView count]; curSec ++)
        {
            UIView *secView = [arrSecView objectAtIndex:curSec];
            
            [secView setTag:SEC_TAG + curSec + 1];
            
            NSLog(@"%@",[secView description]);
            
            CGRect _newFrame = [secView frame];
            _newFrame.origin.y = _newFrame.origin.y + _height;
            
            _visibleRect.size.height += _newFrame.size.height ;
            
            [secView setFrame:_newFrame];
        }
        
        
        arrSecView = [self subviews];

        NSLog(@"%@",[arrSecView description]);
        
        arrSecView = [arrSecView sortedArrayUsingFunction:(NSComparisonResult (*)(id, id, void*))compareViews context:nil];
        
        NSLog(@"%@",[arrSecView description]);

        CGSize _cSize = [self contentSize];
        
        [self setContentSize:CGSizeMake(_cSize.width, _cSize.height + _height)];
        
        [self scrollRectToVisible:_visibleRect animated:YES];
        
    }
 

}

-(void)removeSection_at:(int)_sec
{

    section = [_tblDelegate numberOfSection];
    NSArray *arrSecView = [self subviews];
    
    NSLog(@"%@",[arrSecView description]);
    
    arrSecView = [arrSecView sortedArrayUsingFunction:(NSComparisonResult (*)(id, id, void*))compareViews context:nil];
    
    NSLog(@"%@",[arrSecView description]);
    
    if(_sec < section)
    {
        
        UIView *currentSectionView = [arrSecView objectAtIndex:_sec];
        
        [currentSectionView setTag:SEC_TAG+_sec];
        
        float _height = currentSectionView.frame.size.height;

        CGRect _visibleRect = [currentSectionView frame];

        CGContextRef context = UIGraphicsGetCurrentContext();
        [UIView beginAnimations:nil context:context];
        [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
        [UIView setAnimationDuration:ANIM_DURATION];
        

        [currentSectionView removeFromSuperview];
        

        for(int curSec = _sec; curSec < [arrSecView count]; curSec ++)
        {
            UIView *secView = [arrSecView objectAtIndex:curSec];
            
            [secView setTag:SEC_TAG + curSec + 1];
            
            NSLog(@"%@",[secView description]);
            
            CGRect _newFrame = [secView frame];
            _newFrame.origin.y = _newFrame.origin.y - _height;
            
            [secView setFrame:_newFrame];
            
        }
        
        
        arrSecView = [self subviews];
        
        NSLog(@"%@",[arrSecView description]);
        
        arrSecView = [arrSecView sortedArrayUsingFunction:(NSComparisonResult (*)(id, id, void*))compareViews context:nil];
        
        NSLog(@"%@",[arrSecView description]);
        
        CGSize _cSize = [self contentSize];
        
        [self setContentSize:CGSizeMake(_cSize.width, _cSize.height - _height)];
        
        [self scrollRectToVisible:_visibleRect animated:YES];
        
        [UIView commitAnimations];

    }

    
    
}
-(void)reloadAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    
}


-(UIView *)getView_FromIndexPath:(NSIndexPath *)indexPath
{
    
    UIView *currentSectionView = [self viewWithTag:SEC_TAG + indexPath.section];
    
    NSArray *arrRowView = [currentSectionView subviews];    
    
    arrRowView = [arrRowView sortedArrayUsingFunction:(NSComparisonResult (*)(id, id, void*))compareViews context:nil];
    
    return [arrRowView objectAtIndex:indexPath.row];
    
}

-(void)reloadAllTable
{
    
    
    
    section = [_tblDelegate numberOfSection];
    
    int _secY = 0 ;
    
    
    
    for(int _sec=0; _sec<section; _sec++)
    {
        
        int _rowY=0;
        
        UIView *currentSectionView = [[UIView alloc] init];
        [currentSectionView setTag:SEC_TAG+_sec];
        
        NSInteger rowInSec = [_tblDelegate numberOfRowInSection:_sec];
        
        for(int _row=0; _row<rowInSec; _row++)
        {
            
            float _height = [_tblDelegate heightCell_forRow:_row andSection:_sec];
            
            UIView *rowView = [[UIView alloc] initWithFrame:CGRectMake(0, _rowY, _selfFrame.size.width, _height)];
            [rowView setTag:ROW_TAG+_row];
            
            
            NSIndexPath *curIndPath = [NSIndexPath indexPathForRow:_row inSection:_sec];
            
            rowView = [_tblDelegate currentRow:rowView forIndexPath:curIndPath];
            
            [currentSectionView addSubview:rowView];
            
            _rowY = _rowY+_height;
            
            if(Seperator)
            {
                UILabel *lblSep = [[UILabel alloc] initWithFrame:CGRectMake(0, _rowY + _height, _selfFrame.size.width, heightOfSeperator)];
                [lblSep setBackgroundColor:[UIColor blackColor]];
                _rowY = _rowY+heightOfSeperator;
            }
            
            [currentSectionView setFrame:CGRectMake(0, _secY, 320, _rowY)];
            
            
        }
        
          [self addSubview:currentSectionView];
        
        
        _secY = _secY + _rowY ;
        
    }
    
    
    [self setContentSize:CGSizeMake(320, _secY)];
    
    
}


-(void)upKeyboard:(id)sender
{
    
    UIView *superView=[sender superview];
     CGRect _visableRect = [[superView superview] frame];
   // _visableRect.origin.y +=215;
         [self scrollRectToVisible:_visableRect animated:NO];
  
    [self setFrame:CGRectMake(0, 0, 320, 215)];
    
}


-(void)upKeyboardAtIndexPath:(NSIndexPath *)indexPath;
{

    CGContextRef context = UIGraphicsGetCurrentContext();
    [UIView beginAnimations:nil context:context];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationDuration:ANIM_DURATION];


    UIView *currentRow = [self getView_FromIndexPath:indexPath];
    
    CGRect _newFrame = _selfFrame;
    _newFrame.size.height = 200;
    [self setFrame:_newFrame];
    [UIView commitAnimations];
    CGRect _rFrame = [currentRow frame];
    CGRect _sFrame = [[currentRow superview] frame];
    
    CGRect _visableRect = _rFrame;
    
    _rFrame.origin.y = _rFrame.origin.y + _sFrame.origin.y;
    [currentRow convertRect:[currentRow frame] fromView:self];

//    CGRect _visableRect = [[currentRow superview] frame];
   
    [self scrollRectToVisible:_visableRect animated:YES];
    
    [UIView commitAnimations];

}

-(void)downKeyboard
{
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    [UIView beginAnimations:nil context:context];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationDuration:ANIM_DURATION];

    CGRect _newFrame = _selfFrame;
    [self setFrame:_newFrame];
    
   [UIView commitAnimations];
}



@end
