//
//  MyTableView.h
//  Paytrieval
//
//  Created by i-Verve on 01/11/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol MyTableViewDelegate

-(int)numberOfSection;
-(int)numberOfRowInSection:(int)Section;

-(float)heightCell_forRow:(int)row andSection:(int)section;
//-(UIView *)currentRow:(UIView *)cellRow forRow:(int)row andSection:(int)section;
-(UIView *)currentRow:(UIView *)contentView forIndexPath:(NSIndexPath *)indexPath;



@optional



@end

@interface MyTableView : UIScrollView
{

    id<MyTableViewDelegate> _tblDelegate;

    NSInteger section;
    
    CGRect _selfFrame;
    
}

@property (nonatomic, assign) id<MyTableViewDelegate> _tblDelegate;
@property (nonatomic, assign) BOOL Seperator;
@property (nonatomic, assign) int heightOfSeperator;


-(void)upKeyboardAtIndexPath:(NSIndexPath *)indexPath;
-(void)downKeyboard;
-(void)upKeyboard:(id)sender;

-(void)reloadAllTable;

-(void)insertRowAtIndexPath:(NSIndexPath *)indexPath;
-(void)removeRowAtIndexPath:(NSIndexPath *)indexPath;

-(void)insertSection_at:(int)_sec;
-(void)removeSection_at:(int)_sec;

-(UIView *)getView_FromIndexPath:(NSIndexPath *)indexPath;

-(void)reloadAtIndexPath:(NSIndexPath *)indexPath;



@end
