//
//  RefreshDatabase.h
//  ElogBooks
//
//  Created by nayan mistry on 10/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol RefreshDatabaseDelegate

@optional
-(void)DataInserted;
-(void)TaskAborted;
-(void)setProgress:(float)val forFlag:(NSString *)strFlag;
@end


@interface RefreshDatabase : NSObject<MYXMLParserDelegate>
{
 
    id<RefreshDatabaseDelegate> _delegate;

    //Webservice Delegates
    getWebService *objService;
    
    NSMutableArray *arrWebservicelist;
    NSMutableDictionary *dicCurrentWebserviceData;
    
    BOOL isPUT_INFO_Completed;
    DataSource *dataObj;
    int initialcountValue;
}

@property (nonatomic, assign) id<RefreshDatabaseDelegate> _delegate;;
@property (nonatomic,retain )NSString *IsExecutingBackground;
           

-(void)refreshDataBase:(NSString *)strStatus;
//+(NSString *)getUniqueColumnName:(NSString *)TableName;
@end
