//
//  RefreshDatabase.m
//  ElogBooks
//
//  Created by nayan mistry on 10/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import "RefreshDatabase.h"
#define IS_PARTIAL @"partial"
#define IS_COMPLETE @"complete"

@implementation RefreshDatabase

@synthesize _delegate,IsExecutingBackground;

-(BOOL)isNetworkAvailable
{
    Reachability *internetReach;
    internetReach = [Reachability reachabilityForInternetConnection];
    [internetReach startNotifier];
    NetworkStatus netStatus = [internetReach currentReachabilityStatus];
    [internetReach stopNotifier];
    if(netStatus == NotReachable) 
    { 
        NSLog(@"Network Unavailable");
        return NO;
    }
    else
        return YES;
    
}

-(void)refreshDataBase:(NSString *)strStatus
{
    //static
    //    arrTableNames = [[NSMutableArray alloc]init];
    //    NSMutableDictionary *dic = [[NSMutableDictionary alloc]init];
    //    [dic setObject:@"Customers" forKey:WEB_SERVICE_TABLENAME];
    //    [dic setObject:@"Customers" forKey:PARENT_NODE];
    //    [dic setObject:@"Customer" forKey:CHILD_NODE];
    //    [arrTableNames addObject:dic];
    
    if([self isNetworkAvailable]) //check internet connection
    {
        if ([strStatus isEqualToString:@"START"])
        {
            
            
            arrWebservicelist =  [CommonFunctions getWebservicesArray];
            initialcountValue = [arrWebservicelist count];
            [_delegate setProgress:0.0f forFlag:@"Downloading Data"];

            
            //For background Partial and Completed download
            if (IsExecutingBackground == @"YES")
            {
                //select Previous_TimeStamp from Upload_Info
                NSString *StrPreviousTimeStamp = [DataSource getStringFromQuery:@"select Previous_TimeStamp from Upload_Info"];
                
                if (!([StrPreviousTimeStamp isEqualToString:@"NO_DATA"]))
                {
                    //Partial Parameters
                    NSMutableDictionary *dicPartialJobs = [arrWebservicelist objectAtIndex:0];
                    [dicPartialJobs setObject:StrPreviousTimeStamp forKey:IS_PARTIAL];
                    
                    //Complete Parameters
                    NSMutableDictionary *dicCompleteJobs = [[NSMutableDictionary alloc]initWithDictionary:[arrWebservicelist objectAtIndex:0]]; 
                    [dicCompleteJobs removeObjectForKey:IS_PARTIAL];
                    [dicCompleteJobs setObject:StrPreviousTimeStamp forKey:IS_COMPLETE];
                    [arrWebservicelist insertObject:dicCompleteJobs atIndex:1]; 
                }
                
                IsExecutingBackground = nil;
            }
            else 
            {
                //Main thread download  set timestamp
                [DataSource executeQuery:[NSString stringWithFormat:@"Update Upload_Info set Previous_TimeStamp ='%@' where rowid = 1",[CommonFunctions getCurrentTimeStamp]]];
            }
            
        }
        
        dicCurrentWebserviceData = [arrWebservicelist objectAtIndex:0];


        

        
        objService=[[getWebService alloc] init];
        objService._delegate=self;
        
        [objService setDontShowAlert:YES];
        
               //set Parameters
        
        //Get C0-ordinates
        CLLocationCoordinate2D coordinate = [CommonFunctions GetCoordinates];
        
        NSMutableDictionary *dicc=[[[NSMutableDictionary alloc] init]autorelease];
        [dicc setObject:@"Get" forKey:@"01:qd"];
        [dicc setObject:[ElogBooksAppDelegate getValueForKey:USER_ID] forKey:@"02:uid"];
        [dicc setObject:[dicCurrentWebserviceData  valueForKey:WEB_SERVICE_TABLENAME] forKey:@"03:DataTable"];
        

        
        //add co-ordinates
        [dicc setObject:[NSString stringWithFormat:@"%f",coordinate.latitude] forKey:@"04:lat"];
        [dicc setObject:[NSString stringWithFormat:@"%f",coordinate.longitude]forKey:@"05:lon"];
        
        /*: http://code.elogbooks.co.uk/users/jack/WOM/api/get-info.php?qd=Get&uid=378&DataTable=jobs&updated=28/03/2013
         Partial Example 2: http://code.elogbooks.co.uk/users/jack/WOM/api/get-info.php?qd=Get&uid=378&DataTable=jobs&updated=01/04/2013%2006:00:00
         */
        //Update Upload_Info set Current_TimeStamp = '17/04/2013 03:07:44'  where rowid = 1
        if ([dicCurrentWebserviceData valueForKey:IS_PARTIAL]!=nil) // Partial download
        {
            [dicc setObject:[dicCurrentWebserviceData valueForKey:IS_PARTIAL]  forKey:@"06:updated"];
        }
        else if ([dicCurrentWebserviceData valueForKey:IS_COMPLETE]!=nil) // Complete download
        {
            //complete sample URL
            /*  http://code.elogbooks.co.uk/users/jack/WOM/api/get-info.php?qd=Get&uid=378&DataTable=jobs&complete=1*/
            
            [dicc setObject:[dicCurrentWebserviceData valueForKey:IS_COMPLETE]  forKey:@"06:updated"];
            [dicc setObject:@"1" forKey:@"07:complete"];
            
        }
        
        
        objService.argsDic=dicc;
        
        //webservice name
        objService.strWebService=[dicCurrentWebserviceData valueForKey:WEB_SERVICE_TABLENAME];
        
        //http://code.elogbooks.co.uk/users/jack/WOM/api/get-info.php?qd=Get&uid=38&DataTable=Job_materials
        //Get info URL
        NSString *strurl = [NSString stringWithFormat:@"%@%@",[ElogBooksAppDelegate getValueForKey:BASE_URL],GET_INFO_API];
        //set nodes
        objService.strUrl= strurl;
        objService.strParent= [dicCurrentWebserviceData valueForKey:PARENT_NODE];
        objService.strSubParent=[dicCurrentWebserviceData valueForKey:CHILD_NODE];
        
        [objService performSelector:@selector(setArray) withObject:nil afterDelay:0.1];
        //        }
    }
    else 
    {
        NSLog(@"Problem in insertion and deletion");
        [_delegate TaskAborted];
    }
    
}
#pragma mark Parameterize Dictionary
-(NSMutableDictionary *)getDicAsParameter:(NSMutableDictionary *)dicWithExistingKeys
{
    NSMutableDictionary *dicForParsing = dicWithExistingKeys;
    NSArray *arrkeys = [dicForParsing allKeys];
    for (int i =0; i < [arrkeys count];i++)
    {
        [dicForParsing setObject:[dicForParsing objectForKey:[arrkeys objectAtIndex:i]] forKey:[NSString stringWithFormat:@"%d:%@",i,[arrkeys objectAtIndex:i]]];
        [dicForParsing removeObjectForKey:[arrkeys objectAtIndex:i]];
        
    }
    return dicForParsing;
}


#pragma mark -  My WebService Delegate ....

-(void)filedWithError:(NSString *)strMsg forFlage:(NSString *)flage
{

    if (dicCurrentWebserviceData!=nil)
    {
        NSLog(@"Problem in %@ insertion %@",flage,[dicCurrentWebserviceData description]);
        
        if ([arrWebservicelist count]>0)
        {
            
            [arrWebservicelist removeObjectIdenticalTo:dicCurrentWebserviceData]; //remove current value from array
            
            if ([arrWebservicelist count]>0)
            {
                //Set Progress View
                float progressvalue = [[NSNumber numberWithInt:(initialcountValue-[arrWebservicelist count])]floatValue]/[[NSNumber numberWithInt:initialcountValue]floatValue];
                
                progressvalue = progressvalue*100;
                
                
                [_delegate setProgress:progressvalue forFlag:@"Downloading Data"];
                
                
                [self refreshDataBase:@"CONTINUE"];
            }
            else
            {  //All tables inserted 
                UIAlertView *alert=[[[UIAlertView alloc] initWithTitle:APP_TITLE message:strMsg delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil]autorelease];
               [alert show];
                [_delegate TaskAborted]; 
            }
        }
        else 
        {
            UIAlertView *alert=[[[UIAlertView alloc] initWithTitle:APP_TITLE message:strMsg delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil]autorelease];
            [alert show];
            NSLog(@"Problem in insertion and deletion");
            [_delegate TaskAborted];           
        }
    }
    else 
    {
        UIAlertView *alert=[[[UIAlertView alloc] initWithTitle:APP_TITLE message:strMsg delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil]autorelease];
        [alert show];
    [_delegate TaskAborted]; 
    }
//	[objService release];
}

-(void)EndParsing:(NSMutableArray *)arrData forFlage:(NSString *)flage
{
    //    NSLog(@"\n \n %@ : %@",flage,arrData);
    if ([arrData count]>0)
    {
        
//Testing Purpose        
//        if([flage isEqualToString:TBL_SERVICE_ROUTINE])
//        {
//            NSLog(@"Please stop ...");
//        }
        
        NSLog(@"Deleting %@ values..",flage);
        if (([flage isEqualToString:TBL_JOBPATROLSCHEDULEPOINTS]) || ([flage isEqualToString:TBL_JOB_GROUPS ])|| ([flage isEqualToString:TBL_JOB_GROUP_PRIORITIES])|| ([flage isEqualToString:TBL_CUST_PRIORITIES])|| ([flage isEqualToString:TBL_SERVICE])|| ([flage isEqualToString:TBL_CUST_SERVICES]) || ([flage isEqualToString:TBL_ENG_SERVICES]))
        [DataSource executeQuery:[NSString stringWithFormat:@"delete from %@",flage]];    
         else    
        [DataSource deleteArray:arrData toTable:flage CompareKey:[self getUniqueColumnName:flage]];
        NSLog(@"Inserting %@ values..",flage);
        
        dataObj = [[DataSource alloc]init];
        if ([dicCurrentWebserviceData valueForKey:IS_COMPLETE]==nil)  // Avoid insertion during Completion 
        {
        [dataObj insertArray:arrData toTable:flage :SYNCED_DATA];
        }
        else 
        {
            //Main thread update the  recent timestamp
            [DataSource executeQuery:[NSString stringWithFormat:@"Update Upload_Info set Previous_TimeStamp ='%@' where rowid = 1",[CommonFunctions getCurrentTimeStamp]]];
        }
        [dataObj release];
        
        
        if ([flage isEqualToString:TBL_JOBPATROLSCHEDULEPOINTS])
        {
            
            [DataSource executeQuery:@"update job_patrol_schedule_points set ManualStatusHandler = 'COMPLETE' where date_complete != '' and require_unable LIKE '%%N%%'"];
            
            [DataSource executeQuery:@"update job_patrol_schedule_points set ManualStatusHandler = 'NOT_COMPLETE' where date_complete != '' and require_unable LIKE '%%Y%%'"];
            
            
            NSMutableArray *arrtempForNotcompletePatrols = [DataSource getRecordsFromQuery:@"select sort,point_id,schedule_id from Job_patrol_schedule_points where ManualStatusHandler = 'NOT_COMPLETE'"];
            
            for (int i = 0;i<[arrtempForNotcompletePatrols count];i++)
            {
                NSMutableDictionary *arrdicRec = (NSMutableDictionary *) [arrtempForNotcompletePatrols objectAtIndex:i];
                [DataSource executeQuery:[NSString stringWithFormat:@"update job_patrol_schedule_points set ManualStatusHandler = 'MISSED' where date_complete = '' and require_unable  LIKE '%%N%%' and  sort < '%@'  and schedule_id = '%@'",[arrdicRec valueForKey:@"sort" ],[arrdicRec valueForKey:@"schedule_id"] ]];
            }
            
            NSMutableArray *arrtempForcompletePatrols = [DataSource getRecordsFromQuery:@"select sort,point_id,schedule_id from Job_patrol_schedule_points where ManualStatusHandler = 'COMPLETE'"];
            
            for (int i = 0;i<[arrtempForcompletePatrols count];i++)
            {
                NSMutableDictionary *arrdicRec = (NSMutableDictionary *) [arrtempForcompletePatrols objectAtIndex:i];
                [DataSource executeQuery:[NSString stringWithFormat:@"update job_patrol_schedule_points set ManualStatusHandler = 'MISSED' where date_complete = '' and require_unable  LIKE '%%N%%' and  sort < '%@'  and schedule_id = '%@'",[arrdicRec valueForKey:@"sort" ],[arrdicRec valueForKey:@"schedule_id"] ]];
            }
            
            /*
             
             update Patrol_schedule_points set ManualStatusHandler = 'NOT_COMPLETE' where date_complete != '' and require_unable LIKE '%Y%'
                update Patrol_schedule_points set ManualStatusHandler = 'COMPLETE' where date_complete != '' and require_unable LIKE '%N%'
                
             select sort,point_id,schedule_id from Job_patrol_schedule_points where ManualStatusHandler = 'NOT_COMPLETE'
             
                select sort,point_id,schedule_id from Job_patrol_schedule_points where ManualStatusHandler = 'COMPLETE'
             
             update Patrol_schedule_points set ManualStatusHandler = 'MISSED' where date_complete = '' and require_unable  LIKE '%N%' and  sort < and point_id =  and schedule=
             */
            
            //[DataSource executeQuery:
            // [NSString stringWithFormat:@"update Patrol_schedule_points set ManualStatusHandler = 'NOT_COMPLETE' where date_complete != '' and require_unable LIKE '%%Y%%'"]];
            
        }
        if ([flage isEqualToString:TBL_JOB_MATERIALS])
        {
            [DataSource executeQuery:@"update jobs set IsJobStarted = 'Y' where eng_on_site IS NOT NULL    and eng_on_site != ''"];
        }
        
    }
    else 
    {
        NSLog(@"No values in  %@ ",flage);        
    }
    if ([arrWebservicelist count]>0)
    {
        [arrWebservicelist removeObjectIdenticalTo:dicCurrentWebserviceData]; //remove current value from array
        
        if ([arrWebservicelist count]>0)
        {
            //Set Progress View
            float progressvalue = [[NSNumber numberWithInt:(initialcountValue-[arrWebservicelist count])]floatValue]/[[NSNumber numberWithInt:initialcountValue]floatValue];
            
            progressvalue = progressvalue*100;

            [_delegate setProgress:progressvalue forFlag:@"Downloading Data"];
            
            [self refreshDataBase:@"CONTINUE"];
        }
        else   //All tables inserted 
            [_delegate DataInserted]; 
    }
    else 
    {
        NSLog(@"Problem in insertion and deletion");
        [_delegate TaskAborted];           
    }
}


#pragma mark get Unique column name
-(NSString *)getUniqueColumnName:(NSString *)TableName
{

    
    NSString *strUniqueColumnName = @"";
    if ([TableName isEqualToString:TBL_JOBS])
        strUniqueColumnName = JOBS_ID;
    else  if ([TableName isEqualToString:TBL_ASSET_NOTES])
        strUniqueColumnName = NOTESASSET_ID;
    else  if ([TableName isEqualToString:TBL_ASSETS])
        strUniqueColumnName = ASSETS_ID;
    else  if ([TableName isEqualToString:TBL_CUSTOMERS])
        strUniqueColumnName = CUSTOMERS_ID;
    else  if ([TableName isEqualToString:TBL_JOBLINES])
        strUniqueColumnName = JOBS_ID;
    else  if ([TableName isEqualToString:TBL_JOBPATROLSCHEDULEPOINTS])
        strUniqueColumnName = POINT_ID;
    else  if ([TableName isEqualToString:TBL_JOBPATROLSCHEDULES])
        strUniqueColumnName = SCHEDULE_ID;
    else  if ([TableName isEqualToString:TBL_LEGCOMPTYPES])
        strUniqueColumnName = LEGCOMP_TYPES_ID;
    else  if ([TableName isEqualToString:TBL_PRIORITIES])
        strUniqueColumnName = PRIORITIES_ID;
    else  if ([TableName isEqualToString:TBL_SUBASSETS])
        strUniqueColumnName = ASSETS_SUB_ID;
    else  if ([TableName isEqualToString:TBL_UPLOADEDFILES])
        strUniqueColumnName = FILE_ID;
    else  if ([TableName isEqualToString:TBL_USERS])
        strUniqueColumnName = USER_ID;
    else  if ([TableName isEqualToString:TBL_SUPPLIERS])
        strUniqueColumnName = SUPPLIERS_ID;
    else  if ([TableName isEqualToString:TBL_SUBASSETS_HISTORY])
        strUniqueColumnName = HISTORY_ID;
    else  if ([TableName isEqualToString:TBL_JOB_MATERIALS])
        strUniqueColumnName = JOBS_ID;
    else  if ([TableName isEqualToString:TBL_ALL_USERS])
        strUniqueColumnName = ALL_USERS_ID;
    else  if ([TableName isEqualToString:TBL_SERVICE_ROUTINE])
        strUniqueColumnName = SERVICE_ROUTINE_ID; 
    else  if ([TableName isEqualToString:TBL_SERVICE_ROUTINE_LINES])
        strUniqueColumnName = SERVICE_ROUTINE_LINES_LID; 

    return strUniqueColumnName;
}
@end
