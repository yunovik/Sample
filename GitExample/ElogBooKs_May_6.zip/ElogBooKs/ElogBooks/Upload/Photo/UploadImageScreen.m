//
//  UploadImageScreen.m
//  ElogBooks
//
//  Created by i-Verve on 20/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import "UploadImageScreen.h"


@interface UploadImageScreen ()

@end

@implementation UploadImageScreen
@synthesize strjid,strPoint_id,strOrder,strSchedule_id,strPatrolJobId,dicCurrentPatrolRecord,isUploadingLastPoint,strAid,strIsToCreateJob,strIsTakePhoto,strIsTakeCamera,strIsUNorderedPoint;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
    self.title = @"Upload Image";
    [CommonFunctions setTitleView:self amdtitle:@"Upload Image"];
    [self.view setBackgroundColor:[UIColor whiteColor]];
    
    [CommonFunctions setBack:self target:@selector(btnBackTapped:)];
    
    strImageTitle = @"";
    
    imgView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 10, 300, 356)];
    [[imgView layer] setBorderColor:[[UIColor blackColor] CGColor]];
    [[imgView layer] setBorderWidth:1.5];
    
    [self.view addSubview:imgView];
    
    btnSelect = [CommonFunctions buttonWithTitle:@"Select Image" andFrame:CGRectMake(15, 376, 140, 30)];
    [btnSelect addTarget:self action:@selector(btnSelectTapped:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btnSelect];
    
    btnUpload = [CommonFunctions buttonWithTitle:@"Upload Image" andFrame:CGRectMake(165, 376, 140, 30)];
    [btnUpload addTarget:self action:@selector(btnUploadTapped:) forControlEvents:UIControlEventTouchUpInside];
    [btnUpload setEnabled:NO];
    [self.view addSubview:btnUpload];
    
    
    if (strIsToCreateJob!=nil)
    {
     if (strIsTakeCamera!=nil)
     {
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
    {
        UIImagePickerController *objImgPicker = [[UIImagePickerController alloc] init];
        [objImgPicker setDelegate:self];
        [objImgPicker setAllowsEditing:NO];
        [objImgPicker setSourceType:UIImagePickerControllerSourceTypeCamera];
        [self presentModalViewController:objImgPicker animated:YES];
    }
    else 
    {
        [self.navigationController popViewControllerAnimated:YES];
    }
     }
     else 
    if (strIsTakePhoto!=nil)
    {
        if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary])
        {
            UIImagePickerController *objImgPicker = [[UIImagePickerController alloc] init];
            [objImgPicker setDelegate:self];
            [objImgPicker setAllowsEditing:NO];
            [objImgPicker setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
            [self presentModalViewController:objImgPicker animated:YES];
        }
        else 
        {
            [self.navigationController popViewControllerAnimated:YES];
        }
    }
    }
    
    if ( strPatrolJobId!=nil)  // upload patrol oriented image
    {
        if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
        {
            UIImagePickerController *objImgPicker = [[UIImagePickerController alloc] init];
            [objImgPicker setDelegate:self];
            [objImgPicker setAllowsEditing:NO];
            [objImgPicker setSourceType:UIImagePickerControllerSourceTypeCamera];
            [self presentModalViewController:objImgPicker animated:YES];
        }else {
//            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:APP_TITLE message:@"Sorry, This device not support this feature." delegate:nil cancelButtonTitle:@"Okay" otherButtonTitles:nil];
//            [alertView show];
//            [alertView release];
            Alert_View =[CommonFunctions AlertWithMessage:@"Please wait..."];
            [self.view addSubview:Alert_View];
            [self  MarkPointAsUnableToComplete];
        }   
    }
    

    
    
}

-(void)StartPatrolOrientedTask
{
    if ( strPatrolJobId!=nil)  // upload patrol oriented image
    {
        if (img_ToUpload!=nil)
        {
            strImageTitle = [NSString stringWithFormat:@"%@.png",[CommonFunctions getUniqueName]];
            [strImageTitle retain];
            strTimeStampValue = [CommonFunctions getCurrentTimeStamp];
            [strTimeStampValue retain];
            if ([CommonFunctions isNetAvailable])
            {
                //Complete the job
                AlertView = [CommonFunctions AlertWithMessage:@"Please wait..."];
                [self.view addSubview:AlertView];
                
                PutInfoClass *objPutInfo = [[PutInfoClass alloc] init];
                
                
                NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
                
                NSData *_data = UIImagePNGRepresentation(img_ToUpload);
                NSString *strBase64 = [Base64 encode:_data];
                
                NSString *strUserId = [ElogBooksAppDelegate getValueForKey:USER_ID];
                [dic setObject:strUserId forKey:@"01:uid"];
                
                [dic setObject:@"image" forKey:@"02:UpdateType"];
                
                NSLog(@"%@",strjid);
                [dic setObject:strPatrolJobId forKey:@"03:jid"];
                [dic setObject:strBase64 forKey:@"04:ImageString"];
                [dic setObject:strImageTitle forKey:@"03:Title"];
                
                
                if([strPoint_id length]>0)
                    [dic setObject:strPoint_id forKey:@"04:point_id"];
                
                if([strOrder length]>0)
                    [dic setObject:strOrder forKey:@"03:order"];
                
                if([strSchedule_id length]>0)
                    [dic setObject:strSchedule_id forKey:@"04:schedule_id"];
                
                [dic setObject:strTimeStampValue forKey:@"05:tstamp"];
                
                //                  objPutInfo = [[PutInfoClass alloc] init];
                objPutInfo.argsDic = dic;
                
                objPutInfo.ParentNode = @"Responses";
                objPutInfo.ChildNode = @"Response";
                
                objPutInfo.strWebService=[NSString stringWithFormat:@"UploadImage_Patrol"];
                objPutInfo.retType=isString;
//                objPutInfo.strUrl= @"http://code.elogbooks.co.uk/users/jack/WOM/api/put-info.php";
                objPutInfo.strUrl = [NSString stringWithFormat:@"%@%@",[ElogBooksAppDelegate getValueForKey:BASE_URL],PUT_INFO_API];
                objPutInfo._delegate=self;
                [objPutInfo setArrayPOST];
                
                
                
                
            }
            else
            {
                if ([DataSource executeQuery:[NSString stringWithFormat:@"INSERT INTO Uploaded_files (fid,uid,cid,iid,as_id,type,doc_type,as_type,expired,reveal,orig_name,title,dir,created,expiry,IsSynced)values('TEMP_FILE_ID',%@,0,0,'%@','','','J','','Y','%@','%@','jobs','%@','',%@)",[ElogBooksAppDelegate getValueForKey:USER_ID],strjid,[self ConvertDateToOriginalName:strTimeStampValue:strPatrolJobId],strImageTitle,[CommonFunctions getCurrentTimeStampForDatabaseInsertion:strTimeStampValue ],UN_SYNCED_DATA ]] )
                    NSLog(@"Uploaded file details stored in db");
                [self saveImageInLocal:img_ToUpload:strImageTitle];
                //Complete the job
                
                [self MarkPatrolAsDone];
//                objAlert = [[MEAlertView alloc]initWithMessage:@"As this patrol has  requirement for Photo.Please select the correct option below." delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Unable to complete,Complete"];
//                objAlert.tag= IMAGE_ATT_TAG;
//                objAlert.delegate=self;
//                [objAlert Show];
//                [objAlert release];
            }
        }
    }
}

-(IBAction)btnBackTapped:(id)Sender
{
    [self.navigationController popViewControllerAnimated:YES];
}


-(IBAction)btnSelectTapped:(id)Sender
{
    UIActionSheet *popupQuery = [[UIActionSheet alloc] initWithTitle:APP_TITLE delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Select Picture", @"Capture Picture", nil];
    popupQuery.actionSheetStyle = UIActionSheetStyleBlackOpaque;
    [popupQuery showInView:self.view];
    [popupQuery release];
    
}

-(IBAction)btnUploadTapped:(id)Sender
{
    img_ToUpload = imgView.image;
    [img_ToUpload retain];
    
    if (strjid != nil)
    {
        if (img_ToUpload!=nil)
        {
            strImageTitle = [NSString stringWithFormat:@"%@.png",[CommonFunctions getUniqueName]];
            [strImageTitle retain];
            strTimeStampValue = [CommonFunctions getCurrentTimeStamp];
            [strTimeStampValue retain];
            if ([CommonFunctions isNetAvailable])
            {
                
                AlertView = [CommonFunctions AlertWithMessage:@"Please wait..."];
                [self.view addSubview:AlertView];
                
                PutInfoClass *objPutInfo = [[PutInfoClass alloc] init];
                
                
                NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
                
                NSData *_data = UIImagePNGRepresentation(img_ToUpload);
                NSString *strBase64 = [Base64 encode:_data];
                
                NSString *strUserId = [ElogBooksAppDelegate getValueForKey:USER_ID];
                [dic setObject:strUserId forKey:@"01:uid"];
                
                [dic setObject:@"image" forKey:@"02:UpdateType"];
                
                NSLog(@"%@",strjid);
                [dic setObject:strjid forKey:@"03:jid"];
                [dic setObject:strBase64 forKey:@"04:ImageString"];
                [dic setObject:strImageTitle forKey:@"03:Title"];
                
                if([strPoint_id length]>0)
                    [dic setObject:strPoint_id forKey:@"04:point_id"];
                
                if([strOrder length]>0)
                    [dic setObject:strOrder forKey:@"03:order"];
                
                if([strSchedule_id length]>0)
                    [dic setObject:strSchedule_id forKey:@"04:schedule_id"];
                
                [dic setObject:strTimeStampValue forKey:@"05:tstamp"];
                
                //            objPutInfo = [[PutInfoClass alloc] init];
                objPutInfo.argsDic = dic;
                
                objPutInfo.ParentNode = @"Responses";
                objPutInfo.ChildNode = @"Response";
                
                objPutInfo.strWebService=[NSString stringWithFormat:@"UploadImage"];
                objPutInfo.retType=isString;
//                objPutInfo.strUrl= @"http://code.elogbooks.co.uk/users/jack/WOM/api/put-info.php";
                    objPutInfo.strUrl = [NSString stringWithFormat:@"%@%@",[ElogBooksAppDelegate getValueForKey:BASE_URL],PUT_INFO_API];
                objPutInfo._delegate=self;
                [objPutInfo setArrayPOST];
            }
            else
            {
                
                if ([DataSource executeQuery:[NSString stringWithFormat:@"INSERT INTO Uploaded_files (fid,uid,cid,iid,as_id,type,doc_type,as_type,expired,reveal,orig_name,title,dir,created,expiry,IsSynced)values('TEMP_FILE_ID',%@,0,0,'%@','','','J','','Y','%@','%@','jobs','%@','',%@)",[ElogBooksAppDelegate getValueForKey:USER_ID],strjid,[self ConvertDateToOriginalName:strTimeStampValue:strjid],strImageTitle,[CommonFunctions getCurrentTimeStampForDatabaseInsertion:strTimeStampValue ],UN_SYNCED_DATA ]] )
                    NSLog(@"Uploaded file details stored in db");
                [self saveImageInLocal:img_ToUpload:strImageTitle];
                [self.navigationController popViewControllerAnimated:YES];
            }
        }
    }
    else 
    if ( strPatrolJobId!=nil)  // upload patrol oriented image
    {
        if (img_ToUpload!=nil)
        {
            strImageTitle = [NSString stringWithFormat:@"%@.png",[CommonFunctions getUniqueName]];
            [strImageTitle retain];
            strTimeStampValue = [CommonFunctions getCurrentTimeStamp];
            [strTimeStampValue retain];
            if ([CommonFunctions isNetAvailable])
            {
                //Complete the job
                AlertView = [CommonFunctions AlertWithMessage:@"Please wait..."];
                [self.view addSubview:AlertView];
                
                PutInfoClass *objPutInfo = [[PutInfoClass alloc] init];
                
                
                NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
                
                NSData *_data = UIImagePNGRepresentation(img_ToUpload);
                NSString *strBase64 = [Base64 encode:_data];
                
                NSString *strUserId = [ElogBooksAppDelegate getValueForKey:USER_ID];
                [dic setObject:strUserId forKey:@"01:uid"];
                
                [dic setObject:@"image" forKey:@"02:UpdateType"];
                
                NSLog(@"%@",strjid);
                [dic setObject:strPatrolJobId forKey:@"03:jid"];
                [dic setObject:strBase64 forKey:@"04:ImageString"];
                [dic setObject:strImageTitle forKey:@"03:Title"];
                
                
                if([strPoint_id length]>0)
                    [dic setObject:strPoint_id forKey:@"04:point_id"];
                
                if([strOrder length]>0)
                    [dic setObject:strOrder forKey:@"03:order"];
                
                if([strSchedule_id length]>0)
                    [dic setObject:strSchedule_id forKey:@"04:schedule_id"];
                
                [dic setObject:strTimeStampValue forKey:@"05:tstamp"];
                
                //                  objPutInfo = [[PutInfoClass alloc] init];
                objPutInfo.argsDic = dic;
                
                objPutInfo.ParentNode = @"Responses";
                objPutInfo.ChildNode = @"Response";
                
                objPutInfo.strWebService=[NSString stringWithFormat:@"UploadImage_Patrol"];
                objPutInfo.retType=isString;
//                objPutInfo.strUrl= @"http://code.elogbooks.co.uk/users/jack/WOM/api/put-info.php";
                objPutInfo.strUrl = [NSString stringWithFormat:@"%@%@",[ElogBooksAppDelegate getValueForKey:BASE_URL],PUT_INFO_API];
                objPutInfo._delegate=self;
                [objPutInfo setArrayPOST];
            }
            else
            {
                if ([DataSource executeQuery:[NSString stringWithFormat:@"INSERT INTO Uploaded_files (fid,uid,cid,iid,as_id,type,doc_type,as_type,expired,reveal,orig_name,title,dir,created,expiry,IsSynced)values('TEMP_FILE_ID',%@,0,0,'%@','','','J','','Y','%@','%@','jobs','%@','',%@)",[ElogBooksAppDelegate getValueForKey:USER_ID],strPatrolJobId,[self ConvertDateToOriginalName:strTimeStampValue:strPatrolJobId],strImageTitle,[CommonFunctions getCurrentTimeStampForDatabaseInsertion:strTimeStampValue ],UN_SYNCED_DATA ]] )
                    NSLog(@"Uploaded file details stored in db");
                [self saveImageInLocal:img_ToUpload:strImageTitle];
                //Complete the job
                objAlert = [[MEAlertView alloc]initWithMessage:@"As this patrol has  requirement for Photo.Please select the correct option below." delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Unable to complete,Complete"];
                objAlert.tag= IMAGE_ATT_TAG;
                objAlert.delegate=self;
                [objAlert Show];
                [objAlert release];
            }
        }
    }
    else if (strAid!=nil)
    {
        
        if (img_ToUpload!=nil)
        {
            strImageTitle = [NSString stringWithFormat:@"%@.png",[CommonFunctions getUniqueName]];
            [strImageTitle retain];
            strTimeStampValue = [CommonFunctions getCurrentTimeStamp];
            [strTimeStampValue retain];
            if ([CommonFunctions isNetAvailable])
            {
                
                AlertView = [CommonFunctions AlertWithMessage:@"Please wait..."];
                [self.view addSubview:AlertView];
                
                PutInfoClass *objPutInfo = [[PutInfoClass alloc] init];
                
                
                NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
                
                NSData *_data = UIImagePNGRepresentation(img_ToUpload);
                NSString *strBase64 = [Base64 encode:_data];
                
                NSString *strUserId = [ElogBooksAppDelegate getValueForKey:USER_ID];
                [dic setObject:strUserId forKey:@"01:uid"];
                
                [dic setObject:@"image" forKey:@"02:UpdateType"];
                
                NSLog(@"%@",strAid);
                
                
                [dic setObject:strAid forKey:@"03:jid"];
                [dic setObject:strBase64 forKey:@"04:ImageString"];
                [dic setObject:strImageTitle forKey:@"05:Title"];
                
               
                
                [dic setObject:strTimeStampValue forKey:@"06:tstamp"];
                //                &as_type=A
                [dic setObject:@"A" forKey:@"07:as_type"];
                
                //            objPutInfo = [[PutInfoClass alloc] init];
                objPutInfo.argsDic = dic;
                
                objPutInfo.ParentNode = @"Responses";
                objPutInfo.ChildNode = @"Response";
                
                objPutInfo.strWebService=[NSString stringWithFormat:@"UploadImage"];
                objPutInfo.retType=isString;
//                objPutInfo.strUrl= @"http://code.elogbooks.co.uk/users/jack/WOM/api/put-info.php";
                    objPutInfo.strUrl = [NSString stringWithFormat:@"%@%@",[ElogBooksAppDelegate getValueForKey:BASE_URL],PUT_INFO_API];
                objPutInfo._delegate=self;
                [objPutInfo setArrayPOST];
            }
            else
            {
                
                if ([DataSource executeQuery:[NSString stringWithFormat:@"INSERT INTO Uploaded_files (fid,uid,cid,iid,as_id,type,doc_type,as_type,expired,reveal,orig_name,title,dir,created,expiry,IsSynced)values('TEMP_FILE_ID',%@,0,0,'%@','','','A','','Y','%@','%@','jobs','%@','',%@)",[ElogBooksAppDelegate getValueForKey:USER_ID],strAid,[self ConvertDateToOriginalName:strTimeStampValue:strAid],strImageTitle,[CommonFunctions getCurrentTimeStampForDatabaseInsertion:strTimeStampValue ],UN_SYNCED_DATA ]] )
                    NSLog(@"Uploaded file details stored in db");
                [self saveImageInLocal:img_ToUpload:strImageTitle];
                [self.navigationController popViewControllerAnimated:YES];
            }
        }

        
        
    }
}

-(IBAction)btnUnableTocomplete:(UIButton *)Sender andTag:(int)alertTag
{
    NSLog(@"btnUnableTocomplete Clicked");
    NSString *strCurrentTimeStamp = [CommonFunctions getCurrentTimeStampForDatabaseInsertion:strTimeStampValue];
    [strCurrentTimeStamp retain];
    if (([DataSource executeQuery:[NSString stringWithFormat:@"Update Job_patrol_schedule_points SET IsSynced=%@,require_unable='Y',date_complete ='%@',ManualStatusHandler='NOT_COMPLETE' where schedule_id= %@ and point_id = %@ and sort = %@;",UN_SYNCED_DATA,strCurrentTimeStamp,[dicCurrentPatrolRecord objectForKey:SCHEDULE_ID],[dicCurrentPatrolRecord objectForKey:POINT_ID],[dicCurrentPatrolRecord objectForKey:JOB_PATROL_SCHEDULE_POINT_SORT]]]) && ([DataSource executeQuery:[NSString stringWithFormat:@"Update Job_patrol_schedule_points SET date_complete ='',ManualStatusHandler='MISSED' where  sort < %@ and ManualStatusHandler != 'NOT_COMPLETE' and  ManualStatusHandler != 'COMPLETE' and schedule_id = %@;",[dicCurrentPatrolRecord objectForKey:JOB_PATROL_SCHEDULE_POINT_SORT],[dicCurrentPatrolRecord objectForKey:SCHEDULE_ID]]]))
    {
        NSLog(@"record updated");
        //set current unable feature in the key of the current dictionary
        [dicCurrentPatrolRecord setObject:@"Y" forKey:@"require_unable"];
        
        if ([CommonFunctions isNetAvailable])
        {
            [self completePointForIncompletion:dicCurrentPatrolRecord];
        }
        else
        {
            
            //no internet connection available
            if (isUploadingLastPoint)
            {
                //Complete Patrol
                [self CompletePatrol:dicCurrentPatrolRecord];
            }
            else
            {
                [self.navigationController popViewControllerAnimated:YES];
            }
        }
    }
    else
        NSLog(@"Unable to update the record ");
    
}
-(IBAction)btnOk_Tapped:(UIButton *)Sender andTag:(int)alertTag
{
    NSLog(@"btnOk_Tapped Clicked");
    NSString *strCurrentTimeStamp = [CommonFunctions getCurrentTimeStampForDatabaseInsertion:strTimeStampValue];
    [strCurrentTimeStamp retain];
    if (([DataSource executeQuery:[NSString stringWithFormat:@"Update Job_patrol_schedule_points SET IsSynced=%@,require_unable='N',date_complete ='%@',ManualStatusHandler='COMPLETE' where schedule_id= %@ and point_id = %@ and sort=%@",UN_SYNCED_DATA,strCurrentTimeStamp,[dicCurrentPatrolRecord objectForKey:SCHEDULE_ID],[dicCurrentPatrolRecord objectForKey:POINT_ID],[dicCurrentPatrolRecord objectForKey:JOB_PATROL_SCHEDULE_POINT_SORT]]]) && ([DataSource executeQuery:[NSString stringWithFormat:@"Update Job_patrol_schedule_points SET date_complete ='',require_unable='N',ManualStatusHandler='MISSED' where  sort < %@ and ManualStatusHandler != 'NOT_COMPLETE' and  ManualStatusHandler != 'COMPLETE' and schedule_id = %@;",[dicCurrentPatrolRecord objectForKey:JOB_PATROL_SCHEDULE_POINT_SORT],[dicCurrentPatrolRecord objectForKey:SCHEDULE_ID]]]))
    {
        NSLog(@"record updated");
        
        if ([CommonFunctions isNetAvailable])
        {
            [self completePoint:dicCurrentPatrolRecord];
        }
        else
        {
            //no internet connection available
            if (isUploadingLastPoint)  //last point row
            {
                //Complete Patrol
                [self CompletePatrol:dicCurrentPatrolRecord];
            }
            else
            {
                [self.navigationController popViewControllerAnimated:YES];
            }
        }
    }
    else
        NSLog(@"Unable to update the record");
}
-(IBAction)btnCancel_Tapped:(UIButton *)Sender andTag:(int)alertTag
{
    
}


#pragma mark completePoint
-(void)completePoint:(NSMutableDictionary *)dicCurrentRecord
{
    /*http://code.elogbooks.co.uk/users/jack/WOM/api/put-info.php?uid=38&UpdateType=patrol_point&qd=Update&tstamp=27/12/2012%2018:35:20&jid=7811&point_id=50&order=3&schedule_id=240&unable=N */
    
    
    
    PutInfoClass  *objService=[[PutInfoClass alloc] init];
    objService._delegate=self;
    objService.retType=isArray;
    NSMutableDictionary *dicc=[[[NSMutableDictionary alloc] init]autorelease];
    [dicc setObject:[ElogBooksAppDelegate getValueForKey:USER_ID] forKey:USER_ID];
    [dicc setObject:@"patrol_point" forKey:@"UpdateType"];
    [dicc setObject:@"Update" forKey:@"qd"];
    [dicc setObject: strTimeStampValue forKey:@"tstamp"];
    [dicc setObject:strPatrolJobId forKey:JOBS_ID];
    
    
    [dicc setObject:[dicCurrentRecord objectForKey:POINT_ID]  forKey:POINT_ID];
    [dicc setObject:[dicCurrentRecord objectForKey:SCHEDULE_ID]  forKey:SCHEDULE_ID];
    [dicc setObject:[dicCurrentRecord objectForKey:JOB_PATROL_SCHEDULE_POINT_SORT]  forKey:@"order"];
    [dicc setObject:[dicCurrentRecord objectForKey:JOB_PATROL_SCHEDULE_POINT_REQUIRE_UNABLE]  forKey:@"unable"];
    
    
    objService.argsDic=[CommonFunctions getDicAsParameter:dicc] ;
    //point_id-->1 ===SCHEDULE_ID-->3 ====sort-->5
    objService.strWebService=[NSString stringWithFormat:@"point_id:%@:schedule_id:%@:sort:%@",[dicCurrentRecord objectForKey:POINT_ID],[dicCurrentRecord objectForKey:SCHEDULE_ID],[dicCurrentRecord objectForKey:JOB_PATROL_SCHEDULE_POINT_SORT]];
    objService.strUrl= [NSString stringWithFormat:@"%@%@",[ElogBooksAppDelegate getValueForKey:BASE_URL],PUT_INFO_API];
    objService.ParentNode=@"Responses";
    objService.ChildNode=@"Response";
    [objService performSelector:@selector(setArray) withObject:nil afterDelay:0.1];
    
    
}

#pragma mark CompletePatrol
-(void)CompletePatrol:(NSMutableDictionary *)dicSelected
{
    //update the schedule as unsynced
    //Check whether any unsynced point exists ,if yes then set schedule_id as unsynced
    //select COUNT(Job_patrol_schedule_points.point_id) from Jobs join Job_patrol_schedules on Jobs.jid = Job_patrol_schedules.jid join Job_patrol_schedule_points on Job_patrol_schedule_points.schedule_id=Job_patrol_schedules.schedule_id where jobs.jid=7798 and Job_patrol_schedule_points.IsSynced=0
    
    
    int UnsyncedDatacount =  [[DataSource getStringFromQuery:[NSString stringWithFormat:@"select COUNT(Job_patrol_schedule_points.point_id) from Jobs join Job_patrol_schedules on Jobs.jid = Job_patrol_schedules.jid join Job_patrol_schedule_points on Job_patrol_schedule_points.schedule_id=Job_patrol_schedules.schedule_id where jobs.jid=%@ and Job_patrol_schedule_points.IsSynced=%@",strPatrolJobId,UN_SYNCED_DATA]]intValue];
    if (UnsyncedDatacount >0) //Check any unsynced data available
    {
        if ([DataSource executeQuery:[NSString stringWithFormat:@"update Job_patrol_schedules set IsSynced=%@ where schedule_id=%@",UN_SYNCED_DATA,[dicSelected objectForKey:SCHEDULE_ID]]])
            NSLog(@"Patrol Point updated");
        else
            NSLog(@"Failed to update the current schedule_id");
    }
    
    if(strPatrolJobId!=nil)
    {
        if (Alert_View!=nil)
            [Alert_View removeFromSuperview];
    }
    
    int MissedValuesCount = [[DataSource getStringFromQuery:[NSString stringWithFormat:@" select COUNT(*) as MissedCount from Jobs join Job_patrol_schedules on Jobs.jid = Job_patrol_schedules.jid join Job_patrol_schedule_points on Job_patrol_schedule_points.schedule_id=Job_patrol_schedules.schedule_id where                                                             jobs.jid='%@' and  ( Job_patrol_schedule_points.ManualStatusHandler ='NOT_COMPLETE' or Job_patrol_schedule_points.ManualStatusHandler = 'MISSED' )",strPatrolJobId]]intValue];

    
    //Call webservice here
    NSLog(@"Value updated");
    AddDescription* objNav=[[AddDescription alloc] initWithNibName:@"AddDescription" bundle:nil];
    objNav.strJid=strPatrolJobId;
    objNav.dicRecord = dicSelected;
    if (MissedValuesCount == 0)
    {
        objNav.isNotMissedAnyPoint = YES;   
    }
    [self.navigationController pushViewController:objNav animated:YES];
    [objNav release];
    
    
    
}

#pragma mark CompletePointforIncompletion
-(void)completePointForIncompletion:(NSMutableDictionary *)dicCurrentRecord
{
    PutInfoClass  *objService=[[PutInfoClass alloc] init];
    objService._delegate=self;
    objService.retType=isArray;
    NSMutableDictionary *dicc=[[[NSMutableDictionary alloc] init]autorelease];
    [dicc setObject:[ElogBooksAppDelegate getValueForKey:USER_ID] forKey:USER_ID];
    [dicc setObject:@"patrol_point" forKey:@"UpdateType"];
    [dicc setObject:@"Update" forKey:@"qd"];
    [dicc setObject:strTimeStampValue forKey:@"tstamp"];
    [dicc setObject:strPatrolJobId forKey:JOBS_ID];
    
    //    if (strScannedCode!=nil)
    //        [dicc setObject:strScannedCode  forKey:SCHEDULE_BARCODE];
    [dicc setObject:[dicCurrentRecord objectForKey:POINT_ID]  forKey:POINT_ID];
    [dicc setObject:[dicCurrentRecord objectForKey:SCHEDULE_ID]  forKey:SCHEDULE_ID];
    [dicc setObject:[dicCurrentRecord objectForKey:JOB_PATROL_SCHEDULE_POINT_SORT]  forKey:@"order"];
    [dicc setObject:[dicCurrentRecord objectForKey:JOB_PATROL_SCHEDULE_POINT_REQUIRE_UNABLE]  forKey:@"unable"];
    
    
    objService.argsDic=[CommonFunctions getDicAsParameter:dicc] ;
    //point_id-->1 ===SCHEDULE_ID-->3 ====sort-->5
    objService.strWebService=[NSString stringWithFormat:@"point_id:%@:schedule_id:%@:sort:%@",[dicCurrentRecord objectForKey:POINT_ID],[dicCurrentRecord objectForKey:SCHEDULE_ID],[dicCurrentRecord objectForKey:JOB_PATROL_SCHEDULE_POINT_SORT]];
    objService.strUrl= [NSString stringWithFormat:@"%@%@",[ElogBooksAppDelegate getValueForKey:BASE_URL],PUT_INFO_API];
    objService.ParentNode=@"Responses";
    objService.ChildNode=@"Response";
    [objService performSelector:@selector(setArray) withObject:nil afterDelay:0.1];
}


-(NSString *)ConvertDateToOriginalName:(NSString *)strReceivedDate:(NSString *)strJid
{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"dd/MM/yyyyHH:mm:ss"];
    NSDate *date = [dateFormatter dateFromString:strReceivedDate];
    
    [dateFormatter setDateFormat:@"yyyy-MM-dd-HH-mm-ss"];
    NSString *strOriginalName = [NSString stringWithFormat:@"%@-%@.png",[dateFormatter stringFromDate:date],strJid];
    //    NSLog(@"dateWithNewFormat: %@", dateWithNewFormat);
    return strOriginalName;
}


-(void)EndParsingArray:(NSMutableArray *)arrData forFlage:(NSString *)flage
{
    if (!([flage rangeOfString:@"schedule_id"].location == NSNotFound))
    {
        if ([arrData count]>0)
        {
            if (!([[arrData objectAtIndex:0]rangeOfString:@"Success"].location==NSNotFound))
            {
                if ([flage length]>0) // if success
                {
                    NSArray *arrIdValues = [flage componentsSeparatedByString:@":"];
                    NSString *strPointId=[arrIdValues objectAtIndex:1];
                    NSString *strScheduleId=[arrIdValues objectAtIndex:3];
                    NSString *strSortValue=[arrIdValues objectAtIndex:3];
                    if ([DataSource executeQuery:[NSString stringWithFormat:@"update Job_patrol_schedule_points set IsSynced=%@ where schedule_id=%@ and point_id=%@ and sort=%@",SYNCED_DATA,strScheduleId,strPointId,strSortValue]])
                        NSLog(@"pointId :%@ synced from webservice to local",strPointId);
                    else
                        NSLog(@"pointId :%@  not synced",strPointId);
                }
            }
        }
        
        if (isUploadingLastPoint)
            [self CompletePatrol:dicCurrentPatrolRecord];
        else
        {
            if (Alert_View!=nil)
                [Alert_View removeFromSuperview];
            [self.navigationController popViewControllerAnimated:YES];
        }
    }
}

//-(void)EndParsing:(NSMutableDictionary *)arrData forFlage:(NSString *)flage
-(void)EndParsing:(NSString *)strResponse forFlage:(NSString *)flage
{
    if (strjid !=nil)
    {
        
        NSLog(@"%@:%@",flage,strResponse);
        
        NSRange rng = [strResponse rangeOfString:@":"];
        NSString *strIsSuccess = [strResponse substringToIndex:rng.location];
        NSString *strFId = [strResponse substringFromIndex:rng.location+1];
        NSLog(@"%@:%@",strIsSuccess,strFId);
        
        if([strIsSuccess isEqualToString:@"Success"])
        {
            
            if ([DataSource executeQuery:[NSString stringWithFormat:@"INSERT INTO Uploaded_files (fid,uid,cid,iid,as_id,type,doc_type,as_type,expired,reveal,orig_name,title,dir,created,expiry,IsSynced)values(%@,%@,0,0,'%@','','','J','','Y','%@','%@','jobs','%@','',%@)",strFId,[ElogBooksAppDelegate getValueForKey:USER_ID],strjid,[CommonFunctions getCurrentTimeStampForDatabaseInsertion:strTimeStampValue],strImageTitle,[CommonFunctions getCurrentTimeStampForDatabaseInsertion:strTimeStampValue ],SYNCED_DATA ]] )
                NSLog(@"Uploaded file details stored in db");
            
            
            
            UIAlertView *alert = [[UIAlertView alloc]
                                  initWithTitle:APP_TITLE
                                  message:@"Image uploaded successfully"
                                  delegate:nil
                                  cancelButtonTitle:@"Ok"
                                  otherButtonTitles:nil];
            [alert show];
            
            
            
            // TABLE "Uploaded_files"
            
            //"fid" //
            //"uid" //
            //"cid" //
            //"iid"  // Assets ID
            //"as_id" //jid
            //"type"
            //"doc_type"
            //"as_type"
            //"expired"
            //"reveal"
            //"orig_name"
            //"title"
            //"dir"
            //"created"
            //"expiry"
            //"IsSynced"
            
            
            
            //        NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
            //        [dic release];
            
        }
        else
        {
            [self saveImageInLocal:img_ToUpload:strImageTitle];
            if ([DataSource executeQuery:[NSString stringWithFormat:@"INSERT INTO Uploaded_files (fid,uid,cid,iid,as_id,type,doc_type,as_type,expired,reveal,orig_name,title,dir,created,expiry,IsSynced)values('TEMP_FILE_ID',%@,0,0,'%@','','','J','','Y','%@','%@','jobs','%@','',%@)",[ElogBooksAppDelegate getValueForKey:USER_ID],strjid,[self ConvertDateToOriginalName:strTimeStampValue:strjid],strImageTitle,[CommonFunctions getCurrentTimeStampForDatabaseInsertion:strTimeStampValue ],UN_SYNCED_DATA ]] )
                NSLog(@"Uploaded file details stored in db");
            
        }
        [self.navigationController popViewControllerAnimated:YES];
        
        [AlertView removeFromSuperview];
    }
    else if (strPatrolJobId!=nil)   //uploaded patrol image
    {
        NSLog(@"%@:%@",flage,strResponse);
        [AlertView removeFromSuperview];
        NSRange rng = [strResponse rangeOfString:@":"];
        NSString *strIsSuccess = [strResponse substringToIndex:rng.location];
        NSString *strFId = [strResponse substringFromIndex:rng.location+1];
        
        NSLog(@"%@:%@",strIsSuccess,strFId);
        if([strIsSuccess isEqualToString:@"Success"])
        {
            
            if ([DataSource executeQuery:[NSString stringWithFormat:@"INSERT INTO Uploaded_files (fid,uid,cid,iid,as_id,type,doc_type,as_type,expired,reveal,orig_name,title,dir,created,expiry,IsSynced)values(%@,%@,0,0,'%@','','','J','','Y','%@','%@','jobs','%@','',%@)",strFId,[ElogBooksAppDelegate getValueForKey:USER_ID],strPatrolJobId,[CommonFunctions getCurrentTimeStampForDatabaseInsertion:strTimeStampValue],strImageTitle,[CommonFunctions getCurrentTimeStampForDatabaseInsertion:strTimeStampValue ],SYNCED_DATA ]] )
                NSLog(@"Uploaded file details stored in db");
            
            
            
//            UIAlertView *alert = [[UIAlertView alloc]
//                                  initWithTitle:APP_TITLE
//                                  message:@"Image uploaded successfully"
//                                  delegate:nil
//                                  cancelButtonTitle:@"Ok"
//                                  otherButtonTitles:nil];
//            [alert show];
            
            
            
            // TABLE "Uploaded_files"
            
            //"fid" //
            //"uid" //
            //"cid" //
            //"iid"  // Assets ID
            //"as_id" //jid
            //"type"
            //"doc_type"
            //"as_type"
            //"expired"
            //"reveal"
            //"orig_name"
            //"title"
            //"dir"
            //"created"
            //"expiry"
            //"IsSynced"
            
            
            
            //        NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
            //        [dic release];
            
        }
        else
        {
            [self saveImageInLocal:img_ToUpload:strImageTitle];
            if ([DataSource executeQuery:[NSString stringWithFormat:@"INSERT INTO Uploaded_files (fid,uid,cid,iid,as_id,type,doc_type,as_type,expired,reveal,orig_name,title,dir,created,expiry,IsSynced)values('TEMP_FILE_ID',%@,0,0,'%@','','','J','','Y','%@','%@','jobs','%@','',%@)",[ElogBooksAppDelegate getValueForKey:USER_ID],strPatrolJobId,[self ConvertDateToOriginalName:strTimeStampValue:strjid],strImageTitle,[CommonFunctions getCurrentTimeStampForDatabaseInsertion:strTimeStampValue ],UN_SYNCED_DATA ]] )
                NSLog(@"Uploaded file details stored in db");
            
        }
        if (strPatrolJobId != nil)
        {
            //Complete the job
            [self MarkPatrolAsDone];
//            objAlert = [[MEAlertView alloc]initWithMessage:@"As this patrol has  requirement for Photo.Please select the correct option below." delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Unable to complete,Complete"];
//            objAlert.tag= IMAGE_ATT_TAG;
//            objAlert.delegate=self;
//            [objAlert Show];
//            [objAlert release];
        }
        
        
    }
    else if (strAid!=nil)
    {
        
        NSLog(@"%@:%@",flage,strResponse);
        
        NSRange rng = [strResponse rangeOfString:@":"];
        NSString *strIsSuccess = [strResponse substringToIndex:rng.location];
        NSString *strFId = [strResponse substringFromIndex:rng.location+1];
        
        NSLog(@"%@:%@",strIsSuccess,strFId);
        
        if([strIsSuccess isEqualToString:@"Success"])
        {
            
            if ([DataSource executeQuery:[NSString stringWithFormat:@"INSERT INTO Uploaded_files (fid,uid,cid,iid,as_id,type,doc_type,as_type,expired,reveal,orig_name,title,dir,created,expiry,IsSynced)values(%@,%@,0,0,'%@','','','A','','Y','%@','%@','jobs','%@','',%@)",strFId,[ElogBooksAppDelegate getValueForKey:USER_ID],strAid,[CommonFunctions getCurrentTimeStampForDatabaseInsertion:strTimeStampValue],strImageTitle,[CommonFunctions getCurrentTimeStampForDatabaseInsertion:strTimeStampValue ],SYNCED_DATA ]] )
                NSLog(@"Uploaded file details stored in db");
            
            
            
            UIAlertView *alert = [[UIAlertView alloc]
                                  initWithTitle:APP_TITLE
                                  message:@"Image uploaded successfully"
                                  delegate:nil
                                  cancelButtonTitle:@"Ok"
                                  otherButtonTitles:nil];
            [alert show];
            
            
            
            // TABLE "Uploaded_files"
            
            //"fid" //
            //"uid" //
            //"cid" //
            //"iid"  // Assets ID
            //"as_id" //jid
            //"type"
            //"doc_type"
            //"as_type"
            //"expired"
            //"reveal"
            //"orig_name"
            //"title"
            //"dir"
            //"created"
            //"expiry"
            //"IsSynced"
            
            
            
            //        NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
            //        [dic release];
            
        }
        else
        {
            [self saveImageInLocal:img_ToUpload:strImageTitle];
            if ([DataSource executeQuery:[NSString stringWithFormat:@"INSERT INTO Uploaded_files (fid,uid,cid,iid,as_id,type,doc_type,as_type,expired,reveal,orig_name,title,dir,created,expiry,IsSynced)values('TEMP_FILE_ID',%@,0,0,'%@','','','A','','Y','%@','%@','jobs','%@','',%@)",[ElogBooksAppDelegate getValueForKey:USER_ID],strAid,[self ConvertDateToOriginalName:strTimeStampValue:strAid],strImageTitle,[CommonFunctions getCurrentTimeStampForDatabaseInsertion:strTimeStampValue ],UN_SYNCED_DATA ]] )
                NSLog(@"Uploaded file details stored in db");
            
        }
        [self.navigationController popViewControllerAnimated:YES];
        
        [AlertView removeFromSuperview];
    }
}

-(void)filedWithError:(NSString *)strMsg forFlage:(NSString *)flage
{
    if (!([flage rangeOfString:@"schedule_id"].location == NSNotFound))
    {
        if (isUploadingLastPoint)
            [self CompletePatrol:dicCurrentPatrolRecord];
        else
            [self.navigationController popViewControllerAnimated:YES];
    }
    
    else if (strjid!=nil)
    {
        NSLog(@"%@:%@",flage,strMsg);
        [self saveImageInLocal:img_ToUpload:strImageTitle];
        if ([DataSource executeQuery:[NSString stringWithFormat:@"INSERT INTO Uploaded_files (fid,uid,cid,iid,as_id,type,doc_type,as_type,expired,reveal,orig_name,title,dir,created,expiry,IsSynced)values('TEMP_FILE_ID',%@,0,0,'%@','','','J','','Y','%@','%@','jobs','%@','',%@)",[ElogBooksAppDelegate getValueForKey:USER_ID],strjid,[self ConvertDateToOriginalName:strTimeStampValue:strjid],strImageTitle,[CommonFunctions getCurrentTimeStampForDatabaseInsertion:strTimeStampValue ],UN_SYNCED_DATA ]] )
            NSLog(@"Uploaded file details stored in db");
        
        [self.navigationController popViewControllerAnimated:YES];
        [AlertView removeFromSuperview];
    }
    else  if (strPatrolJobId!=nil) //save for patrol image details
    {
        [self saveImageInLocal:img_ToUpload:strImageTitle];
        [AlertView removeFromSuperview];
        if ([DataSource executeQuery:[NSString stringWithFormat:@"INSERT INTO Uploaded_files (fid,uid,cid,iid,as_id,type,doc_type,as_type,expired,reveal,orig_name,title,dir,created,expiry,IsSynced)values('TEMP_FILE_ID',%@,0,0,'%@','','','J','','Y','%@','%@','jobs','%@','',%@)",[ElogBooksAppDelegate getValueForKey:USER_ID],strPatrolJobId,[self ConvertDateToOriginalName:strTimeStampValue:strjid],strImageTitle,[CommonFunctions getCurrentTimeStampForDatabaseInsertion:strTimeStampValue ],UN_SYNCED_DATA ]] )
            NSLog(@"Uploaded file details stored in db");
        
        if (strPatrolJobId !=nil)
        {
            //Complete the job
            objAlert = [[MEAlertView alloc]initWithMessage:@"As this patrol has  requirement for Photo.Please select the correct option below." delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Unable to complete,Complete"];
            objAlert.tag= IMAGE_ATT_TAG;
            objAlert.delegate=self;
            [objAlert Show];
            [objAlert release];
        }
        
        
    }
    else if (strAid!=nil)
    {
        NSLog(@"%@:%@",flage,strMsg);
        [self saveImageInLocal:img_ToUpload:strImageTitle];
        if ([DataSource executeQuery:[NSString stringWithFormat:@"INSERT INTO Uploaded_files (fid,uid,cid,iid,as_id,type,doc_type,as_type,expired,reveal,orig_name,title,dir,created,expiry,IsSynced)values('TEMP_FILE_ID',%@,0,0,'%@','','','A','','Y','%@','%@','jobs','%@','',%@)",[ElogBooksAppDelegate getValueForKey:USER_ID],strAid,[self ConvertDateToOriginalName:strTimeStampValue:strAid],strImageTitle,[CommonFunctions getCurrentTimeStampForDatabaseInsertion:strTimeStampValue ],UN_SYNCED_DATA ]] )
            NSLog(@"Uploaded file details stored in db");
        
        [self.navigationController popViewControllerAnimated:YES];
        [AlertView removeFromSuperview];
    }
}

-(void)saveImageInLocal :(UIImage *)Img_ToLocal:(NSString *)Unique_imgName
{
    NSError*error;
    NSString *documentsDirectory = [NSHomeDirectory() stringByAppendingPathComponent:@"Library"];
    NSString *dataPath = @"";
    if (strIsToCreateJob!=nil)
    {
    dataPath = [documentsDirectory stringByAppendingPathComponent:NEW_JOBS_IMAGES_FOLDER];
    }
    else 
    dataPath = [documentsDirectory stringByAppendingPathComponent:UN_SYNCEDIMAGES_FOLDER];        
    if (![[NSFileManager defaultManager] fileExistsAtPath:dataPath])
        [[NSFileManager defaultManager]createDirectoryAtPath:dataPath withIntermediateDirectories:NO attributes:nil error:&error];
    NSString*strTemp = [dataPath stringByAppendingPathComponent:
                        [NSString stringWithFormat:@"%@",Unique_imgName]];
    UIImage *image  = Img_ToLocal;
    [UIImagePNGRepresentation(image) writeToFile:strTemp atomically:YES];
}

-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSLog(@"%d",buttonIndex);
    
    if(buttonIndex == 0)
    {
        //Check PhotoLibrary available or not
        if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary])
        {
            UIImagePickerController *objImgPicker = [[UIImagePickerController alloc] init];
            [objImgPicker setDelegate:self];
            [objImgPicker setAllowsEditing:NO];
            [objImgPicker setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
            [self presentModalViewController:objImgPicker animated:YES];
        }
    }
    else if(buttonIndex == 1)
    {
        //Check Camera available or not
        if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
        {
            UIImagePickerController *objImgPicker = [[UIImagePickerController alloc] init];
            [objImgPicker setDelegate:self];
            [objImgPicker setAllowsEditing:NO];
            [objImgPicker setSourceType:UIImagePickerControllerSourceTypeCamera];
            [self presentModalViewController:objImgPicker animated:YES];
        }else {
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:APP_TITLE message:@"Sorry, This device not support this feature." delegate:nil cancelButtonTitle:@"Okay" otherButtonTitles:nil];
            [alertView show];
            [alertView release];
        }
    }
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker 
{
      [picker dismissModalViewControllerAnimated:YES];
    if (strIsToCreateJob!=nil)
    {
        [self.navigationController popViewControllerAnimated:YES];
    }
}
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    
    [picker dismissModalViewControllerAnimated:YES];
       NSLog(@"Image picked from Library"); 
    NSLog(@"%@",[info allKeys]);
    NSData *imagedata = UIImageJPEGRepresentation([info objectForKey:UIImagePickerControllerOriginalImage],1);
    
    UIImage *image = [[UIImage alloc] initWithData:imagedata];
    
    //UIImage *image = [self scaleImage:_image toSize:CGSizeMake(300, 356)];
    
    int mxW = 300;
    int mxH = 356;
    
    int newW,newH;
    
    CGSize ImgSize =image.size;
    
    BOOL isResize = YES;
    
    if(ImgSize.width > mxW)
    {
        newW = mxW;
        newH = (mxW * 100) / ImgSize.width;
    }
    else if(ImgSize.height > mxH)
    {
        newH = mxH;
        newW = (mxH * 100) / ImgSize.height;
    }
    else
    {
        isResize=NO;
        
        [imgView setContentMode:UIViewContentModeCenter];
    }
    
    if (isResize) {
        CGSize newSize = CGSizeMake(newW, 400);  //whaterver size
        UIGraphicsBeginImageContext(newSize);
        [image drawInRect:CGRectMake(0, 0, newSize.width, newSize.height)];
        image = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
    }
    
    [imgView setImage:image];
    [btnUpload setEnabled:YES];
    
    img_ToUpload = imgView.image;
    [img_ToUpload retain];
    
    if (strIsToCreateJob!=nil)
    {
        strImageTitle = [CommonFunctions getUniqueName];
        strImageTitle = [strImageTitle stringByAppendingString:@".png"];
        [strImageTitle retain];
            NSLog(@"Uploaded file details stored in db");
        
      NSMutableArray *arrAttachments =(NSMutableArray *) [ElogBooksAppDelegate getValueForKey:NEW_JOB_ATTACHMENTS];
        [arrAttachments addObject:strImageTitle];
        [self saveImageInLocal:img_ToUpload :strImageTitle];
        [ElogBooksAppDelegate SetGlobalObject:arrAttachments :NEW_JOB_ATTACHMENTS];
        [self.navigationController popViewControllerAnimated:YES];
            
        
    }
    
    
    if (strPatrolJobId!=nil)
    {
        Alert_View =[CommonFunctions AlertWithMessage:@"Please wait..."];
        [self.view addSubview:Alert_View];

        [self StartPatrolOrientedTask];
    }
    
}

-(void)MarkPatrolAsDone 
{
    NSLog(@"btnOk_Tapped Clicked");
    NSString *strCurrentTimeStamp = [CommonFunctions getCurrentTimeStampForDatabaseInsertion:strTimeStampValue];
    [strCurrentTimeStamp retain];
    
    if ([strIsUNorderedPoint isEqualToString:@"YES"])
    {
        
        if (([DataSource executeQuery:[NSString stringWithFormat:@"Update Job_patrol_schedule_points SET IsSynced=%@,require_unable='N',date_complete ='%@',ManualStatusHandler='COMPLETE' where schedule_id= %@ and point_id = %@ and sort=%@",UN_SYNCED_DATA,strCurrentTimeStamp,[dicCurrentPatrolRecord objectForKey:SCHEDULE_ID],[dicCurrentPatrolRecord objectForKey:POINT_ID],[dicCurrentPatrolRecord objectForKey:JOB_PATROL_SCHEDULE_POINT_SORT]]]))
        {
            NSLog(@"record updated");
            
            if ([CommonFunctions isNetAvailable])
            {
                [self completePoint:dicCurrentPatrolRecord];
            }
            else
            {
                //no internet connection available
                if (isUploadingLastPoint)  //last point row
                {
                    //Complete Patrol
                    [self CompletePatrol:dicCurrentPatrolRecord];
                }
                else
                {
                    if (Alert_View!=nil)
                        [Alert_View removeFromSuperview];
                    [self.navigationController popViewControllerAnimated:YES];
                }
            }
        }
        else
            NSLog(@"Unable to update the record");
        
        
    }
    else {
        if (([DataSource executeQuery:[NSString stringWithFormat:@"Update Job_patrol_schedule_points SET IsSynced=%@,require_unable='N',date_complete ='%@',ManualStatusHandler='COMPLETE' where schedule_id= %@ and point_id = %@ and sort=%@",UN_SYNCED_DATA,strCurrentTimeStamp,[dicCurrentPatrolRecord objectForKey:SCHEDULE_ID],[dicCurrentPatrolRecord objectForKey:POINT_ID],[dicCurrentPatrolRecord objectForKey:JOB_PATROL_SCHEDULE_POINT_SORT]]]) && ([DataSource executeQuery:[NSString stringWithFormat:@"Update Job_patrol_schedule_points SET date_complete ='',require_unable='N',ManualStatusHandler='MISSED' where  sort < %@ and ManualStatusHandler != 'NOT_COMPLETE' and  ManualStatusHandler != 'COMPLETE' and schedule_id = %@;",[dicCurrentPatrolRecord objectForKey:JOB_PATROL_SCHEDULE_POINT_SORT],[dicCurrentPatrolRecord objectForKey:SCHEDULE_ID]]]))
        {
            NSLog(@"record updated");
            
            if ([CommonFunctions isNetAvailable])
            {
                [self completePoint:dicCurrentPatrolRecord];
            }
            else
            {
                //no internet connection available
                if (isUploadingLastPoint)  //last point row
                {
                    //Complete Patrol
                    [self CompletePatrol:dicCurrentPatrolRecord];
                }
                else
                {
                    if (Alert_View!=nil)
                        [Alert_View removeFromSuperview];
                    [self.navigationController popViewControllerAnimated:YES];
                }
            }
        }
        else
            NSLog(@"Unable to update the record");
    }
    

}
-(void)MarkPointAsUnableToComplete
{
    NSLog(@"btnUnableTocomplete Clicked");
    
    strTimeStampValue = [CommonFunctions getCurrentTimeStamp];
    NSString *strCurrentTimeStamp = [CommonFunctions getCurrentTimeStampForDatabaseInsertion:strTimeStampValue];
    [strCurrentTimeStamp retain];
    
    if ([strIsUNorderedPoint isEqualToString:@"YES"])
    {

        
        if (([DataSource executeQuery:[NSString stringWithFormat:@"Update Job_patrol_schedule_points SET IsSynced=%@,require_unable='Y',date_complete ='%@',ManualStatusHandler='NOT_COMPLETE' where schedule_id= %@ and point_id = %@ and sort = %@;",UN_SYNCED_DATA,strCurrentTimeStamp,[dicCurrentPatrolRecord objectForKey:SCHEDULE_ID],[dicCurrentPatrolRecord objectForKey:POINT_ID],[dicCurrentPatrolRecord objectForKey:JOB_PATROL_SCHEDULE_POINT_SORT]]]))
        {
            NSLog(@"record updated");
            //set current unable feature in the key of the current dictionary
            [dicCurrentPatrolRecord setObject:@"Y" forKey:@"require_unable"];
            
            if ([CommonFunctions isNetAvailable])
            {
                [self completePointForIncompletion:dicCurrentPatrolRecord];
            }
            else
            {
                
                //no internet connection available
                if (isUploadingLastPoint)
                {
                    //Complete Patrol
                    [self CompletePatrol:dicCurrentPatrolRecord];
                }
                else
                {
                    if (Alert_View!=nil)
                        [Alert_View removeFromSuperview];
                    [self.navigationController popViewControllerAnimated:YES];
                }
            }
        }
        else
            NSLog(@"Unable to update the record ");
        
        
        
        
    }
    else {
        
        if (([DataSource executeQuery:[NSString stringWithFormat:@"Update Job_patrol_schedule_points SET IsSynced=%@,require_unable='Y',date_complete ='%@',ManualStatusHandler='NOT_COMPLETE' where schedule_id= %@ and point_id = %@ and sort = %@;",UN_SYNCED_DATA,strCurrentTimeStamp,[dicCurrentPatrolRecord objectForKey:SCHEDULE_ID],[dicCurrentPatrolRecord objectForKey:POINT_ID],[dicCurrentPatrolRecord objectForKey:JOB_PATROL_SCHEDULE_POINT_SORT]]]) && ([DataSource executeQuery:[NSString stringWithFormat:@"Update Job_patrol_schedule_points SET date_complete ='',ManualStatusHandler='MISSED' where  sort < %@ and ManualStatusHandler != 'NOT_COMPLETE' and  ManualStatusHandler != 'COMPLETE' and schedule_id = %@;",[dicCurrentPatrolRecord objectForKey:JOB_PATROL_SCHEDULE_POINT_SORT],[dicCurrentPatrolRecord objectForKey:SCHEDULE_ID]]]))
        {
            NSLog(@"record updated");
            //set current unable feature in the key of the current dictionary
            [dicCurrentPatrolRecord setObject:@"Y" forKey:@"require_unable"];
            
            if ([CommonFunctions isNetAvailable])
            {
                [self completePointForIncompletion:dicCurrentPatrolRecord];
            }
            else
            {
                
                //no internet connection available
                if (isUploadingLastPoint)
                {
                    //Complete Patrol
                    [self CompletePatrol:dicCurrentPatrolRecord];
                }
                else
                {
                    if (Alert_View!=nil)
                        [Alert_View removeFromSuperview];
                    [self.navigationController popViewControllerAnimated:YES];
                }
            }
        }
        else
            NSLog(@"Unable to update the record ");
        
        
    }

    
}

- (UIImage*) scaleImage:(UIImage*)image toSize:(CGSize)newSize
{
    CGSize scaledSize = newSize;
    float scaleFactor = 1.0;
    if( image.size.width > image.size.height ) {
        scaleFactor = image.size.width / image.size.height;
        scaledSize.width = newSize.width;
        scaledSize.height = newSize.height / scaleFactor;
    }
    else {
        scaleFactor = image.size.height / image.size.width;
        scaledSize.height = newSize.height;
        scaledSize.width = newSize.width / scaleFactor;
    }
    
    UIGraphicsBeginImageContextWithOptions( scaledSize, NO, 0.0 );
    CGRect scaledImageRect = CGRectMake( 0.0, 0.0, scaledSize.width, scaledSize.height );
    [image drawInRect:scaledImageRect];
    UIImage* scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return scaledImage;
}

- (void)imagePickerController:(UIImagePickerController *)picker
        didFinishPickingImage:(UIImage *)image
                  editingInfo:(NSDictionary *)editingInfo
{
    [picker dismissModalViewControllerAnimated:YES];
    NSLog(@"Image picked from camera");
}

//Tells the delegate that the user cancelled the pick operation.

- (void)viewDidUnload
{
    strjid = nil;
    strPatrolJobId = nil;
    strAid = nil;
    strIsToCreateJob = nil;
    strIsTakePhoto=nil;
    strIsTakeCamera=nil;
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
