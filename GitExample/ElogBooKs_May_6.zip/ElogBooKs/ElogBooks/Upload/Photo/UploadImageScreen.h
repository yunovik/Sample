//
//  UploadImageScreen.h
//  ElogBooks
//
//  Created by i-Verve on 20/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PutInfoClass.h"
#import "MEAlertView.h"
#import "AddDescription.h"
@interface UploadImageScreen : UIViewController
<
UIActionSheetDelegate,
UIImagePickerControllerDelegate,
UINavigationControllerDelegate,
PutInfoDelegate,
MEAlertViewDelegate
>
{
    
    UIView *AlertView,*Alert_View;
    
    NSString *strImageTitle,*strTimeStampValue;
    
    UIImageView *imgView;
    UIButton *btnSelect,*btnUpload;
    UIImage *img_ToUpload;
    MEAlertView *objAlert;
}
@property(retain,nonatomic)NSString *strjid,*strIsUNorderedPoint;

@property(retain,nonatomic)NSString *strAid;
@property(retain,nonatomic)NSString *strPoint_id;
@property(retain,nonatomic)NSString *strOrder;
@property(retain,nonatomic)NSString *strSchedule_id;
@property (nonatomic,retain)NSString *strPatrolJobId,*strIsToCreateJob,*strIsTakePhoto,*strIsTakeCamera;;
@property (nonatomic,retain) NSMutableDictionary *dicCurrentPatrolRecord;
@property (nonatomic,assign)BOOL isUploadingLastPoint;

-(UIImage*) scaleImage:(UIImage*)image toSize:(CGSize)newSize;
-(void)saveImageInLocal :(UIImage *)Img_ToLocal:(NSString *)Unique_imgName;
@end
