//
//  UploadFile.m
//  ElogBooks
//
//  Created by i-Verve on 26/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import "UploadFile.h"

@interface UploadFile ()

@end

@implementation UploadFile

@synthesize strPath;

- (void)viewDidLoad
{
    
    //NSString *currentpath;
    int count;
    
    int i;
    
    
    filemgr = [NSFileManager defaultManager];
    
    if ([strPath length]<=0) {
        strPath=@"/";
    }
    else
    {
        
    }
    
    [CommonFunctions setBack:self target:@selector(btnBackTapped:)];

    [CommonFunctions setTitleView:self amdtitle:@"Upload File"];
    
    //Back Button On Navigation

    arrFilesNFolders = [[NSMutableArray alloc] init];

    NSArray *_tmpArr = [[NSArray alloc] init];
    
    _tmpArr = [filemgr contentsOfDirectoryAtPath:strPath error: nil];
    
    count = [_tmpArr count];
    
    
    for (i = 0; i < count; i++){
        [arrFilesNFolders addObject:[_tmpArr objectAtIndex:i]];
    }
    
    //    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Files" message:[arrFilesNFolders description] delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    //    [alertView show];
    
    tblFilesFolders = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, 320, 416)];
    [tblFilesFolders setDelegate:self];
    [tblFilesFolders setDataSource:self];
    [self.view addSubview:tblFilesFolders];
    
    
    [tblFilesFolders setBackgroundColor:[UIColor clearColor]];
//    [self.view setBackgroundColor:getImageColor(@"Default.png")];
    [self.view setBackgroundColor:[UIColor whiteColor]];

    CELL_HEIGHT=61;
    
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}


#pragma mark -
#pragma mark -buttonTapped Method

-(IBAction)btnBackTapped:(id)sender
{
    
    [self.navigationController popViewControllerAnimated:YES];
    //[self dismissModalViewControllerAnimated:YES];
}



#pragma mark -
#pragma mark - Table view data source

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    
    return strPath;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *CellIdentifier = [NSString stringWithFormat:@"Cel_%d",indexPath.row];
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if(cell == nil) {
        
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] ;
        
        cell.selectionStyle = UITableViewCellSelectionStyleBlue;
        [cell.contentView setBackgroundColor:getImageColor(@"Cell_Stripe.png")];   

        
        NSString *strContrnt = [arrFilesNFolders objectAtIndex:indexPath.row];
        
        NSLog(@"%s",[filemgr fileSystemRepresentationWithPath:[NSString stringWithFormat:@"%@/%@",strPath,strContrnt]]);
        
        NSArray *_tmpArr = [[NSArray alloc] init];
        _tmpArr = [filemgr contentsOfDirectoryAtPath:[NSString stringWithFormat:@"%@/%@",strPath,strContrnt] error: nil];

        
        UIImageView *imgIcon = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, CELL_HEIGHT, CELL_HEIGHT)];
        UILabel *lblName = [[UILabel alloc] initWithFrame:CGRectMake(67, 0, 253, CELL_HEIGHT)];

        
        BOOL isDir;
        BOOL fileExists = [filemgr fileExistsAtPath:[NSString stringWithFormat:@"%@/%@",strPath,strContrnt] isDirectory:&isDir];
        
        if (fileExists)
        {
            
            if (isDir) {
                
                NSLog(@"Folder already exists...");
                [imgIcon setImage:[UIImage imageNamed:@"FFolder.png"]];
                
                lblName.text = [NSString stringWithFormat:@"%@ (%d)",strContrnt,_tmpArr.count];

                //[cell setAccessoryType:UITableViewCellAccessoryDetailDisclosureButton];
                
            }else {
                lblName.text =strContrnt;

                [imgIcon setImage:[UIImage imageNamed:@"FFile.png"]];
                
                //[cell setAccessoryType:UITableViewCellAccessoryNone];
                
                cell.selectionStyle = UITableViewCellSelectionStyleNone;

            }
        }
        
        [imgIcon setContentMode:UIViewContentModeCenter];
        [cell.contentView addSubview:imgIcon];
        
        

        
        lblName.backgroundColor = [UIColor clearColor];
        lblName.numberOfLines = 0;
        [lblName setFont:FONT_NEUE_SIZE(12)];
        [lblName setTextColor:DEFAULT_FONT_COLOR];
        [cell.contentView addSubview:lblName];
        [lblName release];
        
        UIView *selectedView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 61)];
        [selectedView setBackgroundColor:getImageColor(@"Cell_Stripe_Sel.png")];
        [cell setSelectedBackgroundView:selectedView];

        
    }
    
    return cell;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
    return [arrFilesNFolders count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return CELL_HEIGHT;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSString *strContrnt = [arrFilesNFolders objectAtIndex:indexPath.row];

    BOOL isDir;
    BOOL fileExists = [filemgr fileExistsAtPath:[NSString stringWithFormat:@"%@/%@",strPath,strContrnt] isDirectory:&isDir];
    
    if (fileExists)
    {
        
        if (isDir) {
            
            NSLog(@"Folder already exists...");
            UploadFile *objNav = [[UploadFile alloc] initWithNibName:@"UploadFile" bundle:nil];
            if ([strPath isEqualToString:@"/"]) {
                objNav.strPath = [NSString stringWithFormat:@"%@%@",strPath,strContrnt];    
            }else {
                objNav.strPath = [NSString stringWithFormat:@"%@/%@",strPath,strContrnt];
            }
            
            
            [self.navigationController pushViewController:objNav animated:YES];

        }else {
            
            
            NSData *data = [NSData dataWithContentsOfFile:[NSString stringWithFormat:@"%@/%@",strPath,strContrnt]];
            
            NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
            NSString *documentsDirectory = [paths objectAtIndex:0];
            
            NSFileManager *fileManager = [NSFileManager defaultManager];
            [fileManager fileExistsAtPath:documentsDirectory];

            NSString*imagePath = [documentsDirectory stringByAppendingPathComponent:
                                  strContrnt];
            
            if([data writeToFile:imagePath atomically:YES])
                NSLog(@"Image Saved!!");
            else
                NSLog(@"Not  Saved!!");
            
            
            UIAlertView *alertView = [[UIAlertView alloc] 
                                      initWithTitle:APP_TITLE 
                                      message:[NSString stringWithFormat:@"Would you like to upload %@ file?",strContrnt] 
                                      delegate:nil
                                      cancelButtonTitle:@"No" 
                                      otherButtonTitles:@"Yes", nil];
            [alertView show];
            [alertView release];
        }
    }

}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end