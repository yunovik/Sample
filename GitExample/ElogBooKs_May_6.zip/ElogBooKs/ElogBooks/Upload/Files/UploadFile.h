//
//  UploadFile.h
//  ElogBooks
//
//  Created by i-Verve on 26/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UploadFile : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    
    NSFileManager *filemgr;
    
    NSMutableArray *arrFilesNFolders;
    
    NSString *strPath;
    
    UITableView *tblFilesFolders;
    
    int CELL_HEIGHT;
}

@property(retain,nonatomic)NSString *strPath;
@end
