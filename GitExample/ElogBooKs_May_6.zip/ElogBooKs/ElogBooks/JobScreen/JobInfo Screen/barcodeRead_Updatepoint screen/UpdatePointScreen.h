//
//  UpdatePointScreen.h
//  ElogBooks
//
//  Created by iphone on 13/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZBarSDK.h"
#import "MEAlertView.h"
@interface UpdatePointScreen : UIViewController<UIImagePickerControllerDelegate,UINavigationControllerDelegate,ZBarReaderDelegate,MEAlertViewDelegate,PutInfoDelegate>
{
    UIView *alert_View;
    UIImageView *imgView;
    UILabel *lblCodeNumber;
    UIButton *btnUnableToupload;
    NSString *strScannedCode;
    MEAlertView    *objAlert;
    NSString *strCurrentTimeStamp;
    PutInfoClass *objService;
}
-(void)saveBarcode : (NSString *)strCode;
-(void)btnUploadTapped:(id)sender;

@property (nonatomic,retain)NSString *strJid,*strPatrolJobId,*strIsCreatingJob,*strRequiredBarcode,*strIsUNorderedPoint;
@property (nonatomic,retain)NSMutableDictionary *dicPatrolPointRecord;
@property (nonatomic,assign)BOOL isUploadingLastPoint;
@end
