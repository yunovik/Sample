//
//  UpdatePointScreen.m
//  ElogBooks
//
//  Created by iphone on 13/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import "UpdatePointScreen.h"
#import "ZBarSDK.h"
#import "MEAlertView.h"
#import "AddDescription.h"
@interface UpdatePointScreen ()

@end

@implementation UpdatePointScreen
@synthesize strJid,dicPatrolPointRecord,isUploadingLastPoint,strPatrolJobId,strIsCreatingJob,strRequiredBarcode,strIsUNorderedPoint;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    
    UIView *backView = [[[UIView alloc] init] autorelease];
    backView.frame = CGRectMake(0, 0, 320, 61);
    backView.backgroundColor = getImageColor(@"Cell_Stripe.png");
    [self.view addSubview:backView];
    
    
    UILabel *lblLocation = [[UILabel alloc]initWithFrame:CGRectMake(10, 10 ,230, 20)];
    lblLocation.backgroundColor = [UIColor clearColor];
    [lblLocation setFont:FONT_NEUE_BOLD_SIZE(14) ];
    [lblLocation setTextColor:DEFAULT_FONT_COLOR];
    NSString *Strlocation = @"";
    
    
    if (strIsCreatingJob== nil)
    {
    if (strJid !=nil)
        Strlocation = [DataSource getStringFromQuery: [NSString stringWithFormat:@"select location from jobs where jid ='%@'",strJid]];
    else
        Strlocation = [dicPatrolPointRecord valueForKey:JOBS_LOCATION];
    if ([Strlocation length]>0)
    [lblLocation setText: [NSString stringWithFormat:@"Location: %@",Strlocation]];
    else 
    [lblLocation setText: [NSString stringWithFormat:@"Location: Not Available"]];        
    [backView addSubview:lblLocation];
    [lblLocation release];
    }
    
    if (dicPatrolPointRecord!=nil)
    {
        UILabel *lblTime = [[UILabel alloc]initWithFrame:CGRectMake(260, 10 ,50, 20)];
        lblTime.backgroundColor = [UIColor clearColor];
        [lblTime setFont:FONT_NEUE_BOLD_SIZE(14) ];
        [lblTime setTextColor:DEFAULT_FONT_COLOR];
        [lblTime setText: [dicPatrolPointRecord valueForKey:@"start_time"]];
        [backView addSubview:lblTime];
        [lblTime release];
        
        
        UILabel *lblTimeAlloted = [[UILabel alloc]initWithFrame:CGRectMake(10, 28 ,230, 20)];
        lblTimeAlloted.backgroundColor = [UIColor clearColor];
        [lblTimeAlloted setFont:FONT_NEUE_SIZE(14) ];
        [lblTimeAlloted setTextColor:DEFAULT_FONT_COLOR];
        [lblTimeAlloted setText: [NSString stringWithFormat:@"Time alloted: %@ mins",[dicPatrolPointRecord valueForKey: @"time_allowed"]]];
        [backView addSubview:lblTimeAlloted];
        [lblTimeAlloted release];
    }
    
    UILabel *lblDescription = [[UILabel alloc]initWithFrame:CGRectMake(10, 70,300, 40)];
    lblDescription.backgroundColor = [UIColor clearColor];
    [lblDescription setFont:FONT_NEUE_SIZE(12) ];
    [lblDescription setTextColor:[UIColor redColor]];
    [lblDescription setNumberOfLines:2];
//    strRequiredBarcode
    if (dicPatrolPointRecord!=nil)
        [lblDescription setText:@"This patrol point requires a barcode to be scanned before it can be marked as done"];
    else if (strJid!=nil)
        [lblDescription setText:@"This Job requires a barcode to be scanned before it can be marked as done"];
    else if (strIsCreatingJob!=nil)
        [lblDescription setText:@"Please scan a Barcode"];
    [self.view addSubview:lblDescription];
    [lblDescription release];
    
    if(strRequiredBarcode.length>0)
    {
        UILabel *lblRequiredBarcode = [[UILabel alloc]initWithFrame:CGRectMake(10, 95,300, 40)];
        lblRequiredBarcode.backgroundColor = [UIColor clearColor];
        [lblRequiredBarcode setFont:FONT_NEUE_SIZE(12) ];
        [lblRequiredBarcode setTextColor:[UIColor redColor]];
        [lblRequiredBarcode setNumberOfLines:2];
        [lblRequiredBarcode setText:[NSString stringWithFormat:@"Require Barcode : %@",strRequiredBarcode]];
        [self.view addSubview:lblRequiredBarcode];
        [lblRequiredBarcode release];

    }
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    
    UIImageView *imgBack = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, screenBounds.size.width, screenBounds.size.height)];
    [imgBack setImage:[UIImage imageNamed:@"Default-568h@2x.png"]];
    [self.view addSubview:imgBack];
    [self.view sendSubviewToBack:imgBack];
    
    UIButton  *btnScan = [CommonFunctions buttonWithTitle:@"Scan Barcode" andFrame:CGRectMake(10, 130, 120, 33)];
    [btnScan addTarget:self action:@selector(btnScanTapped:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btnScan];
    
//    UIButton *btnScan = [[UIButton alloc]init];
//    [btnScan setImage:[UIImage imageNamed:@"scanButton.png"] forState:UIControlStateNormal];
//    [btnScan setFrame:CGRectMake(10, 115, 90, 33)];
//    [btnScan addTarget:self action:@selector(btnScanTapped:) forControlEvents:UIControlEventTouchUpInside];
//    [self.view addSubview:btnScan];
    
    imgView = [[UIImageView alloc]initWithFrame:CGRectMake(10, 170, 300, 200)];
    [imgView.layer setBorderColor:[[UIColor blackColor]CGColor]];
    [imgView.layer setBorderWidth:1.3];
    [self.view addSubview:imgView];
    
    UIButton  *btnCancel = [CommonFunctions buttonWithTitle:@"Cancel" andFrame:CGRectMake(10, 376, 60, 20)];
    [btnCancel addTarget:self action:@selector(btnBackTapped:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btnCancel];
    
    btnUnableToupload = [CommonFunctions buttonWithTitle:@"Unable to scan barcode" andFrame:CGRectMake(125, 376, 185, 30)];
    [btnUnableToupload addTarget:self action:@selector(btnUnableTouploadTapped:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btnUnableToupload];
    
    
    [CommonFunctions setBack:self target:@selector(btnBackTapped:)];
    
    //static
    //      [btnUpload setEnabled:YES];
    [super viewDidLoad];
    
    // Do any additional setup after loading the view from its nib.
}
-(IBAction)btnBackTapped:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
-(IBAction)btnScanTapped:(id)sender
{
    
//    [lblCodeNumber setText:@""];
    ZBarReaderViewController *reader = [ZBarReaderViewController new];
    reader.readerDelegate = self;
    reader.supportedOrientationsMask = ZBarOrientationMaskAll;
    reader.editing=YES;
    
    ZBarImageScanner *scanner = reader.scanner;
    [scanner setSymbology: ZBAR_I25
                   config: ZBAR_CFG_ENABLE
                       to: 0];
    
    [self presentModalViewController: reader
                            animated: YES];
}

- (void) imagePickerController: (UIImagePickerController*) reader didFinishPickingMediaWithInfo: (NSDictionary*) info
{
    // ADD: get the decode results
    
    id<NSFastEnumeration> results =
    [info objectForKey: ZBarReaderControllerResults];
    ZBarSymbol *symbol = nil;
    for(symbol in results)
        // EXAMPLE: just grab the first barcode
        break;
    
    [imgView setImage:[info objectForKey:UIImagePickerControllerOriginalImage]];
    NSLog(@"%@",info);
    [reader dismissModalViewControllerAnimated: YES];
    strScannedCode = symbol.data;
    [strScannedCode retain];
    
    if ([strScannedCode length]>0)
    {
        [self BarCodeScanned];
    }
    else 
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:APP_TITLE message:@"Please select unable to scan Barcode!" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        [alert show];
        [alert release];  
    }
}

-(void)BarCodeScanned
{
    if (strJid !=nil) //update from job_info
    {
        if ([DataSource executeQuery:[NSString stringWithFormat:@"update Assets set barcode ='%@' where aid in (select aid from jobs where jid = '%@')",strScannedCode,strJid]])
            NSLog(@"Barcode value updated in local");
        [self.navigationController popViewControllerAnimated:YES];
    }
    else if (dicPatrolPointRecord !=nil)
    {

      if ([strScannedCode caseInsensitiveCompare:strRequiredBarcode] == NSOrderedSame)
      {
          
          alert_View = [CommonFunctions AlertWithMessage:@"Please wait..."];
          
          [self.view addSubview:alert_View];
          
            strCurrentTimeStamp = [CommonFunctions getCurrentTimeStampForDatabaseInsertion];
            [strCurrentTimeStamp retain];
          
          if ([strIsUNorderedPoint isEqualToString:@"YES"])
          {
             
              
              
              if (([DataSource executeQuery:[NSString stringWithFormat:@"Update Job_patrol_schedule_points SET barcode='%@',IsSynced=%@,require_unable='N',date_complete ='%@',ManualStatusHandler='COMPLETE' where schedule_id= %@ and point_id = %@ and sort=%@",strScannedCode,UN_SYNCED_DATA,strCurrentTimeStamp,[dicPatrolPointRecord objectForKey:SCHEDULE_ID],[dicPatrolPointRecord objectForKey:POINT_ID],[dicPatrolPointRecord objectForKey:JOB_PATROL_SCHEDULE_POINT_SORT]]]))
              {
                  NSLog(@"record updated");
                  
                  if ([CommonFunctions isNetAvailable])
                  {
                      [self completePoint:dicPatrolPointRecord];
                  }
                  else
                  {
                      
                      
                      //no internet connection available
                      if (isUploadingLastPoint)  //last point row
                      {
                          //Complete Patrol
                          [self CompletePatrol:dicPatrolPointRecord];
                      }
                      else
                      {
                          if (alert_View!=nil)
                              [alert_View removeFromSuperview];
                          [self.navigationController popViewControllerAnimated:YES];
                      }
                  }
              }
              else
              {
                  NSLog(@"Unable to update the record");
              }
              
              
              
              
          }
          else 
          {
              if (([DataSource executeQuery:[NSString stringWithFormat:@"Update Job_patrol_schedule_points SET barcode='%@',IsSynced=%@,require_unable='N',date_complete ='%@',ManualStatusHandler='COMPLETE' where schedule_id= %@ and point_id = %@ and sort=%@",strScannedCode,UN_SYNCED_DATA,strCurrentTimeStamp,[dicPatrolPointRecord objectForKey:SCHEDULE_ID],[dicPatrolPointRecord objectForKey:POINT_ID],[dicPatrolPointRecord objectForKey:JOB_PATROL_SCHEDULE_POINT_SORT]]]) && ([DataSource executeQuery:[NSString stringWithFormat:@"Update Job_patrol_schedule_points SET date_complete ='',require_unable='N',ManualStatusHandler='MISSED' where  sort < %@ and ManualStatusHandler != 'NOT_COMPLETE' and  ManualStatusHandler != 'COMPLETE' and schedule_id = %@;",[dicPatrolPointRecord objectForKey:JOB_PATROL_SCHEDULE_POINT_SORT],[dicPatrolPointRecord objectForKey:SCHEDULE_ID]]]))
              {
                  NSLog(@"record updated");
                  
                  if ([CommonFunctions isNetAvailable])
                  {
                      [self completePoint:dicPatrolPointRecord];
                  }
                  else
                  {
                      
                      
                      //no internet connection available
                      if (isUploadingLastPoint)  //last point row
                      {
                          //Complete Patrol
                          [self CompletePatrol:dicPatrolPointRecord];
                      }
                      else
                      {
                          if (alert_View!=nil)
                              [alert_View removeFromSuperview];
                          [self.navigationController popViewControllerAnimated:YES];
                      }
                  }
              }
              else
              {
                  NSLog(@"Unable to update the record");
              }      
          }
        
        
      }
      else 
      {
          UIAlertView *alert = [[UIAlertView alloc] initWithTitle:APP_TITLE message:@"Scanned Value Mismatched !\n Please try again !" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
          [alert show];
          [alert release];  
      }
        
    }
    else if (strIsCreatingJob != nil)
    {
        [ElogBooksAppDelegate SetGlobalObject:strScannedCode :BARCODE_FOR_NEW_JOB];
        [self.navigationController popViewControllerAnimated:YES];
    }
}

-(void)btnUnableTouploadTapped:(id)sender
{

    if (strJid!=nil)
    {
        [self.navigationController popViewControllerAnimated:YES]; 
    }
    else  if (dicPatrolPointRecord!=nil)
    {
    //    //missed.png
        alert_View = [CommonFunctions AlertWithMessage:@"Please wait...."];
        [self.view addSubview:alert_View];
    NSLog(@"btnUnableTocomplete Clicked");
    strCurrentTimeStamp = [CommonFunctions getCurrentTimeStampForDatabaseInsertion];
    [strCurrentTimeStamp retain];
        
   if ([strIsUNorderedPoint isEqualToString: @"YES"])
   {
    
       if (([DataSource executeQuery:[NSString stringWithFormat:@"Update Job_patrol_schedule_points SET IsSynced=%@,require_unable='Y',date_complete ='%@',ManualStatusHandler='NOT_COMPLETE' where schedule_id= %@ and point_id = %@ and sort = %@;",UN_SYNCED_DATA,strCurrentTimeStamp,[dicPatrolPointRecord objectForKey:SCHEDULE_ID],[dicPatrolPointRecord objectForKey:POINT_ID],[dicPatrolPointRecord objectForKey:JOB_PATROL_SCHEDULE_POINT_SORT]]]) )
       {
           NSLog(@"record updated");
           //set current unable feature in the key of the current dictionary
           [dicPatrolPointRecord setObject:@"Y" forKey:@"require_unable"];
           if ([CommonFunctions isNetAvailable])
           {
               [self completePointForIncompletion:dicPatrolPointRecord];
           }
           else
           {
               //no internet connection available
               if (isUploadingLastPoint)
               {
                   //Complete Patrol
                   [self CompletePatrol:dicPatrolPointRecord];
               }
               else
               {
                   if (alert_View!=nil)
                       [alert_View removeFromSuperview];
                   [self.navigationController popViewControllerAnimated:YES];
               }
           }
       }
       else
           NSLog(@"Unable to update the record ");
       
       
       
   }
   else 
   {
       
       
       if (([DataSource executeQuery:[NSString stringWithFormat:@"Update Job_patrol_schedule_points SET IsSynced=%@,require_unable='Y',date_complete ='%@',ManualStatusHandler='NOT_COMPLETE' where schedule_id= %@ and point_id = %@ and sort = %@;",UN_SYNCED_DATA,strCurrentTimeStamp,[dicPatrolPointRecord objectForKey:SCHEDULE_ID],[dicPatrolPointRecord objectForKey:POINT_ID],[dicPatrolPointRecord objectForKey:JOB_PATROL_SCHEDULE_POINT_SORT]]]) && ([DataSource executeQuery:[NSString stringWithFormat:@"Update Job_patrol_schedule_points SET date_complete ='',ManualStatusHandler='MISSED' where  sort < %@ and ManualStatusHandler != 'NOT_COMPLETE' and  ManualStatusHandler != 'COMPLETE' and schedule_id = %@;",[dicPatrolPointRecord objectForKey:JOB_PATROL_SCHEDULE_POINT_SORT],[dicPatrolPointRecord objectForKey:SCHEDULE_ID]]]))
       {
           NSLog(@"record updated");
           //set current unable feature in the key of the current dictionary
           [dicPatrolPointRecord setObject:@"Y" forKey:@"require_unable"];
           if ([CommonFunctions isNetAvailable])
           {
               [self completePointForIncompletion:dicPatrolPointRecord];
           }
           else
           {
               //no internet connection available
               if (isUploadingLastPoint)
               {
                   //Complete Patrol
                   [self CompletePatrol:dicPatrolPointRecord];
               }
               else
               {
                   if (alert_View!=nil)
                       [alert_View removeFromSuperview];
                   [self.navigationController popViewControllerAnimated:YES];
               }
           }
       }
       else
           NSLog(@"Unable to update the record ");
       
   }
        

}
    else if (strIsCreatingJob != nil)
    {
        [self.navigationController popViewControllerAnimated:YES];
    }
}

//-(void)saveBarcode:(NSString *)strCode
//{
//    
//    
//    //    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
//    //    NSString *documentsDirectory = [paths objectAtIndex:0];
//    //    NSString *dataPath = [documentsDirectory stringByAppendingPathComponent:@"files"];
//    //    dataPath = [dataPath stringByAppendingString:@"Barcode"];
//    //
//    //
//    //    NSError *error;
//    //    if (![[NSFileManager defaultManager] fileExistsAtPath:dataPath])
//    //        [[NSFileManager defaultManager] createDirectoryAtPath:dataPath withIntermediateDirectories:NO attributes:nil error:&error];
//    //
//    //    if (![[NSFileManager defaultManager] fileExistsAtPath:dataPath])
//    //        [[NSFileManager defaultManager] createDirectoryAtPath:dataPath withIntermediateDirectories:NO attributes:nil error:&error];
//    //
//    //    NSLog(@"%@",dataPath);
//    //    NSString *strPath =[dataPath stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.png",strCode]];
//    //    NSData *imageData = UIImagePNGRepresentation(imgView.image);
//    //    NSFileManager *fileManager = [NSFileManager defaultManager];
//    //    [fileManager createFileAtPath:strPath contents:imageData attributes:nil];
//    
//    if (strJid !=nil) //update from job_info
//    {
//        if ([DataSource executeQuery:[NSString stringWithFormat:@"update Assets set barcode ='%@' where aid in (select aid from jobs where jid = %@)",strCode,strJid]])
//            NSLog(@"Barcode value updated in local");
//        [self.navigationController popViewControllerAnimated:YES];
//    }
//    else if (dicPatrolPointRecord !=nil)
//    {
//        //Complete the job
//        objAlert = [[MEAlertView alloc]initWithMessage:@"As this patrol has  requirement for Barcode.Please select the correct option below." delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Unable to complete,Complete"];
//        objAlert.tag= BARCODE_ATT_TAG;
//        objAlert.delegate=self;
//        [objAlert Show];
//        [objAlert release];
//    }
//    
//}

-(IBAction)btnUnableTocomplete:(UIButton *)Sender andTag:(int)alertTag
{
    //    //missed.png
    NSLog(@"btnUnableTocomplete Clicked");
    strCurrentTimeStamp = [CommonFunctions getCurrentTimeStampForDatabaseInsertion];
    [strCurrentTimeStamp retain];
    if (([DataSource executeQuery:[NSString stringWithFormat:@"Update Job_patrol_schedule_points SET IsSynced=%@,require_unable='Y',date_complete ='%@',ManualStatusHandler='NOT_COMPLETE' where schedule_id= %@ and point_id = %@ and sort = %@;",UN_SYNCED_DATA,strCurrentTimeStamp,[dicPatrolPointRecord objectForKey:SCHEDULE_ID],[dicPatrolPointRecord objectForKey:POINT_ID],[dicPatrolPointRecord objectForKey:JOB_PATROL_SCHEDULE_POINT_SORT]]]) && ([DataSource executeQuery:[NSString stringWithFormat:@"Update Job_patrol_schedule_points SET date_complete ='',ManualStatusHandler='MISSED' where  sort < %@ and ManualStatusHandler != 'NOT_COMPLETE' and  ManualStatusHandler != 'COMPLETE' and schedule_id = %@;",[dicPatrolPointRecord objectForKey:JOB_PATROL_SCHEDULE_POINT_SORT],[dicPatrolPointRecord objectForKey:SCHEDULE_ID]]]))
    {
        NSLog(@"record updated");
        //set current unable feature in the key of the current dictionary
        [dicPatrolPointRecord setObject:@"Y" forKey:@"require_unable"];
        
        if ([CommonFunctions isNetAvailable])
        {
            [self completePointForIncompletion:dicPatrolPointRecord];
        }
        else
        {
            
            //no internet connection available
            if (isUploadingLastPoint)
            {
                //Complete Patrol
                [self CompletePatrol:dicPatrolPointRecord];
            }
            else
            {
                [self.navigationController popViewControllerAnimated:YES];
            }
        }
    }
    else
        NSLog(@"Unable to update the record ");
}
-(IBAction)btnOk_Tapped:(UIButton *)Sender andTag:(int)alertTag
{
    NSLog(@"btnOk_Tapped Clicked");
    strCurrentTimeStamp = [CommonFunctions getCurrentTimeStampForDatabaseInsertion];
    [strCurrentTimeStamp retain];
    if (([DataSource executeQuery:[NSString stringWithFormat:@"Update Job_patrol_schedule_points SET barcode='%@',IsSynced=%@,require_unable='N',date_complete ='%@',ManualStatusHandler='COMPLETE' where schedule_id= %@ and point_id = %@ and sort=%@",strScannedCode,UN_SYNCED_DATA,strCurrentTimeStamp,[dicPatrolPointRecord objectForKey:SCHEDULE_ID],[dicPatrolPointRecord objectForKey:POINT_ID],[dicPatrolPointRecord objectForKey:JOB_PATROL_SCHEDULE_POINT_SORT]]]) && ([DataSource executeQuery:[NSString stringWithFormat:@"Update Job_patrol_schedule_points SET date_complete ='',require_unable='N',ManualStatusHandler='MISSED' where  sort < %@ and ManualStatusHandler != 'NOT_COMPLETE' and  ManualStatusHandler != 'COMPLETE' and schedule_id = %@;",[dicPatrolPointRecord objectForKey:JOB_PATROL_SCHEDULE_POINT_SORT],[dicPatrolPointRecord objectForKey:SCHEDULE_ID]]]))
    {
        NSLog(@"record updated");
        
        if ([CommonFunctions isNetAvailable])
        {
            [self completePoint:dicPatrolPointRecord];
        }
        else
        {
            //no internet connection available
            if (isUploadingLastPoint)  //last point row
            {
                //Complete Patrol
                [self CompletePatrol:dicPatrolPointRecord];
            }
            else
            {
                [self.navigationController popViewControllerAnimated:YES];
            }
        }
    }
    else
        NSLog(@"Unable to update the record");
}
-(IBAction)btnCancel_Tapped:(UIButton *)Sender andTag:(int)alertTag
{
    
}

#pragma mark Parsing Delegates
#pragma mark Parsing delegates
-(void)filedWithError:(NSString *)strMsg forFlage:(NSString *)flage
{
    if (isUploadingLastPoint)
        [self CompletePatrol:dicPatrolPointRecord];
    else
        [self.navigationController popViewControllerAnimated:YES];
}
-(void)EndParsingArray:(NSMutableArray *)arrData forFlage:(NSString *)flage
{
    NSLog(@"%@",[arrData description]);
    //    If success remove set Issynced to 1
    
    
    
    if ([arrData count]>0)
    {
        if (!([[arrData objectAtIndex:0]rangeOfString:@"Success"].location==NSNotFound))
        {
            if ([flage length]>0) // if success
            {
                NSArray *arrIdValues = [flage componentsSeparatedByString:@":"];
                NSString *strPointId=[arrIdValues objectAtIndex:1];
                NSString *strScheduleId=[arrIdValues objectAtIndex:3];
                NSString *strSortValue=[arrIdValues objectAtIndex:3];
                if ([DataSource executeQuery:[NSString stringWithFormat:@"update Job_patrol_schedule_points set IsSynced=%@ where schedule_id=%@ and point_id=%@ and sort=%@",SYNCED_DATA,strScheduleId,strPointId,strSortValue]])
                    NSLog(@"pointId :%@ synced from webservice to local",strPointId);
                else
                    NSLog(@"pointId :%@  not synced",strPointId);
            }
        }
    }
    
    if (isUploadingLastPoint)
        [self CompletePatrol:dicPatrolPointRecord];
    else
    {
        if (alert_View!=nil)
            [alert_View removeFromSuperview];
        [self.navigationController popViewControllerAnimated:YES];
    }
}

#pragma mark CompletePointforIncompletion
-(void)completePointForIncompletion:(NSMutableDictionary *)dicCurrentRecord
{
    objService=[[PutInfoClass alloc] init];
    objService._delegate=self;
    objService.retType=isArray;
    NSMutableDictionary *dicc=[[[NSMutableDictionary alloc] init]autorelease];
    [dicc setObject:[ElogBooksAppDelegate getValueForKey:USER_ID] forKey:USER_ID];
    [dicc setObject:@"patrol_point" forKey:@"UpdateType"];
    [dicc setObject:@"Update" forKey:@"qd"];
    [dicc setObject: [CommonFunctions getCurrentTimeStamp:strCurrentTimeStamp] forKey:@"tstamp"];
    [dicc setObject:strPatrolJobId forKey:JOBS_ID];
    
    //    if (strScannedCode!=nil)
    //        [dicc setObject:strScannedCode  forKey:SCHEDULE_BARCODE];
    [dicc setObject:[dicCurrentRecord objectForKey:POINT_ID]  forKey:POINT_ID];
    [dicc setObject:[dicCurrentRecord objectForKey:SCHEDULE_ID]  forKey:SCHEDULE_ID];
    [dicc setObject:[dicCurrentRecord objectForKey:JOB_PATROL_SCHEDULE_POINT_SORT]  forKey:@"order"];
    [dicc setObject:[dicCurrentRecord objectForKey:JOB_PATROL_SCHEDULE_POINT_REQUIRE_UNABLE]  forKey:@"unable"];
    
    
    objService.argsDic=[CommonFunctions getDicAsParameter:dicc] ;
    //point_id-->1 ===SCHEDULE_ID-->3 ====sort-->5
    objService.strWebService=[NSString stringWithFormat:@"point_id:%@:schedule_id:%@:sort:%@",[dicCurrentRecord objectForKey:POINT_ID],[dicCurrentRecord objectForKey:SCHEDULE_ID],[dicCurrentRecord objectForKey:JOB_PATROL_SCHEDULE_POINT_SORT]];
    objService.strUrl= [NSString stringWithFormat:@"%@%@",[ElogBooksAppDelegate getValueForKey:BASE_URL],PUT_INFO_API];
    objService.ParentNode=@"Responses";
    objService.ChildNode=@"Response";
    [objService performSelector:@selector(setArray) withObject:nil afterDelay:0.1];
}


#pragma mark completePoint
-(void)completePoint:(NSMutableDictionary *)dicCurrentRecord
{
    /*http://code.elogbooks.co.uk/users/jack/WOM/api/put-info.php?uid=38&UpdateType=patrol_point&qd=Update&tstamp=27/12/2012%2018:35:20&jid=7811&point_id=50&order=3&schedule_id=240&unable=N */
    
    
    
    objService=[[PutInfoClass alloc] init];
    objService._delegate=self;
    objService.retType=isArray;
    NSMutableDictionary *dicc=[[[NSMutableDictionary alloc] init]autorelease];
    [dicc setObject:[ElogBooksAppDelegate getValueForKey:USER_ID] forKey:USER_ID];
    [dicc setObject:@"patrol_point" forKey:@"UpdateType"];
    [dicc setObject:@"Update" forKey:@"qd"];
    [dicc setObject: [CommonFunctions getCurrentTimeStamp:strCurrentTimeStamp] forKey:@"tstamp"];
    [dicc setObject:strPatrolJobId forKey:JOBS_ID];
    
    if (strScannedCode!=nil)
        [dicc setObject:strScannedCode  forKey:SCHEDULE_BARCODE];
    [dicc setObject:[dicCurrentRecord objectForKey:POINT_ID]  forKey:POINT_ID];
    [dicc setObject:[dicCurrentRecord objectForKey:SCHEDULE_ID]  forKey:SCHEDULE_ID];
    [dicc setObject:[dicCurrentRecord objectForKey:JOB_PATROL_SCHEDULE_POINT_SORT]  forKey:@"order"];
    [dicc setObject:[dicCurrentRecord objectForKey:JOB_PATROL_SCHEDULE_POINT_REQUIRE_UNABLE]  forKey:@"unable"];
    
    
    objService.argsDic=[CommonFunctions getDicAsParameter:dicc] ;
    //point_id-->1 ===SCHEDULE_ID-->3 ====sort-->5
    objService.strWebService=[NSString stringWithFormat:@"point_id:%@:schedule_id:%@:sort:%@",[dicCurrentRecord objectForKey:POINT_ID],[dicCurrentRecord objectForKey:SCHEDULE_ID],[dicCurrentRecord objectForKey:JOB_PATROL_SCHEDULE_POINT_SORT]];
    objService.strUrl= [NSString stringWithFormat:@"%@%@",[ElogBooksAppDelegate getValueForKey:BASE_URL],PUT_INFO_API];
    objService.ParentNode=@"Responses";
    objService.ChildNode=@"Response";
    [objService performSelector:@selector(setArray) withObject:nil afterDelay:0.1];
    
    
}

#pragma mark CompletePatrol
-(void)CompletePatrol:(NSMutableDictionary *)dicSelected
{
    //update the schedule as unsynced
    //Check whether any unsynced point exists ,if yes then set schedule_id as unsynced
    //select COUNT(Job_patrol_schedule_points.point_id) from Jobs join Job_patrol_schedules on Jobs.jid = Job_patrol_schedules.jid join Job_patrol_schedule_points on Job_patrol_schedule_points.schedule_id=Job_patrol_schedules.schedule_id where jobs.jid=7798 and Job_patrol_schedule_points.IsSynced=0
    
    
    int UnsyncedDatacount =  [[DataSource getStringFromQuery:[NSString stringWithFormat:@"select COUNT(Job_patrol_schedule_points.point_id) from Jobs join Job_patrol_schedules on Jobs.jid = Job_patrol_schedules.jid join Job_patrol_schedule_points on Job_patrol_schedule_points.schedule_id=Job_patrol_schedules.schedule_id where jobs.jid=%@ and Job_patrol_schedule_points.IsSynced=%@",strPatrolJobId,UN_SYNCED_DATA]]intValue];
    if (UnsyncedDatacount >0) //Check any unsynced data available
    {
        if ([DataSource executeQuery:[NSString stringWithFormat:@"update Job_patrol_schedules set IsSynced=%@ where schedule_id=%@",UN_SYNCED_DATA,[dicSelected objectForKey:SCHEDULE_ID]]])
            NSLog(@"Patrol Point updated");
        else
            NSLog(@"Failed to update the current schedule_id");
    }
    
    if (strPatrolJobId!=nil)
    {
        if (alert_View!=nil)
            [alert_View removeFromSuperview];
    }
    
    int MissedValuesCount = [[DataSource getStringFromQuery:[NSString stringWithFormat:@" select COUNT(*) as MissedCount from Jobs join Job_patrol_schedules on Jobs.jid = Job_patrol_schedules.jid join Job_patrol_schedule_points on Job_patrol_schedule_points.schedule_id=Job_patrol_schedules.schedule_id where                                                             jobs.jid='%@' and  ( Job_patrol_schedule_points.ManualStatusHandler ='NOT_COMPLETE' or Job_patrol_schedule_points.ManualStatusHandler = 'MISSED' )",strPatrolJobId]]intValue];
    
    //Call webservice here
    NSLog(@"Value updated");
    AddDescription* objNav=[[AddDescription alloc] initWithNibName:@"AddDescription" bundle:nil];
    objNav.strJid=strPatrolJobId;
    objNav.dicRecord = dicSelected;
    if (MissedValuesCount == 0)
    {
        objNav.isNotMissedAnyPoint = YES;   
    }

    [self.navigationController pushViewController:objNav animated:YES];
    [objNav release];
    
    
    
}


- (void)viewDidUnload
{
    strJid = nil;
    dicPatrolPointRecord = nil;
    strIsCreatingJob = nil;
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
