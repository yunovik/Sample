//
//  JobInfoScreen.h
//  ElogBooks
//
//  Created by I-VERVE5 on 10/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JobInfoScreen : UIViewController<UIScrollViewDelegate,UITableViewDelegate,UITableViewDataSource,CLLocationManagerDelegate,MYXMLParserDelegate>
{
    UIScrollView *scrVertical;
    NSArray *arrHeader;
    NSMutableArray  *arrItems;
    
    NSMutableArray *arrData;
    
    NSMutableArray *arrJobInfoKey;
    
    NSMutableArray *arrWorkDone;
    NSMutableArray *arrCallHistory;
    NSMutableArray *arrAttachment;
    
    
    UITableView *tblView;
    
    BOOL isShow1,isShow2,isShow3,isServiceExists;
    
    NSString *strCurrJobType;
    int CELL_HEIGHT;
    CLLocationManager *locationManager;
    getWebService *objService;
    NSString *StrAssets_id;
    NSArray *arrkeys;
}
-(void)LoadHorizontalScrollview;
-(void)LoadArrays;
@property(retain,nonatomic)NSString *strJid;

@end
