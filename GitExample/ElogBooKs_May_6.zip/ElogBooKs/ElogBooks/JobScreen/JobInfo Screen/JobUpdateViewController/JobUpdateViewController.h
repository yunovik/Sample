//
//  JobUpdateViewController.h
//  ElogBooks
//
//  Created by iphone on 23/01/13.
//  Copyright (c) 2013 nayanmist@gmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JobUpdateViewController : UIViewController<UITextFieldDelegate,UITextViewDelegate,PutInfoDelegate>
{
    IBOutlet UIScrollView *scrView;
    UIDatePicker *objDatePicker;
    NSDateFormatter *dateFormatter;
    IBOutlet UITextField *txthours,*txtTravel,*txtMileage,*txtFirstAttendance,*txtJobCompletion;
    UIButton *btnFade;
    IBOutlet UIButton *btnDateTimeFirstAttend;
    UITextField *txtTempField;
    IBOutlet  UIButton *btnUpdateJob;
    IBOutlet UITextView *txViewJobUpdate;
    NSString *strCurrentTimestamp;

}
@property(retain,nonatomic)NSString *strTitleStatus,*strJid;
-(IBAction)btnDateTimeFirstAttendTapped:(id)sender;
-(IBAction)btnUpdateJobTapped:(id)sender;
@end
