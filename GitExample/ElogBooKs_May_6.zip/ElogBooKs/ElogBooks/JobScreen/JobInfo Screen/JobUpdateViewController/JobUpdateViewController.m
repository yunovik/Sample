//
//  JobUpdateViewController.m
//  ElogBooks
//
//  Created by iphone on 23/01/13.
//  Copyright (c) 2013 nayanmist@gmail.com. All rights reserved.
//

#import "JobUpdateViewController.h"

@interface JobUpdateViewController ()

@end

@implementation JobUpdateViewController
@synthesize strJid,strTitleStatus;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    


    [CommonFunctions setTitleView:self amdtitle:strTitleStatus];
    
    UIView *backView = [[[UIView alloc] init] autorelease];
    backView.frame = CGRectMake(0, 0, 320, 61);
    backView.backgroundColor = getImageColor(@"Cell_Stripe.png");
    [self.view addSubview:backView];
    
    
    [CommonFunctions setBack:self target:@selector(btnBackTapped:)];
    
    NSMutableArray *arrJobInfo = [DataSource getRecordsFromQuery:
                                  [NSString stringWithFormat:
                                   @"select jid,stt,location,date_due from jobs Where jid = '%@'",strJid]];
    
    UILabel *lblPatrolId = [[UILabel alloc]initWithFrame:CGRectMake(10, 10 ,70, 20)];
    lblPatrolId.backgroundColor = [UIColor clearColor];
    [lblPatrolId setFont:FONT_NEUE_BOLD_SIZE(17) ];
    [lblPatrolId setTextColor:DEFAULT_FONT_COLOR];
    [lblPatrolId setText:[NSString stringWithFormat:@"%@ -",[[arrJobInfo objectAtIndex:0] objectForKey:JOBS_ID]]];
    //    lblAsstId.text = [redDic objectForKey:@"id"];
    [backView addSubview:lblPatrolId];
    [lblPatrolId release];
    
    UILabel *lblPatrolStatus = [[UILabel alloc]initWithFrame:CGRectMake(80, 10, 120, 20)];
    lblPatrolStatus.backgroundColor = [UIColor clearColor];
    [lblPatrolStatus setFont:FONT_NEUE_BOLD_SIZE(17) ];
    [lblPatrolStatus setTextColor:DEFAULT_FONT_COLOR];
    [lblPatrolStatus setText:[[arrJobInfo objectAtIndex:0] objectForKey:JOBS_STT]];
    //    lblPatrolStatus.text = [redDic objectForKey:@"id"];
    [backView addSubview:lblPatrolStatus];
    [lblPatrolStatus release];
    
    UILabel *lblPatrolDesc = [[UILabel alloc]initWithFrame:CGRectMake(10, 25, 200, 20)];
    lblPatrolDesc.backgroundColor = [UIColor clearColor];
    [lblPatrolDesc setFont:FONT_NEUE_SIZE(14) ];
    [lblPatrolDesc setTextColor:DEFAULT_FONT_COLOR];
    [lblPatrolDesc setText:[[arrJobInfo objectAtIndex:0] objectForKey:JOBS_LOCATION]];
    //    lblPatrolDesc.text = [redDic objectForKey:@"id"];
    [backView addSubview:lblPatrolDesc];
    [lblPatrolDesc release];
    
    btnUpdateJob.backgroundColor =getImageColor(@"Cell_Stripe.png");
    
    
    //Set Button Title
    [btnUpdateJob setTitle:strTitleStatus forState:UIControlStateNormal];

    
    
    if ([[UIScreen mainScreen] bounds].size.height == 568) {
        [scrView setFrame:CGRectMake(0, 15, 320, 498)];
    }else
    {
        [scrView setFrame:CGRectMake(0, 101, 320, 498)];
    }
    [scrView setContentSize:CGSizeMake(320, 565)];
    
    //Hide Fadeview
    btnFade = [[UIButton alloc]initWithFrame:CGRectMake(0, [[UIScreen mainScreen] bounds].size.height, 320,500)];
    btnFade.backgroundColor = [UIColor blackColor];
    [btnFade addTarget:self action:@selector(HideDatePicker:) forControlEvents:UIControlEventTouchUpInside];
    [btnFade setAlpha:0.41];
    [self.view addSubview:btnFade];

    
    
        
    //DateTimePicker  Allocation
    objDatePicker = [[UIDatePicker alloc] initWithFrame:CGRectMake(0,[[UIScreen mainScreen] bounds].size.height-20, 320, 230)];
    objDatePicker.datePickerMode = UIDatePickerModeDateAndTime;
    [objDatePicker addTarget:self action:@selector(datePickerValuechanged:) forControlEvents:UIControlEventValueChanged];
    [self.view addSubview:objDatePicker];

    dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"dd/MM/YYYY HH:mm:ss"];
    
    
    
    
    NSString *str_EngOnSiteTime = [DataSource getStringFromQuery:[NSString stringWithFormat:@"SELECT eng_on_site FROM Jobs where jid = '%@'",strJid]];
    
    if ([str_EngOnSiteTime length]>0) //eng_on_site set 
        txtFirstAttendance.text = [CommonFunctions getCurrentTimeStamp:str_EngOnSiteTime];
    else 
        txtFirstAttendance.text = [dateFormatter stringFromDate:[NSDate date]];
    
    txViewJobUpdate.text = @"Click to begin typing";
    txViewJobUpdate.textColor = [UIColor grayColor];
    txViewJobUpdate.layer.borderWidth = 1.0;
    [txViewJobUpdate setDelegate:self];

}


#pragma datePickerValuechanged
-(void)datePickerValuechanged:(id)sender
{
        txtFirstAttendance.text =   [dateFormatter stringFromDate:objDatePicker.date];
}



#pragma mark btnDateTimeFirstAttendanceTapped
-(IBAction)btnDateTimeFirstAttendTapped:(id)sender
{
    [txViewJobUpdate resignFirstResponder];

    [txtTempField resignFirstResponder];
    [btnFade setFrame:CGRectMake(0, 0, 320,[[UIScreen mainScreen] bounds].size.height)];

    [UIView animateWithDuration:0.5 animations:^{
       [scrView setContentOffset:CGPointMake(0, 50)];
        [objDatePicker setFrame:CGRectMake(0,[[UIScreen mainScreen] bounds].size.height-280, 320, 250)];
//        [objDatePicker setTag:TAG_DATE_FIRST_ATTEND];
    }];
    
}
-(void)HideDatePicker:(id)sender
{
    txtFirstAttendance.text = [dateFormatter stringFromDate:objDatePicker.date];
    [btnFade setFrame:CGRectMake(0, [[UIScreen mainScreen] bounds].size.height, 320,480)];
    
    [UIView animateWithDuration:0.5 animations:^{
        [objDatePicker setFrame:CGRectMake(0,[[UIScreen mainScreen] bounds].size.height-20, 320, 230)];
        [scrView setContentOffset:CGPointMake(0, 0)];
    }];
    
}

#pragma mark UITextfield Delegates

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    txtTempField = textField;
    [UIView animateWithDuration:0.5 animations:^{
        if ((textField == txtFirstAttendance) || (textField == txtJobCompletion))
        {
            [scrView setContentOffset:CGPointMake(0, 100) ];
        }
        [scrView setContentSize:CGSizeMake(320, 780)];
    }];
    return YES;
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    [UIView animateWithDuration:0.5 animations:^{
        [scrView setContentSize:CGSizeMake(320, 565)];
        [scrView setContentOffset:CGPointMake(0, 0) animated:YES];
        [textField resignFirstResponder];
    }];
    return YES;
}

-(void)btnBackTapped:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}


-(IBAction)btnUpdateJobTapped:(id)sender
{
if ([[txViewJobUpdate.text stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0)
{

        //Update the Job start Job URL
 /*http://code.elogbooks.co.uk/users/jack/WOM/api/put-info.php?uid=38&UpdateType=jobs&qd=Update&tstamp=27/12/2012%2018:35:20&jid=2824&eng_complete=27/12/2012%2018:35:20&description=testeddesc&miles=2&travel=3&hours=4&aid=261&condition=5&risk=3 */
    
        if ([CommonFunctions isNetAvailable])
        {
//            isUpdatingJob = TRUE;
            //Get C0-ordinates
            CLLocationCoordinate2D coordinate = [CommonFunctions GetCoordinates];

            
          PutInfoClass   *objService=[[PutInfoClass alloc] init];
            objService._delegate=self;
           
            NSMutableDictionary *dicc=[[[NSMutableDictionary alloc] init]autorelease];
            [dicc setObject:[ElogBooksAppDelegate getValueForKey:USER_ID] forKey:USER_ID];
            [dicc setObject:@"jobs" forKey:@"UpdateType"];
            

            //check if the job is started 
     NSString *strIsJobStarted       = [DataSource getStringFromQuery:[NSString stringWithFormat:@"select IsJobStarted from jobs where jid = '%@'",strJid]];
            if ([strIsJobStarted isEqualToString:@"N"])
            [dicc setObject:@"Start" forKey:@"qd"];
            else 
            [dicc setObject:@"Update" forKey:@"qd"];            
            
            
            [dicc setObject: txtFirstAttendance.text forKey:@"tstamp"];
            [dicc setObject:strJid forKey:JOBS_ID];
            
            [dicc setObject:[NSString stringWithFormat:@"%f",coordinate.latitude] forKey:@"lat"];
            [dicc setObject:[NSString stringWithFormat:@"%f",coordinate.longitude]forKey:@"lon"];
            
            
            
            [dicc setObject:txViewJobUpdate.text forKey:JOBS_DESC];
            if ([txthours.text length]>0)
            [dicc setObject:txthours.text forKey:J_LINE_H];
            else 
            [dicc setObject:@"0.0" forKey:J_LINE_H];                
              if ([txtTravel.text length]>0)
            [dicc setObject:txtTravel.text forKey:J_LINE_T];
            else 
                [dicc setObject:@"0.0" forKey:J_LINE_T];
           if ([txtTravel.text length]>0)
            [dicc setObject:txtMileage.text forKey:J_LINE_M];
            else 
          [dicc setObject:@"0.0" forKey:J_LINE_M];                
            objService.argsDic=[CommonFunctions getDicAsParameter:dicc];
            
            objService.strWebService=[NSString stringWithFormat:@"startJob:%@",strJid];
            objService.strUrl= [NSString stringWithFormat:@"%@%@",[ElogBooksAppDelegate getValueForKey:BASE_URL],PUT_INFO_API];
            objService.ParentNode=@"Responses";
            objService.ChildNode=@"Response";
            objService.retType=isArray;
            [objService performSelector:@selector(setArray) withObject:nil afterDelay:0.1];
        }
        else
        {
            //Update the Job in local
            


    if ([DataSource executeQuery: [NSString stringWithFormat:@"Update Jobs set eid = '%@' ,stt = 'In Progress',eng_on_site='%@',IsSynced=%@ where jid ='%@'",[ElogBooksAppDelegate getValueForKey:USER_ID],[CommonFunctions getCurrentTimeStampForDatabaseInsertion:txtFirstAttendance.text],UN_SYNCED_DATA,strJid]])
                    NSLog(@"Job Updated in local");
                else
                    NSLog(@"Job Failed to  Update in local");
            
            
            if ([DataSource executeQuery:[NSString stringWithFormat:@"insert into Job_lines (jid,eid,tstamp,hours,travel,miles,description,name,helpdesk,call_type,IsSynced)values(%@,%@,'%@',%@,%@,%@,'%@','%@','N/A','N/A',%@)",strJid,[ElogBooksAppDelegate getValueForKey:USER_ID],[CommonFunctions getCurrentTimeStampForDatabaseInsertion:txtFirstAttendance.text],txthours.text,txtTravel.text,txtMileage.text,txViewJobUpdate.text,[ElogBooksAppDelegate getValueForKey:USER_NAME],UN_SYNCED_DATA]])  //update Job Lines
            {
                NSLog(@"Job Lines updated");
            }
            
            [self.navigationController popViewControllerAnimated:YES];
            
            
        }
    }

    else 
    {
        UIAlertView *alert=[[[UIAlertView alloc] initWithTitle:APP_TITLE message: @"Please enter Description " delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil]autorelease];
        [alert show];
    }
    
    
}




#pragma mark Parsing delegates
-(void)filedWithError:(NSString *)strMsg forFlage:(NSString *)flage
{



    
        //Update the Job in local
        
        
        
        if ([DataSource executeQuery: [NSString stringWithFormat:@"Update Jobs set eid = '%@' ,stt = 'In Progress',eng_on_site='%@',IsSynced=%@ where jid ='%@'",[ElogBooksAppDelegate getValueForKey:USER_ID],[CommonFunctions getCurrentTimeStampForDatabaseInsertion:txtFirstAttendance.text],UN_SYNCED_DATA,strJid]])
            NSLog(@"Job Updated in local");
        else
            NSLog(@"Job Failed to  Update in local");
        
        
        if ([DataSource executeQuery:[NSString stringWithFormat:@"insert into Job_lines (jid,eid,tstamp,hours,travel,miles,description,name,helpdesk,call_type,IsSynced)values(%@,%@,'%@',%@,%@,%@,'%@','%@','N/A','N/A',%@)",strJid,[ElogBooksAppDelegate getValueForKey:USER_ID],[CommonFunctions getCurrentTimeStampForDatabaseInsertion:txtFirstAttendance.text],txthours.text,txtTravel.text,txtMileage.text,txViewJobUpdate.text,[ElogBooksAppDelegate getValueForKey:USER_NAME],UN_SYNCED_DATA]])  //update Job Lines
        {
            NSLog(@"Job Lines updated");
        }
        
    
        
        
    
        [self.navigationController popViewControllerAnimated:YES];
    }

-(void)EndParsingArray:(NSMutableArray *)arrData forFlage:(NSString *)flage
{
    if ([arrData count]>0)
    {
        if (!([[arrData objectAtIndex:0]rangeOfString:@"Success"].location==NSNotFound))
        {
            
            
            if([DataSource executeQuery:[NSString stringWithFormat:@"Update Jobs set  IsJobStarted='Y' where jid=%@",strJid]])
                NSLog(@"Job :%@:synced",flage); 
            else 
                NSLog(@"Job :%@:failed to synce",flage);  

            
            if ([DataSource executeQuery: [NSString stringWithFormat:@"Update Jobs set eid = '%@' ,stt = 'In Progress',eng_on_site='%@',IsSynced=%@ where jid ='%@'",[ElogBooksAppDelegate getValueForKey:USER_ID],[CommonFunctions getCurrentTimeStampForDatabaseInsertion:txtFirstAttendance.text],SYNCED_DATA,strJid]])
                NSLog(@"Job Updated in local");
            else
                NSLog(@"Job Failed to  Update in local");
            
            
            if ([DataSource executeQuery:[NSString stringWithFormat:@"insert into Job_lines (jid,eid,tstamp,hours,travel,miles,description,name,helpdesk,call_type,IsSynced)values(%@,%@,'%@',%@,%@,%@,'%@','%@','N/A','N/A',%@)",strJid,[ElogBooksAppDelegate getValueForKey:USER_ID],[CommonFunctions getCurrentTimeStampForDatabaseInsertion:txtFirstAttendance.text],txthours.text,txtTravel.text,txtMileage.text,txViewJobUpdate.text,[ElogBooksAppDelegate getValueForKey:USER_NAME],SYNCED_DATA]])  //update Job Lines
            {
                NSLog(@"Job Lines updated");
            }
        }
        else
        {
            
            if ([DataSource executeQuery: [NSString stringWithFormat:@"Update Jobs set eid = '%@' ,stt = 'In Progress',eng_on_site='%@',IsSynced=%@ where jid ='%@'",[ElogBooksAppDelegate getValueForKey:USER_ID],[CommonFunctions getCurrentTimeStampForDatabaseInsertion:txtFirstAttendance.text],UN_SYNCED_DATA,strJid]])
                NSLog(@"Job Updated in local");
            else
                NSLog(@"Job Failed to  Update in local");
            
            
            if ([DataSource executeQuery:[NSString stringWithFormat:@"insert into Job_lines (jid,eid,tstamp,hours,travel,miles,description,name,helpdesk,call_type,IsSynced)values(%@,%@,'%@',%@,%@,%@,'%@','%@','N/A','N/A',%@)",strJid,[ElogBooksAppDelegate getValueForKey:USER_ID],[CommonFunctions getCurrentTimeStampForDatabaseInsertion:txtFirstAttendance.text],txthours.text,txtTravel.text,txtMileage.text,txViewJobUpdate.text,[ElogBooksAppDelegate getValueForKey:USER_NAME],UN_SYNCED_DATA]])  //update Job Lines
            {
                NSLog(@"Job Lines updated");
            }
        }
    }
     [self.navigationController popViewControllerAnimated:YES];
    }

#pragma mark TextView Delegates
- (BOOL)textViewShouldBeginEditing:(UITextView *)textView
{
    if ([textView.text isEqualToString:@"Click to begin typing"])
    {
        textView.text =@"";
        textView.textColor = [UIColor blackColor];
    }
    
    [UIView animateWithDuration:0.5 animations:^{
//        [scrView setContentSize:CGSizeMake(320, 600)];
    }];
    return YES;
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    
    if([text isEqualToString:@"\n"])
    {
        [UIView animateWithDuration:0.5 animations:^{
//            [scrView setContentSize:CGSizeMake(320, 565)];
            [textView resignFirstResponder];
        }];
        return NO;
    }
    return YES;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
