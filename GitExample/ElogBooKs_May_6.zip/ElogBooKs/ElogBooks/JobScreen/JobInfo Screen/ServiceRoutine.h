//
//  ServiceRoutine.h
//  ElogBooks
//
//  Created by i-verve10 on 28/03/13.
//  Copyright (c) 2013 nayanmist@gmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ServiceRoutine : UIViewController <UIWebViewDelegate>
{
    UIWebView *web_View;
}
@property (nonatomic,retain)NSString *strJid;
@end
