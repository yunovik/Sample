//
//  JobInfoScreen.m
//  ElogBooks
//
//  Created by I-VERVE5 on 10/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import "JobInfoScreen.h"
#import "SubAssetScreen.h"
#import "SignViewController.h"
#import "AddMaterials.h"
#import "UpdatePointScreen.h"
#import "UpdateJobViewController.h"
#import "UploadImageScreen.h"
#import "UploadFile.h"
#import "JobUpdateViewController.h"
#import "HomeScreen.h"
#import "JobListScreen.h"
#import "ServiceRoutine.h"
#import "SearchingScreen.h"

#define PLANNED_JOB_ITEMS_TAG 7001
#define REACTIVE_JOB_ITEMS_TAG 7000

@interface JobInfoScreen ()

@end

@implementation JobInfoScreen
@synthesize strJid;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    //    arr = [[arrData objectAtIndex:0] allKeys];
    //    [arr retain];
    
    CELL_HEIGHT = 25;
    
    self.title = @"Job Info";
    [CommonFunctions setTitleView:self amdtitle:@"Job Info"];
    

    [self LoadHorizontalScrollview];
    
    [self.view setClipsToBounds:YES];
    
    
    
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    screenBounds.origin.y=80;
    screenBounds.size.height=screenBounds.size.height-145;

    
    tblView = [[UITableView alloc]init];
    tblView.frame = screenBounds;
    tblView.delegate = nil;
    tblView.dataSource = nil;
    
    [tblView setBackgroundColor:[UIColor clearColor]];
    [tblView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    
    [self.view addSubview:tblView];
    
    //strJid = @"7687";

    
//    NSMutableArray *arrKeys = [[NSMutableArray alloc]initWithObjects:JOBS_ID,JOBS_TYPE,JOBS_STT,JOBS_PRIORITY,JOBS_DESC,JOBS_CUSTOMER,JOBS_LOCATION,JOBS_ASSET_NAME,JOBS_DATE_DUE,JOBS_UPDATE_DUE,JOBS_ENG_ON_SITE, nil];
//    
//    NSMutableArray *arrValues = [[NSMutableArray alloc]initWithObjects:@"Job Number",@"Job Type",@"Status",@"Priority",@"Description",@"Customer",@"Location",@"Asset Name",@"Attend Due",@"Update Due",@"Attended Date", nil];
//    
//    arrJobInfoKey  = [[NSMutableArray alloc] init];
//    
//    for (int i=0;i<[arrKeys count]; i++)
//    {
//        NSMutableDictionary *dic;
//        dic = [[NSMutableDictionary alloc] init];
//        [dic setObject:[arrKeys objectAtIndex:i] forKey:@"Key"];
//        [dic setObject:[arrValues objectAtIndex:i] forKey:@"Value"];
//        [arrJobInfoKey addObject:dic];
//        [dic release];
//    }
    [CommonFunctions setBack:self target:@selector(btnBackTapped:)];
}

#pragma mark Horizontal Scrollview
-(void)LoadHorizontalScrollview
{
    //Top ScrollView
    if(scrVertical !=nil)
    {
    [scrVertical removeFromSuperview];
    scrVertical = nil;
    }
    
    scrVertical= [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, 320, 80)];
    scrVertical.backgroundColor = getImageColor(@"PatrolInfo_Row_Stripe.png");
    scrVertical.alpha = 0.8;
    scrVertical.pagingEnabled = NO;
    scrVertical.scrollEnabled = YES;
    scrVertical.delegate = self;
    scrVertical.hidden=NO;
    scrVertical.showsHorizontalScrollIndicator = NO;
    [self.view addSubview:scrVertical];
    
    arrItems = [[NSMutableArray alloc] init];
    NSMutableDictionary *dicItem;
    //static 
    //    NSString *strAttendDate = @"";
    //    [strAttendDate retain];
    
    NSString *strAttendDate = [DataSource getStringFromQuery:[NSString stringWithFormat:@"SELECT eng_on_site FROM jobs where %@='%@'",JOBS_ID,strJid]];
    
    
    if ( [strAttendDate isEqualToString:@""])
    {
        
        dicItem  = [[NSMutableDictionary alloc] init];
        [dicItem setObject:@"Check in" forKey:@"Title"];
        [dicItem setObject:getImage(@"Check-in.png") forKey:@"Image"];
        [arrItems addObject:dicItem];
    }
    dicItem  = [[NSMutableDictionary alloc] init];
    [dicItem setObject:@"Update" forKey:@"Title"];
    [dicItem setObject:getImage(@"Update.png") forKey:@"Image"];
    [arrItems addObject:dicItem];
    
    dicItem  = [[NSMutableDictionary alloc] init];
    [dicItem setObject:@"Complete" forKey:@"Title"];
    [dicItem setObject:getImage(@"Complete.png") forKey:@"Image"];
    [arrItems addObject:dicItem];
    
    isServiceExists = FALSE;
    if ([[DataSource getStringFromQuery:[NSString stringWithFormat:@"select jobs.srid from jobs join service_routines on jobs.srid = service_routines.iid where jid = '%@' and jobs.srid!=0",strJid]]length]>0)
    {
        isServiceExists = TRUE;
        dicItem  = [[NSMutableDictionary alloc] init];
        [dicItem setObject:@"Service Routine" forKey:@"Title"];
        [dicItem setObject:getImage(@"ServiceRoutine.png") forKey:@"Image"];
        [arrItems addObject:dicItem];
    }
    
    dicItem  = [[NSMutableDictionary alloc] init];
    [dicItem setObject:@"Materials" forKey:@"Title"];
    [dicItem setObject:getImage(@"Materials.png") forKey:@"Image"];
    [arrItems addObject:dicItem];
    
    dicItem  = [[NSMutableDictionary alloc] init];
    [dicItem setObject:@"SubAssets" forKey:@"Title"];
    [dicItem setObject:getImage(@"Sub_assets.png") forKey:@"Image"];
    [arrItems addObject:dicItem];
    
    dicItem  = [[NSMutableDictionary alloc] init];
    [dicItem setObject:@"Photo" forKey:@"Title"];
    [dicItem setObject:getImage(@"Photos.png") forKey:@"Image"];
    [arrItems addObject:dicItem];
    
    dicItem  = [[NSMutableDictionary alloc] init];
    [dicItem setObject:@"Signature" forKey:@"Title"];
    [dicItem setObject:getImage(@"Signature.png") forKey:@"Image"];
    [arrItems addObject:dicItem];
    
    dicItem  = [[NSMutableDictionary alloc] init];
    [dicItem setObject:@"Barcode" forKey:@"Title"];
    [dicItem setObject:getImage(@"Barcode.png") forKey:@"Image"];
    [arrItems addObject:dicItem];
    
    //    dicItem  = [[NSMutableDictionary alloc] init];
    //    [dicItem setObject:@"File" forKey:@"Title"];
    //    [dicItem setObject:getImage(@"File.png") forKey:@"Image"];
    //    [arrItems addObject:dicItem];
    
    int xx = 7;
    
    int gape = 7;
    
    int ww =48;
    
    int hh = 65;
    
    for(int i=0;i<[arrItems count];i++)
    {
        NSMutableDictionary *dicItem = [arrItems objectAtIndex:i];
        
        UIView *itemView = [[UIView alloc] initWithFrame:CGRectMake(xx, gape, ww, hh)];
        [itemView setBackgroundColor:[UIColor clearColor]];
        
        
        UIButton *btnItem = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, ww, 48)];
        [btnItem addTarget:self  action:@selector(ItemSelect:)forControlEvents:UIControlEventTouchDown];
        
        if ([strAttendDate isEqualToString:@""])
            [btnItem setTag: REACTIVE_JOB_ITEMS_TAG+i];
        else 
            [btnItem setTag: PLANNED_JOB_ITEMS_TAG+i];        
        
        [btnItem setImage:[dicItem objectForKey:@"Image"] forState:UIControlStateNormal];
        [itemView addSubview:btnItem];
        
        UILabel *lblItem = [[UILabel alloc] initWithFrame:CGRectMake(0, 48, ww, 20)];
        [lblItem setText:[dicItem objectForKey:@"Title"]];
        [lblItem setBackgroundColor:[UIColor clearColor]];
        [lblItem setTextColor:DEFAULT_FONT_COLOR];
        [lblItem setFont:[UIFont fontWithName:@"helvetica" size:10]];
        [lblItem setLineBreakMode:UILineBreakModeWordWrap];
        [lblItem setTextAlignment:UITextAlignmentCenter];
        [lblItem setNumberOfLines:0];
        [lblItem sizeToFit];
        
        [itemView addSubview:lblItem];
        
        [scrVertical addSubview:itemView];
        
        xx += ww + gape;
    }
    
    [scrVertical setContentSize:CGSizeMake(xx, 0)];
    
    [self.view addSubview:scrVertical];
}
-(NSArray *)ReturnSortedArray 
{
    NSArray *arrKeys;
    BOOL includeService;
   if ([arrData count]>0)
   {
       NSMutableDictionary *dicRec = [arrData objectAtIndex:0];
       NSString  *strServiceRoutineValue = [dicRec valueForKey:@"ServiceRoutine"];
       if ([strServiceRoutineValue length]>0)
           includeService = YES;
       else 
           includeService = NO;
   }
    
    if ([strCurrJobType isEqualToString:@"Planned"])
    {
        if ([StrAssets_id intValue]>0)
        {
            if (includeService)
            arrKeys = [[NSArray alloc]initWithObjects:@"JobNumber",@"JobType",@"Status",@"Priority",@"Frequency",@"Description",@"Customer",@"Building",@"Floor",@"Location",@"ServiceRoutine",@"Asset",@"AssetNo",@"BarCode",@"Model",@"SerialNo",@"LegComp",@"Condition",@"Risk",@"AssetNotes",@"JobNotes",@"AttendDue",@"Attended_Date",@"UpdateDue",nil];
            else 
                arrKeys = [[NSArray alloc]initWithObjects:@"JobNumber",@"JobType",@"Status",@"Priority",@"Frequency",@"Description",@"Customer",@"Building",@"Floor",@"Location",@"Asset",@"AssetNo",@"BarCode",@"Model",@"SerialNo",@"LegComp",@"Condition",@"Risk",@"AssetNotes",@"JobNotes",@"AttendDue",@"Attended_Date",@"UpdateDue",nil];
            
        }else 
        {
                      if (includeService)
                        arrKeys = [[NSArray alloc]initWithObjects:@"JobNumber",@"JobType",@"Status",@"Priority",@"Frequency",@"Description",@"Customer",@"ServiceRoutine",@"JobNotes",@"AttendDue",@"AttendedDate",@"UpdateDue", nil];
                      else 
                          arrKeys = [[NSArray alloc]initWithObjects:@"JobNumber",@"JobType",@"Status",@"Priority",@"Frequency",@"Description",@"Customer",@"JobNotes",@"AttendDue",@"AttendedDate",@"UpdateDue", nil];
        }
    }
    else 
    {
        if ([StrAssets_id intValue]>0)
        {
                                  if (includeService)
                                   arrKeys = [[NSArray alloc]initWithObjects:@"JobNumber",@"JobType",@"Status",@"Priority",@"Description",@"Customer",@"Building",@"Floor",@"Location",@"ServiceRoutine",@"Asset",@"AssetNo",@"BarCode",@"Model",@"SerialNo",@"LegComp",@"Condition",@"Risk",@"AssetNotes",@"JobNotes",@"AttendDue",@"Attended_Date",@"UpdateDue",nil];
                                   else 
                                   arrKeys = [[NSArray alloc]initWithObjects:@"JobNumber",@"JobType",@"Status",@"Priority",@"Description",@"Customer",@"Building",@"Floor",@"Location",@"Asset",@"AssetNo",@"BarCode",@"Model",@"SerialNo",@"LegComp",@"Condition",@"Risk",@"AssetNotes",@"JobNotes",@"AttendDue",@"Attended_Date",@"UpdateDue",nil];

        }else 
        {
            if (includeService)
               arrKeys = [[NSArray alloc]initWithObjects:@"JobNumber",@"JobType",@"Status",@"Priority",@"Description",@"Customer",@"ServiceRoutine",@"JobNotes",@"AttendDue",@"AttendedDate",@"UpdateDue", nil];
            else 
                arrKeys = [[NSArray alloc]initWithObjects:@"JobNumber",@"JobType",@"Status",@"Priority",@"Description",@"Customer",@"JobNotes",@"AttendDue",@"AttendedDate",@"UpdateDue", nil];

        }
    }
    return arrKeys;
}
#pragma mark ViewWillAppear
-(void)viewWillAppear:(BOOL)animated
{
    
    [self LoadArrays];
    
    tblView.delegate = self;
    tblView.dataSource = self;
    [tblView reloadData];
    [super viewWillAppear:YES];
}

#pragma mark -
-(void)LoadArrays
{
    //    //static
    //    strJid = @"35776";
    //Get JobType
    strCurrJobType =[DataSource getStringFromQuery:[NSString stringWithFormat:@"select CASE WHEN   (job_type ='PM')  THEN 'Planned' WHEN (job_type ='Non-PM')  THEN 'Reactive' ELSE job_type END As job_type from jobs where jid=%@",strJid]];
    [strCurrJobType retain];
    
    
    StrAssets_id = [DataSource getStringFromQuery:[NSString stringWithFormat:@"select aid from Jobs where jid ='%@'",strJid]];
    //static 
    //    StrAssets_id = @"0";
    
    [StrAssets_id retain];
    //    arrData = [[NSMutableArray alloc]initWithArray:[DataSource getRecordsFromQuery:[NSString stringWithFormat:@"SELECT jid,job_type,stt,priority,description,date_due,date_due_comp,eng_on_site,eng_complete,Customers.customer,Assets.descr as asset_name,jobs.updated,jobs.date_due_comp ,jobs.eng_complete as Completed   from  jobs left join Customers   on Jobs.cid = Customers.cid left join Assets on jobs.aid = Assets.aid   Where jid=%@",strJid]]];
    
    if ([strCurrJobType isEqualToString:@"Planned"])
    {
        if ([StrAssets_id intValue]>0)   
            arrData = [[NSMutableArray alloc]initWithArray:[DataSource getRecordsFromQuery:[NSString stringWithFormat:@"SELECT jid as JobNumber,job_type as JobType,stt as Status,priority as Priority,jobs.period as Frequency,description as Description,Customers.customer As Customer,Assets.building as Building,Assets.bfloor as Floor,Assets.location as Location,Assets.descr as Asset,jobs.aid as AssetNo,Assets.barcode as BarCode,Assets.model as Model,Assets.serialno as SerialNo,Assets.legcomp as LegComp,Assets.cond as Condition,Assets.risk as Risk,Assets.notes As AssetNotes,jobs.notes as JobNotes,date_due As AttendDue,date_due_comp,eng_on_site As Attended_Date,eng_complete,jobs.updated As UpdateDue,jobs.date_due_comp,service_routines.srid as ServiceRoutine      from  jobs left join Customers   on Jobs.cid = Customers.cid left join Assets on jobs.aid = Assets.aid left join  service_routines on jobs.srid = service_routines.iid   Where jid='%@'",strJid]]];
        else 
            arrData = [[NSMutableArray alloc]initWithArray:[DataSource getRecordsFromQuery:[NSString stringWithFormat:@"select  jid as JobNumber,job_type as JobType,stt as Status,priority as Priority,jobs.period as Frequency,description as Description,Customers.customer As Customer,jobs.notes as JobNotes,date_due As AttendDue,date_due_comp,eng_on_site As AttendedDate,eng_complete,jobs.updated As UpdateDue,jobs.date_due_comp,service_routines.srid as ServiceRoutine from Jobs left join Customers on Jobs.cid = Customers.cid  left    join  service_routines on jobs.srid = service_routines.iid where jid = '%@'",strJid]]];
    }
    else 
    {
        if ([StrAssets_id intValue]>0)   
            arrData = [[NSMutableArray alloc]initWithArray:[DataSource getRecordsFromQuery:[NSString stringWithFormat:@"SELECT jid as JobNumber,job_type as JobType,stt as Status,priority as Priority,description as Description,Customers.customer As Customer,Assets.building as Building,Assets.bfloor as Floor,Assets.location as Location,Assets.descr as Asset,jobs.aid as AssetNo,Assets.barcode as BarCode,Assets.model as Model,Assets.serialno as SerialNo,Assets.legcomp as LegComp,Assets.cond as Condition,Assets.risk as Risk,Assets.notes As AssetNotes,jobs.notes as JobNotes,date_due As AttendDue,date_due_comp,eng_on_site As Attended_Date,eng_complete,jobs.updated As UpdateDue,jobs.date_due_comp,service_routines.srid as ServiceRoutine    from  jobs left join Customers   on Jobs.cid = Customers.cid left join Assets on jobs.aid = Assets.aid left join  service_routines on jobs.srid = service_routines.iid   Where jid='%@'",strJid]]]; 
        else 
            arrData = [[NSMutableArray alloc]initWithArray:[DataSource getRecordsFromQuery:[NSString stringWithFormat:@"select  jid as JobNumber,job_type as JobType,stt as Status,priority as Priority,description as Description,Customers.customer As Customer,jobs.notes as JobNotes,date_due As AttendDue,date_due_comp,eng_on_site As AttendedDate,eng_complete,jobs.updated As UpdateDue,jobs.date_due_comp,service_routines.srid as ServiceRoutine  from Jobs left join Customers on Jobs.cid = Customers.cid left join  service_routines on jobs.srid = service_routines.iid where jid = '%@'",strJid]]]; 
        
    }
    
    
    //Rename keys Accordingly
    /*[dict setObject: [dict objectForKey: @"oldkey"] forKey: @"newkey"];
     [dict removeObjectForKey: @"oldkey"];*/
    
    
    arrWorkDone = [[NSMutableArray alloc]initWithArray:[DataSource getRecordsFromQuery:[NSString stringWithFormat:@"Select * from Job_Lines Where jid=%@ AND helpdesk LIKE 'N/A'",strJid]]];
    
    arrCallHistory = [[NSMutableArray alloc]initWithArray:[DataSource getRecordsFromQuery:[NSString stringWithFormat:@"Select * from Job_Lines Where jid=%@ AND helpdesk NOT LIKE '%N/A%' order by tstamp desc",strJid]]];
    
    arrAttachment = [[NSMutableArray alloc]initWithArray:[DataSource getRecordsFromQuery:[NSString stringWithFormat:@"Select * from Uploaded_files Where as_id LIKE '%@'",strJid]]];
    arrkeys = [self ReturnSortedArray];
}
    

#pragma mark - backTapped Method

-(IBAction)btnBackTapped:(id)sender
{
    
    NSArray *arrviewControllers = [self.navigationController viewControllers];
    id obj;
    
    for (int i=[arrviewControllers count]-1 ;i>0;i--)
    {
        if ([[arrviewControllers objectAtIndex:i]isKindOfClass:[JobListScreen class]])
        {
            obj = (JobListScreen *)[arrviewControllers objectAtIndex:i];
            break; 
        }
        else 
            if ([[arrviewControllers objectAtIndex:i]isKindOfClass:[SearchingScreen   class]])
            {
                obj = (SearchingScreen   *)[arrviewControllers objectAtIndex:i];
                break; 
            }
        else
        if ([[arrviewControllers objectAtIndex:i]isKindOfClass:[HomeScreen class]])
        {
            obj = (HomeScreen *)[arrviewControllers objectAtIndex:i];
            break; 
            
        }
    }
    if (obj !=nil)
    {
        [self.navigationController popToViewController:obj animated:YES];
    }
    else
    {
        NSLog(@"navigation controller crashed");
    }
}

#pragma mark -
#pragma mark Tableview Delegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    switch (section) 
    {
        case 0:
            if ([arrData count]>0)
                return  [arrkeys  count];
            else 
                return 0;
        case 1:
            
            if(isShow1)
                return arrWorkDone.count;
            else 
                return 0;
        case 2:
            if(isShow2)
                return arrCallHistory.count;
            else 
                return 0;
        case 3:
            
            if(isShow3)
                return arrAttachment.count;
            else 
                return 0;
        default:
            return 0;
    }
    
    return 0;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *CellIdentifier = [NSString stringWithFormat:@"CellId_%i_%i",indexPath.row,indexPath.section];
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    cell = nil;
    
    if(cell == nil) 
    {
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] ;
        
        [cell setSelectionStyle:UITableViewCellEditingStyleNone];
        
        if (indexPath.section == 0) {
            
//            NSMutableDictionary *dicRec = [arrData objectAtIndex:0];
//            NSLog(@"%@",dicRec);
            
//            NSMutableDictionary *dic = [arrData objectAtIndex:indexPath.row];
            
//            NSLog(@"%@",[arrJobInfoKey description]);
            
            NSMutableDictionary *dicCurrentRecord = [arrData objectAtIndex:0];
            
            NSString *strVal =  [dicCurrentRecord valueForKey: [arrkeys objectAtIndex:indexPath.row] ];
            
           
                
            NSString *strTitle =  [arrkeys objectAtIndex:indexPath.row];
            
            
            
//            if(indexPath.row==4 && indexPath.section == 0)
//            {
//                
//                UILabel *lbl = [[UILabel alloc]initWithFrame:CGRectMake(20, 5, 120, 20)];
//                lbl.text = strTitle;
//                lbl.backgroundColor =[UIColor clearColor];
//                lbl.font = FONT_NEUE_BOLD_SIZE(12);
//                [cell.contentView addSubview:lbl];
//                
//                CGSize _stringSize =[strVal sizeWithFont:FONT_NEUE_SIZE(12) constrainedToSize:CGSizeMake(270,MAXFLOAT) lineBreakMode:UILineBreakModeCharacterWrap];
//                UILabel *lblJobDesc = [[UILabel alloc] initWithFrame:CGRectMake(20, 27, 270, _stringSize.height)];
//                lblJobDesc.backgroundColor = [UIColor clearColor];
//                lblJobDesc.numberOfLines = 0;
//                lblJobDesc.textColor = DEFAULT_FONT_COLOR;
//                [lblJobDesc setFont:FONT_NEUE_SIZE(12)];
//                lblJobDesc.text = strVal;
//                [cell.contentView addSubview:lblJobDesc];
//                [lblJobDesc release];
//            }
//            else
//            {

//                    strTitle = [strTitle stringByReplacingOccurrencesOfString:@"_" withString:@" "];

                   [cell.contentView addSubview:[CommonFunctions getLableWithTitle:strTitle andDesc:strVal WithFrame:CGRectMake(20, 5, 300, 20)]];


//            }
            
            
            
        }
        
        else if (indexPath.section == 1 || indexPath.section == 2 ) 
        {
            
            NSMutableDictionary *recDic;
            
            if(indexPath.section == 1)
            {
                recDic = [arrWorkDone objectAtIndex:indexPath.row];
            }else {
                recDic = [arrCallHistory objectAtIndex:indexPath.row];
            }
            
            
            
            
            UILabel *lblDate = [[UILabel alloc]initWithFrame:CGRectMake(0,0, 70, CELL_HEIGHT)];
            [lblDate setText:[CommonFunctions getDate:[recDic objectForKey:J_LINE_TSTAMP]]];
            lblDate.textColor = DEFAULT_FONT_COLOR;
            lblDate.backgroundColor = [UIColor clearColor];
            lblDate.font=FONT_NEUE_SIZE(14);
            [cell.contentView addSubview:lblDate];
            
            
            CGSize _size = [[recDic objectForKey:J_LINE_NAME] sizeWithFont:FONT_NEUE_SIZE(14) constrainedToSize:CGSizeMake(50,MAXFLOAT) lineBreakMode:UILineBreakModeCharacterWrap];
            
            UILabel *lblEng = [[UILabel alloc]initWithFrame:CGRectMake(70, 2, 50, _size.height)];
            [lblEng setText:[recDic objectForKey:J_LINE_NAME]];
            [lblEng setNumberOfLines:0];
            lblEng.textColor = DEFAULT_FONT_COLOR;
            lblEng.font =FONT_NEUE_SIZE(14);
            [lblEng setClipsToBounds:YES];
            [lblEng setBackgroundColor:[UIColor clearColor]];
            [cell.contentView addSubview:lblEng];
            
            
            _size = [[recDic objectForKey:J_LINE_DESC] sizeWithFont:FONT_NEUE_SIZE(14) constrainedToSize:CGSizeMake(100,MAXFLOAT) lineBreakMode:UILineBreakModeCharacterWrap];
            
            UILabel *lblDescription = nil;
            if (indexPath.section == 1)
            lblDescription = [[UILabel alloc]initWithFrame:CGRectMake(150, 2, 100, _size.height)];
            else if (indexPath.section == 2)
            lblDescription = [[UILabel alloc]initWithFrame:CGRectMake(150, 2, 180, _size.height)];
            [lblDescription setText:[recDic objectForKey:J_LINE_DESC]];
            lblDescription.textColor = DEFAULT_FONT_COLOR;
            lblDescription.font = FONT_NEUE_SIZE(14);
            lblDescription.numberOfLines = 0;
            [lblDescription setClipsToBounds:YES];
            lblDescription.backgroundColor = [UIColor clearColor];
            [cell.contentView addSubview:lblDescription];
            
           if ( indexPath.section == 1 )
           {
            UILabel *lblH = [[UILabel alloc]initWithFrame:CGRectMake(255, 0, 20, CELL_HEIGHT)];
            [lblH setText:[recDic objectForKey:J_LINE_H]];
            lblH.textColor = DEFAULT_FONT_COLOR;
            lblH.font=FONT_NEUE_SIZE(14);
            lblH.backgroundColor = [UIColor clearColor];
            [cell.contentView addSubview:lblH];
            
            UILabel *lblT = [[UILabel alloc]initWithFrame:CGRectMake(275,0, 20, CELL_HEIGHT)];
            [lblT setText:[recDic objectForKey:J_LINE_T]];
            lblT.textColor = DEFAULT_FONT_COLOR;
            lblT.font=FONT_NEUE_SIZE(14);
            lblT.backgroundColor = [UIColor clearColor];
            [cell.contentView addSubview:lblT];
            
            UILabel *lblM = [[UILabel alloc]initWithFrame:CGRectMake(295, 0, 20, CELL_HEIGHT)];
            [lblM setText:[recDic objectForKey:J_LINE_M]];
            lblM.textColor = DEFAULT_FONT_COLOR;
            lblM.font=FONT_NEUE_SIZE(14);
            lblM.backgroundColor = [UIColor clearColor];
            [cell.contentView addSubview:lblM];
           }
            
        }
        else if (indexPath.section == 3)
        {
            
            NSMutableDictionary *recDic = [arrAttachment objectAtIndex:indexPath.row];
            
            UILabel *lblDate = [[UILabel alloc]initWithFrame:CGRectMake(20, 0, 75, 25)];
            [lblDate setText:[CommonFunctions getDate:[recDic objectForKey:FILE_CREATED]]];
            lblDate.textColor = DEFAULT_FONT_COLOR;
            lblDate.font=FONT_NEUE_SIZE(14);
            lblDate.backgroundColor = [UIColor clearColor];
            [cell.contentView addSubview:lblDate];
            
            UILabel *lblFileName = [[UILabel alloc]initWithFrame:CGRectMake(93, 2, 200, 25)];
            [lblFileName setText:[recDic objectForKey:FILE_TITLE]];
            lblFileName.textColor = DEFAULT_FONT_COLOR;
            lblFileName.font=FONT_NEUE_SIZE(14);
            lblFileName.backgroundColor = [UIColor clearColor];
            [cell.contentView addSubview:lblFileName];
            
        }
        
        [cell.contentView setBackgroundColor:[UIColor whiteColor]];
    }
    
    return cell;
    
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 4;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
//    if(indexPath.row==4 && indexPath.section == 0)
//    {
//        
//        NSLog(@"%i",indexPath.row);
//        NSString *txtForLable;
//        
//        if ([arrData count]>0) {
//            txtForLable =[[[arrData objectAtIndex:0] objectForKey:JOBS_DESC] retain];
//        }
//        else {
//            txtForLable=@"";
//        }
//        
//        CGSize constraintSize;
//        constraintSize.width = 270;
//        constraintSize.height = MAXFLOAT;
//        
//        CGSize _stringSize =[txtForLable sizeWithFont:FONT_NEUE_SIZE(14) constrainedToSize: constraintSize lineBreakMode: UILineBreakModeCharacterWrap];
//        NSLog(@"%f",_stringSize.height);
//        
//        if(_stringSize.height < CELL_HEIGHT)
//        {
//            _stringSize.height = CELL_HEIGHT + 25;
//        }
//        else
//        {
//            _stringSize.height+=40;
//        }
//        
//        return _stringSize.height;
//    }
//    else
        if(indexPath.section == 1 || indexPath.section == 2)
    {
        
        NSString *txtDesc = @"";
        NSString *txtName = @"";
        
        
        if(indexPath.section == 1)
        {
            if ([arrWorkDone count]>0) {
                txtDesc =[[[arrWorkDone objectAtIndex:indexPath.row] objectForKey:J_LINE_DESC] retain];
                txtName =[[[arrWorkDone objectAtIndex:indexPath.row] objectForKey:J_LINE_NAME] retain];
            }
        }
        else
        {
            if ([arrCallHistory count]>0) {
                txtDesc =[[[arrCallHistory objectAtIndex:indexPath.row] objectForKey:J_LINE_DESC] retain];
                txtName =[[[arrCallHistory objectAtIndex:indexPath.row] objectForKey:J_LINE_NAME] retain];
            }
        }
        
        
        CGSize _size = [CommonFunctions getSize:txtDesc Font:FONT_NEUE_SIZE(14) constrainedToSize:CGSizeMake(100,MAXFLOAT) LineBreakMode:UILineBreakModeCharacterWrap min:CELL_HEIGHT];
        
        float _descH = _size.height;
        
        _size = [CommonFunctions getSize:txtName Font:FONT_NEUE_SIZE(14) constrainedToSize:CGSizeMake(70,MAXFLOAT) LineBreakMode:UILineBreakModeCharacterWrap min:CELL_HEIGHT];
        
        float _nameH = _size.height;
        
        if(_descH > _nameH) 
            return _descH;
        else
            return _nameH;
        
    }
    
    return CELL_HEIGHT;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    
    if(section==1)
    {
        if(isShow1) return 61;
    }
    else if(section==2)
    {
        if(isShow2) return 61;
    }else if(section==3)
    {
        if(isShow3) return 61;
    }
    
    return 36;
}
- (UIView *) tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *headerView = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 36)] autorelease];
    
    UIImageView *viewImage = [[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 320, 36)]autorelease] ;
	[viewImage setImage:[[UIImage imageNamed:@"jobInfo_HeaderStripe.png"] stretchableImageWithLeftCapWidth:18 topCapHeight:18]];
	[viewImage setBackgroundColor:[UIColor clearColor]];
	[headerView addSubview:viewImage];
    
//    [headerView setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"jobInfo_HeaderStripe.png"]]];
    
    UILabel *lblHeaderTitle= [[UILabel alloc]initWithFrame:CGRectMake(20, 5, 300, 20)];
    lblHeaderTitle.font = FONT_NEUE_SIZE(14);
               [lblHeaderTitle setTextColor:DEFAULT_FONT_COLOR];
    lblHeaderTitle.backgroundColor = [UIColor clearColor];
    
//    UIButton *btnHiddenSlide = [[UIButton alloc]initWithFrame:CGRectMake(285, 3200, 25, 36)];
//    btnHiddenSlide.backgroundColor = [UIColor redColor];
//    [btnHiddenSlide setTag:section];
//    [btnHiddenSlide addTarget:self action:@selector(btnPlusMinusTapped:) forControlEvents:UIControlEventTouchUpInside];
//    [headerView addSubview:btnHiddenSlide];

    
    UIButton *btnPlusMinus = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 320, 36)];
    [btnPlusMinus setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    btnPlusMinus.titleLabel.textAlignment = UITextAlignmentRight;
    [btnPlusMinus setContentHorizontalAlignment:UIControlContentHorizontalAlignmentRight];
    [btnPlusMinus setContentVerticalAlignment:UIControlContentVerticalAlignmentCenter];
    [btnPlusMinus setContentEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 10)];
    btnPlusMinus.backgroundColor = [UIColor clearColor];
    [btnPlusMinus setTag:section];
    [btnPlusMinus addTarget:self action:@selector(btnPlusMinusTapped:) forControlEvents:UIControlEventTouchUpInside];
    
    
    
    [headerView addSubview:btnPlusMinus];
    
    
    if(section == 0)
    {
        lblHeaderTitle.text = @"Job Info";
        
    }
    else if(section == 1 || section == 2)
    {
        if(section == 1)
        {
            if([arrWorkDone count]<=0){
                [btnPlusMinus setHidden:YES];
                lblHeaderTitle.text = @"Work Done - Not available";
                
            }
            else {
                [btnPlusMinus setHidden:NO];
                lblHeaderTitle.text = @"Work Done";
                
            }
            
        }
        else
        {
            if([arrCallHistory count]<=0){
                [btnPlusMinus setHidden:YES];
                lblHeaderTitle.text = @"Call History - Not available";
                
            }
            else
            {
                [btnPlusMinus setHidden:NO];
                lblHeaderTitle.text = @"Call History";
            }
        }

        if((isShow1 && section == 1) || (isShow2 && section == 2))
        {
            [btnPlusMinus setTitle:@"-" forState:UIControlStateNormal];
            
            UIView *titleView = [[UIView alloc]initWithFrame:CGRectMake(0, 36, 320,25)];
            titleView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"jobInfo_Row_Stripe.png"]];
            [headerView addSubview:titleView];
            
            UILabel *lblDate = [[UILabel alloc]initWithFrame:CGRectMake(5, 2, 75, 20)];
            lblDate.text = @"Date";
            lblDate.textColor = DEFAULT_FONT_COLOR;
            lblDate.backgroundColor = [UIColor clearColor];
            [titleView addSubview:lblDate];
            
            UILabel *lblEng = [[UILabel alloc]initWithFrame:CGRectMake(75, 2, 50, 20)];
            lblEng.text = @"Eng";
            lblEng.textColor = DEFAULT_FONT_COLOR;
            lblEng.backgroundColor = [UIColor clearColor];
            [titleView addSubview:lblEng];
            UILabel *lblDescription = nil;
             if (isShow1 && section == 1)
            lblDescription = [[UILabel alloc]initWithFrame:CGRectMake(150, 2, 100, 20)];
            else if  (isShow2 && section == 2)
            lblDescription = [[UILabel alloc]initWithFrame:CGRectMake(150, 2, 180, 20)];
            
            lblDescription.text = @"Description";
            lblDescription.textColor = DEFAULT_FONT_COLOR;
            lblDescription.backgroundColor = [UIColor clearColor];
            [titleView addSubview:lblDescription];
            
            if (isShow1 && section == 1)
            {
            UILabel *lblHTM = [[UILabel alloc]initWithFrame:CGRectMake(252, 2, 60, 20)];
            lblHTM.text = @"H  T  M";
            lblHTM.textColor = DEFAULT_FONT_COLOR;
            lblHTM.backgroundColor = [UIColor clearColor];
            [titleView addSubview:lblHTM];
            }
        }
        else
        {
            [btnPlusMinus setTitle:@"+" forState:UIControlStateNormal];
        }
        
    }
    else if(section == 3)
    {
        if([arrAttachment count]<=0){
            [btnPlusMinus setHidden:YES];
            lblHeaderTitle.text = @"Attachments - Not available";
            
        }
        else {
            [btnPlusMinus setHidden:NO];
            lblHeaderTitle.text = @"Attachments ";
            
        }
        
        
        
        if(isShow3)
        {
            [btnPlusMinus setTitle:@"-" forState:UIControlStateNormal];
            
            UIView *titleView = [[UIView alloc]initWithFrame:CGRectMake(0, 36, 320,25)];
            titleView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"jobInfo_Row_Stripe.png"]];
            [headerView addSubview:titleView];
            
            UILabel *lblDate = [[UILabel alloc]initWithFrame:CGRectMake(5, 0, 75, 25)];
            lblDate.text = @"Date";
            lblDate.textColor = DEFAULT_FONT_COLOR;
            lblDate.backgroundColor = [UIColor clearColor];
            [titleView addSubview:lblDate];
            
            UILabel *lblFileName = [[UILabel alloc]initWithFrame:CGRectMake(93, 2, 200, 25)];
            lblFileName.text = @"File Name";
            lblFileName.textColor = DEFAULT_FONT_COLOR;
            lblFileName.backgroundColor = [UIColor clearColor];
            [titleView addSubview:lblFileName];
            
        }
        else
        {
            [btnPlusMinus setTitle:@"+" forState:UIControlStateNormal];
        }
        
    }
    else
    {
        lblHeaderTitle.text =nil;
        
    }
    
    
    [headerView addSubview:lblHeaderTitle];
    return headerView;
}
#pragma mark -
#pragma mark Button Method


-(IBAction)btnPlusMinusTapped:(UIButton *)sender
{
    
    if(sender.tag == 1)
    {
        isShow1=!isShow1;
        
        [tblView reloadSections:[NSIndexSet indexSetWithIndex:sender.tag] withRowAnimation:UITableViewRowAnimationFade];
        
        if (isShow1)
        {
            [tblView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:sender.tag] atScrollPosition:UITableViewScrollPositionTop animated:YES];
        }
        
    }
    if(sender.tag == 2)
    {
        isShow2=!isShow2;
        
        [tblView reloadSections:[NSIndexSet indexSetWithIndex:sender.tag] withRowAnimation:UITableViewRowAnimationFade];
        
        if (isShow2)
        {
            [tblView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:sender.tag] atScrollPosition:UITableViewScrollPositionTop animated:YES];
        }
        
    }
    if(sender.tag == 3)
    {
        isShow3=!isShow3;
        
        [tblView reloadSections:[NSIndexSet indexSetWithIndex:sender.tag] withRowAnimation:UITableViewRowAnimationFade];
        
        if (isShow3)
        {
            [tblView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:sender.tag] atScrollPosition:UITableViewScrollPositionTop animated:YES];
        }
        
    }
    
    
    
    
    
}
-(IBAction)btnCallHistory:(id)sender{
    NSLog(@"btnCallHistory clicked");
}
-(IBAction)btnAttachment:(id)sender{
    NSLog(@"btnAttachment clicked");
}

#pragma mark ScrollItem Selected
-(IBAction)ItemSelect:(id)button{
    
    int currentTag;
    currentTag = [button tag]-REACTIVE_JOB_ITEMS_TAG;
    
    if (currentTag <0)
        return ;
    
    if (currentTag>2 && !isServiceExists)
        currentTag+=1;
        
    if(currentTag == 0)  //Upload Co-ordinates and perfom check-in
    {

         
          NSString *strCurrentTimeStamp = [CommonFunctions getCurrentTimeStamp];  
        
        if ([DataSource executeQuery: [NSString stringWithFormat:@"UPDATE Jobs SET eng_on_site='%@', stt='In Progress',IsSynced=%@  WHERE jid = '%@'",[CommonFunctions getCurrentTimeStampForDatabaseInsertion:strCurrentTimeStamp],UN_SYNCED_DATA,strJid]])
            NSLog(@"Job Status Updated");
        
        if ([CommonFunctions isNetAvailable])
        {
        //Upload Co-ordinates
        
        
        CLLocationCoordinate2D coordinate = [CommonFunctions GetCoordinates];
        objService=[[getWebService alloc] init];
        objService._delegate=self;
        
        NSMutableDictionary *dicc=[[[NSMutableDictionary alloc] init]autorelease];
        [dicc setObject:[ElogBooksAppDelegate getValueForKey:USER_ID] forKey:USER_ID];
        
        [dicc setObject:@"jobs" forKey:@"UpdateType"];
        [dicc setObject:@"Start" forKey:@"qd"];
    
        [dicc setObject:strCurrentTimeStamp forKey:@"tstamp"];        
        
        [dicc setObject:strJid forKey:JOBS_ID];
        
        [dicc setObject:[NSString stringWithFormat:@"%f",coordinate.latitude] forKey:@"lat"];
        [dicc setObject:[NSString stringWithFormat:@"%f",coordinate.longitude]forKey:@"lon"];
        
        
        
       
      
        objService.argsDic=[CommonFunctions getDicAsParameter:dicc];
        //name the service
        objService.strWebService=@"latlon";
        //Get info URL
        NSString *strurl = [NSString stringWithFormat:@"%@%@",[ElogBooksAppDelegate getValueForKey:BASE_URL],PUT_INFO_API];
        //set nodes
        objService.strUrl= strurl;
        objService.strParent=@"Responses";
        objService.strSubParent=@"Responses";
        [objService performSelector:@selector(setArray) withObject:nil afterDelay:0.1];
        }
        else 
        {
        //Update Job Status and set Eng_on_site
            [self LoadArrays];
        [self LoadHorizontalScrollview];
        [tblView reloadData];
            
        }
    }
    else if(currentTag == 1)
    {
        JobUpdateViewController *objNav = [[JobUpdateViewController alloc] initWithNibName:@"JobUpdateViewController" bundle:nil];
        objNav.strTitleStatus = @"Update Job";
        objNav.strJid = strJid;
        [self.navigationController pushViewController:objNav animated:YES];
        [objNav release];
    }
    else if(currentTag == 2)
    {
        UpdateJobViewController *objNav = [[UpdateJobViewController alloc] initWithNibName:@"UpdateJobViewController" bundle:nil];
        objNav.strTitleStatus = @"Complete Job";
        objNav.strJid = strJid;
        [self.navigationController pushViewController:objNav animated:YES];
        [objNav release];
    }
    else if(currentTag == 3)
    {

        ServiceRoutine *objNav = [[ServiceRoutine alloc] initWithNibName:@"ServiceRoutine" bundle:nil];
        objNav.strJid =strJid;
        [self.navigationController pushViewController:objNav animated:YES];
        [objNav release];
        
        
    }
    else if(currentTag == 4)
    {
        AddMaterials *objNav = [[AddMaterials alloc] initWithNibName:@"AddMaterials" bundle:nil];
        objNav.strJid =strJid;
        [self.navigationController pushViewController:objNav animated:YES];
        [objNav release];
        
    }
    else if(currentTag == 5)
    {
        SubAssetScreen *objNav = [[SubAssetScreen alloc] initWithNibName:@"SubAssetScreen" bundle:nil];
        objNav.strJid = strJid;
        [self.navigationController pushViewController:objNav animated:YES];
        [objNav release];
    } 
    else if(currentTag == 6)
    {
        UploadImageScreen *objNav = [[UploadImageScreen alloc] initWithNibName:@"UploadImageScreen" bundle:nil];
        objNav.strjid=strJid;
        [self.navigationController pushViewController:objNav animated:YES];
        [objNav release];

    }
    else if(currentTag == 7)
    {
        SignViewController *objNav = [[SignViewController alloc] initWithNibName:@"SignViewController" bundle:nil];
        objNav.strjid=strJid;
        [self.navigationController pushViewController:objNav animated:YES];
        [objNav release];
        
    }
    else if(currentTag == 8)
    {
        UpdatePointScreen *objUpdatePoint = [[UpdatePointScreen alloc]initWithNibName:@"UpdatePointScreen" bundle:nil];
        objUpdatePoint.strJid = strJid;
        [self.navigationController pushViewController:objUpdatePoint animated:YES];
        [objUpdatePoint release];
    }
    
    
//    else if(currentTag == 9)
//    {
//        
////        UploadFile  *objNav = [[[UploadFile alloc] initWithNibName:@"UploadFile" bundle:nil]autorelease];
////        objNav.navigationItem.hidesBackButton = YES;
////        [self.navigationController pushViewController:objNav animated:YES];
//
////        [objNav.view setFrame:CGRectMake(0, 100, 320, 300)];
////        UINavigationController *objNavContrl = [[UINavigationController alloc] initWithRootViewController:objNav];
////        [self.navigationController presentModalViewController:objNavContrl animated:YES];
//    }
    
    NSLog(@"@Item clicked");
}

#pragma mark WebService Delegates
-(void)filedWithError:(NSString *)strMsg forFlage:(NSString *)flage
{
 
    //Funciton to be called while reloading 
    [self LoadArrays];
    [self LoadHorizontalScrollview];
    [tblView reloadData];
    
    UIAlertView *alert=[[[UIAlertView alloc] initWithTitle:APP_TITLE message:strMsg delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil]autorelease];
    [alert show];
	[objService release];
}

-(void)EndParsing:(NSMutableArray *)arrDataa forFlage:(NSString *)flage
{
    if ([flage isEqualToString:@"latlon"]) //latlon parsing result
    {
        //Funciton to be called while reloading 
        [self LoadArrays];
        [self LoadHorizontalScrollview];
        [tblView reloadData];
        
        if ([arrData count]>0)
        {
            if  (!([[[arrDataa objectAtIndex:0]valueForKey:@"Response"]rangeOfString:@"Success"].location ==NSNotFound)) //Success
            {
                NSLog(@"Timestamp with co-ordinates updated");
                UIAlertView *alert=[[[UIAlertView alloc] initWithTitle:APP_TITLE message:@"Geolocation Updated!" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil]autorelease];
                [alert show];
                
                if([DataSource executeQuery:[NSString stringWithFormat:@"Update Jobs set  IsJobStarted='Y' where jid=%@",strJid]])
                    NSLog(@"Job :%@:synced",flage); 
                else 
                    NSLog(@"Job :%@:failed to synce",flage);  
                
                if ([DataSource executeQuery: [NSString stringWithFormat:@"UPDATE Jobs SET IsSynced=%@  WHERE jid = '%@'",SYNCED_DATA,strJid]])
                    NSLog(@"Job Status Updated");
            }
        }
        

    }
}

#pragma mark -
#pragma mark scrollView

- (void)scrollViewDidScroll:(UIScrollView *)sender 
{
    
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
}

- (void)viewDidUnload
{
    arrkeys = nil;
    StrAssets_id = nil;
    strCurrJobType = nil;
    arrData = nil;
    arrWorkDone = nil;
    arrCallHistory = nil;
    arrAttachment = nil;
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
