//
//  SubAssetViewEditScreen.h
//  ElogBooks
//
//  Created by I-VERVE5 on 12/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SubAssetViewEditScreen : UIViewController<UITextFieldDelegate,PutInfoDelegate>
{
    IBOutlet UIScrollView *ScrView; 
    IBOutlet UITextField *txtSubAssetLocation,*txtCondition,*txtRisk,*txtModelName,*txtSerialNO,*txtSerialName,*txtTypetag;
    IBOutlet UITextField *txtDescription,*txtNotes;
    UIButton *btnCancel;
    UIButton *btnEdit;
    BOOL isEditTapped;
    //Webservice Delegates
    PutInfoClass *objService;
}
@property (nonatomic,retain)NSString *strASSETS_SUB_ID,*strSubAssetsName,*strAssets_sub_histId,*strJid;
@property (nonatomic,retain) NSMutableDictionary *dicRecordSelected;
@end
