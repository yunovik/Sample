//
//  SubAssetViewEditScreen.m
//  ElogBooks
//
//  Created by I-VERVE5 on 12/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import "SubAssetViewEditScreen.h"
#define  TAG_TEXT_FIELD 6000
@interface SubAssetViewEditScreen ()

@end

@implementation SubAssetViewEditScreen
@synthesize strASSETS_SUB_ID,strSubAssetsName,strAssets_sub_histId,strJid,dicRecordSelected;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    
    self.title = @"Sub Assets Info/Edit";
    
    [CommonFunctions setTitleView:self amdtitle:@"Sub Assets Info/Edit"];
    
    
    UIView *backView = [[[UIView alloc] init] autorelease];
    backView.frame = CGRectMake(0, 0, 320, 61);
    backView.backgroundColor = getImageColor(@"Cell_Stripe.png");
    [self.view addSubview:backView];
    
    //Back Button On Navigation
    [CommonFunctions setBack:self target:@selector(btnBackTapped:)];
    
    UILabel *lblAsstId = [[UILabel alloc]initWithFrame:CGRectMake(10, 20 ,65, 20)];
    lblAsstId.backgroundColor = [UIColor clearColor];
    [lblAsstId setFont:FONT_NEUE_BOLD_SIZE(13) ];
    [lblAsstId setTextColor:DEFAULT_FONT_COLOR];
    [lblAsstId setText:[dicRecordSelected objectForKey:ASSETS_SUB_ID] ];
    //lblAsstId.text = [redDic objectForKey:@"id"];
    [backView addSubview:lblAsstId];
    [lblAsstId release];
    
    UILabel *lblAsstName = [[UILabel alloc]initWithFrame:CGRectMake(75, 20, 280, 20)];
    lblAsstName.backgroundColor = [UIColor clearColor];
    [lblAsstName setFont:FONT_NEUE_BOLD_SIZE(13) ];
    [lblAsstName setTextColor:DEFAULT_FONT_COLOR];
    if (([dicRecordSelected valueForKey:ASSETS_SUB_LOCATION]!=nil) &&([dicRecordSelected valueForKey:ASSETS_SUB_SNAME]!=nil))
    [lblAsstName setText: [NSString stringWithFormat:@"%@-%@",[dicRecordSelected objectForKey:ASSETS_SUB_LOCATION],[dicRecordSelected objectForKey:ASSETS_SUB_SNAME]]];
    else if ([dicRecordSelected valueForKey:ASSETS_SUB_LOCATION]!=nil)
    [lblAsstName setText: [NSString stringWithFormat:@"%@",[dicRecordSelected objectForKey:ASSETS_SUB_LOCATION]]];   
    else if ([dicRecordSelected valueForKey:ASSETS_SUB_SNAME]!=nil)
        [lblAsstName setText: [NSString stringWithFormat:@"%@",[dicRecordSelected objectForKey:ASSETS_SUB_SNAME]]];   

                                                                        
    //    lblAsstId.text = [redDic objectForKey:@"id"];
    [backView addSubview:lblAsstName];
    [lblAsstName release];
    
    
    btnCancel=[UIButton buttonWithType:UIButtonTypeCustom];
    [btnCancel setFrame:CGRectMake(200,5,50,50)];
    UIImage *InfoImage = getImage(@"btnCancel.png");
    [btnCancel setImage:InfoImage forState:UIControlStateNormal];
    [btnCancel addTarget:self action:@selector(btnCancelTapped:) forControlEvents:UIControlEventTouchUpInside];
    [btnCancel setEnabled:YES];
    [btnCancel setHidden:YES];
    [backView addSubview:btnCancel];
    
    btnEdit = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    btnEdit = [[UIButton alloc]init];
    btnEdit=[UIButton buttonWithType:UIButtonTypeCustom];
    [btnEdit setFrame:CGRectMake(260,5,50,50)];
    UIImage *EditImage = getImage(@"btnsubassetsedit.png");
    [btnEdit setImage:EditImage forState:UIControlStateNormal];
    [btnEdit addTarget:self action:@selector(btnEditTapped:) forControlEvents:UIControlEventTouchUpInside];
    [btnEdit setEnabled:YES];
    [backView addSubview:btnEdit];
    
    //set Left Indentation
    for (int i=TAG_TEXT_FIELD+0;i<TAG_TEXT_FIELD+9;i++)
    {
        UITextField *txtTmpField = (UITextField *)[self.view viewWithTag:i];
        [txtTmpField setUserInteractionEnabled:NO];
        [CommonFunctions SetLeftViewMode:txtTmpField :10.0f];
    }
    
    [self SetPreviousValues];
    
    //    //Set Previous Values
    //    NSMutableArray *arrInfo = [DataSource getRecordsFromQuery:[NSString stringWithFormat:@"select Assets_sub.loc,Assets.model As modelNo,Assets.cond,Assets.risk,Assets_sub.model As modelName,Assets_sub.sname,Assets_sub.stype from Assets_sub join Assets on Assets.aid = Assets_sub.aid where Assets_sub.said = %@",strASSETS_SUB_ID]];
    //    if ([arrInfo count]>0)
    //    {
    //        if ([[arrInfo objectAtIndex:0]valueForKey:@"loc"]!=nil)
    //            txtSubAssetLocation.text = [[arrInfo objectAtIndex:0]valueForKey:@"loc"];
    //        if ([[arrInfo objectAtIndex:0]valueForKey:@"cond"]!=nil)
    //            txtCondition.text = [[arrInfo objectAtIndex:0]valueForKey:@"cond"];
    //        if ([[arrInfo objectAtIndex:0]valueForKey:@"risk"]!=nil)
    //            txtRisk.text = [[arrInfo objectAtIndex:0]valueForKey:@"risk"];
    //        if ([[arrInfo objectAtIndex:0]valueForKey:@"modelName"]!=nil)
    //            txtModelName.text = [[arrInfo objectAtIndex:0]valueForKey:@"modelName"];
    //        if ([[arrInfo objectAtIndex:0]valueForKey:@"modelNo"]!=nil)
    //            txtModelNo.text = [[arrInfo objectAtIndex:0]valueForKey:@"modelNo"];
    //        if ([[arrInfo objectAtIndex:0]valueForKey:@"sname"]!=nil)
    //            txtSerialName.text = [[arrInfo objectAtIndex:0]valueForKey:@"sname"];
    //        if ([[arrInfo objectAtIndex:0]valueForKey:@"model"]!=nil)
    //            txtTypetag.text = [[arrInfo objectAtIndex:0]valueForKey:@"stype"];
    //
    //    }
    
}
#pragma mark SetPrevious Values
-(void)SetPreviousValues
{
//    NSMutableArray *arrInfo;
//    //Set Previous Values
//    if ([strAssets_sub_histId length]>0 && [strASSETS_SUB_ID length]>0)
//        arrInfo = [DataSource getRecordsFromQuery:[NSString stringWithFormat:@" select Assets_sub.loc,Assets_sub.model,Assets_sub.serialno,Assets_sub.sname,Assets_sub.stype,Assets_sub_history.cond,Assets_sub_history.risk from Assets_sub left join Assets_sub_history on Assets_sub.said = Assets_sub_history.said where Assets_sub.said = %@ or Assets_sub_history.hiid = %@",strASSETS_SUB_ID,strAssets_sub_histId]];
//    else if ([strASSETS_SUB_ID length]>0)
//        arrInfo = [DataSource getRecordsFromQuery:[NSString stringWithFormat:@" select Assets_sub.loc,Assets_sub.model,Assets_sub.serialno,Assets_sub.sname,Assets_sub.stype,Assets_sub_history.cond,Assets_sub_history.risk from Assets_sub left join Assets_sub_history on Assets_sub.said = Assets_sub_history.said where Assets_sub.said = %@",strASSETS_SUB_ID]];
//    if ([arrInfo count]>0)
//    {
        if ([dicRecordSelected valueForKey:ASSETS_SUB_LOCATION]!=nil)
            txtSubAssetLocation.text = [dicRecordSelected valueForKey:ASSETS_SUB_LOCATION];
     if ([dicRecordSelected valueForKey:ASSETS_SUB_HISTORY_COND]!=nil)
            txtCondition.text = [dicRecordSelected valueForKey:ASSETS_SUB_HISTORY_COND];
     if ([dicRecordSelected valueForKey:ASSETS_SUB_HISTORY_RISK]!=nil)
            txtRisk.text = [dicRecordSelected valueForKey:ASSETS_SUB_HISTORY_RISK];
        if ([dicRecordSelected valueForKey:ASSETS_SUB_MODEL]!=nil)
            txtModelName.text = [dicRecordSelected valueForKey:ASSETS_SUB_MODEL];
        if ([dicRecordSelected valueForKey:ASSETS_SUB_SERIALNO]!=nil)
            txtSerialNO.text = [dicRecordSelected valueForKey:ASSETS_SUB_SERIALNO];
        if ([dicRecordSelected valueForKey:ASSETS_SUB_SNAME]!=nil)
            txtSerialName.text = [dicRecordSelected valueForKey:ASSETS_SUB_SNAME];
       if ([dicRecordSelected valueForKey:ASSETS_SUB_STYPE]!=nil)
            txtTypetag.text = [dicRecordSelected valueForKey:ASSETS_SUB_STYPE];
    if ([dicRecordSelected valueForKey:ASSETS_SUB_SDESCR]!=nil)
        txtDescription.text = [dicRecordSelected valueForKey:ASSETS_SUB_SDESCR];
    if ([dicRecordSelected valueForKey:ASSETS_SUB_NOTES]!=nil)
        txtNotes.text = [dicRecordSelected valueForKey:ASSETS_SUB_NOTES];
//    }
}
#pragma mark - backTapped Method

-(IBAction)btnBackTapped:(id)sender
{
    
    [self.navigationController popViewControllerAnimated:YES];
}
-(IBAction)btnCancelTapped:(id)sender
{
    
    [self SetPreviousValues];
    isEditTapped = FALSE;
    [btnCancel setHidden: YES];
    UIImage *EditImage = getImage(@"btnsubassetsedit.png");
    [btnEdit setImage:EditImage forState:UIControlStateNormal];
    for (int i=TAG_TEXT_FIELD+0;i<TAG_TEXT_FIELD+9;i++)
    {
        UITextField *txtTmpField = (UITextField *)[self.view viewWithTag:i];
        [[txtTmpField layer]setBorderWidth:0];
        [txtTmpField setUserInteractionEnabled:NO];
    }
    [ScrView setContentOffset:CGPointMake(0, 0) animated:YES];
}

-(IBAction)btnEditTapped:(id)sender
{
    if (!isEditTapped)
    {
        UIImage *EditImage = getImage(@"btnComplete.png");
        [sender setImage:EditImage forState:UIControlStateNormal];
        isEditTapped = TRUE;
        [btnCancel setHidden:NO];
        for (int i=TAG_TEXT_FIELD+0;i<TAG_TEXT_FIELD+9;i++)
        {
            UITextField *txtTmpField = (UITextField *)[self.view viewWithTag:i];
            [[txtTmpField layer] setBorderWidth:1.5f];
            [txtTmpField setUserInteractionEnabled:YES];
            [[txtTmpField layer] setBorderColor:[[UIColor colorWithRed:86.0/255.0f green:86.0/255.0f blue:86.0/255.0f alpha:1.0] CGColor]];
            [[txtTmpField layer]setCornerRadius:5];
        }
    }
    else
    {
        
        isEditTapped = FALSE;
        UIImage *EditImage = getImage(@"btnsubassetsedit.png");
        [sender setImage:EditImage forState:UIControlStateNormal];
        [btnCancel setHidden:YES];
        for (int i=TAG_TEXT_FIELD+0;i<TAG_TEXT_FIELD+9;i++)
        {
            UITextField *txtTmpField = (UITextField *)[self.view viewWithTag:i];
            [[txtTmpField layer]setBorderWidth:0];
            [txtTmpField setUserInteractionEnabled:NO];
        }
        //Save  the changes
        
        NSString *strCurrentTimeStamp = [CommonFunctions getCurrentTimeStampForDatabaseInsertion];
        
        //update or insert  Assets_sub_history table 
        if (([[txtRisk.text stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0) || ([[txtCondition.text stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0))
        {
            //update assets_history
            if ([[[dicRecordSelected valueForKey:HISTORY_ID]stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0) 
            {
                //update history
                if (([[txtRisk.text stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0 ) && ([[txtCondition.text stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0 ))
                [DataSource executeQuery: [NSString stringWithFormat:@"update Assets_sub_history set risk=%@,cond=%@,IsSynced=%@ where hiid = %@",txtRisk.text,txtCondition.text,UN_SYNCED_DATA,[dicRecordSelected valueForKey:HISTORY_ID]]];
                else if ([[txtRisk.text stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0 )
                    [DataSource executeQuery: [NSString stringWithFormat:@"update Assets_sub_history set risk=%@,IsSynced=%@ where hiid = %@",txtRisk.text,UN_SYNCED_DATA,[dicRecordSelected valueForKey:HISTORY_ID]]];
                else if ([[txtCondition.text stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0 )
                    [DataSource executeQuery: [NSString stringWithFormat:@"update Assets_sub_history set cond=%@,IsSynced=%@ where hiid = %@",txtCondition.text,UN_SYNCED_DATA,[dicRecordSelected valueForKey:HISTORY_ID]]];
            }
            else 
            {
                //Create History
                if (([[txtRisk.text stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0 ) && ([[txtCondition.text stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0 ))                
                [DataSource executeQuery: [NSString stringWithFormat:@"insert into Assets_sub_history (jid,said,uid,hdate,src,risk,cond,IsSynced) values(%@,%@,%@,'%@','H','%@','%@',%@)",strJid,[dicRecordSelected valueForKey:ASSETS_SUB_ID],[ElogBooksAppDelegate getValueForKey:USER_ID],strCurrentTimeStamp,txtRisk.text,txtCondition.text,UN_SYNCED_DATA]];
                else if ([[txtRisk.text stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0 )
                    [DataSource executeQuery: [NSString stringWithFormat:@"insert into Assets_sub_history (jid,said,uid,hdate,src,risk,IsSynced) values(%@,%@,%@,'%@','H','%@',%@)",strJid,[dicRecordSelected valueForKey:ASSETS_SUB_ID],[ElogBooksAppDelegate getValueForKey:USER_ID],strCurrentTimeStamp,txtRisk.text,UN_SYNCED_DATA]];
                else if ([[txtCondition.text stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0 )
                    [DataSource executeQuery: [NSString stringWithFormat:@"insert into Assets_sub_history (jid,said,uid,hdate,src,cond,IsSynced) values(%@,%@,%@,'%@','H','%@',%@)",strJid,[dicRecordSelected valueForKey:ASSETS_SUB_ID],[ElogBooksAppDelegate getValueForKey:USER_ID],strCurrentTimeStamp,txtCondition.text,UN_SYNCED_DATA]];
                
            }
        }
        //update assets_sub table 
        if  ([dicRecordSelected valueForKey:ASSETS_SUB_ID]!=nil)
        {
            NSString *strQuery= @"Update Assets_sub set ";
            if([[txtSubAssetLocation.text stringByReplacingOccurrencesOfString:@" " withString:@""]length] >0 )
                strQuery = [strQuery stringByAppendingString: [NSString stringWithFormat:@"loc='%@',",txtSubAssetLocation.text]];
            if([[txtModelName.text stringByReplacingOccurrencesOfString:@" " withString:@""]length] >0 )
                strQuery = [strQuery stringByAppendingString: [NSString stringWithFormat:@"model='%@',",txtModelName.text]];
            if([[txtSerialNO.text stringByReplacingOccurrencesOfString:@" " withString:@""]length] >0 )
                strQuery = [strQuery stringByAppendingString: [NSString stringWithFormat:@"serialno='%@',",txtSerialNO.text]];
            if([[txtSerialName.text stringByReplacingOccurrencesOfString:@" " withString:@""]length] >0 )
                strQuery = [strQuery stringByAppendingString: [NSString stringWithFormat:@"sname='%@',",txtSerialName.text]];
            if([[txtTypetag.text stringByReplacingOccurrencesOfString:@" " withString:@""]length] >0 )
                strQuery = [strQuery stringByAppendingString: [NSString stringWithFormat:@"stype='%@',",txtTypetag.text]];
            if([[txtDescription.text stringByReplacingOccurrencesOfString:@" " withString:@""]length] >0 )
                strQuery = [strQuery stringByAppendingString: [NSString stringWithFormat:@"sdescr='%@',",txtDescription.text]];
            if([[txtNotes.text stringByReplacingOccurrencesOfString:@" " withString:@""]length] >0 )
                strQuery = [strQuery stringByAppendingString: [NSString stringWithFormat:@"notes='%@',",txtNotes.text]];
               //insert sync info
                strQuery = [strQuery stringByAppendingString: [NSString stringWithFormat:@"IsSynced=%@,",UN_SYNCED_DATA]];
               strQuery = [strQuery substringToIndex:[strQuery length]-1]; //remove last comma
                strQuery = [strQuery stringByAppendingString: [NSString stringWithFormat:@" where said=%@",[dicRecordSelected valueForKey:ASSETS_SUB_ID] ]];
             if  ([DataSource executeQuery:strQuery])
             {
                 NSLog(@"Value updated in Assets_sub TAble");
                 if ([CommonFunctions isNetAvailable])
                 {
                     
                     /*http://code.elogbooks.co.uk/users/jack/WOM/api/put-info.php?UpdateType=sub_assets&uid=38&jid=7686&include_5699=Y&location_5699=New%20Location&name_5699=New%20Name&cond_5699=5&risk_5699=4&qd=Update%20Sub%20Assets&type_5699=New%20Type&description_5699=New%20description&notes_5699=New%20Notes
                      */
                     //upload the values
                     objService=[[PutInfoClass alloc] init];
                     objService._delegate=self;
                     objService.retType=isArray;
                     NSMutableDictionary *dicc=[[[NSMutableDictionary alloc] init]autorelease];
                     [dicc setObject:@"sub_assets" forKey:@"UpdateType"];
                     [dicc setObject:[ElogBooksAppDelegate getValueForKey:USER_ID] forKey:USER_ID];
                     [dicc setObject:strJid forKey:JOBS_ID];                       [dicc setObject:@"Update Sub Assets" forKey:@"qd"];
                     NSString *str_XX = [dicRecordSelected valueForKey:ASSETS_SUB_ID];
                     [dicc setObject:@"Y" forKey: [NSString stringWithFormat:@"include_%@",str_XX]];
                     if ([[txtSubAssetLocation.text stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0)
                         [dicc setObject:txtSubAssetLocation.text forKey: [NSString stringWithFormat:@"location_%@",str_XX]];
                     if ([[txtSerialName.text stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0)
                         [dicc setObject:txtSerialName.text forKey: [NSString stringWithFormat:@"name_%@",str_XX]];
                     if ([[txtCondition.text stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0)
                         [dicc setObject:txtCondition.text forKey: [NSString stringWithFormat:@"cond_%@",str_XX]];
                     if ([[txtRisk.text stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0)
                         [dicc setObject:txtRisk.text forKey: [NSString stringWithFormat:@"risk_%@",str_XX]];
                     if ([[txtTypetag.text stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0)
                         [dicc setObject:txtTypetag.text forKey: [NSString stringWithFormat:@"type_%@",str_XX]];
                     if ([[txtDescription.text stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0)
                         [dicc setObject:txtDescription.text forKey: [NSString stringWithFormat:@"description_%@",str_XX]];
                     if ([[txtNotes.text stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0)
                         [dicc setObject:txtNotes.text forKey: [NSString stringWithFormat:@"notes_%@",str_XX]];
                     objService.argsDic=[CommonFunctions getDicAsParameter:dicc];
                     //point_id-->1 ===SCHEDULE_ID-->3 ====sort-->5 
                     objService.strWebService= @"Update Sub Assets";
                     objService.strUrl= [NSString stringWithFormat:@"%@%@",[ElogBooksAppDelegate getValueForKey:BASE_URL],PUT_INFO_API];
                     objService.ParentNode=@"Responses";
                     objService.ChildNode=@"Response";
                     [objService performSelector:@selector(setArray) withObject:nil afterDelay:0.1];

                     
                     
                 }
                 else 
                 {
                   [self.navigationController popViewControllerAnimated:YES];                     
                 } 
                 
             }
        }

    }
}
#pragma mark Parsing delegates
-(void)filedWithError:(NSString *)strMsg forFlage:(NSString *)flage
{
    NSLog(@"Failed to sync the subasset");
    [self.navigationController popViewControllerAnimated:YES];    
}
-(void)EndParsingArray:(NSMutableArray *)arrData forFlage:(NSString *)flage
{
    if ([arrData count]>0)
    {
        if (!([[arrData objectAtIndex:0]rangeOfString:@"Success"].location ==NSNotFound))
        {
            //record updated successfully
           if ( [DataSource executeQuery:[NSString stringWithFormat:@"Update Assets_sub set IsSynced =%@ where said = %@",SYNCED_DATA,[dicRecordSelected valueForKey:ASSETS_SUB_ID]]])
               NSLog(@"Value synced in Assets_sub table ");
               else 
                   NSLog(@"Value failed to synce in Assets_sub table ");
            
            //select MAX(hiid) from Assets_sub_history 
            if ([[[dicRecordSelected valueForKey:HISTORY_ID]stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0)
            {
            //update     
                [DataSource executeQuery: [NSString stringWithFormat:@"Update Assets_sub_history set IsSynced=%@ where hiid =%@",SYNCED_DATA,[dicRecordSelected valueForKey:HISTORY_ID]]];
            }
            else 
            {
              //update with the recently generate Id   
                NSString *strTempHiid = [DataSource getStringFromQuery: @"select MAX(hiid) from Assets_sub_history"];
          [DataSource executeQuery: [NSString stringWithFormat:@"Update Assets_sub_history set IsSynced=%@ where hiid =%@",SYNCED_DATA,strTempHiid]];
            }
            
            
        }
    }
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)UpdateOnServer:(NSMutableDictionary *)rec
{
    
    // loc ='NewLoca',model='',serialno='',sname='SA2',stype='',IsSynced=0 where said = 5700
    
    
    NSString* strUserId=[ElogBooksAppDelegate getValueForKey:USER_ID];
    NSString* said = [rec objectForKey:@"said"];
    
    NSString* jid = [rec objectForKey:@"jid"];
    NSString* include_xx = @"Y";
    NSString* location_xx = [rec objectForKey:@"location_xx"];
    NSString* name_xx = [rec objectForKey:@"name_xx"];
    NSString* description_xx = [rec objectForKey:@"description_xx"];
    NSString* type_xx = [rec objectForKey:@"type_xx"];
    NSString* cond_xx = [rec objectForKey:@"cond_xx"];
    NSString* risk_xx = [rec objectForKey:@"risk_xx"];
    
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
    
    [dic setObject:strUserId forKey:@"01:uid"];
    
    [dic setObject:@"sub_assets" forKey:@"02:UpdateType"];
    
    [dic setObject:@"Update Sub Assets" forKey:@"03:qd"];
    [dic setObject:jid forKey:@"04:jid"];
    
    
    [dic setObject:include_xx forKey:[NSString stringWithFormat:@"05:include_%@",said]];
    
    if([location_xx length]>0)
        [dic setObject:location_xx forKey:[NSString stringWithFormat:@"06:location_%@",said]];
    
    if([name_xx length]>0)
        [dic setObject:name_xx forKey:[NSString stringWithFormat:@"07:name_%@",said]];
    
    if([description_xx length]>0)
        [dic setObject:description_xx forKey:[NSString stringWithFormat:@"08:description_%@",said]];
    
    if([type_xx length]>0)
        [dic setObject:type_xx forKey:[NSString stringWithFormat:@"09:type_%@",said]];
    
    if([cond_xx length]>0)
        [dic setObject:cond_xx forKey:[NSString stringWithFormat:@"10:cond_%@",said]];
    
    if([risk_xx length]>0)
        [dic setObject:risk_xx forKey:[NSString stringWithFormat:@"11:risk_%@",said]];
    
    
    PutInfoClass *objJobsService = [[PutInfoClass alloc] init];
    objJobsService.argsDic = dic;
    
    objJobsService.ParentNode = @"Responses";
    objJobsService.ChildNode = @"Response";
    
    objJobsService.strWebService=[NSString stringWithFormat:@"SubAssets_%@",[rec objectForKey:@"said"]];
    
//    objJobsService.strUrl= @"http://code.elogbooks.co.uk/users/jack/WOM/api/put-info.php";
    objJobsService.strUrl = [NSString stringWithFormat:@"%@%@",[ElogBooksAppDelegate getValueForKey:BASE_URL],PUT_INFO_API];
    
}

#pragma mark UitextField delegates
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    if ([textField tag]>TAG_TEXT_FIELD+3)
        [ScrView setContentOffset:CGPointMake(0, ([textField tag]-TAG_TEXT_FIELD)*20 ) animated:YES];
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [ScrView setContentOffset:CGPointMake(0, 0) animated:YES];
    [textField resignFirstResponder];
    return YES;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
