//
//  SubAssetScreen.m
//  ElogBooks
//
//  Created by I-VERVE5 on 11/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import "SubAssetScreen.h"
#import "SubAssetViewEditScreen.h"
@interface SubAssetScreen ()

@end

@implementation SubAssetScreen
@synthesize strJid;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
#pragma mark ViewwillAppear
-(void)viewWillAppear:(BOOL)animated
{
    if (lastIndexPath!=nil)
    {
     [self RefreshData];
        [tblSubAsset reloadRowsAtIndexPaths:[NSArray arrayWithObject:lastIndexPath] withRowAnimation:UITableViewRowAnimationFade];
//      [tblSubAsset reloadData];
    }
    [super viewWillAppear:animated];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    
    self.title = @"Sub Assets";
    [CommonFunctions setTitleView:self amdtitle:@"Sub Assets"];
    //Back Button On Navigation
    [CommonFunctions setBack:self target:@selector(btnBackTapped:)];

    NSMutableArray *arrInfo = [DataSource getRecordsFromQuery: [NSString stringWithFormat:@"select aid,descr,location from Assets where aid in (select aid from Jobs where jid=%@)",strJid]];
   if ([arrInfo count]>0)
   {
    //UIview 
    UIView *backView = [[[UIView alloc] init] autorelease];
    backView.frame = CGRectMake(0, 0, 320, 61);
    backView.backgroundColor = getImageColor(@"Cell_Stripe.png");
    [self.view addSubview:backView];
    //[View release];
    

    
    UILabel *lblAsstId = [[UILabel alloc]initWithFrame:CGRectMake(10, 10 ,50, 20)];
    lblAsstId.backgroundColor = [UIColor clearColor];
    [lblAsstId setFont:FONT_NEUE_BOLD_SIZE(17) ];
    [lblAsstId setTextColor:DEFAULT_FONT_COLOR];
    [lblAsstId setText:[[arrInfo objectAtIndex:0]valueForKey:ASSETS_ID]];
    //    lblAsstId.text = [redDic objectForKey:@"id"];
    [backView addSubview:lblAsstId];
    [lblAsstId release];
    
    UILabel *lblAsstName = [[UILabel alloc]initWithFrame:CGRectMake(60, 7, 250, 29)];
    lblAsstName.backgroundColor = [UIColor clearColor];
        lblAsstName.numberOfLines = 0;
        [lblAsstName setLineBreakMode:UILineBreakModeWordWrap];
    [lblAsstName setFont:FONT_NEUE_BOLD_SIZE(17) ];
    [lblAsstName setTextColor:DEFAULT_FONT_COLOR];
    [lblAsstName setText:[[arrInfo objectAtIndex:0]valueForKey:ASSETS_DESC]];
    //    lblAsstId.text = [redDic objectForKey:@"id"];
    [backView addSubview:lblAsstName];
    [lblAsstName release];
    
    UILabel *lblAsstDesc = [[UILabel alloc]initWithFrame:CGRectMake(10, 35, 200, 20)];
    lblAsstDesc.backgroundColor = [UIColor clearColor];
    [lblAsstDesc setFont:FONT_NEUE_SIZE(14) ];
    [lblAsstDesc setTextColor:DEFAULT_FONT_COLOR];
    [lblAsstDesc setText:[[arrInfo objectAtIndex:0]valueForKey:ASSETS_LOCATION]];
    //    lblAsstId.text = [redDic objectForKey:@"id"];
    [backView addSubview:lblAsstDesc];
    [lblAsstDesc release];
    }
    // UITableView 
    
//    tblSubAsset = [[[UITableView alloc] initWithFrame:CGRectMake(0,61,320,399) style:UITableViewStylePlain]autorelease];
    tblSubAsset = [[[UITableView alloc] initWithFrame:CGRectMake(0,61,320,[[UIScreen mainScreen] bounds].size.height-81) style:UITableViewStylePlain]autorelease];
    UIEdgeInsets myInsets = {0, 0, 44, 0};
    tblSubAsset.contentInset = myInsets;
    tblSubAsset.dataSource = self;
    [tblSubAsset setShowsVerticalScrollIndicator:NO];
    [tblSubAsset setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    tblSubAsset.delegate = self;
    [self.view addSubview:tblSubAsset];

    [tblSubAsset setBackgroundColor:[UIColor clearColor]];
    
//    [self.view setBackgroundColor:getImageColor(@"Default.png")];
    [self.view setBackgroundColor:[UIColor whiteColor]];

   [self RefreshData];
       
//    if (strJid !=nil)
//    {
//        arr_SubAsList = [DataSource getRecordsFromQuery:[NSString stringWithFormat:@" select Assets_sub.loc as Status ,Assets_sub.said as said ,Assets_sub_history.cond as Condition,Assets_sub_history.risk As Risk,Assets_sub_history.hiid As hiid,  MAX(Assets_sub_history.hdate)  from Assets_sub left join Assets_sub_history on Assets_sub.said = Assets_sub_history.said where Assets_sub.aid in  (select aid from Jobs where jid = 7687)  GROUP BY Assets_sub.said",strJid]]; 
//        
//        /* select Assets_sub.loc as Status ,Assets_sub.said as said ,Assets_sub_history.cond as Condition,Assets_sub_history.risk As Risk,Assets_sub_history.hiid As hiid,  Assets_sub_history.hdate  from Assets_sub left join Assets_sub_history on Assets_sub.said = Assets_sub_history.said where Assets_sub.aid in  (select aid from Jobs where jid = 2787)
//         */
//    }
//    else  //static
//    {
//    arr_SubAsList = [[NSMutableArray alloc] init];
//    NSMutableDictionary *dicItem;
//    // Item 1.
//     for(int i=0;i<=10;i++)
//     {
//        dicItem  = [[NSMutableDictionary alloc] init];
//        [dicItem setObject:[NSString stringWithFormat:@"%d",1000+i] forKey:@"said"];
//        [dicItem setObject:@"Sub Asset Location" forKey:@"Status"];
//        [dicItem setObject:@"Condition $" forKey:@"Condition"];
//        [dicItem setObject:@"Risk $" forKey:@"Risk"];
//        [arr_SubAsList addObject:dicItem];
//        [dicItem release];
//     }
//   } 
    
    /*select Assets.risk as risk,Assets.cond as condition,Assets_sub.said,Assets.location,Assets.aid,Assets.descr As Name from Assets join Jobs on Jobs.aid = Assets.aid join Assets_sub on Assets.aid = Assets_sub.aid where Jobs.jid=2798*/  
    /*unique_Section_Category_Array = (NSMutableArray *)[[NSSet setWithArray:tempCategoryArray] allObjects];*/
    /* NSSet *uniqueStates = [NSSet setWithArray:[myArrayOfCustomObjects valueForKey:@"state"]];*/
    
}
#pragma mark -Refresh Data
-(void)RefreshData
{
    if (strJid !=nil)
    {
        arr_SubAsList = [DataSource getRecordsFromQuery:[NSString stringWithFormat:@"select Assets_sub.loc ,Assets_sub.said as said,Assets_sub_history.cond,Assets_sub_history.risk,Assets_sub.model,Assets_sub.serialno,Assets_sub.sname,Assets_sub.stype,Assets_sub.sdescr,Assets_sub.notes,Assets_sub_history.hiid from Assets_sub left join Assets_sub_history on Assets_sub.said = Assets_sub_history.said where Assets_sub.aid in (select aid from jobs where jid = '%@' )",strJid]]; 

        
//previous query         
//        arr_SubAsList = [DataSource getRecordsFromQuery:[NSString stringWithFormat:@" select Assets_sub.loc as Status ,Assets_sub.said as said ,Assets_sub_history.cond as Condition,Assets_sub_history.risk As Risk,Assets_sub_history.hiid As hiid,  MAX(Assets_sub_history.hdate)  from Assets_sub left join Assets_sub_history on Assets_sub.said = Assets_sub_history.said where Assets_sub.aid in  (select aid from Jobs where jid = %@)  GROUP BY Assets_sub.said",strJid]]; 
//        
        
        
        /* select Assets_sub.loc as Status,Assets_sub.said as said,Assets_sub_history.cond as Condition,Assets_sub_history.risk as Risk,Assets_sub.model,Assets_sub.serialno,Assets_sub.sname,Assets_sub.stype,Assets_sub.sdescr,Assets_sub.notes from Assets_sub left join Assets_sub_history on Assets_sub.said = Assets_sub_history.said where Assets_sub.aid in (select aid from jobs where jid = 8289 )
         */
    }
}
#pragma mark - Table view data source

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath 
{
    NSString *CellIdentifier = [NSString stringWithFormat:@"Cel_%d",indexPath.row];
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    NSDictionary *redDic = [arr_SubAsList objectAtIndex:indexPath.row ];
    
    cell = nil;
    if(cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] ;
        cell.selectionStyle = UITableViewCellSelectionStyleBlue;
        
        [cell.contentView setBackgroundColor:getImageColor(@"Cell_Stripe.png")];   
        
        
        UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(10, 5, 40, 20)];
        label.backgroundColor = [UIColor clearColor];
        [label setFont:FONT_NEUE_BOLD_SIZE(12) ];
        [label setTextColor:DEFAULT_FONT_COLOR];
        if ([redDic valueForKey:ASSETS_SUB_ID]!=nil)
        label.text = [redDic objectForKey:ASSETS_SUB_ID];
        [cell.contentView addSubview:label];
        [label release];
        
        UILabel *lbllocation = [[UILabel alloc] initWithFrame:CGRectMake(50, 5, 160, 20)];
        lbllocation.backgroundColor = [UIColor clearColor];
        lbllocation.numberOfLines = 0;
        [lbllocation setFont:FONT_NEUE_BOLD_SIZE(12) ];
        [lbllocation setTextColor:DEFAULT_FONT_COLOR];
        if ([redDic valueForKey:ASSETS_SUB_LOCATION]!=nil)
        lbllocation.text = [redDic objectForKey:ASSETS_SUB_LOCATION];
        [cell.contentView addSubview:lbllocation];
        [lbllocation release];
        
        
        
        UILabel *lblSubAssetName = [[UILabel alloc] initWithFrame:CGRectMake(200, 5, 200, 20)];
        lblSubAssetName.backgroundColor = [UIColor clearColor];
        lblSubAssetName.numberOfLines = 0;
        [lblSubAssetName setFont:FONT_NEUE_BOLD_SIZE(12) ];
        [lblSubAssetName setTextColor:DEFAULT_FONT_COLOR];
        if ([redDic valueForKey:ASSETS_SUB_SNAME]!=nil)
        lblSubAssetName.text = [redDic objectForKey:ASSETS_SUB_SNAME];
        [cell.contentView addSubview:lblSubAssetName];
        [lblSubAssetName release];
        
        UILabel *lblCondition = [[UILabel alloc] initWithFrame:CGRectMake(10, 20, 100, 25)];
        lblCondition.backgroundColor = [UIColor clearColor];
        lblCondition.numberOfLines = 0;
        [lblCondition setFont:FONT_NEUE_SIZE(12) ];
        [lblCondition setTextColor:DEFAULT_FONT_COLOR];
        if ([redDic valueForKey:ASSETS_SUB_HISTORY_COND]!=nil)
        lblCondition.text = [NSString stringWithFormat: @"Condition:  %@",[redDic objectForKey:ASSETS_SUB_HISTORY_COND]];
        [cell.contentView addSubview:lblCondition];
        [lblCondition release];
        
        
        UILabel *lblRisk = [[UILabel alloc] initWithFrame:CGRectMake(110, 20, 100, 25)];
        lblRisk.backgroundColor = [UIColor clearColor];
        lblRisk.numberOfLines = 0;
        [lblRisk setFont:FONT_NEUE_SIZE(12) ];
        [lblRisk setTextColor:DEFAULT_FONT_COLOR];
                if ([redDic valueForKey:ASSETS_SUB_HISTORY_RISK]!=nil)
        lblRisk.text =  [NSString stringWithFormat:@"Risk:  %@",[redDic objectForKey:ASSETS_SUB_HISTORY_RISK]];
        [cell.contentView addSubview:lblRisk];
        [lblRisk release];
        
//        UIButton *btnInfo = [UIButton buttonWithType:UIButtonTypeRoundedRect];
//        btnInfo = [[UIButton alloc]init];
//        btnInfo=[UIButton buttonWithType:UIButtonTypeCustom];
//        [btnInfo setFrame:CGRectMake(260,5,50,50)];
//        UIImage *newButtonImage = [UIImage imageNamed:@"Info.png"];        
//        [btnInfo setImage:newButtonImage forState:UIControlStateNormal];
//        [btnInfo addTarget:self action:@selector(InfoTapped:) forControlEvents:UIControlEventTouchUpInside];
//        [btnInfo setTitle:@"-" forState:UIControlStateNormal];
//        [btnInfo setEnabled:YES];
//        [cell.contentView addSubview:btnInfo];
//        [btnInfo release];
        
        
        UIView *selectedView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 61)];
        [selectedView setBackgroundColor:getImageColor(@"Cell_Stripe_Sel.png")];
        //[selectedView setBackgroundColor:[UIColor greenColor]];
        [cell setSelectedBackgroundView:selectedView];
        
    }
    
    return cell;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return arr_SubAsList.count;
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 61;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    SubAssetViewEditScreen* objNav=[[SubAssetViewEditScreen alloc] initWithNibName:@"SubAssetViewEditScreen" bundle:nil];
        objNav.strJid = strJid;
    objNav.dicRecordSelected = [arr_SubAsList objectAtIndex:indexPath.row];
    
    objNav.strASSETS_SUB_ID = [[arr_SubAsList objectAtIndex:indexPath.row]valueForKey:ASSETS_SUB_ID];
    objNav.strSubAssetsName = [[arr_SubAsList objectAtIndex:indexPath.row]valueForKey:ASSETS_SUB_SNAME];
    objNav.strAssets_sub_histId = [[arr_SubAsList objectAtIndex:indexPath.row]valueForKey:HISTORY_ID];
    [self.navigationController pushViewController:objNav animated:YES];
    [objNav release];
    
    lastIndexPath = indexPath;
    [lastIndexPath retain];
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark -
#pragma mark - backTapped Method

-(IBAction)btnBackTapped:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}


-(IBAction)InfoTapped:(id)sender
{
    NSLog(@"clicked Info");
}
- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
