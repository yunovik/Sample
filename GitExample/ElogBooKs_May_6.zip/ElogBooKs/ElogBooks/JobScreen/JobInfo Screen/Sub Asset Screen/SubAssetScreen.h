//
//  SubAssetScreen.h
//  ElogBooks
//
//  Created by I-VERVE5 on 11/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SubAssetScreen : UIViewController<UITableViewDelegate,UITableViewDataSource>
{
    UITableView *tblSubAsset;
    NSMutableArray *arr_SubAsList;
    NSIndexPath *lastIndexPath;

}
@property (nonatomic,retain) NSString *strJid;
@end
