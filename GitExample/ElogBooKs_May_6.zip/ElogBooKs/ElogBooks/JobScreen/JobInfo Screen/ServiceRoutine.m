//
//  ServiceRoutine.m
//  ElogBooks
//
//  Created by i-verve10 on 28/03/13.
//  Copyright (c) 2013 nayanmist@gmail.com. All rights reserved.
//

#import "ServiceRoutine.h"

@interface ServiceRoutine ()

@end

@implementation ServiceRoutine
@synthesize strJid;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    {
        
        self.title = @"Service Routine";
        [CommonFunctions setTitleView:self amdtitle:@"Service Routine"];
        
        
            [CommonFunctions setBack:self target:@selector(btnBackTapped:)];
        //Titleview
        
        UIView *headerView = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 36)] autorelease];
        UIImageView *viewImage = [[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 320, 36)]autorelease] ;
        [viewImage setImage:[[UIImage imageNamed:@"jobInfo_HeaderStripe.png"] stretchableImageWithLeftCapWidth:18 topCapHeight:18]];
        [viewImage setBackgroundColor:[UIColor clearColor]];
        [headerView addSubview:viewImage];
        UILabel *lblHeaderTitle= [[[UILabel alloc]initWithFrame:CGRectMake(20, 5, 300, 20)]autorelease];
        lblHeaderTitle.font = FONT_NEUE_SIZE(14);
        [lblHeaderTitle setTextColor:DEFAULT_FONT_COLOR_DARK];
         lblHeaderTitle.text = @"Service Routine Information";
        lblHeaderTitle.backgroundColor = [UIColor clearColor];
        [headerView addSubview:lblHeaderTitle];
        [self.view addSubview: headerView];
        
        
       NSMutableArray *arrServiceRoutines =  [DataSource getRecordsFromQuery:[NSString stringWithFormat:@"select service_routines.iid,service_routines.srid as name,service_routines.descr,service_routine_lines.period, CAST ( dord AS INTEGER) as dord,service_routine_lines.itm,service_routine_lines.act,service_routine_lines.notes from jobs join service_routines on jobs.srid = service_routines.iid join service_routine_lines on service_routines.iid = service_routine_lines.iid where jid = '%@'   order by dord",strJid]];
        
        NSMutableString *strhtmlcontent = [[NSMutableString alloc]initWithString:@"<html><body>"];
        if ([arrServiceRoutines count]>0)
        [strhtmlcontent appendString:[NSString stringWithFormat:@"<B>Name : %@</B><BR>",[[arrServiceRoutines objectAtIndex:0]valueForKey:@"name"]]];
        [strhtmlcontent appendString:[NSString stringWithFormat:@"<BR><B>Description : %@</B><BR>",[[arrServiceRoutines objectAtIndex:0]valueForKey:@"descr"]]];
      
        NSMutableArray *arrFrequency = [DataSource getRecordsFromQuery:[NSString stringWithFormat:@"select DISTINCT(period) as period from( select service_routine_lines.period, CAST ( dord AS INTEGER) as dord from jobs join service_routines on jobs.srid = service_routines.iid join service_routine_lines on service_routines.iid = service_routine_lines.iid where jid = '%@' ) as FinalTable  order by period,dord",strJid]];
        
        for (int j = 0;j<[arrFrequency count];j++)
        {
            [strhtmlcontent appendString:[NSString stringWithFormat:@"<BR><B>Frequency :%@</B><BR>",[[arrFrequency objectAtIndex:j]valueForKey:@"period"]]];
            
            NSMutableArray *arrFilteredFreq = [NSMutableArray arrayWithArray:[arrServiceRoutines filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"%K contains [cd] %@",@"period",[[arrFrequency objectAtIndex:j]valueForKey:@"period"]]]]  ;
           
            [arrFilteredFreq  sortUsingDescriptors:[NSArray arrayWithObjects:[[NSSortDescriptor alloc] initWithKey:@"dord"  ascending:YES],nil]];
            
            [strhtmlcontent appendString:@"<font size=""2"">"];
                for (int i =0;i<[arrFilteredFreq count];i++)
                {
                    if ([[[arrFilteredFreq objectAtIndex:i]valueForKey:@"itm"] length]>0)
                    [strhtmlcontent appendString:[NSString stringWithFormat:@"<BR><B>Item:</B> %@<BR>",[[arrFilteredFreq objectAtIndex:i]valueForKey:@"itm"]]];
                    if ([[[arrFilteredFreq objectAtIndex:i]valueForKey:@"act"] length]>0)
                    [strhtmlcontent appendString:[NSString stringWithFormat:@"<BR><B>Action:</B> %@<BR>",[[arrFilteredFreq objectAtIndex:i]valueForKey:@"act"]]];
                    if ([[[arrFilteredFreq objectAtIndex:i]valueForKey:@"notes"] length]>0)
                    [strhtmlcontent appendString:[NSString stringWithFormat:@"<BR><B>Notes:</B> %@<BR>",[[arrFilteredFreq objectAtIndex:i]valueForKey:@"notes"]]];
                    
                }
            [strhtmlcontent appendString:@"</font>"];
        }
        [strhtmlcontent appendString:@"</body></html>"];
       
        web_View = [[UIWebView alloc] initWithFrame:CGRectMake(10, 36, 310, 380)];
//        web_View.contentMode = UIViewContentModeScaleAspectFit;
        [web_View loadHTMLString:strhtmlcontent baseURL:nil];
        [self.view addSubview:web_View];
//        web_View.backgroundColor = [UIColor whiteColor];
        
        
        
        [web_View setBackgroundColor:[UIColor clearColor]];
        for(UIView* subview in [web_View subviews]){
            if([subview respondsToSelector:@selector(setBackgroundColor:)]){
                [subview setBackgroundColor:[UIColor clearColor]];
            }
            for(UIView* imageView in [subview subviews]){
                if([imageView isKindOfClass:[UIImageView class]]){
                    imageView.hidden = YES;
                }
            }
        }
        

        
    }
    
    
    
    [super viewDidLoad];
    
    
    // Do any additional setup after loading the view from its nib.
}



#pragma mark btnBackTapped
-(IBAction)btnBackTapped:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];  
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
