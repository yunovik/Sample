//
//  UpdateJobViewController.m
//  ELogBooks
//
//  Created by nayan mistry on 05/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import "UpdateJobViewController.h"
#define TAG_DATE_FIRST_ATTEND 555
#define TAG_DATE_COMPLETE 777
@interface UpdateJobViewController ()

@end

@implementation UpdateJobViewController
@synthesize strTitleStatus,strJid;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{

    
    [lblUploadWaring setHidden:YES];
    
    //set uinavigation view enable
    [self.navigationController.navigationBar setHidden:NO];
    //set navigation title
    self.title = strTitleStatus;
    [CommonFunctions setTitleView:self amdtitle:strTitleStatus];
    
    //UIview
    UIView *backView = [[[UIView alloc] init] autorelease];
    backView.frame = CGRectMake(0, 0, 320, 61);
    backView.backgroundColor = getImageColor(@"Cell_Stripe.png");
    [self.view addSubview:backView];
    //[View release];
    
    //Back Button On Navigation
    [CommonFunctions setBack:self target:@selector(btnBackTapped:)];
    
    NSMutableArray *arrJobInfo = [DataSource getRecordsFromQuery:
                                  [NSString stringWithFormat:
                                   @"select jid,stt,location,date_due from jobs Where jid = '%@'",strJid]];
    
    UILabel *lblPatrolId = [[UILabel alloc]initWithFrame:CGRectMake(10, 10 ,70, 20)];
    lblPatrolId.backgroundColor = [UIColor clearColor];
    [lblPatrolId setFont:FONT_NEUE_BOLD_SIZE(17) ];
    [lblPatrolId setTextColor:DEFAULT_FONT_COLOR];
    [lblPatrolId setText:[NSString stringWithFormat:@"%@ -",[[arrJobInfo objectAtIndex:0] objectForKey:JOBS_ID]]];
    //    lblAsstId.text = [redDic objectForKey:@"id"];
    [backView addSubview:lblPatrolId];
    [lblPatrolId release];
    
    UILabel *lblPatrolStatus = [[UILabel alloc]initWithFrame:CGRectMake(80, 10, 120, 20)];
    lblPatrolStatus.backgroundColor = [UIColor clearColor];
    [lblPatrolStatus setFont:FONT_NEUE_BOLD_SIZE(17) ];
    [lblPatrolStatus setTextColor:DEFAULT_FONT_COLOR];
    [lblPatrolStatus setText:[[arrJobInfo objectAtIndex:0] objectForKey:JOBS_STT]];
    //    lblPatrolStatus.text = [redDic objectForKey:@"id"];
    [backView addSubview:lblPatrolStatus];
    [lblPatrolStatus release];
    
    UILabel *lblPatrolDesc = [[UILabel alloc]initWithFrame:CGRectMake(10, 25, 200, 20)];
    lblPatrolDesc.backgroundColor = [UIColor clearColor];
    [lblPatrolDesc setFont:FONT_NEUE_SIZE(14) ];
    [lblPatrolDesc setTextColor:DEFAULT_FONT_COLOR];
    [lblPatrolDesc setText:[[arrJobInfo objectAtIndex:0] objectForKey:JOBS_LOCATION]];
    //    lblPatrolDesc.text = [redDic objectForKey:@"id"];
    [backView addSubview:lblPatrolDesc];
    [lblPatrolDesc release];
    
    btnUpdateJob.backgroundColor =getImageColor(@"Cell_Stripe.png");

    
    //Set Button Title
    [btnUpdateJob setTitle:strTitleStatus forState:UIControlStateNormal];
    
    
    
    
    //Set  Background color of all controls
//    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"Default.png"]];
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    
    UIImageView *imgBack = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, screenBounds.size.width, screenBounds.size.height)];
//    [imgBack setImage:[UIImage imageNamed:@"Default-568h@2x.png"]];
    [self.view addSubview:imgBack];
    [self.view sendSubviewToBack:imgBack];

    txViewJobUpdate.text = @"Click to begin typing";
    txViewJobUpdate.textColor = [UIColor grayColor];
    txViewJobUpdate.layer.borderWidth = 1.0;

//    txViewJobUpdate.backgroundColor = getImageColor(@"Cell_Stripe.png");
//    txthours.backgroundColor = getImageColor(@"Cell_Stripe.png");
//    txtTravel.backgroundColor = getImageColor(@"Cell_Stripe.png");
//    txtMileage.backgroundColor = getImageColor(@"Cell_Stripe.png");
//    txtJobAsset.backgroundColor = getImageColor(@"Cell_Stripe.png");
//    txtFirstAttendance.backgroundColor = getImageColor(@"Cell_Stripe.png");
//    txtJobCompletion.backgroundColor = getImageColor(@"Cell_Stripe.png");
    
    
    //Reset IsEscalationRequired value
    IsEscalationRequired = FALSE;
    
    // /* SELECT aid,location || ' : ' || descr from assets*/
//    arrPickerData = [DataSource getRecordsFromQuery:@"SELECT aid,location || ' : ' || descr As assetsName,location,descr,cond,risk from assets"];
    //select filtered assets
        arrPickerData = [DataSource getRecordsFromQuery:[NSString stringWithFormat:@"SELECT assets.aid,assets.location || ' : ' || assets.descr As assetsName,assets.location,descr,cond,risk from assets  where assets.cid in (select cid from jobs where jid = '%@') order by assetsName",strJid]];
    
    
    
    
    //default asset option
    NSMutableDictionary *dic = [[NSMutableDictionary alloc]init];
    [dic setObject:@"0" forKey:@"aid"];
    [dic setObject:@"None Selected" forKey:@"assetsName"];
    [arrPickerData insertObject:dic atIndex:0];
    
    //Set Scrollview contentsize
    if ([[UIScreen mainScreen] bounds].size.height == 568) {
        [scrView setFrame:CGRectMake(0, 15, 320, 498)];
    }else
    {
        [scrView setFrame:CGRectMake(0, 101, 320, 498)];
    }
    [scrView setContentSize:CGSizeMake(320, 565)];
    
    //set DateFormatter Allocation in Webservice format
    dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"dd/MM/YYYY HH:mm:ss"];
    
    
    //Hide Fadeview
    btnFade = [[UIButton alloc]initWithFrame:CGRectMake(0, [[UIScreen mainScreen] bounds].size.height-20, 320,480)];
    btnFade.backgroundColor = [UIColor blackColor];
    [btnFade addTarget:self action:@selector(HideDatePicker:) forControlEvents:UIControlEventTouchUpInside];
    [btnFade setAlpha:0.41];
    [self.view addSubview:btnFade];
    //DateTimePicker  Allocation
           objDatePicker = [[UIDatePicker alloc] initWithFrame:CGRectMake(0,[[UIScreen mainScreen] bounds].size.height-20, 320, 230)];
    objDatePicker.datePickerMode = UIDatePickerModeDateAndTime;
    [objDatePicker addTarget:self action:@selector(datePickerValuechanged:) forControlEvents:UIControlEventValueChanged];
    [self.view addSubview:objDatePicker];
    
    //set current Dates
    if ([strTitleStatus isEqualToString:@"Update Job"])
    {
        txtFirstAttendance.text = [dateFormatter stringFromDate:[NSDate date]];
    }
    else if ([strTitleStatus isEqualToString:@"Complete Job"])
    {
        txtJobCompletion.text =  [dateFormatter stringFromDate: [NSDate date]];
        
        NSString *str_EngOnSiteTime = [DataSource getStringFromQuery:[NSString stringWithFormat:@"SELECT eng_on_site FROM Jobs where jid = '%@'",strJid]];
        
        if ([str_EngOnSiteTime length]>0) //eng_on_site set 
        {
            txtFirstAttendance.text =   [CommonFunctions getCurrentTimeStamp:str_EngOnSiteTime];   
        }
        else 
        txtFirstAttendance.text =   [dateFormatter stringFromDate:[NSDate date]];
    }
    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

#pragma mark btnSubmitJobTapped
-(IBAction)btnSubmitJobTapped:(id)sender
{
    [txViewJobUpdate resignFirstResponder];
    if (txtTempField!=nil)
        [txtTempField resignFirstResponder];
    
    NSString *strResult = [self ValidateFields];
    if ([strResult isEqualToString:@"OK"])
    {
        UIButton *resultButton = (UIButton *)sender;
        NSLog(@" The button's title is %@.", resultButton.currentTitle);
        
        [self checkWhetherValueIsSet:txthours];
        [self checkWhetherValueIsSet:txtMileage];
        [self checkWhetherValueIsSet:txtTravel];
        
        if ([[txtJobCompletion.text stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0)
        {
            //complete the Job
            NSMutableDictionary *dicSelectedAsset = [arrPickerData objectAtIndex:lastSelectedIndex];
            if ([CommonFunctions isNetAvailable])
            {
                
                
                //Upload the completed JOb
                /*http://code.elogbooks.co.uk/users/jack/WOM/api/put-info.php?uid=38&UpdateType=jobs&qd=Update&tstamp=27/12/2012%2018:35:20&jid=2824&eng_complete=27/12/2012%2018:35:20&description=testeddesc&miles=2&travel=3&hours=4&aid=261&condition=5&risk=3 */
                
                objService=[[PutInfoClass alloc] init];
                objService._delegate=self;
                
                NSMutableDictionary *dicc=[[[NSMutableDictionary alloc] init]autorelease];
                [dicc setObject:[ElogBooksAppDelegate getValueForKey:USER_ID] forKey:USER_ID];
                [dicc setObject:@"jobs" forKey:@"UpdateType"];
                [dicc setObject:@"Update" forKey:@"qd"];
                [dicc setObject: txtJobCompletion.text forKey:@"tstamp"];
                [dicc setObject:strJid forKey:JOBS_ID];
                [dicc setObject:txtJobCompletion.text forKey:JOBS_ENG_COMPLETE];
                [dicc setObject:txViewJobUpdate.text forKey:JOBS_DESC];
                [dicc setObject:txthours.text forKey:J_LINE_H];
                [dicc setObject:txtTravel.text forKey:J_LINE_T];
                [dicc setObject:txtMileage.text forKey:J_LINE_M];
                if ([[txtJobAsset.text stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0)  //if asset is set
                {
                    [dicc setObject:[dicSelectedAsset valueForKey:ASSETS_ID] forKey:ASSETS_ID];
                    [dicc setObject:[dicSelectedAsset valueForKey:ASSETS_COND] forKey:ASSETS_COND];
                    [dicc setObject:[dicSelectedAsset valueForKey:ASSETS_RISK] forKey:ASSETS_RISK];
                }
                objService.argsDic=[CommonFunctions getDicAsParameter:dicc] ;
                
                objService.strWebService=[NSString stringWithFormat:@"JobsComplete:%@",strJid];
                objService.strUrl= [NSString stringWithFormat:@"%@%@",[ElogBooksAppDelegate getValueForKey:BASE_URL],PUT_INFO_API];
                objService.ParentNode=@"Responses";
                objService.ChildNode=@"Response";
                objService.retType=isArray;
                [objService performSelector:@selector(setArray) withObject:nil afterDelay:0.1];
                
                
            }
            else
            {
                //complete the job in local
                
                if ([[txtJobAsset.text stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0) //If asset is set
                {
                    
                    if ([DataSource executeQuery:[NSString stringWithFormat:@"Update Jobs SET aid=%@,eid='%@',description='%@',location='%@',stt='Completed',eng_on_site='%@',IsSynced=%@,escalation='%@',eng_complete='%@' where jid=%@",[dicSelectedAsset valueForKey:ASSETS_ID],[ElogBooksAppDelegate getValueForKey:USER_ID],[dicSelectedAsset valueForKey:ASSETS_DESC],[dicSelectedAsset valueForKey:ASSETS_LOCATION],[CommonFunctions getCurrentTimeStampForDatabaseInsertion:txtFirstAttendance.text],UN_SYNCED_DATA,(IsEscalationRequired == TRUE)?@"Y":@"N",[CommonFunctions getCurrentTimeStampForDatabaseInsertion:txtJobCompletion.text],strJid]])
                        NSLog(@"Job Updated in local");
                    else
                        NSLog(@"Job Failed to  Update in local");
                    
                    
                }
                else
                {
                    if ([DataSource executeQuery:[NSString stringWithFormat:@"Update Jobs set eng_on_site='%@',eid='%@',stt='Completed',eng_complete='%@',IsSynced=%@,escalation='%@' where jid=%@",[CommonFunctions getCurrentTimeStampForDatabaseInsertion:txtFirstAttendance.text],[ElogBooksAppDelegate getValueForKey:USER_ID],[CommonFunctions getCurrentTimeStampForDatabaseInsertion:txtJobCompletion.text],UN_SYNCED_DATA,(IsEscalationRequired==TRUE)?@"Y":@"N",strJid]])
                        NSLog(@"Eng_complete value set ");
                }
                
                
                if ([DataSource executeQuery:[NSString stringWithFormat:@"insert into Job_lines (jid,eid,tstamp,hours,travel,miles,description,name,helpdesk,call_type,IsSynced)values(%@,%@,'%@',%@,%@,%@,'%@','%@','N/A','N/A',%@)",strJid,[ElogBooksAppDelegate getValueForKey:USER_ID],[CommonFunctions getCurrentTimeStampForDatabaseInsertion:txtFirstAttendance.text],txthours.text,txtTravel.text,txtMileage.text,txViewJobUpdate.text,[ElogBooksAppDelegate getValueForKey:USER_NAME],UN_SYNCED_DATA]])  //update Job Lines
                {
                    NSLog(@"Job Lines updated");
                }
                
                [self ClearAllTextFields];
                [self.navigationController popToViewController: [[self.navigationController viewControllers]objectAtIndex:[[self.navigationController viewControllers]count]-3 ] animated:YES];
            }
            
            
        }
        else
        {
            //Update the Job start Job URL
            /*http://code.elogbooks.co.uk/users/jack/WOM/api/put-info.php?uid=38&UpdateType=jobs&qd=Start&tstamp=08/12/2012%2011:19:12&jid=7953 */
            NSMutableDictionary *dicSelectedAsset = [arrPickerData objectAtIndex:lastSelectedIndex];
            if ([CommonFunctions isNetAvailable])
            {
                isUpdatingJob = TRUE;
                objService=[[PutInfoClass alloc] init];
                objService._delegate=self;
                
                NSMutableDictionary *dicc=[[[NSMutableDictionary alloc] init]autorelease];
                [dicc setObject:[ElogBooksAppDelegate getValueForKey:USER_ID] forKey:USER_ID];
                [dicc setObject:@"jobs" forKey:@"UpdateType"];
                [dicc setObject:@"Start" forKey:@"qd"];
                [dicc setObject: txtFirstAttendance.text forKey:@"tstamp"];
                [dicc setObject:strJid forKey:JOBS_ID];
                
                
                [dicc setObject:txViewJobUpdate.text forKey:JOBS_DESC];
                [dicc setObject:txthours.text forKey:J_LINE_H];
                [dicc setObject:txtTravel.text forKey:J_LINE_T];
                [dicc setObject:txtMileage.text forKey:J_LINE_M];
                if ([[txtJobAsset.text stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0)  //if asset is set
                {
                    [dicc setObject:[dicSelectedAsset valueForKey:ASSETS_ID] forKey:ASSETS_ID];
                    [dicc setObject:[dicSelectedAsset valueForKey:ASSETS_COND] forKey:ASSETS_COND];
                    [dicc setObject:[dicSelectedAsset valueForKey:ASSETS_RISK] forKey:ASSETS_RISK];
                }
                objService.argsDic=[CommonFunctions getDicAsParameter:dicc] ;
                
                objService.strWebService=[NSString stringWithFormat:@"startJob:%@",strJid];
                objService.strUrl= [NSString stringWithFormat:@"%@%@",[ElogBooksAppDelegate getValueForKey:BASE_URL],PUT_INFO_API];
                objService.ParentNode=@"Responses";
                objService.ChildNode=@"Response";
                objService.retType=isArray;
                [objService performSelector:@selector(setArray) withObject:nil afterDelay:0.1];
            }
            else
            {
                //Update the Job in local
                
                if ([[txtJobAsset.text stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0) //If asset is set
                {
                    //If asset is set ,then Asset is updated
                    if ([DataSource executeQuery:[NSString stringWithFormat:@"Update Jobs SET aid=%@,eid='%@',description='%@',location='%@',stt='In Progress',eng_on_site='%@',IsSynced=%@,escalation='%@' where jid=%@",[dicSelectedAsset valueForKey:ASSETS_ID],[ElogBooksAppDelegate getValueForKey:USER_ID],[dicSelectedAsset valueForKey:ASSETS_DESC],[dicSelectedAsset valueForKey:ASSETS_LOCATION],[CommonFunctions getCurrentTimeStampForDatabaseInsertion:txtFirstAttendance.text],UN_SYNCED_DATA,(IsEscalationRequired == TRUE)?@"Y":@"N",strJid]])
                        NSLog(@"Job Updated in local");
                    else
                        NSLog(@"Job Failed to  Update in local");
                }
                else
                {
                    
                    if ([DataSource executeQuery:[NSString stringWithFormat:@"Update Jobs SET eid='%@',stt='In Progress',eng_on_site='%@',IsSynced=%@,escalation='%@' where jid=%@",[ElogBooksAppDelegate getValueForKey:USER_ID],[CommonFunctions getCurrentTimeStampForDatabaseInsertion:txtFirstAttendance.text],UN_SYNCED_DATA,(IsEscalationRequired == TRUE)?@"Y":@"N",strJid]])
                        NSLog(@"Job Updated in local");
                    else
                        NSLog(@"Job Failed to  Update in local");
                    
                    
                }
                
                if ([DataSource executeQuery:[NSString stringWithFormat:@"insert into Job_lines (jid,eid,tstamp,hours,travel,miles,description,name,helpdesk,call_type,IsSynced)values(%@,%@,'%@',%@,%@,%@,'%@','%@','N/A','N/A',%@)",strJid,[ElogBooksAppDelegate getValueForKey:USER_ID],[CommonFunctions getCurrentTimeStampForDatabaseInsertion:txtFirstAttendance.text],txthours.text,txtTravel.text,txtMileage.text,txViewJobUpdate.text,[ElogBooksAppDelegate getValueForKey:USER_NAME],UN_SYNCED_DATA]])  //update Job Lines
                {
                    NSLog(@"Job Lines updated");
                }
                
                [self ClearAllTextFields];
                [self.navigationController popViewControllerAnimated:YES];
                
                
            }
        }
    }
    else  //alert validation
    {
        UIAlertView *alert=[[[UIAlertView alloc] initWithTitle:APP_TITLE message: [NSString stringWithFormat:@"Please enter %@",strResult] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil]autorelease];
        [alert show];
    }
    
    //    UPDATE Job_lines SET tstamp='asd',hours='value',travel='value2',miles='ad',description='asdf',eid='uid' WHERE jid=2787;
    //    UPDATE Jobs SET aid=12,eid='uid',description=':1',location=':1',stt='In Progress',updated='time',date_due='date_first_attnedance',date_due_comp='complete' where jid =2787;
    
}

#pragma mark Parsing delegates
-(void)filedWithError:(NSString *)strMsg forFlage:(NSString *)flage
{
    if (isUpdatingJob)  //job updated or started failed
    {
        isUpdatingJob = FALSE;
        //If failed
        //Update the Job in local
        
        NSMutableDictionary *dicSelectedAsset = [arrPickerData objectAtIndex:lastSelectedIndex];
        if ([[txtJobAsset.text stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0) //If asset is set
        {
            //If asset is set ,then Asset is updated
            if ([DataSource executeQuery:[NSString stringWithFormat:@"Update Jobs SET aid=%@,eid='%@',description='%@',location='%@',stt='In Progress',eng_on_site='%@',IsSynced=%@,escalation='%@' where jid=%@",[dicSelectedAsset valueForKey:ASSETS_ID],[ElogBooksAppDelegate getValueForKey:USER_ID],[dicSelectedAsset valueForKey:ASSETS_DESC],[dicSelectedAsset valueForKey:ASSETS_LOCATION],[CommonFunctions getCurrentTimeStampForDatabaseInsertion:txtFirstAttendance.text],UN_SYNCED_DATA,(IsEscalationRequired == TRUE)?@"Y":@"N",strJid]])
                NSLog(@"Job Updated in local");
            else
                NSLog(@"Job Failed to  Update in local");
        }
        else
        {
            if ([DataSource executeQuery:[NSString stringWithFormat:@"Update Jobs SET eid='%@',stt='In Progress',eng_on_site='%@',IsSynced=%@,escalation='%@' where jid=%@",[ElogBooksAppDelegate getValueForKey:USER_ID],[CommonFunctions getCurrentTimeStampForDatabaseInsertion:txtFirstAttendance.text],UN_SYNCED_DATA,(IsEscalationRequired == TRUE)?@"Y":@"N",strJid]])
                NSLog(@"Job Updated in local");
            else
                NSLog(@"Job Failed to  Update in local");
        }
        if ([DataSource executeQuery:[NSString stringWithFormat:@"insert into Job_lines (jid,eid,tstamp,hours,travel,miles,description,name,helpdesk,call_type,IsSynced)values(%@,%@,'%@',%@,%@,%@,'%@','%@','N/A','N/A',%@)",strJid,[ElogBooksAppDelegate getValueForKey:USER_ID],[CommonFunctions getCurrentTimeStampForDatabaseInsertion:txtFirstAttendance.text],txthours.text,txtTravel.text,txtMileage.text,txViewJobUpdate.text,[ElogBooksAppDelegate getValueForKey:USER_NAME],UN_SYNCED_DATA]])  //update Job Lines
        {
            NSLog(@"Job Lines updated");
        }
        [self ClearAllTextFields];
        [self.navigationController popViewControllerAnimated:YES];
    }
    else  //job completion failed
    {
        if ([[txtJobAsset.text stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0) //If asset is set
        {
            NSMutableDictionary *dicSelectedAsset = [arrPickerData objectAtIndex:lastSelectedIndex];
            
            if ([DataSource executeQuery:[NSString stringWithFormat:@"Update Jobs SET aid=%@,eid='%@',description='%@',location='%@',stt='In Progress',eng_on_site='%@',IsSynced=%@,escalation='%@',eng_complete='%@' where jid=%@",[dicSelectedAsset valueForKey:ASSETS_ID],[ElogBooksAppDelegate getValueForKey:USER_ID],[dicSelectedAsset valueForKey:ASSETS_DESC],[dicSelectedAsset valueForKey:ASSETS_LOCATION],[CommonFunctions getCurrentTimeStampForDatabaseInsertion:txtFirstAttendance.text],UN_SYNCED_DATA,(IsEscalationRequired == TRUE)?@"Y":@"N",[CommonFunctions getCurrentTimeStampForDatabaseInsertion:txtJobCompletion.text],strJid]])
                NSLog(@"Job Updated in local");
            else
                NSLog(@"Job Failed to  Update in local");
            
            
        }else
        {
            if ([DataSource executeQuery:[NSString stringWithFormat:@"Update Jobs set eng_on_site='%@',eid='%@',stt='Completed',eng_complete='%@',IsSynced=%@,escalation='%@' where jid=%@",[CommonFunctions getCurrentTimeStampForDatabaseInsertion:txtFirstAttendance.text],[ElogBooksAppDelegate getValueForKey:USER_ID],[CommonFunctions getCurrentTimeStampForDatabaseInsertion:txtJobCompletion.text],UN_SYNCED_DATA,(IsEscalationRequired==TRUE)?@"Y":@"N",strJid]])
                NSLog(@"Eng_complete value set ");
        }
        
        
        if ([DataSource executeQuery:[NSString stringWithFormat:@"insert into Job_lines (jid,eid,tstamp,hours,travel,miles,description,name,helpdesk,call_type,IsSynced)values(%@,%@,'%@',%@,%@,%@,'%@','%@','N/A','N/A',%@)",strJid,[ElogBooksAppDelegate getValueForKey:USER_ID],[CommonFunctions getCurrentTimeStampForDatabaseInsertion:txtFirstAttendance.text],txthours.text,txtTravel.text,txtMileage.text ,txViewJobUpdate.text,[ElogBooksAppDelegate getValueForKey:USER_NAME],UN_SYNCED_DATA]])  //update Job Lines
        {
            NSLog(@"Job Lines updated");
        }
        
        [self ClearAllTextFields];
        [self.navigationController popToViewController: [[self.navigationController viewControllers]objectAtIndex:[[self.navigationController viewControllers]count]-3 ] animated:YES];

    }
}


-(void)EndParsingArray:(NSMutableArray *)arrData forFlage:(NSString *)flage
{
    
    if (isUpdatingJob) //updating JOb
    {
        isUpdatingJob = FALSE;
        if (!([[arrData objectAtIndex:0]rangeOfString:@"Success"].location==NSNotFound)) //successfully job started
        {
            NSMutableDictionary *dicSelectedAsset = [arrPickerData objectAtIndex:lastSelectedIndex];
            if ([[txtJobAsset.text stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0) //If asset is set
            {
                //If asset is set ,then Asset is updated
                if ([DataSource executeQuery:[NSString stringWithFormat:@"Update Jobs SET aid=%@,eid='%@',description='%@',location='%@',stt='In Progress',eng_on_site='%@',IsSynced=%@,escalation='%@' where jid=%@",[dicSelectedAsset valueForKey:ASSETS_ID],[ElogBooksAppDelegate getValueForKey:USER_ID],[dicSelectedAsset valueForKey:ASSETS_DESC],[dicSelectedAsset valueForKey:ASSETS_LOCATION],[CommonFunctions getCurrentTimeStampForDatabaseInsertion:txtFirstAttendance.text],SYNCED_DATA,(IsEscalationRequired == TRUE)?@"Y":@"N",strJid]])
                    NSLog(@"Job Updated in local");
                else
                    NSLog(@"Job Failed to  Update in local");
            }
            else
            {
                
                if ([DataSource executeQuery:[NSString stringWithFormat:@"Update Jobs SET eid='%@',stt='In Progress',eng_on_site='%@',IsSynced=%@,escalation='%@' where jid=%@",[ElogBooksAppDelegate getValueForKey:USER_ID],[CommonFunctions getCurrentTimeStampForDatabaseInsertion:txtFirstAttendance.text],SYNCED_DATA,(IsEscalationRequired == TRUE)?@"Y":@"N",strJid]])
                    NSLog(@"Job Updated in local");
                else
                    NSLog(@"Job Failed to  Update in local");
                
                
            }
            
            if ([DataSource executeQuery:[NSString stringWithFormat:@"insert into Job_lines (jid,eid,tstamp,hours,travel,miles,description,name,helpdesk,call_type,IsSynced)values(%@,%@,'%@',%@,%@,%@,'%@','%@','N/A','N/A',%@)",strJid,[ElogBooksAppDelegate getValueForKey:USER_ID],[CommonFunctions getCurrentTimeStampForDatabaseInsertion:txtFirstAttendance.text],txthours.text,txtTravel.text,txtMileage.text,txViewJobUpdate.text,[ElogBooksAppDelegate getValueForKey:USER_NAME],SYNCED_DATA]])  //update Job Lines
            {
                NSLog(@"Job Lines updated");
            }
            
            
        }
        else //failed to update the job uploaded
        {
            NSMutableDictionary *dicSelectedAsset = [arrPickerData objectAtIndex:lastSelectedIndex];
            if ([[txtJobAsset.text stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0) //If asset is set
            {
                //If asset is set ,then Asset is updated
                if ([DataSource executeQuery:[NSString stringWithFormat:@"Update Jobs SET aid=%@,eid='%@',description='%@',location='%@',stt='In Progress',eng_on_site='%@',IsSynced=%@,escalation='%@' where jid=%@",[dicSelectedAsset valueForKey:ASSETS_ID],[ElogBooksAppDelegate getValueForKey:USER_ID],[dicSelectedAsset valueForKey:ASSETS_DESC],[dicSelectedAsset valueForKey:ASSETS_LOCATION],[CommonFunctions getCurrentTimeStampForDatabaseInsertion:txtFirstAttendance.text],UN_SYNCED_DATA,(IsEscalationRequired == TRUE)?@"Y":@"N",strJid]])
                    NSLog(@"Job Updated in local");
                else
                    NSLog(@"Job Failed to  Update in local");
            }
            else
            {
                
                if ([DataSource executeQuery:[NSString stringWithFormat:@"Update Jobs SET eid='%@',stt='In Progress',eng_on_site='%@',IsSynced=%@,escalation='%@' where jid=%@",[ElogBooksAppDelegate getValueForKey:USER_ID],[CommonFunctions getCurrentTimeStampForDatabaseInsertion:txtFirstAttendance.text],UN_SYNCED_DATA,(IsEscalationRequired == TRUE)?@"Y":@"N",strJid]])
                    NSLog(@"Job Updated in local");
                else
                    NSLog(@"Job Failed to  Update in local");
                
                
            }
            
            if ([DataSource executeQuery:[NSString stringWithFormat:@"insert into Job_lines (jid,eid,tstamp,hours,travel,miles,description,name,helpdesk,call_type,IsSynced)values(%@,%@,'%@',%@,%@,%@,'%@','%@','N/A','N/A',%@)",strJid,[ElogBooksAppDelegate getValueForKey:USER_ID],[CommonFunctions getCurrentTimeStampForDatabaseInsertion:txtFirstAttendance.text],txthours.text,txtTravel.text,txtMileage.text,txViewJobUpdate.text,[ElogBooksAppDelegate getValueForKey:USER_NAME],UN_SYNCED_DATA]])  //update Job Lines
            {
                NSLog(@"Job Lines updated");
            }
            
        }
        
        
        [self ClearAllTextFields];
        [self.navigationController popViewControllerAnimated:YES];
        
    }
    else //completing Job
    {
        NSMutableDictionary *dicSelectedAsset = [arrPickerData objectAtIndex:lastSelectedIndex];
        if (!([[arrData objectAtIndex:0]rangeOfString:@"Success"].location==NSNotFound)) //successfully job started
        {
            [DataSource executeQuery:[NSString stringWithFormat:@"DELETE FROM Job_lines WHERE jid= %@",strJid]];
            [DataSource executeQuery:[NSString stringWithFormat:@"DELETE FROM Jobs WHERE jid= %@",strJid]];
            [DataSource executeQuery:[NSString stringWithFormat:@"DELETE FROM Job_materials WHERE jid= %@",strJid]];
        }
        else  //not successfully uploaded
        {
            
            if ([[txtJobAsset.text stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0) //If asset is set
            {
                
                
                if ([DataSource executeQuery:[NSString stringWithFormat:@"Update Jobs SET aid=%@,eid='%@',description='%@',location='%@',stt='In Progress',eng_on_site='%@',IsSynced=%@,escalation='%@',eng_complete='%@' where jid=%@",[dicSelectedAsset valueForKey:ASSETS_ID],[ElogBooksAppDelegate getValueForKey:USER_ID],[dicSelectedAsset valueForKey:ASSETS_DESC],[dicSelectedAsset valueForKey:ASSETS_LOCATION],[CommonFunctions getCurrentTimeStampForDatabaseInsertion:txtFirstAttendance.text],UN_SYNCED_DATA,(IsEscalationRequired == TRUE)?@"Y":@"N",[CommonFunctions getCurrentTimeStampForDatabaseInsertion:txtJobCompletion.text],strJid]])
                    NSLog(@"Job Updated in local");
                else
                    NSLog(@"Job Failed to  Update in local");
                
                
            }else
            {
                if ([DataSource executeQuery:[NSString stringWithFormat:@"Update Jobs set eng_on_site='%@',eid='%@',stt='Completed',eng_complete='%@',IsSynced=%@,escalation='%@' where jid=%@",[CommonFunctions getCurrentTimeStampForDatabaseInsertion:txtFirstAttendance.text],[ElogBooksAppDelegate getValueForKey:USER_ID],[CommonFunctions getCurrentTimeStampForDatabaseInsertion:txtJobCompletion.text],UN_SYNCED_DATA,(IsEscalationRequired==TRUE)?@"Y":@"N",strJid]])
                    NSLog(@"Eng_complete value set ");
            }
            
            
            if ([DataSource executeQuery:[NSString stringWithFormat:@"insert into Job_lines (jid,eid,tstamp,hours,travel,miles,description,name,helpdesk,call_type,IsSynced)values(%@,%@,'%@',%@,%@,%@,'%@','%@','N/A','N/A',%@)",strJid,[ElogBooksAppDelegate getValueForKey:USER_ID],[CommonFunctions getCurrentTimeStampForDatabaseInsertion:txtFirstAttendance.text],txthours.text,txtTravel.text,txtMileage.text,txViewJobUpdate.text,[ElogBooksAppDelegate getValueForKey:USER_NAME],UN_SYNCED_DATA]])  //update Job Lines
            {
                NSLog(@"Job Lines updated");
            }
            
            
            
            
        }
        [self ClearAllTextFields];
        [self.navigationController popToViewController: [[self.navigationController viewControllers]objectAtIndex:[[self.navigationController viewControllers]count]-3 ] animated:YES];
        
    }
    
}
#pragma mark ClearAllTextFields
-(void)ClearAllTextFields
{
    [txViewJobUpdate setTextColor:[UIColor grayColor]];
    [txViewJobUpdate setText:@"Click to begin typing"];
    [txthours setText:@""];
    [txtMileage setText:@""];
    [txtTravel setText:@""];
    [txtFirstAttendance setText:@""];
    [txtJobCompletion setText:@""];
    [txtJobAsset setText:@""];
}

#pragma mark btnAssetJobTapped
-(IBAction)btnAssetJobTapped:(id)sender
{
    [txViewJobUpdate resignFirstResponder];
    if (txtTempField!=nil)
        [txtTempField resignFirstResponder];
    
    //Set value in txtJobAsset
    
    NSString *str_selectedAsset = [[arrPickerData objectAtIndex:lastSelectedIndex]valueForKey:@"assetsName"];
    if ([str_selectedAsset isEqualToString:@"None Selected"])
        txtJobAsset.text = @"";
    else 
    txtJobAsset.text = str_selectedAsset;
    
    
//    txtJobAsset.text = [[arrPickerData objectAtIndex:lastSelectedIndex]valueForKey:@"assetsName"];
    //Show Picker
    PickerViewControl *objPicker = [[PickerViewControl alloc] initWithFrame:[self.view frame]];
    objPicker.arrPickerData = arrPickerData;
    objPicker.strSelectKey = @"assetsName";
    objPicker._delegate=self;
    objPicker.selectedIndex=lastSelectedIndex;
    [objPicker setPicker];
    [self.view addSubview:objPicker];
    
}

#pragma mark PickerViewControl Delegate
-(void)pickerCloseWithTag:(int)tag
{
    NSLog(@"PickerClosed:");
    [UIView animateWithDuration:0.5 animations:^{
        [scrView setContentOffset:CGPointMake(0, 0)];
        [scrView setContentSize:CGSizeMake(320, 565)];
    }];
    
}

-(void)selectedRow:(int)row andValue:(NSString *)strVal andTag:(int)tag selectedRow:(int)selRow
{
    
    lastSelectedIndex=selRow;
    NSString *str_selectedAsset = [[arrPickerData objectAtIndex:lastSelectedIndex]valueForKey:@"assetsName"];
    if ([str_selectedAsset isEqualToString:@"None Selected"])
    txtJobAsset.text = @"";
    else 
    txtJobAsset.text = str_selectedAsset;
    NSLog(@"PickerClosed:");
}

#pragma mark btnBackTapped
-(void)btnBackTapped:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark btnDateTimeFirstAttendanceTapped
-(IBAction)btnDateTimeFirstAttendTapped:(id)sender
{
    //Set Scrollview contentOffset
    [btnFade setFrame:CGRectMake(0, 0, 320,[[UIScreen mainScreen] bounds].size.height)];
    [UIView animateWithDuration:0.5 animations:^{
        [scrView setContentOffset:CGPointMake(0, 100)];
//        [objDatePicker setFrame:CGRectMake(0, 200, 320, 250)];
        [objDatePicker setFrame:CGRectMake(0,[[UIScreen mainScreen] bounds].size.height-280, 320, 250)];
        [objDatePicker setTag:TAG_DATE_FIRST_ATTEND];
    }];
    
    
    
}
#pragma mark btnDateTimeCompleteTapped
-(IBAction)btnDateTimeCompleteTapped:(id)sender
{
    [btnFade setFrame:CGRectMake(0, 0, 320,480)];
    //Set Scrollview contentOffset
    [UIView animateWithDuration:0.5 animations:^{
        [scrView setContentOffset:CGPointMake(0, 150)];
        [objDatePicker setFrame:CGRectMake(0,[[UIScreen mainScreen] bounds].size.height-280, 320, 250)];
        [objDatePicker setTag:TAG_DATE_COMPLETE];
    }];
}
#pragma  mark HideDatePickerTapped
-(void)HideDatePicker:(id)sender
{
    if (objDatePicker.tag == TAG_DATE_COMPLETE)
    {
        txtJobCompletion.text =  [dateFormatter stringFromDate:objDatePicker.date];
    }
    else if (objDatePicker.tag == TAG_DATE_FIRST_ATTEND)
    {
        txtFirstAttendance.text = [dateFormatter stringFromDate:objDatePicker.date];
    }
    [btnFade setFrame:CGRectMake(0, [[UIScreen mainScreen] bounds].size.height-20, 320,480)];
    
    [UIView animateWithDuration:0.5 animations:^{
        [objDatePicker setFrame:CGRectMake(0,[[UIScreen mainScreen] bounds].size.height-20, 320, 230)];
        [scrView setContentOffset:CGPointMake(0, 0)];
    }];
    
}



#pragma datePickerValuechanged
-(void)datePickerValuechanged:(id)sender
{
    if ([sender tag]==TAG_DATE_COMPLETE)
    {
        txtJobCompletion.text =  [dateFormatter stringFromDate:objDatePicker.date];
    }
    else if ([sender tag]==TAG_DATE_FIRST_ATTEND)
    {
        txtFirstAttendance.text =   [dateFormatter stringFromDate:objDatePicker.date];
    }
}


#pragma mark btnIsEscalationRequiredTapped
-(IBAction)btnIsEscalationRequiredTapped:(id)sender
{
    
    UIButton *tmpButton = (UIButton *)sender;
    
    
    if (!IsEscalationRequired)
    {
        IsEscalationRequired = TRUE;
        [tmpButton setImage:[UIImage imageNamed:@"tickbox_x1.png"] forState:UIControlStateNormal];
    }
    else
    {
        IsEscalationRequired = FALSE;
        [tmpButton setImage:[UIImage imageNamed:@"tickbox_empty_x1.png"] forState:UIControlStateNormal];
    }
    
}

#pragma mark Validation
-(NSString *)ValidateFields
{
    NSString *strResult = @"OK";
    if (([[txViewJobUpdate.text stringByReplacingOccurrencesOfString:@" " withString:@""]length]<=0) || ([txViewJobUpdate.text isEqualToString:@"Click to begin typing"]))
        strResult = @"description";
    //add any more field
    return strResult;
    
}

-(void)checkWhetherValueIsSet:(UITextField *)textField
{
    
    if (!([[[textField text]stringByReplacingOccurrencesOfString:@" " withString:@""]length]>0))
        textField.text = @"0";
    
}

#pragma mark UITextfield Delegates
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    txtTempField = textField;
    [UIView animateWithDuration:0.5 animations:^{
        if ((textField == txtFirstAttendance) || (textField == txtJobCompletion)|| (textField == txtJobAsset))
        {
            [scrView setContentOffset:CGPointMake(0, 100) ];
        }
        [scrView setContentSize:CGSizeMake(320, 780)];
    }];
    return YES;
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    
    static NSCharacterSet *charSet = nil;
    if(!charSet) {
        charSet = [[[NSCharacterSet characterSetWithCharactersInString:@"0123456789"] invertedSet] retain];
    }
    NSRange location = [string rangeOfCharacterFromSet:charSet];
    return (location.location == NSNotFound);
	return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [UIView animateWithDuration:0.5 animations:^{
        [scrView setContentSize:CGSizeMake(320, 565)];
        [scrView setContentOffset:CGPointMake(0, 0) animated:YES];
        [textField resignFirstResponder];
    }];
    return YES;
}

#pragma mark TextView Delegates
- (BOOL)textViewShouldBeginEditing:(UITextView *)textView
{
    if ([textView.text isEqualToString:@"Click to begin typing"])
    {
        textView.text =@"";
        textView.textColor = [UIColor blackColor];
    }
    
    [UIView animateWithDuration:0.5 animations:^{
        [scrView setContentSize:CGSizeMake(320, 780)];
    }];
    return YES;
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    
    if([text isEqualToString:@"\n"])
    {
        [UIView animateWithDuration:0.5 animations:^{
            [scrView setContentSize:CGSizeMake(320, 565)]; 
            [textView resignFirstResponder];
        }];
        return NO;
    }
    return YES;
}
- (void)viewDidUnload
{
    [super viewDidUnload];
    dateFormatter = nil;
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
