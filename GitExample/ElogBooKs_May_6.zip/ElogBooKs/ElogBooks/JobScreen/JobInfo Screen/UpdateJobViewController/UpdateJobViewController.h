//
//  UpdateJobViewController.h
//  ELogBooks
//
//  Created by nayan mistry on 05/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UpdateJobViewController : UIViewController<UITextViewDelegate,UITextFieldDelegate,PickerViewControlDelegate,PutInfoDelegate>
{
    IBOutlet UIScrollView *scrView;
    
    IBOutlet UITextView *txViewJobUpdate;
    IBOutlet UITextField *txthours,*txtTravel,*txtMileage,*txtJobAsset,*txtFirstAttendance,*txtJobCompletion;
    IBOutlet  UIButton *btnUpdateJob,*btnAttachPhoto,*btnAttachSignature,*btnAttachFile,*btnAttachBarcode,*btnAttachments,*btnUpdateHistory;
    IBOutlet UIButton *btnIsEscalationRequired;
    IBOutlet UILabel *lblUploadWaring;
    BOOL IsEscalationRequired;
    IBOutlet UIButton *btnAssetJob,*btnDateTimeFirstAttend,*btnDateTimeComplete;
    //    PickerViewControl *objPicker;
    //Picker Requirements
    NSMutableArray *arrPickerData;
    UIDatePicker *objDatePicker;
    int lastSelectedIndex;
    UIButton *btnFade;
    NSDateFormatter *dateFormatter;
    //Webservice Delegates
    PutInfoClass *objService;
    BOOL isUpdatingJob;
    UITextField *txtTempField;
}
-(IBAction)btnIsEscalationRequiredTapped:(id)sender;
-(IBAction)btnAssetJobTapped:(id)sender;
-(IBAction)btnDateTimeFirstAttendTapped:(id)sender;
-(IBAction)btnDateTimeCompleteTapped:(id)sender;
@property(retain,nonatomic)NSString *strTitleStatus,*strJid;
-(void)HideDatePicker:(id)sender;
-(void)btnBackTapped:(id)sender;
-(IBAction)btnSubmitJobTapped:(id)sender;
-(NSString *)ValidateFields;
@end
