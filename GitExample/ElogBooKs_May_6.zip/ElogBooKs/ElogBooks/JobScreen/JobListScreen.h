//
//  JobListScreen.h
//  ElogBooks
//
//  Created by I-VERVE5 on 10/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JobListScreen : UIViewController<UITableViewDelegate,UITableViewDataSource,PickerViewControlDelegate>

{
    UIView *View;
    NSMutableArray *arr_Typ,*arr_Due,*arr_JobList,*arr_CustList;
    
    UILabel *lbl_Jobtype;
    
    UIButton *BtnJobtype,*BtnJobDue,*btnCountLabel;
     
    NSString *strSelectedCustId;
    int lastSelDue,lastSelType,lastselcustomer;
    
    UITableView *tblJobList;
    UIButton *BtnCustomerForJob;
    UIView *backView;
    UIImageView *imgView;
    BOOL IsCustomerCreated,IsJobTypeorJobDueEdited;
}

-(void)ShowCount :(NSString *)Jobs_Type :(NSString *)JobsDue_type :(int)jobsCount;
-(IBAction)OpenPicker:(id)sender;

-(void)fiterDataWith:(NSString *)strJobType and:(NSString *)strJobDue and :(NSString *)strCustId; 

@property(retain,nonatomic)NSString *selJobType;

@end
