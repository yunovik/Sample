//
//  JobListScreen.m
//  ElogBooks
//
//  Created by I-VERVE5 on 10/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import "JobListScreen.h"
#import "JobInfoScreen.h"

#define BTNJOBTYPE_TAG 100
#define BTNJOBDUE_TAG 101
#define JOBTYPEPICKER_TAG 1000
#define JOBDUEPICKER_TAG 1001
#define BTNCUSOMERFORJOB_TAG 777
#define JOBCUSTOMPICKER_TAG 5555
@interface JobListScreen ()

@end

@implementation JobListScreen

@synthesize selJobType;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)changeCustomerView :(BOOL)IsHide
{
    if (IsHide)
    {
       
        [UIView animateWithDuration:0.5 
                              delay:0
                            options:UIViewAnimationOptionAllowUserInteraction
                         animations:^{
//                             if (IsCustomerCreated)
                                 if (BtnCustomerForJob.retainCount >0)
                                 {
                                 [BtnCustomerForJob removeFromSuperview];
                                      BtnCustomerForJob= nil;
                                 }
                             
                             IsCustomerCreated = FALSE;
                             [imgView setFrame:CGRectMake(0, 0, 320, 41)];  
                             [backView setFrame:CGRectMake(0, 0, 320, 41)];
                           [btnCountLabel setFrame:CGRectMake(0, 41, 320, 41)];
                             CGRect screenBounds = [[UIScreen mainScreen] bounds];
                             screenBounds.origin.y=41+41;
                             screenBounds.size.height=screenBounds.size.height-104;
                             [tblJobList setFrame:screenBounds];
                             lastselcustomer = 0;   
                         }
                         completion:nil];

    }
    else
    {

        [UIView animateWithDuration:0.5 
                              delay:0
                            options:UIViewAnimationOptionAllowUserInteraction
                         animations:^{

                             [backView setFrame:CGRectMake(0, 0, 320, 41+41)]; 
                             [imgView setFrame:CGRectMake(0, 0, 320, 41+41)];
                            [btnCountLabel setFrame:CGRectMake(0, 41+41, 320, 41)];
                             
                             CGRect screenBounds = [[UIScreen mainScreen] bounds];
                             screenBounds.origin.y=41+41+41;
                             screenBounds.size.height=screenBounds.size.height-104-41-41;
                             [tblJobList setFrame:screenBounds];
                             
                             //Add the customer button
                             if (BtnCustomerForJob.retainCount>0)
                             {
                             [BtnCustomerForJob removeFromSuperview];
                                 BtnCustomerForJob= nil;
                             }
                             BtnCustomerForJob = [UIButton buttonWithType:UIButtonTypeCustom];
                             [BtnCustomerForJob addTarget:self action:@selector(OpenPicker:)forControlEvents:UIControlEventTouchDown];
                             
                             
                             if ([arr_CustList count]>0)
                             {
                                 strSelectedCustId = [[arr_CustList objectAtIndex:0]valueForKey:@"cid"];
                                 [strSelectedCustId retain];  
                                 [BtnCustomerForJob setTitle:[[arr_CustList objectAtIndex:0]valueForKey:@"customer"]  forState:UIControlStateNormal];        
                             }
                             IsCustomerCreated = YES;
                             [BtnCustomerForJob.titleLabel setFont:FONT_NEUE_SIZE(14) ];  
                             [BtnCustomerForJob setTitleColor:DEFAULT_FONT_COLOR forState:UIControlStateNormal ];
                             [BtnCustomerForJob setBackgroundImage:[UIImage imageNamed:@"Btn_JobInfo.png"] forState:UIControlStateNormal];
                             BtnCustomerForJob.frame = CGRectMake(7.0, 43.0, 305, 30);
                             
                             BtnCustomerForJob.tag = BTNCUSOMERFORJOB_TAG;
                             
                             BtnCustomerForJob.backgroundColor = [UIColor clearColor];
                             [backView addSubview:BtnCustomerForJob];    
                             
                         }
                         completion:nil];

       
    }
}

#pragma mark Show count Label Content
-(void)ShowCount :(NSString *)Jobs_Type :(NSString *)JobsDue_type :(int)jobsCount
{
    /*
     if jobs not found >> You currently have no jobs matching the criteria All Jobs and Due Today! (RED font color)
     else >> You have 230 jobs matching the criteria All Jobs and Due Today! */
    NSString *strTitleContent = @"";
    btnCountLabel.titleLabel.lineBreakMode = UILineBreakModeWordWrap;
//    button.titleLabel.textAlignment = UITextAlignmentCenter;
    if (jobsCount == 0)
    {
        [btnCountLabel setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
        strTitleContent = [NSString stringWithFormat: @"You currently have no jobs matching the criteria \n %@ and %@ !",Jobs_Type,JobsDue_type];
    }
    else {
        
         [btnCountLabel setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
         strTitleContent = [NSString stringWithFormat: @"You have %d jobs matching the criteria \n %@ and %@ !",jobsCount,Jobs_Type,JobsDue_type];
    }
   [btnCountLabel setTitle:strTitleContent  forState:UIControlStateNormal];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    
    self.title = @"Jobs";    
    [CommonFunctions setTitleView:self amdtitle:@"Jobs"];

    //UIview for Planned and Due Job
    //UIview for Planned and Due Job
    backView = [[[UIView alloc] init] autorelease];
    backView.frame = CGRectMake(0, 0, 320, 41);
//    backView.backgroundColor = getImageColor(@"Cell_Stripe.png");
    imgView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 320, 41)];
	UIImage *imgBack = [[UIImage imageNamed:@"Cell_Stripe.png"] stretchableImageWithLeftCapWidth:25 topCapHeight:15];
    [imgView setImage:imgBack];
    [backView addSubview:imgView];
    [self.view addSubview:backView];
    //[View release];
    
    
    //Back Button On Navigation
    [CommonFunctions setBack:self target:@selector(btnBackTapped:)];
    
    //UIButton  Jobtype
    BtnJobtype = [UIButton buttonWithType:UIButtonTypeCustom];
    [BtnJobtype addTarget:self action:@selector(OpenPicker:)forControlEvents:UIControlEventTouchDown];
    if ([selJobType length]==0)
    {
    [BtnJobtype setTitle:@"All Jobs" forState:UIControlStateNormal];
        selJobType = @"All Jobs";
    }
    [BtnJobtype.titleLabel setFont:FONT_NEUE_SIZE(14) ];  
    [BtnJobtype setTitleColor:DEFAULT_FONT_COLOR forState:UIControlStateNormal ];
    [BtnJobtype setBackgroundImage:[UIImage imageNamed:@"Btn_JobInfo.png"] forState:UIControlStateNormal];
    BtnJobtype.frame = CGRectMake(7.0, 6.0, 149.0, 29);
    BtnJobtype.tag = BTNJOBTYPE_TAG;
    BtnJobtype.backgroundColor = [UIColor clearColor];
    [backView addSubview:BtnJobtype];
    
    //UIButton JobDue
    BtnJobDue = [UIButton buttonWithType:UIButtonTypeCustom];
    [BtnJobDue addTarget:self action:@selector(OpenPicker:)forControlEvents:UIControlEventTouchDown];
    [BtnJobDue setTitle:@"All" forState:UIControlStateNormal];
    [BtnJobDue.titleLabel setFont:FONT_NEUE_SIZE(14) ];  
    [BtnJobDue setBackgroundImage:[UIImage imageNamed:@"Btn_JobInfo.png"] forState:UIControlStateNormal];
    [BtnJobDue setTitleColor:DEFAULT_FONT_COLOR forState:UIControlStateNormal ];
    BtnJobDue.frame = CGRectMake(164.0, 6.0, 149.0, 29.0);
    BtnJobDue.tag = BTNJOBDUE_TAG;
    BtnJobDue.backgroundColor = [UIColor clearColor];
    [backView addSubview:BtnJobDue];
    
    //NSMutableArraies
    arr_Typ = [[NSMutableArray alloc]initWithObjects:@"All Jobs",@"Planned Jobs",@"Reactive Jobs",@"My Jobs", nil];
    arr_Due = [[NSMutableArray alloc]initWithObjects:@"All",@"Due Today",@"Tomorrow Jobs",@"This Week Jobs",@"This month Jobs",@"Overdue Jobs",@"Update Due Jobs", nil];
    
    //Count Label
    //UIButton JobDue
    btnCountLabel = [UIButton buttonWithType:UIButtonTypeCustom];
    [btnCountLabel.titleLabel setFont:FONT_NEUE_SIZE(14) ];  
    btnCountLabel.enabled = FALSE;
    [btnCountLabel setBackgroundImage:[UIImage imageNamed:@"Btn_JobInfo.png"] forState:UIControlStateNormal];
    [btnCountLabel setTitleColor:DEFAULT_FONT_COLOR forState:UIControlStateNormal ];
    btnCountLabel.frame = CGRectMake(0 , 41, 320, 41);
    btnCountLabel.backgroundColor = [UIColor clearColor];
    [self.view addSubview:btnCountLabel];
    
    
    
    // UITableView
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    screenBounds.origin.y=41+41;
    screenBounds.size.height=screenBounds.size.height-104;
    
    tblJobList = [[[UITableView alloc] initWithFrame:screenBounds style:UITableViewStylePlain]autorelease];
    tblJobList.dataSource = self;
//    [tblJobList setShowsVerticalScrollIndicator:NO];
    tblJobList.delegate = self;
    
//    [tblJobList setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    [self.view addSubview:tblJobList];
    
    [tblJobList setBackgroundColor:[UIColor clearColor]];
    
//    [self.view setBackgroundColor:getImageColor(@"Default.png")];
    [self.view setBackgroundColor:[UIColor whiteColor]];

    
    
//    //static values
//    NSString *strJobType = @"";
//    if ([BtnJobtype.titleLabel.text isEqualToString:@"Planned Jobs"])
//        strJobType = @"PM";
//    else      if ([BtnJobtype.titleLabel.text isEqualToString:@"Reactive Jobs"])
//        strJobType = @"Non-PM";
//    arr_CustList = [DataSource getRecordsFromQuery:[NSString stringWithFormat:@"select DISTINCT(Customers.cid),Customers.customer  from Customers join Jobs on Customers.cid = Jobs.cid  where Jobs.job_type ='PM' or Jobs.job_type='%@' ",strJobType]];
    

    
    
    if ([selJobType isEqualToString:@"Planned Jobs"]) {
        
        //strJobType=@"PM";
        [self fiterDataWith:@"Planned Jobs" and:@"All" and:strSelectedCustId];
        [BtnJobtype setTitle:@"Planned Jobs" forState:UIControlStateNormal];

    }
    else if ([selJobType isEqualToString:@"Reactive Jobs"])
    {
        [self fiterDataWith:@"Reactive Jobs" and:@"All" and:strSelectedCustId];
        [BtnJobtype setTitle:@"Reactive Jobs" forState:UIControlStateNormal];

    }else {

        [self fiterDataWith:@"All Jobs" and:@"All" and:strSelectedCustId];
        [BtnJobtype setTitle:@"All Jobs" forState:UIControlStateNormal];

    }
   
    //arr_JobList =[DataSource getRecordsFromQuery:[NSString stringWithFormat:
    //                                              @" SELECT jid,stt,description,date_due FROM jobs where job_type='PM'"]];
    
}

-(void)viewWillAppear:(BOOL)animated
{
    if ([selJobType isEqualToString:@"Planned Jobs"]) {
        
        //strJobType=@"PM";
        [self fiterDataWith:@"Planned Jobs" and:@"All" and:strSelectedCustId];
        [BtnJobtype setTitle:@"Planned Jobs" forState:UIControlStateNormal];
        
    }
    else if ([selJobType isEqualToString:@"Reactive Jobs"])
    {
        [self fiterDataWith:@"Reactive Jobs" and:@"All" and:strSelectedCustId];
        [BtnJobtype setTitle:@"Reactive Jobs" forState:UIControlStateNormal];
        
    }else {
        
      [self fiterDataWith:@"All Jobs" and:@"All" and:strSelectedCustId];
        [BtnJobtype setTitle:@"All Jobs" forState:UIControlStateNormal];
        
    }
}

-(void)viewDidAppear:(BOOL)animated
{
    NSLog(@"viewDidAppear");
}
-(void)fiterDataWith:(NSString *)strJobType and:(NSString *)strJobDue and :(NSString *)strCustId
{

//    select jid,stt,description,SUBSTR(date_due,0,11) As CompareDate from jobs where job_type='PM' and CompareDate > '2012-10-30' and CompareDate < '2012-12-07'

    NSString *strSelectPart = [NSString stringWithFormat:
                               @"SELECT jid,stt,description,strftime('%%H:%%M',date_due)  As date_due, strftime('%%d-%%m-%%Y', date(jobs.date_due)) as due_date,job_type,location,jobs.cid,Customers.customer,Users.name,CASE WHEN datetime('now') > datetime(jobs.date_due) THEN 'Y' ELSE 'N' END As IsOverDueJob FROM jobs join Customers on jobs.cid = Customers.cid left join Users on jobs.eid = Users.uid"];
    NSString *Strcustseletpart = [NSString stringWithFormat:@"select DISTINCT(jobs.cid),Customers.customer  from jobs join Customers on jobs.cid = Customers.cid"];
    
    
    
    NSString *strQuery = @"\nwhere";
    
    if ([strJobType isEqualToString:@"Planned Jobs"]) 
    {
        strJobType=@"PM";   
        strQuery = [strQuery stringByAppendingString:[NSString stringWithFormat:
                    @" job_type='%@'",strJobType]];
    }
    else if ([strJobType isEqualToString:@"Reactive Jobs"])  
    {
        strJobType=@"Non-PM";
        strQuery = [strQuery stringByAppendingString:[NSString stringWithFormat:
                    @" job_type='%@'",strJobType]];
    }
      else if ([strJobType isEqualToString:@"My Jobs"]) 
      {
          strJobType=[ElogBooksAppDelegate getValueForKey:USER_ID];
          strQuery = [strQuery stringByAppendingString:[NSString stringWithFormat:
                                                        @" Jobs.eid='%@' AND job_type!='Patrol' ",strJobType]];
      }
    else 
    {
        //All jobs
        strJobType=@"Patrol";
        strQuery = [strQuery stringByAppendingString:[NSString stringWithFormat:
                    @" job_type!='%@'",strJobType]];
    }
    
    
    
    
    if ([strJobDue isEqualToString:@"All"]) {
//        strQuery = [NSString stringWithFormat:
//                    @"job_type='%@'",strJobType];
        
    }
    else if ([strJobDue isEqualToString:@"Due Today"]) {

        strQuery = [strQuery stringByAppendingString:[NSString stringWithFormat:
                    @" AND date(date_due) = date('now') "]];
//        strQuery = [NSString stringWithFormat:
//                    @"\nwhere date(date_due) = date('now') AND job_type='%@'",strJobType];
        
    }
    else if ([strJobDue isEqualToString:@"Tomorrow Jobs"]) {
        strQuery = [strQuery stringByAppendingString:[NSString stringWithFormat:
                    @" AND date(date_due) = date('now','1 day')"]];
//        strQuery = [NSString stringWithFormat:
//                    @"\nwhere date(date_due) = date('now','1 day') AND job_type='%@'",strJobType];

    }
    else if ([strJobDue isEqualToString:@"This Week Jobs"]) {
        strQuery = [strQuery stringByAppendingString:[NSString stringWithFormat:
                    @" AND date(date_due) BETWEEN date('now') and date('now','7 day')"]];
//        strQuery = [NSString stringWithFormat:
//                    @"\nwhere date(date_due) BETWEEN date('now') and date('now','7 day') AND job_type='%@'",strJobType];
        
    }
    else if ([strJobDue isEqualToString:@"This month Jobs"]) {
        strQuery = [strQuery stringByAppendingString:[NSString stringWithFormat:
                    @" AND date(date_due) BETWEEN date('now','start of month') and date('now','start of month','+1 month','-1 day')"]];
//        strQuery = [NSString stringWithFormat:
//                    @"\nwhere date(date_due) BETWEEN date('now','start of month') and date('now','start of month','+1 month','-1 day') AND job_type='%@'",strJobType];
    }
    else if ([strJobDue isEqualToString:@"Overdue Jobs"]) {

        strQuery = [strQuery stringByAppendingString:[NSString stringWithFormat:
                    @" AND date(date_due) < date('now')"]];
        
//        strQuery = [NSString stringWithFormat:
//                    @"\nwhere date(date_due) < date('now') AND job_type='%@'",strJobType];
    }
    else if ([strJobDue isEqualToString:@"Update Due Jobs"]) {
        strQuery = [strQuery stringByAppendingString:[NSString stringWithFormat:
                    @" AND date(date_reminder) < date('now')"]];

//        strQuery = [NSString stringWithFormat:
//                    @"\nwhere date(date_reminder) < date('now') AND job_type='%@'",strJobType];
    }
    
    

    strQuery = [strQuery stringByAppendingString:@" and eng_complete=''"];
    
        NSString *strQuery2 = [Strcustseletpart stringByAppendingFormat:strQuery];
    
    if (strCustId !=nil)
    strQuery = [strQuery stringByAppendingFormat:@"and jobs.cid=%@",strCustId];

    strQuery = [strSelectPart stringByAppendingFormat:@"%@",strQuery];
    
    //order by Date_due
    strQuery = [strQuery stringByAppendingFormat:@" order by jobs.date_due "];

    arr_JobList = [DataSource getRecordsFromQuery:strQuery];
    
    NSString *strJobCount = [DataSource getStringFromQuery:[NSString stringWithFormat:@"SELECT COUNT(*) from (%@)",strQuery]];
    
    [self ShowCount:BtnJobtype.titleLabel.text :BtnJobDue.titleLabel.text :[strJobCount intValue]];
    
    [tblJobList reloadData];    
    NSLog(@"\n-----------------------------------------------------\n"
          "QUERY: %@ \n DESCR: %@"
          "\n-----------------------------------------------------\n",strQuery,[arr_JobList description]);
    
//arrange customers alphabetically
    
    strQuery2 = [strQuery2 stringByAppendingString:@" order by customer"];
        arr_CustList = [DataSource getRecordsFromQuery:strQuery2];
    
       if (!([arr_CustList count]>1))
       {
           [self changeCustomerView:YES];
       }
       else 
       {
           
           //add all customers field
           NSMutableDictionary *dic = [[[NSMutableDictionary alloc]init]autorelease];
           [dic setObject:@"All Customers" forKey:@"customer"];
           [arr_CustList  insertObject:dic atIndex:0];

           if (!IsCustomerCreated)
            {
           [self changeCustomerView:NO];
            }
       }    
}


#pragma mark -
#pragma mark - Table view data source

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *CellIdentifier = [NSString stringWithFormat:@"Cel_%d",indexPath.row];
    NSLog(@"%i",arr_JobList.count);

    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    NSDictionary *redDic = [arr_JobList objectAtIndex:indexPath.row ];
    
    cell = nil;
    if(cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier]autorelease] ;
        cell.selectionStyle = UITableViewCellSelectionStyleBlue;
        
//        UIImageView *imgBackView = [[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 320, 91)]autorelease];
//        UIImage *imgBack = [[UIImage imageNamed:@"Cell_Stripe.png"] stretchableImageWithLeftCapWidth:25 topCapHeight:24];
//        [imgBackView setImage:imgBack];
//        [cell.contentView addSubview:imgBackView];
        
        
        UILabel *lblJId = [[UILabel alloc]initWithFrame:CGRectMake(10, 20, 40+30, 14)];
        lblJId.backgroundColor = [UIColor clearColor];
        [lblJId setFont:FONT_NEUE_BOLD_SIZE(12)];
        [lblJId setTextColor:DEFAULT_FONT_COLOR];
        lblJId.text = [redDic objectForKey:@"jid"];
        [cell.contentView addSubview:lblJId];
        [lblJId release];
        
        UILabel *lblStatus = [[UILabel alloc] initWithFrame:CGRectMake(40+30+10, 20, 100, 14)];
        lblStatus.backgroundColor = [UIColor clearColor];
        [lblStatus setFont:FONT_NEUE_BOLD_SIZE(12) ];
        [lblStatus setTextColor:DEFAULT_FONT_COLOR];
        lblStatus.text = [NSString stringWithFormat:@" - %@",[redDic objectForKey:@"stt"]];
        [cell.contentView addSubview:lblStatus];
        [lblStatus release];
        
        
        UILabel *lblJobDesc = [[UILabel alloc] initWithFrame:CGRectMake(10, 34, 240, 14)];
        lblJobDesc.backgroundColor = [UIColor clearColor];
        lblJobDesc.lineBreakMode=UILineBreakModeCharacterWrap;
        lblJobDesc.numberOfLines = 0;
//        [lblJobDesc setFont:FONT_NEUE_BOLD_SIZE(12)];
        [lblJobDesc setFont:FONT_NEUE_SIZE(12)];
        [lblJobDesc setTextColor:DEFAULT_FONT_COLOR];
        if ([redDic valueForKey:@"description"]!=nil)
            lblJobDesc.text = [NSString stringWithFormat:@"Description: %@",[redDic objectForKey:@"description"]];
//        [lblJobDesc sizeToFit];
        [cell.contentView addSubview:lblJobDesc];
        [lblJobDesc release];
        
        //Lbl Job customer  
        UILabel *lblJobCustomer = [[UILabel alloc] initWithFrame:CGRectMake(10, 48, 240, 14)];
        lblJobCustomer.backgroundColor = [UIColor clearColor];
        [lblJobCustomer setFont:FONT_NEUE_SIZE(12)];
        [lblJobCustomer setTextColor:DEFAULT_FONT_COLOR];
        if ([redDic valueForKey:@"customer"]!=nil)
            lblJobCustomer.text = [NSString stringWithFormat:@"Customer: %@",[redDic objectForKey:@"customer"]];
        [cell.contentView addSubview:lblJobCustomer];
        [lblJobCustomer release];
        
        //Lbl Job Location
        UILabel *lblJobLocation = [[UILabel alloc] initWithFrame:CGRectMake(10, 62, 240, 14)];
        lblJobLocation.backgroundColor = [UIColor clearColor];
        [lblJobLocation setFont:FONT_NEUE_SIZE(12)];
        [lblJobLocation setTextColor:DEFAULT_FONT_COLOR];
        if ([redDic valueForKey:@"location"]!=nil)
            lblJobLocation.text = [NSString stringWithFormat:@"Location: %@",[redDic objectForKey:@"location"]];
        [cell.contentView addSubview:lblJobLocation];
        [lblJobLocation release];
        
        
        UILabel *lbleng_name = [[UILabel alloc] initWithFrame:CGRectMake(10, 76, 240, 14)];
        lbleng_name.backgroundColor = [UIColor clearColor];
        [lbleng_name setFont:FONT_NEUE_SIZE(12)];
        [lbleng_name setTextColor:DEFAULT_FONT_COLOR];
        if ([redDic valueForKey:@"name"]!=nil)
            lbleng_name.text = [NSString stringWithFormat:@"Engineer: %@",[redDic objectForKey:@"name"]];
        [cell.contentView addSubview:lbleng_name];
        [lbleng_name release];
        
        
        UILabel *lblDate = [[UILabel alloc] initWithFrame:CGRectMake(10, 90, 240, 14)];
        lblDate.backgroundColor = [UIColor clearColor];
        [lblDate setFont:FONT_NEUE_SIZE(12)];
        [lblDate setTextColor:DEFAULT_FONT_COLOR];
        if ([redDic valueForKey:@"due_date"]!=nil)
            lblDate.text = [NSString stringWithFormat:@"Due Date: %@",[redDic objectForKey:@"due_date"]];
        [cell.contentView addSubview:lblDate];
        [lblDate release];
        
        
        UILabel *lblTime = [[UILabel alloc] initWithFrame:CGRectMake(260, 54, 50, 15)];
        lblTime.backgroundColor = [UIColor clearColor];
        lblTime.numberOfLines = 0;
        [lblTime setFont:FONT_NEUE_BOLD_SIZE(17)];
        
        NSString *strIsOverDueJob = [redDic objectForKey:@"IsOverDueJob"];
        
        if ([strIsOverDueJob isEqualToString:@"Y"])
        [lblTime setTextColor:[UIColor redColor]];
        else 
        [lblTime setTextColor:DEFAULT_FONT_COLOR];
        
        lblTime.text = [redDic objectForKey:@"date_due"];//[CommonFunctions getTime:[redDic objectForKey:@"date_due"]];
        [cell.contentView addSubview:lblTime];
        [lblTime release];
        
        
        NSLog(@"%@",[CommonFunctions getDate:[redDic objectForKey:@"date_due"]]);
        NSLog(@"%@",[CommonFunctions getTime:[redDic objectForKey:@"date_due"]]);
        
        
        
        //        UILabel *lblDate = [[UILabel alloc] initWithFrame:CGRectMake(262, 35, 50, 15)];
        //        lblDate.backgroundColor = [UIColor clearColor];
        //        lblDate.numberOfLines = 0;
        //        [lblDate setFont:FONT_NEUE_SIZE(12) ];
        //        [lblDate setTextColor:DEFAULT_FONT_COLOR];
        //        lblDate.text =[CommonFunctions getDate:[redDic objectForKey:@"date_due"]];
        //        [cell.contentView addSubview:lblDate];
        //        [lblDate release];
        
        
        
        
        
//        UIView *selectedView = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 61)]autorelease];
//        [selectedView setBackgroundColor:getImageColor(@"Cell_Stripe_Sel.png")];
//        //[selectedView setBackgroundColor:[UIColor greenColor]];
//        [cell setSelectedBackgroundView:selectedView];
        
    }
    
    return cell;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSLog(@"%i",arr_JobList.count);
    return arr_JobList.count;
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
        return 124;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSString *strJid = [[arr_JobList objectAtIndex:indexPath.row] objectForKey:JOBS_ID];
    //NSString *strSelJobType = [[arr_JobList objectAtIndex:indexPath.row] objectForKey:JOBS_TYPE];
    
    JobInfoScreen* objJobInfo=[[JobInfoScreen alloc] initWithNibName:@"JobInfoScreen" bundle:nil];
    objJobInfo.strJid = strJid;
    //objJobInfo.jobType = strSelJobType;
    //objJobInfo.s
    
    [self.navigationController pushViewController:objJobInfo animated:YES];
    [objJobInfo release];
    
    [tblJobList deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark -
#pragma mark - backTapped Method

-(IBAction)btnBackTapped:(id)sender
{
    
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark -
#pragma mark - OpenPicker Method

-(IBAction)OpenPicker:(id)sender{
    
    PickerViewControl *objPicker = [[PickerViewControl alloc] initWithFrame:[self.view frame]];
    
    
    if ([sender tag] == BTNJOBTYPE_TAG) {
        objPicker.arrPickerData = arr_Typ;
        objPicker.tag = JOBTYPEPICKER_TAG;
        objPicker.selectedIndex=lastSelType;
    }
    else  if ([sender tag]== BTNJOBDUE_TAG)
    {
        objPicker.arrPickerData = arr_Due;
        objPicker.tag = JOBDUEPICKER_TAG;
        objPicker.selectedIndex=lastSelDue;
    }
    else 
    {
        objPicker.arrPickerData = arr_CustList;
        objPicker.strSelectKey = @"customer";
        objPicker.tag = JOBCUSTOMPICKER_TAG;
        objPicker.selectedIndex=lastselcustomer;
    }

    objPicker._delegate=self;
    [objPicker setPicker];
    
    [self.view addSubview:objPicker];
    
//    [self fiterDataWith:[BtnJobtype titleLabel].text and:[BtnJobDue titleLabel].text and:strSelectedCustId];

}

-(void)pickerCloseWithTag:(int)tag 
{
    NSLog(@"PickerClosed:");
}

-(void)selectedRow:(int)row andValue:(NSString *)strVal andTag:(int)tag selectedRow:(int)selRow
{
    
    
    if (tag==JOBTYPEPICKER_TAG) {
        [BtnJobtype setTitle:strVal forState:UIControlStateNormal];
        lastSelType = selRow;
        
//        if(selRow == 0)
//        {
//            selJobType=@"Planned Jobs";
//
//        }else
//        {
//            selJobType=@"Reactive Jobs";
//          
//        }
        selJobType = [arr_Typ objectAtIndex:lastSelType];
        strSelectedCustId = nil;
        IsCustomerCreated = FALSE;
    }
    else  if (tag == JOBDUEPICKER_TAG)
    {
        [BtnJobDue setTitle:strVal forState:UIControlStateNormal];
        lastSelDue = selRow;
        strSelectedCustId = nil;
        IsCustomerCreated = FALSE;
    }
   else  if (tag == JOBCUSTOMPICKER_TAG)
        {
            [BtnCustomerForJob setTitle:strVal forState:UIControlStateNormal];
            lastselcustomer = selRow;
            strSelectedCustId = [[arr_CustList objectAtIndex:lastselcustomer]valueForKey:@"cid"];
        }
    
    
    [self fiterDataWith:[BtnJobtype titleLabel].text and:[BtnJobDue titleLabel].text and:strSelectedCustId];
    

    
    // NSLog(@"%@",strVal);
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
    
}
- (void)dealloc {
    //    [arr_Typ release];
    [super dealloc];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
