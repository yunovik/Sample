//
//  HomeScreen.h
//  ELogBooks
//
//  Created by iphone on 05/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UploadDatabase.h"
@interface HomeScreen : UIViewController<UITableViewDelegate,UITableViewDataSource,UIAlertViewDelegate,UploadDataBaseDelegate>
{


    UIPageControl *pageControl;
   IBOutlet UITableView *tblView;
    NSMutableArray *arrGrid;
    UIView *alert_View1;
}

-(void)btnMenuTapped:(id)Sender;
-(NSInteger)CheckIsAnyUnSyncedData;
@end
