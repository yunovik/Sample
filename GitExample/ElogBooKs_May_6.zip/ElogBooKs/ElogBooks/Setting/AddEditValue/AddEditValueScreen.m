//
//  AddEditValueScreen.m
//  ElogBooks
//
//  Created by i-Verve on 28/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import "AddEditValueScreen.h"
#import "SyncInBackGround.h"

@interface AddEditValueScreen ()

@end

@implementation AddEditValueScreen


@synthesize arrValues,isSelect,isAdd,strKey,strValue,strTableName;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [CommonFunctions setTitleView:self amdtitle:@"Setting"];
    [CommonFunctions setBack:self target:@selector(btnBackTapped:)];
//    [self.view setBackgroundColor:getImageColor(@"Default.png")];
    [self.view setBackgroundColor:[UIColor whiteColor]];

    txtView = [[UITextView alloc] initWithFrame:CGRectMake(10, 10, 300, 170)];
    [[txtView layer] setBorderColor:[[UIColor blackColor] CGColor]];
    [[txtView layer] setBorderWidth:2.0f];
    [[txtView layer] setCornerRadius:5.0f];
    [txtView setFont:FONT_NEUE_BOLD_SIZE(20)];
    
    
    CGFloat topCorrect = ([txtView bounds].size.height - [txtView contentSize].height * [txtView zoomScale])/2.0;
    topCorrect = ( topCorrect < 0.0 ? 0.0 : topCorrect );
    txtView.contentOffset = (CGPoint){.x = 0, .y = -topCorrect};
    
    
    [txtView setTextAlignment:UITextAlignmentCenter];
    
    [txtView setContentMode:UIViewContentModeCenter];
    [txtView setText:strValue];
    [self.view addSubview:txtView];
    
    //UIButton *btnSave = [[UIButton alloc] initWithFrame:CGRectMake(10, 175, 300, 25)];
    UIButton *btnSave = [CommonFunctions buttonWithTitle:@"Save" andFrame:CGRectMake(10, 195, 300, 30)];
    [btnSave addTarget:self action:@selector(btnSave_Tapped:) forControlEvents:UIControlEventTouchUpInside];
    [btnSave setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [[btnSave layer] setBorderColor:[[UIColor colorWithPatternImage:[UIImage imageNamed:@"Assets_Stripe_Sel.png"]] CGColor]];
    [[btnSave layer] setBorderWidth:2.0f];
    [[btnSave layer] setCornerRadius:5.0f];
    [btnSave setTitle:@"Save" forState:UIControlStateNormal];
    
    [self.view addSubview:btnSave];
    
    if (isSelect) 
    {
        
        [txtView setUserInteractionEnabled:NO];
        [txtView resignFirstResponder];
        
        int row=0;
        for (NSString *str in arrValues)
        {
            if ([strValue isEqualToString:str])
            {
                break;
            }
            
            row++;
        }
        
//        UIPickerView *picker = [[UIPickerView alloc] initWithFrame:CGRectMake(0, 240, 320, 215)];

        UIPickerView *picker = [[UIPickerView alloc] initWithFrame:CGRectMake(0, [[UIScreen mainScreen] bounds].size.height-243, 320, 215)];
        [picker setDelegate:self];
        [picker setDataSource:self];
        [picker setShowsSelectionIndicator:YES];
        [picker selectRow:row inComponent:0 animated:NO];
        
        
        [self.view addSubview:picker];
    }
    else
    {
        [txtView becomeFirstResponder];
    }
    
}

#pragma mark -
#pragma mark - backTapped Method

-(IBAction)btnBackTapped:(id)sender
{
    
    [self.navigationController popViewControllerAnimated:YES];
}


-(IBAction)btnSave_Tapped:(id)Sender
{
    NSString *strCurrentOption =  [txtView.text stringByReplacingOccurrencesOfString:@"Minutes" withString:@""];
    if([DataSource executeQuery:
     [NSString stringWithFormat:
      @" UPDATE Setting SET %@='%@'",strKey,strCurrentOption]])
    {
        NSLog(@"Sucess");
        
        
        SyncInBackGround *objSync = (SyncInBackGround *)[ElogBooksAppDelegate getSyncInBackGroundObj];
//        [objSync InValidate];
        [objSync setTimerDuration];

        
        [self.navigationController popViewControllerAnimated:YES];
    }
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

// returns the # of rows in each component..
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{   
    return arrValues.count;
}


- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return [arrValues objectAtIndex:row];
}


- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    txtView.text = [arrValues objectAtIndex:row];
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
