//
//  AddEditValueScreen.h
//  ElogBooks
//
//  Created by i-Verve on 28/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddEditValueScreen : UIViewController<
UIPickerViewDataSource,
UIPickerViewDelegate
>
{
    UITextView *txtView;

}

@property(assign,nonatomic)BOOL isAdd;
@property(assign,nonatomic)BOOL isSelect;
@property(retain,nonatomic)NSString *strKey;
@property(retain,nonatomic)NSString *strValue;
@property(retain,nonatomic)NSString *strTableName;
@property(retain,nonatomic)NSMutableArray *arrValues;
@end
