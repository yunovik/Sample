//
//  SettingScreen.m
//  ElogBooks
//
//  Created by i-Verve on 14/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import "SettingScreen.h"
#import "AddEditValueScreen.h"


@interface SettingScreen ()

@end

@implementation SettingScreen

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    
    return self;
}

- (void)viewDidLoad
{
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(receiveTestNotification:) 
                                                 name:@"TestNotification"
                                               object:nil];
    
    [CommonFunctions setTitleView:self amdtitle:@"Settings"];
    
    [CommonFunctions setBack:self target:@selector(btnBackTapped:)];
    
    arrSetting = [DataSource getAllDataFrom:@"Setting"];
//    [self.view setBackgroundColor:getImageColor(@"Default.png")];

    [self.view setBackgroundColor:[UIColor whiteColor]];

    CGRect screenBounds = [[UIScreen mainScreen] bounds];

    tblSetting = [[UITableView alloc] initWithFrame:screenBounds];
    [tblSetting setDelegate:self];
    [tblSetting setDataSource:self];
    [tblSetting setBackgroundColor:[UIColor clearColor]];
    [tblSetting setSeparatorColor:[UIColor clearColor]];
    [tblSetting setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    [self.view addSubview:tblSetting];
    
    arrSetting = [DataSource getAllDataFrom:@"Setting"];
    
    NSLog(@"%@",[arrSetting description]);
    [tblSetting reloadData];

    [super viewDidLoad];

}
#pragma mark -
#pragma mark - backTapped Method

-(IBAction)btnBackTapped:(id)sender
{
    
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)viewWillAppear:(BOOL)animated
{

    
    [self loadSettingTable];
}

#pragma mark Load Array Settings 
-(void)loadSettingTable
{
    arrSetting = [DataSource getAllDataFrom:@"Setting"];
    
    //Add row value for previous successful sync timing 
    NSMutableDictionary *dic= [[NSMutableDictionary alloc]init];
    NSString *str_SettingTimeStamp = [DataSource getStringFromQuery:@"select settings_Timestamp from Upload_Info"];
    if ([str_SettingTimeStamp isEqualToString:@"NO_DATA"])
        str_SettingTimeStamp = @"Not Available";
    [dic setObject:str_SettingTimeStamp forKey:@"settings_Timestamp"];
    [arrSetting addObject:dic];
    
    if ([arrSetting count]>0)
    {
        if ([[[arrSetting objectAtIndex:0]valueForKey:@"Time"]isEqualToString:@"Manual"])
        {
            [arrSetting addObject:@"Sync Now"];
        }
    }
    NSLog(@"%@",[arrSetting description]);
    [tblSetting reloadData];    
}

#pragma mark -
#pragma mark Table view methods

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrSetting count];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 43;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *CellIdentifier = [NSString stringWithFormat:@"Cel_%d",indexPath.row];
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    cell = nil;
    
    if (cell == nil) 
    {
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] ;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        
        if (indexPath.row == 0)
        {
        [cell.contentView setBackgroundColor:getImageColor(@"Home_Cell.png")];
        UILabel *labelTitle = [[UILabel alloc]initWithFrame:CGRectMake(25, 0, 150, 43)];
        labelTitle.backgroundColor = [UIColor clearColor];
                        labelTitle.text = [NSString stringWithFormat:@"Sync. Time Duration :"];

        [labelTitle setFont:FONT_NEUE_BOLD_SIZE(14)];
        [labelTitle setTextColor:DEFAULT_FONT_COLOR];
        [cell.contentView addSubview:labelTitle];
        
        UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(170, 0, 120, 43)];
        label.backgroundColor = [UIColor clearColor];
        if ([[[arrSetting objectAtIndex:indexPath.row] objectForKey:@"Time"]isEqualToString:@"Manual"])
        label.text =  [[arrSetting objectAtIndex:indexPath.row] objectForKey:@"Time"];
        else 
        label.text = [NSString stringWithFormat:@"%@ Minutes",[[arrSetting objectAtIndex:indexPath.row] objectForKey:@"Time"]];            
        [label setFont:FONT_NEUE_SIZE(14)];
        [label setTextColor:DEFAULT_FONT_COLOR];
        [cell.contentView addSubview:label];

        UIView *selectedView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 61)];
        [selectedView setBackgroundColor:getImageColor(@"Home_Cell_Sel")];
        [cell setSelectedBackgroundView:selectedView];
            
    [cell setSelectionStyle:UITableViewCellSelectionStyleBlue];
        }
        else  if (indexPath.row == 1)
        {
            [cell setUserInteractionEnabled:NO];
            [cell.contentView setBackgroundColor:getImageColor(@"Home_Cell.png")];
            UILabel *labelTitle = [[UILabel alloc]initWithFrame:CGRectMake(25, 0, 150, 43)];
            labelTitle.backgroundColor = [UIColor clearColor];
                    labelTitle.text = [NSString stringWithFormat:@"Last Synced :"];
            [labelTitle setFont:FONT_NEUE_BOLD_SIZE(14)];
            [labelTitle setTextColor:DEFAULT_FONT_COLOR];
            [cell.contentView addSubview:labelTitle];
            
            UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(120, 0, 160, 43)];
            label.backgroundColor = [UIColor clearColor];
            label.text = [NSString stringWithFormat:@"%@",[[arrSetting objectAtIndex:indexPath.row] objectForKey:@"settings_Timestamp"]];            
            [label setFont:FONT_NEUE_SIZE(14)];
            [label setTextColor:DEFAULT_FONT_COLOR];
            [cell.contentView addSubview:label];
            UIView *selectedView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 61)];
            [selectedView setBackgroundColor:getImageColor(@"Home_Cell_Sel")];
            //[selectedView setBackgroundColor:[UIColor greenColor]];
            [cell setSelectedBackgroundView:selectedView];
            [cell setSelectionStyle:UITableViewCellSelectionStyleBlue];
            
            
        }
        else 
        {
            
//            UIImageView *imgBackView = [[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 320, 43)]autorelease];
//            UIImage *imgBack = [[UIImage imageNamed:@"Cell_Stripe.png"] stretchableImageWithLeftCapWidth:25 topCapHeight:43];
//            [imgBackView setImage:imgBack];
//            [cell.contentView addSubview:imgBackView];
            cell.backgroundColor = [UIColor clearColor];
            UIButton *btnSave = [CommonFunctions buttonWithTitle:[arrSetting objectAtIndex:indexPath.row]  andFrame:CGRectMake(100, 7, 120, 35)];
            [btnSave addTarget:self action:@selector(btnSyncNowTapped:) forControlEvents:UIControlEventTouchUpInside];
            [btnSave setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
            [[btnSave layer] setBorderColor:[[UIColor colorWithPatternImage:[UIImage imageNamed:@"Assets_Stripe_Sel.png"]] CGColor]];
            [[btnSave layer] setBorderWidth:2.0f];
            [[btnSave layer] setCornerRadius:5.0f];
            [cell.contentView addSubview:btnSave];
            
        }
       
        
    }
    
   
    
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (indexPath.row == 0) {
        
        NSMutableArray *arrObjects = [[[NSMutableArray alloc] init]autorelease];
        for (int i=5; i<=60; i=i+5) {
            [arrObjects addObject:[NSString stringWithFormat:@"%d Minutes",i]];
        }
        [arrObjects addObject:@"Manual"];
        AddEditValueScreen *objNav = [[AddEditValueScreen alloc] initWithNibName:@"AddEditValueScreen" bundle:nil];
        objNav.isSelect=YES;
        objNav.arrValues=arrObjects;
        objNav.strKey=@"Time";
        NSString *strCurrentOption = [[arrSetting objectAtIndex:indexPath.row]objectForKey:@"Time"];
        if ([strCurrentOption isEqualToString:@"Manual"])
            objNav.strValue = strCurrentOption;
        else 
        objNav.strValue=[NSString stringWithFormat:@"%@ Minutes",strCurrentOption];
        [self.navigationController pushViewController:objNav animated:YES];
        [objNav release];
        
    }

}

#pragma mark Receive Notification
- (void) receiveTestNotification:(NSNotification *) notification
{
    // [notification name] should always be @"TestNotification"
    // unless you use this method for observation of other notifications
    // as well.
    
    if ([[notification name] isEqualToString:@"TestNotification"])
    {
        [self loadSettingTable];
    }
}

#pragma mark SyncStarted 
-(void)SyncStarted 
{
    progressBar = [[UIProgressView alloc]initWithProgressViewStyle:UIProgressViewStyleDefault];
    [progressBar setProgress: 0.0];
    [progressBar setBackgroundColor:[UIColor clearColor]];
    progressBar.progressTintColor = [UIColor greenColor];
    
    progressBar.frame = CGRectMake(10, 360 , 300, 20);
    [self.view addSubview:progressBar];
    
    lblProgressStatus = [[UILabel alloc]initWithFrame:CGRectMake(10, 320, 300, 40)];
    [lblProgressStatus setBackgroundColor:[UIColor clearColor]];
    [lblProgressStatus setTextAlignment: UITextAlignmentCenter];
    [self.view addSubview:lblProgressStatus];
    
    //if normal
    NSString *strNewJobsCount = nil;
    strNewJobsCount = [DataSource getStringFromQuery:@"select COUNT(*) from NewJobs"];
    if ([strNewJobsCount intValue]>0)
    {
        [self UpdateNewJobs];
    }
    else 
    {
        [self Start_Update];
    }

}

-(void)UpdateNewJobs
{
       
    NSMutableArray *arrPutInfo = [CommonFunctions getArraynewReactiveJobs];
    UploadDatabase *objPutInfo = [[UploadDatabase alloc] init];
    objPutInfo.arrWebServiceObjects = arrPutInfo;
    objPutInfo._delegate=self;
    [objPutInfo Uploading:@"START"];
}
-(void)checkSyncCompleted
{
      if ((![[ElogBooksAppDelegate getValueForKey:IsSync_ON]isEqualToString:@"YES"]))
      {
          //stop timer
          [_timer invalidate];
          _timer = nil;
        [self SyncStarted];
      }
}

-(void)btnSyncNowTapped:(id)sender
{
    
    if ([CommonFunctions isNetAvailable])
    {
        //Allocate Co-ordinates
      [CommonFunctions performSelectorOnMainThread:@selector(AllocCooridnates) withObject:nil waitUntilDone:NO];   
        
     // disable navigation controller  
    [self.navigationController.navigationBar setUserInteractionEnabled:NO];
    alertView = [CommonFunctions AlertWithMessage:@"Please Wait..."];
    [self.view addSubview:alertView];    
        
        //Check whether already started
        if (!([[ElogBooksAppDelegate getValueForKey:IsSync_ON]isEqualToString:@"YES"]))
        {
            [self SyncStarted];
        }
        else 
        {
             _timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(checkSyncCompleted) userInfo:nil repeats:YES];
        }

        
    }
    else 
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:APP_TITLE message:@"No Internet Connection Available!" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        [alert show];
        [alert release]; 
    }
    
}

#pragma mark Sync Delegates
#pragma -
#pragma -UploadDataBaseDelegate

-(void)UploadComplete:(NSMutableDictionary *)_responceDic;
{
    
    if ([_responceDic objectForKey:CREATE_JOB]!=nil) //is uploaded job creation status
    {
        [self Start_Update];
    }
    else //normal uploading
    {
    NSLog(@"Upload Response \n %@",[_responceDic description]);
    
     [progressBar setProgress:0.0]; 
    
    RefreshDatabase *refreshObj = [[RefreshDatabase alloc]init];
 refreshObj.IsExecutingBackground = @"YES";
    refreshObj._delegate =self;
    
    [refreshObj refreshDataBase:@"START"];
    }
    
    
}

-(void)setProgress:(float)val forFlag:(NSString *)strFlag
{
    NSLog(@" \n Current Progress: %f",val);
    lblProgressStatus.text = strFlag;
    [progressBar setProgress:val/100];
}



-(void)Start_Update
{
    NSMutableArray *arrPutInfo = [CommonFunctions getArrayForPutInfo];
    UploadDatabase *objPutInfo = [[UploadDatabase alloc] init];
    objPutInfo.arrWebServiceObjects = arrPutInfo;
    objPutInfo._delegate=self;
    [objPutInfo Uploading:@"START"];
}

#pragma mark DataInserted
-(void)DataInserted
{
    NSLog(@"values successfully inserted");
    //Set Settings label text content "settings_Timestamp"
    [DataSource executeQuery:[NSString stringWithFormat:@"Update Upload_Info set settings_Timestamp = '%@' where rowid =1",[CommonFunctions getCurrentTimeStampForDatabaseInsertion]]];
       [self SyncCompleted];
}

#pragma mark TaskAborted
-(void)TaskAborted
{
    NSLog(@"values not inserted--failed");
    [self SyncCompleted];    
}

-(void)SyncCompleted
{
    
    [self  loadSettingTable];
    
    // disable navigation controller  
    [self.navigationController.navigationBar setUserInteractionEnabled:YES];
    [lblProgressStatus removeFromSuperview];
    [progressBar removeFromSuperview];
    [alertView removeFromSuperview];
}

- (void)viewDidUnload
{
     [[NSNotificationCenter defaultCenter] removeObserver:self];
    [super viewDidUnload];
    progressBar = nil;
    _timer = nil;
    alertView = nil;
    arrSetting = nil;
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
