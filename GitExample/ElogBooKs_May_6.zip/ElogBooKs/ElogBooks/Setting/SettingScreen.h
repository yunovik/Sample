//
//  SettingScreen.h
//  ElogBooks
//
//  Created by i-Verve on 14/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UploadDatabase.h"
#import "RefreshDatabase.h"
@interface SettingScreen : UIViewController
<UITableViewDataSource,
UITableViewDelegate,
UploadDataBaseDelegate,
RefreshDatabaseDelegate>
{

    NSMutableArray *arrSetting;
    UITableView *tblSetting;
    UIView *alertView;
    UIProgressView *progressBar;
    UILabel *lblProgressStatus;

    NSTimer *_timer;
}
-(void)btnSyncNowTapped:(id)sender;
@end
