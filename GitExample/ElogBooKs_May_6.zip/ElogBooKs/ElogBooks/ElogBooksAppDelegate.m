//
//  ElogBooksAppDelegate.m
//  ElogBooks
//
//  Created by nayan mistry on 07/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import "ElogBooksAppDelegate.h"
#import "SplashScreenViewController.h"


#import "SearchingScreen.h"
#import "HomeScreen.h"
#import "JobListScreen.h"
#import "AssetsListScreen.h"
#import "PatrolsScreen.h"
#import "SettingScreen.h"
#import "SyncInBackGround.h"

#define VIEW_ITEM_TAG 1000

typedef enum {
    OPEN,
    CLOSE,
} SHUTTER;


BOOL isRefresh;


@implementation ElogBooksAppDelegate

SyncInBackGround *objSync;


@synthesize window = _window;
@synthesize viewController = _viewController;

NSMutableDictionary *dicGlobalValues;


+(BOOL)isRefresh
{
    return isRefresh;
}

+(void)setRefresh:(BOOL)isVal
{
    isRefresh=isVal;
}

- (void)dealloc
{
    [_window release];
    [_viewController release];
    [super dealloc];
}

bool isShow;

//Get and Set global Dictionary
+(void)SetGlobalObject: (id)strValueToStore :(NSString*)strKeyForValueToStore 
{
    if (strValueToStore==nil)
    {
        [dicGlobalValues removeObjectForKey:strKeyForValueToStore];
    }
    else 
    [dicGlobalValues setObject:strValueToStore forKey:strKeyForValueToStore];
}

+(id)getValueForKey:(NSString*)strKeyValueToFetch 
{
    return [dicGlobalValues valueForKey:strKeyValueToFetch];
}


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{


    
    self.window = [[[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]] autorelease];
    // Override point for customization after application launch.
    self.viewController = [[SplashScreenViewController alloc] initWithNibName:@"SplashScreenViewController" bundle:nil];
    

    
    
    objNavigation = [[[UINavigationController alloc] initWithRootViewController:self.viewController]autorelease];
    UIImage *image = getImage(@"Nav_Bar_Stripe.png");
    image = [image stretchableImageWithLeftCapWidth:1.0f topCapHeight:0];
    [objNavigation.navigationBar setBackgroundImage:image forBarMetrics:UIBarMetricsDefault];    
    
    [self setTitleGridView];
    
    //Initialize Global Dictionary
    dicGlobalValues = [[NSMutableDictionary alloc]init];
    
    [[UINavigationBar appearance] setTintColor:[UIColor blackColor]];
    
    
    //check Database Availability
    if ([[NSUserDefaults standardUserDefaults] boolForKey:@"HasLaunchedOnce"])
    {
        // app already launched
        NSLog(@"Already launched");
    }
    else
    {
        // This is the first launch ever
        if([DataSource DeletePreviousCopyIfExists:@"elogbookDatabase.sqlite"])
            NSLog(@"Previous copy deleted");   
        else 
            NSLog(@"Previous copy doesn't exists");    
        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"HasLaunchedOnce"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
    }
    //set Database
    [DataSource getDBPath:@"elogbookDatabase.sqlite"];
    
    //Upload Co-ordinates

    [CommonFunctions AllocCooridnates];

    
    

    
    
    objSync = [[SyncInBackGround alloc] init];
    
    

    return YES;
}



#pragma mark CClocation Manager delegates
- (void)locationManager:(CLLocationManager *)manager
    didUpdateToLocation:(CLLocation *)newLocation
           fromLocation:(CLLocation *)oldLocation
{
    
    
    // Configure the new event with information from the location
    CLLocationCoordinate2D coordinate = [newLocation coordinate];
    
    //  NSString *lat = [NSString stringWithFormat:@"%  coordinate.latitude
    NSString *lat =  [NSString stringWithFormat:@"%f",coordinate.latitude];
    NSString *lon =  [NSString stringWithFormat:@"%f",coordinate.longitude];
    NSLog(@"lat = %@: Lon = %@",lat,lon);
    [manager stopUpdatingLocation];
    //    int degrees = newLocation.coordinate.latitude;
    //    double decimal = fabs(newLocation.coordinate.latitude - degrees);
    //    int minutes = decimal * 60;
    //    double seconds = decimal * 3600 - minutes * 60;
    //    NSString *lat = [NSString stringWithFormat:@"%d° %d' %1.4f\"", 
    //                     degrees, minutes, seconds];
    //    NSLog(@"%@",lat);
    //    //  latLabel.text = lat;
    //    degrees = newLocation.coordinate.longitude;
    //    decimal = fabs(newLocation.coordinate.longitude - degrees);
    //    minutes = decimal * 60;
    //    seconds = decimal * 3600 - minutes * 60;
    //    NSString *longt = [NSString stringWithFormat:@"%d° %d' %1.4f\"", 
    //                       degrees, minutes, seconds];
    //    NSLog(@"%@",longt);
}

- (void)locationManager:(CLLocationManager *)manager
       didFailWithError:(NSError *)error
{
    NSLog(@"ERORO OCCURED");
}
- (void)locationManager:(CLLocationManager *)manager didChangeAuthorizationStatus:(CLAuthorizationStatus)status 
{
    NSLog(@"ERORO OCCURED");
}
////////////////////////////////////////////////////////////////////////////////////////////////




+(id)getSyncInBackGroundObj
{
    return objSync;
}


-(void)setTitleGridView
{
    btnGrid = [[UIButton alloc] initWithFrame:CGRectMake(262, -1, 58, 44)];
    
    [btnGrid addTarget:self action:@selector(btnGridTapped:) forControlEvents:UIControlEventTouchUpInside];
    [btnGrid setImage:[UIImage imageNamed:@"Grid.png"] forState:UIControlStateNormal];
    [objNavigation.navigationBar addSubview:btnGrid];
    isShow=TRUE;
    
    self.window.rootViewController = objNavigation;
    [self.window makeKeyAndVisible];
    
    NSMutableArray  *arrGrid = [[NSMutableArray alloc] init];
    NSMutableDictionary *dicItem;
    
    // Item 1.
    
    for(int i=0;i<=0;i++)
    {
        
        dicItem  = [[NSMutableDictionary alloc] init];
        [dicItem setObject:@"Setting" forKey:@"Title"];
        [dicItem setObject:getImage(@"Settings.png") forKey:@"Image"];
        [arrGrid addObject:dicItem];
        
        dicItem  = [[NSMutableDictionary alloc] init];
        [dicItem setObject:@"Search" forKey:@"Title"];
        [dicItem setObject:getImage(@"Search.png") forKey:@"Image"];
        [arrGrid addObject:dicItem];
        
        dicItem  = [[NSMutableDictionary alloc] init];
        [dicItem setObject:@"Home" forKey:@"Title"];
        [dicItem setObject:getImage(@"Home.png") forKey:@"Image"];
        [arrGrid addObject:dicItem];
        
        dicItem  = [[NSMutableDictionary alloc] init];
        [dicItem setObject:@"Jobs" forKey:@"Title"];
        [dicItem setObject:getImage(@"Jobs.png") forKey:@"Image"];
        [arrGrid addObject:dicItem];
        
        dicItem  = [[NSMutableDictionary alloc] init];
        [dicItem setObject:@"Assets" forKey:@"Title"];
        [dicItem setObject:getImage(@"Assets.png") forKey:@"Image"];
        [arrGrid addObject:dicItem];
        
        dicItem  = [[NSMutableDictionary alloc] init];
        [dicItem setObject:@"Patrols" forKey:@"Title"];
        [dicItem setObject:getImage(@"Patrols.png") forKey:@"Image"];
        [arrGrid addObject:dicItem];
        
    }
    
    
    gridView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 320,0)];
    [gridView setBackgroundColor:[UIColor purpleColor]];
    
    btnTransparent = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
    [btnTransparent addTarget:self action:@selector(btnHideGridTapped:) forControlEvents:UIControlEventTouchUpInside];
    
    //[transView setBackgroundColor:[UIColor clearColor]];
    
    scrGridView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, 320, 190)];
    scrGridView.backgroundColor = [UIColor  blackColor];
    scrGridView.alpha = 0.8;
    scrGridView.pagingEnabled = YES;
    scrGridView.scrollEnabled = YES;
    scrGridView.delegate = self;
    scrGridView.hidden=NO;
    scrGridView.showsHorizontalScrollIndicator = NO;
    
    [gridView addSubview:scrGridView];
    
    
    
    int totalPage = 1;
    
    if (arrGrid.count%6 == 0) {
        totalPage = arrGrid.count/6;
    }
    else
    {
        totalPage =(arrGrid.count/6) + 1 ;
    }
    
    [scrGridView setContentSize:CGSizeMake(totalPage * 320, 0)];
    
    int index = 0;
    
    for(int p=0;p<totalPage;p++)
    {
        
        int xx = (p * 320)+1;
        int yy = 0;
        
        int totalItem = 0;
        
        
        if(p == totalPage -1)
        {
            totalItem = [arrGrid count]%6;
            if(totalItem == 0) totalItem=6;
        }else {
            totalItem = 6;
        }
        
        for(int i=0;i<totalItem;i++)
        {
            
            NSMutableDictionary *dicItem  = [arrGrid objectAtIndex:index];
            
            UIView *viewItem = [[UIView alloc] initWithFrame:CGRectMake(xx, yy, 106, 95)];
            
            [viewItem setTag:VIEW_ITEM_TAG + i];
            
//            CGFloat hue = ( arc4random() % 256 / 256.0 ); // 0.0 to 1.0
//            CGFloat saturation = ( arc4random() % 128 / 256.0 ) + 0.5; // 0.5 to 1.0, away from white
//            CGFloat brightness = ( arc4random() % 128 / 256.0 ) + 0.5; // 0.5 to 1.0, away from black
//            UIColor *color = [UIColor colorWithHue:hue saturation:saturation brightness:brightness alpha:1];
            
            
            UIColor *color = [UIColor clearColor];
            [viewItem setBackgroundColor:color];
            
            UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(0, 10, 106, 60)];
            [btn setImage:[dicItem objectForKey:@"Image"] forState:UIControlStateNormal];
            [btn setTag:index];
            [btn addTarget:self action:@selector(btnMenuTapped:) forControlEvents:UIControlEventTouchUpInside];
            [viewItem addSubview:btn];
            
            UILabel *lblTitle = [[UILabel alloc]initWithFrame:CGRectMake(0, 71, 106, 20)];
            lblTitle.backgroundColor = [UIColor clearColor];
            [lblTitle setTextAlignment:UITextAlignmentCenter];
            lblTitle.textColor = [UIColor grayColor];
            lblTitle.text = [dicItem objectForKey:@"Title"];
            lblTitle.numberOfLines = 2;
            lblTitle.lineBreakMode = UILineBreakModeWordWrap;
            lblTitle.font = [UIFont fontWithName:@"Arial-BoldMT" size:16];
            [viewItem addSubview:lblTitle];
            
            [scrGridView addSubview:viewItem];
            
            if(i==2)
            {
                xx = (p * 320)+1;
                yy = yy + 95;
            }else {
                xx = xx + 106;
            }
            
            index++;
        }
    }
    
    UIImageView *pageBackView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 190, 320, 20)];
    UIImage *imgP = getImage(@"Paging_Strip");
    [pageBackView setImage:[imgP stretchableImageWithLeftCapWidth:1.0f topCapHeight:0]];
    
    [gridView addSubview:pageBackView];
    
    pageControl = [[UIPageControl alloc] init];
    pageControl.frame = CGRectMake(0,190,320,20);
    pageControl.currentPage = 0;
    pageControl.backgroundColor = [UIColor clearColor];
    pageControl.numberOfPages = totalPage;
    pageControl.hidden =NO;
    
    [gridView addSubview:pageControl];
    [gridView addSubview:scrGridView];
    [gridView setClipsToBounds:YES];
    
}

-(void)btnGridTapped:(id)Sender
{
    
    UIViewController *viewController = [[objNavigation viewControllers] objectAtIndex:[[objNavigation viewControllers] count]-1];
    [Sender setUserInteractionEnabled:NO];
    
    if(isShow)
    {

        for(int i=0;i<6;i++)
        {
            UIView *viewItem = (UIView *)[gridView viewWithTag:VIEW_ITEM_TAG + i];
            [viewItem setUserInteractionEnabled:YES];
            [viewItem setAlpha:1.0f];
        }

        
        if ([viewController isKindOfClass:[SettingScreen class]])
        {
            UIView *viewItem = (UIView *)[gridView viewWithTag:VIEW_ITEM_TAG + 0];
            [viewItem setUserInteractionEnabled:NO];
            [viewItem setAlpha:0.5];
        }
        else if ([viewController isKindOfClass:[SearchingScreen class]])
        {
            UIView *viewItem = (UIView *)[gridView viewWithTag:VIEW_ITEM_TAG + 1];
            [viewItem setUserInteractionEnabled:NO];
            [viewItem setAlpha:0.5];
        }
        else if ([viewController isKindOfClass:[HomeScreen class]])
        {
            UIView *viewItem = (UIView *)[gridView viewWithTag:VIEW_ITEM_TAG + 2];
            [viewItem setUserInteractionEnabled:NO];
            [viewItem setAlpha:0.5];
        }
        else if ([viewController isKindOfClass:[JobListScreen class]])
        {
            UIView *viewItem = (UIView *)[gridView viewWithTag:VIEW_ITEM_TAG + 3];
            [viewItem setUserInteractionEnabled:NO];
            [viewItem setAlpha:0.5];
        }
        else if ([viewController isKindOfClass:[AssetsListScreen class]])
        {
            UIView *viewItem = (UIView *)[gridView viewWithTag:VIEW_ITEM_TAG + 4];
            [viewItem setUserInteractionEnabled:NO];
            [viewItem setAlpha:0.5];
        }
        else if ([viewController isKindOfClass:[PatrolsScreen class]])
        {
            UIView *viewItem = (UIView *)[gridView viewWithTag:VIEW_ITEM_TAG + 5];
            [viewItem setUserInteractionEnabled:NO];
            [viewItem setAlpha:0.5];
        }
        else if ([viewController isKindOfClass:[SettingScreen class]])
        {
            UIView *viewItem = (UIView *)[gridView viewWithTag:VIEW_ITEM_TAG + 1];
            [viewItem setUserInteractionEnabled:NO];
            [viewItem setAlpha:0.5];
        }

        [viewController.view addSubview:btnTransparent];
        [viewController.view addSubview:gridView];
        
        [gridView setFrame:CGRectMake(0, 0, 320, 0)];
        [btnGrid setImage:[UIImage imageNamed:@"Grid_Sel.png"] forState:UIControlStateNormal];
        
        UIButton *btnBack = (UIButton *)[objNavigation.navigationBar viewWithTag:143];
        if([btnBack isKindOfClass:[UIButton class]])
        {
            [btnBack setEnabled:NO];
        }
        
        [viewController.view setUserInteractionEnabled:NO];
        
        [UIView animateWithDuration:0.7f
                         animations:^
         {
             [gridView setFrame:CGRectMake(0, 0, 320, 210)];
         }
                         completion:^(BOOL finished)
         {
             [btnGrid setUserInteractionEnabled:YES];
             [btnTransparent setUserInteractionEnabled:YES];
             [viewController.view setUserInteractionEnabled:YES];

         }];
        
    }
    else
    {
        [btnGrid setImage:[UIImage imageNamed:@"Grid.png"] forState:UIControlStateNormal];
        
        [UIView animateWithDuration:0.7f
                         animations:^
         {
             [gridView setFrame:CGRectMake(0, 0, 320, 0)];
             
             
         }
                         completion:^(BOOL finished)
         {
             
             UIButton *btnBack = (UIButton *)[objNavigation.navigationBar viewWithTag:143];
             if([btnBack isKindOfClass:[UIButton class]])
             {
                 [btnBack setEnabled:YES];
             }

             [btnGrid setUserInteractionEnabled:YES];
             [gridView removeFromSuperview];
             [btnTransparent removeFromSuperview];
         }];
        
    }
    
    isShow=!isShow;
    
}


-(IBAction)btnHideGridTapped:(id)Sender
{
    
    isShow=YES;
    
    [btnTransparent setUserInteractionEnabled:NO];
    
    [UIView animateWithDuration:0.7f
                     animations:^
     {
         [gridView setFrame:CGRectMake(0, 0, 320, 0)];
         
         
     }
                     completion:^(BOOL finished)
     {
         
         UIButton *btnBack = (UIButton *)[objNavigation.navigationBar viewWithTag:143];
         if([btnBack isKindOfClass:[UIButton class]])
         {
             [btnBack setEnabled:YES];
         }

         [btnGrid setImage:[UIImage imageNamed:@"Grid.png"] forState:UIControlStateNormal];
         [btnGrid setUserInteractionEnabled:YES];
         [gridView removeFromSuperview];
         [btnTransparent removeFromSuperview];
     }];
    
}



-(void)btnMenuTapped:(id)Sender
{


    isShow=YES;
    
    [UIView animateWithDuration:0.7f
                     animations:^
     {
         [gridView setFrame:CGRectMake(0, 0, 320, 0)];
         
         
     }
                     completion:^(BOOL finished)
     {
         
         UIButton *btnBack = (UIButton *)[objNavigation.navigationBar viewWithTag:143];
         if([btnBack isKindOfClass:[UIButton class]])
         {
             [btnBack setEnabled:YES];
         }

         NSLog(@"%d",[Sender tag]);
         int tag = [Sender tag];
         
         if(tag == 0) // Setting
         {
             NSArray *arrViewcontrollers = [objNavigation viewControllers];
             
             BOOL isPop=NO;
             
             for (int i=0;i<[arrViewcontrollers count]; i++) 
             {
                 if ([[arrViewcontrollers objectAtIndex:i]isKindOfClass:[SettingScreen class]])
                 {
                     [objNavigation popToViewController:[arrViewcontrollers objectAtIndex:i] animated:YES];
                     isPop=YES;
                     break;
                 }
                 
             }
             if(!isPop)
             {
                 SettingScreen *objNav = [[SettingScreen alloc] initWithNibName:@"SettingScreen" bundle:nil];
                 [objNavigation pushViewController:objNav animated:YES];
                 [objNav release];
             }
         }
         else if(tag == 1) // Search
         {
             NSArray *arrViewcontrollers = [objNavigation viewControllers];
             
             BOOL isPop=NO;
             
             for (int i=0;i<[arrViewcontrollers count]; i++) 
             {
                 if ([[arrViewcontrollers objectAtIndex:i]isKindOfClass:[SearchingScreen class]])
                 {
                     [objNavigation popToViewController:[arrViewcontrollers objectAtIndex:i] animated:YES];
                     isPop=YES;
                     break;
                 }
                 
             }
             
             if(!isPop)
             {
                 SearchingScreen *objNav = [[SearchingScreen alloc] initWithNibName:@"SearchingScreen" bundle:nil];
                 [objNavigation pushViewController:objNav animated:YES];
                 [objNav release];
             }
             
         }
         else if(tag == 2) // Home
         {
             NSArray *arrViewcontrollers = [objNavigation viewControllers];
             
             BOOL isPop=NO;
             
             for (int i=0;i<[arrViewcontrollers count]; i++) 
             {
                 if ([[arrViewcontrollers objectAtIndex:i]isKindOfClass:[HomeScreen class]])
                 {
                     [objNavigation popToViewController:[arrViewcontrollers objectAtIndex:i] animated:YES];
                     isPop=YES;
                     break;
                 }
                 
             }
             
             if(!isPop)
             {
                 HomeScreen *objNav = [[HomeScreen alloc] initWithNibName:@"HomeScreen" bundle:nil];
                 [objNavigation pushViewController:objNav animated:YES];
                 [objNav release];
             }
             
         }
         else if(tag == 3) // Jobs
         {
             NSArray *arrViewcontrollers = [objNavigation viewControllers];
             
             BOOL isPop=NO;
             
             for (int i=0;i<[arrViewcontrollers count]; i++) 
             {
                 if ([[arrViewcontrollers objectAtIndex:i]isKindOfClass:[JobListScreen class]])
                 {
                     [objNavigation popToViewController:[arrViewcontrollers objectAtIndex:i] animated:YES];
                     isPop=YES;
                     break;
                 }
                 
             }
             
             if(!isPop)
             {
                 JobListScreen *objNav = [[JobListScreen alloc] initWithNibName:@"JobListScreen" bundle:nil];
                 [objNavigation pushViewController:objNav animated:YES];
                 [objNav release];
             }
             
             
         }
         else if(tag == 4) // Assets
         {
             NSArray *arrViewcontrollers = [objNavigation viewControllers];
             
             BOOL isPop=NO;
             
             for (int i=0;i<[arrViewcontrollers count]; i++) 
             {
                 if ([[arrViewcontrollers objectAtIndex:i]isKindOfClass:[AssetsListScreen class]])
                 {
                     [objNavigation popToViewController:[arrViewcontrollers objectAtIndex:i] animated:YES];
                     isPop=YES;
                     break;
                 }
                 
             }
             
             if(!isPop)
             {
                 AssetsListScreen *objNav = [[AssetsListScreen alloc] initWithNibName:@"AssetsListScreen" bundle:nil];
                 [objNavigation pushViewController:objNav animated:YES];
                 [objNav release];
             }
             
         }
         else if(tag == 5) // 	Patrols
         {
             NSArray *arrViewcontrollers = [objNavigation viewControllers];
             
             BOOL isPop=NO;
             
             for (int i=0;i<[arrViewcontrollers count]; i++) 
             {
                 if ([[arrViewcontrollers objectAtIndex:i]isKindOfClass:[PatrolsScreen class]])
                 {
                     [objNavigation popToViewController:[arrViewcontrollers objectAtIndex:i] animated:YES];
                     isPop=YES;
                     break;
                 }
                 
             }
             
             if(!isPop)
             {
                 PatrolsScreen *objNav = [[PatrolsScreen alloc] initWithNibName:@"PatrolsScreen" bundle:nil];
                 [objNavigation pushViewController:objNav animated:YES];
                 [objNav release];
             }
             
         }
         else if(tag == 6) // Unknown..
         {

         }
         
         [btnGrid setImage:[UIImage imageNamed:@"Grid.png"] forState:UIControlStateNormal];
         [btnGrid setUserInteractionEnabled:YES];
         [gridView removeFromSuperview];
         [btnTransparent removeFromSuperview];

     }];
    
}


- (void)scrollViewDidScroll:(UIScrollView *)sender 
{
    
    
    CGFloat pageWidth = sender.frame.size.width;
    int page = floor((sender.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
    
    pageControl.currentPage = page;
    
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    
   
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
     [CommonFunctions AllocCooridnates];
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
