//
//  CommonFunctions.h
//  TestTagFast
//
//  Created by Mac-1 on 7/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <QuartzCore/QuartzCore.h>
#import <CoreLocation/CoreLocation.h>

@interface CommonFunctions : NSObject <CLLocationManagerDelegate>
{

}

+(UIView*)AlertWithMessage:(NSString *)msg;


+(NSMutableArray *)getArrayJobs:(NSMutableArray *)arrPutInfo;
+(NSMutableArray *)getArraySubAssets:(NSMutableArray *)arrPutInfo;
+(NSMutableArray *)getArraySchedulePoints:(NSMutableArray *)arrPutInfo;
+(NSMutableArray *)getArrayImage:(NSMutableArray *)arrPutInfo;


+(BOOL)AllocCooridnates;
+(BOOL)iSReadyForCompletion:(NSString *)StrScheduleId;
+(BOOL)isLastPointWithoutCompleted:(NSString *)StrScheduleId;
+(NSMutableArray *)getArraynewReactiveJobs;
+(void)changeJobIdToOriginal:(NSString *)OldValue :(NSString*)OriginalValue;
//+(CLLocationCoordinate2D)GetCoordinates :(id)_self;
+(CLLocationCoordinate2D)GetCoordinates ;
//+(CGFloat)GetStringSize :(NSString *)string;
+(NSString *)getCurrentTimeStamp:(NSString *)strDate;
+(NSString *)getCurrentTimeStampForDatabaseInsertion;
+(NSString *)getCurrentTimeStampForDatabaseInsertion:(NSString *)strDate;
+(BOOL)isNetAvailable;
+(UIImage *)AlertButton:(NSString*)txt andFrame:(CGRect)frame image:(NSString *)imageName;

+(NSString *)getCurrentTimeStamp;
+(NSString *)getUniqueName;

+(NSMutableDictionary *)getDicAsParameter:(NSMutableDictionary *)dicWithExistingKeys;

+(void)setTitleView:(UIViewController *)_self amdtitle:(NSString *)_title;
+(NSString *)getBaseUrl;
+(NSMutableArray *)getWebservicesArray;
+(UIButton *)buttonWithTitle:(NSString*)txt andFrame:(CGRect)frame;
+(UIButton *)buttonWithTitle:(NSString*)txt andFrame:(float)x :(float)y :(float)w :(float)h;
//Set Text Field Margin Indentation
+(BOOL)SetLeftViewMode:(UITextField *)TextFieldName:(CGFloat)LeftInsetValue;
+(BOOL)SetRightViewMode:(UITextField *)TextFieldName:(CGFloat)RightInsetValue;
+(NSString *)ConvertDateToOriginalName:(NSString *)strReceivedDate:(NSString *)strJid;
+(void)setBack:(UIViewController *)_self target:(SEL)_sel;

+(UIView *)getLableWithTitle:(NSString *)strTitle andDesc:(NSString *)strDesc WithFrame:(CGRect)_frame;

+(CGSize )getSize:(NSString *)text Font:(UIFont *)_fnt constrainedToSize:(CGSize)_cSize LineBreakMode:(UILineBreakMode)_lbMode min:(int)_min;
// WebService Objects...

+(NSString *)getTimeFromDate:(NSDate *)DateTime;
+(NSString *)getDate:(NSString *)strDateTime;
+(NSString *)getTime:(NSString *)strDateTime;

+(NSString *)getWebServicePath;

+(NSString *)getCurrentTime;

+(NSString *)getTitleDate:(NSString *)strEDate;

+(NSString *)getCurrentPayPeriodFrom:(NSMutableArray *)arr withDate:(NSString *)strCDate;

+(BOOL)is:(NSDate *)cDate inBetween:(NSDate *)sDate and:(NSDate *)eDate;

+(NSDate *)dateFromString:(NSString *)strDate;

+(UIColor *)getBackgroundColor;
+(UIColor *)getColorForImage:(NSString*)string;

+(UIImage *)strachableImage:(NSString *)imgName;

+(NSMutableArray *)getArrayForPutInfo;
+(UIImageView *)ImageOfView:(UIView *)viewImage;

+(UILabel*)LabelWithText:(NSString*)txt andFrame:(float)x :(float)y :(float)w :(float)h;
//+(UIImage *)ButtonImageWithTitle:(NSString*)txt andFrame:(CGRect)frame textAlignment:(NSString *)alnmnt;
+(UIImage *)ButtonImageWithTitle:(NSString*)txt andFrame:(CGRect)frame textAlignment:(NSString *)alnmnt image:(NSString *)imageName andIsBorder:(BOOL)isBorber andFontSize:(int)fSize;

//+(UIImage *)ButtonImageWithTitle:(NSString*)txt andFrame:(CGRect)frame textAlignment:(NSString *)alnmnt image:(NSString *)imageName andIsBorder:(BOOL)isBorber;

+(BOOL)checkTextField:(UITextField *)textField;
+(NSString*)getMMDDYY:(NSString*)strDate;
+(NSString*)getDDMMYY:(NSString*)strDate;
@end
