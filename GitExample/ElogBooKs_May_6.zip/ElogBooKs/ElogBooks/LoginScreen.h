//
//  LoginScreen.h
//  ELogBooks
//
//  Created by nayan mistry on 04/12/12.
//  Copyright (c) 2012 nayanmist@gmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RefreshDatabase.h"
#import "UploadDatabase.h"
#define  TAG_TEXTFIELD 100
@interface LoginScreen : UIViewController <UITextFieldDelegate,MYXMLParserDelegate,PickerViewControlDelegate>
{
    IBOutlet UIScrollView *scrView;
    
    
    CGSize tmpScrView;
    IBOutlet UITextField *txtAccount,*txtDomain,*txtUserName,*txtPwd;
    IBOutlet UIButton *btnLogin;
    UITextField *tmpTextField;

    //Picker Items
    
    UIPickerView *PickerDomain;
    UIActionSheet  *sheet;
    
    //Array 
    NSMutableArray *arrDomains;
    
    //Webservice Delegates
    getWebService *objService;
    RefreshDatabase *refreshObj;
    IBOutlet UIProgressView *progressBar;
    int lastSelected;
}
-(IBAction)btnLoginTapped: (id)sender;
-(IBAction)OpenPicker:(id)sender;
@end
